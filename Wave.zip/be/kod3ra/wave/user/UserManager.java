/*    */ package be.kod3ra.wave.user;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class UserManager {
/* 14 */   private final Map<UUID, User> userMap = new HashMap<>();
/*    */   
/*    */   public User getUser(UUID uuid) {
/* 18 */     return this.userMap.get(uuid);
/*    */   }
/*    */   
/*    */   public void addUser(User user) {
/* 22 */     this.userMap.put(user.getUUID(), user);
/*    */   }
/*    */   
/*    */   public void removeUser(UUID uuid) {
/* 26 */     this.userMap.remove(uuid);
/*    */   }
/*    */   
/*    */   public User getUser(Player player) {
/* 34 */     UUID uuid = player.getUniqueId();
/* 35 */     User user = getUser(uuid);
/* 37 */     if (user == null) {
/* 38 */       user = new User(uuid);
/* 39 */       addUser(user);
/*    */     } 
/* 42 */     return user;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\UserManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */