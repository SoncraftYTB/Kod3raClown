/*    */ package be.kod3ra.wave.user;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.checks.Check;
/*    */ import be.kod3ra.wave.packet.WrappedPacket;
/*    */ import com.github.retrooper.packetevents.event.PacketListenerAbstract;
/*    */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public final class UserPacketListener extends PacketListenerAbstract {
/*    */   public void onPacketReceive(PacketReceiveEvent event) {
/* 14 */     if (event.getUser() == null || event.getUser().getUUID() == null)
/*    */       return; 
/* 17 */     UUID uuid = event.getUser().getUUID();
/* 18 */     User user = Wave.getInstance().getUserData().getUser(uuid);
/* 20 */     if (user == null)
/*    */       return; 
/* 23 */     PacketTypeCommon packetTypeCommon = event.getPacketType();
/* 24 */     int packetId = event.getPacketId();
/* 25 */     long timeStamp = event.getTimestamp();
/* 27 */     WrappedPacket wrappedPacket = new WrappedPacket(event, packetTypeCommon, packetId, timeStamp);
/* 29 */     user.getCheckManager().getClassToInstanceMap().values().forEach(check -> check.onPacket(user, wrappedPacket));
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\UserPacketListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */