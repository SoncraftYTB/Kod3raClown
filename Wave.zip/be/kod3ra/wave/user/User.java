/*    */ package be.kod3ra.wave.user;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.checks.CheckManager;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public final class User {
/*    */   private String name;
/*    */   
/*    */   private final UUID uuid;
/*    */   
/*    */   private final Player player;
/*    */   
/*    */   private int packetCount;
/*    */   
/*    */   private long lastXRayDetectionTime;
/*    */   
/*    */   private CheckManager checkManager;
/*    */   
/*    */   public User(UUID uuid) {
/* 20 */     this.uuid = uuid;
/* 21 */     this.player = getPlayer();
/* 22 */     this.name = this.player.getName();
/* 24 */     this.checkManager = new CheckManager(Wave.getInstance());
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 28 */     return Bukkit.getPlayer(this.uuid);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 32 */     return this.name;
/*    */   }
/*    */   
/*    */   public CheckManager getCheckManager() {
/* 36 */     return this.checkManager;
/*    */   }
/*    */   
/*    */   public UUID getUUID() {
/* 40 */     return this.uuid;
/*    */   }
/*    */   
/*    */   public long getLastXRayDetectionTime() {
/* 44 */     return this.lastXRayDetectionTime;
/*    */   }
/*    */   
/*    */   public void setLastXRayDetectionTime(long time) {
/* 48 */     this.lastXRayDetectionTime = time;
/*    */   }
/*    */   
/*    */   public UserData getUserData() {
/* 52 */     return Wave.getInstance().getUserData();
/*    */   }
/*    */   
/*    */   public int getPacketCount() {
/* 56 */     return this.packetCount;
/*    */   }
/*    */   
/*    */   public void setPacketCount(int packetCount) {
/* 60 */     this.packetCount = packetCount;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\User.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */