/*    */ package be.kod3ra.wave.user;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public final class UserData {
/* 12 */   private final Map<UUID, User> userMap = Maps.newHashMap();
/*    */   
/* 13 */   private final Map<UUID, Long> lastWaterEnterTimes = new HashMap<>();
/*    */   
/* 14 */   private final Map<UUID, Long> joinTimeMap = new HashMap<>();
/*    */   
/* 15 */   private final Map<UUID, Long> lastTeleportTimes = new HashMap<>();
/*    */   
/* 16 */   private final Map<UUID, Long> lastDamageTimeMap = new HashMap<>();
/*    */   
/* 17 */   private final Map<UUID, Long> lastDamageIgnoredTimeMap = new HashMap<>();
/*    */   
/* 18 */   private final Map<UUID, Long> lastAttackTimeMap = new HashMap<>();
/*    */   
/* 19 */   private Map<UUID, Long> lastSneakIgnoreTimes = new HashMap<>();
/*    */   
/*    */   public void createUserData(Player player) {
/* 22 */     if (!this.userMap.containsKey(player.getUniqueId()))
/* 23 */       this.userMap.put(player.getUniqueId(), new User(player.getUniqueId())); 
/*    */   }
/*    */   
/*    */   public void setLastDamageTime(UUID playerId, long time) {
/* 28 */     this.lastDamageTimeMap.put(playerId, Long.valueOf(time));
/*    */   }
/*    */   
/*    */   public long getLastDamageTime(UUID playerId) {
/* 33 */     return ((Long)this.lastDamageTimeMap.getOrDefault(playerId, Long.valueOf(0L))).longValue();
/*    */   }
/*    */   
/*    */   public void setLastDamageIgnoredTime(UUID playerId, long time) {
/* 37 */     this.lastDamageIgnoredTimeMap.put(playerId, Long.valueOf(time));
/*    */   }
/*    */   
/*    */   public long getLastDamageIgnoredTime(UUID playerId) {
/* 42 */     return ((Long)this.lastDamageIgnoredTimeMap.getOrDefault(playerId, Long.valueOf(0L))).longValue();
/*    */   }
/*    */   
/*    */   public void setLastAttackTime(UUID playerId, long time) {
/* 46 */     this.lastAttackTimeMap.put(playerId, Long.valueOf(time));
/*    */   }
/*    */   
/*    */   public long getLastAttackTime(UUID playerId) {
/* 50 */     return ((Long)this.lastAttackTimeMap.getOrDefault(playerId, Long.valueOf(0L))).longValue();
/*    */   }
/*    */   
/*    */   public long getJoinTime(UUID uuid) {
/* 54 */     return ((Long)this.joinTimeMap.getOrDefault(uuid, Long.valueOf(0L))).longValue();
/*    */   }
/*    */   
/*    */   public void setJoinTime(UUID uuid, long joinTime) {
/* 58 */     this.joinTimeMap.put(uuid, Long.valueOf(joinTime));
/*    */   }
/*    */   
/*    */   public void deleteUserData(Player player) {
/* 62 */     this.userMap.remove(player.getUniqueId());
/*    */   }
/*    */   
/*    */   public User getUser(Player player) {
/* 66 */     return this.userMap.get(player.getUniqueId());
/*    */   }
/*    */   
/*    */   public User getUser(UUID uuid) {
/* 70 */     return this.userMap.get(uuid);
/*    */   }
/*    */   
/*    */   public void setLastSneakIgnoreTime(UUID playerId, long time) {
/* 74 */     this.lastSneakIgnoreTimes.put(playerId, Long.valueOf(time));
/*    */   }
/*    */   
/*    */   public long getLastSneakIgnoreTime(UUID playerId) {
/* 78 */     return ((Long)this.lastSneakIgnoreTimes.getOrDefault(playerId, Long.valueOf(0L))).longValue();
/*    */   }
/*    */   
/*    */   public long getLastWaterEnterTime(UUID playerUUID) {
/* 82 */     return ((Long)this.lastWaterEnterTimes.getOrDefault(playerUUID, Long.valueOf(0L))).longValue();
/*    */   }
/*    */   
/*    */   public void setLastWaterEnterTime(UUID playerUUID, long time) {
/* 86 */     this.lastWaterEnterTimes.put(playerUUID, Long.valueOf(time));
/*    */   }
/*    */   
/*    */   public void setLastTeleportTime(UUID playerId, long time) {
/* 90 */     this.lastTeleportTimes.put(playerId, Long.valueOf(time));
/*    */   }
/*    */   
/*    */   public long getLastTeleportTime(UUID playerId) {
/* 94 */     return ((Long)this.lastTeleportTimes.getOrDefault(playerId, Long.valueOf(0L))).longValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\UserData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */