/*    */ package be.kod3ra.wave.user.engine;
/*    */ 
/*    */ import be.kod3ra.wave.packet.WrappedPacket;
/*    */ import com.github.retrooper.packetevents.protocol.world.Location;
/*    */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying;
/*    */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerPositionAndRotation;
/*    */ 
/*    */ public class MovementEngine {
/*    */   private double lastX;
/*    */   
/*    */   private double lastY;
/*    */   
/*    */   private double lastZ;
/*    */   
/*    */   private double lastDeltaX;
/*    */   
/*    */   private double lastDeltaY;
/*    */   
/*    */   private double lastDeltaZ;
/*    */   
/*    */   private double lastDeltaXZ;
/*    */   
/*    */   public void updateCoordinates(WrappedPacket wrappedPacket) {
/* 13 */     if ((wrappedPacket.isMovingAndRotation() || wrappedPacket.isMoving() || wrappedPacket.isFlying()) && 
/* 14 */       wrappedPacket.getPacketReceiveEvent() != null) {
/* 15 */       WrapperPlayClientPlayerFlying positionPacket = new WrapperPlayClientPlayerFlying(wrappedPacket.getPacketReceiveEvent());
/* 17 */       Location location = positionPacket.getLocation();
/* 19 */       double currentX = location.getX();
/* 20 */       double currentY = location.getY();
/* 21 */       double currentZ = location.getZ();
/* 23 */       double deltaX = currentX - this.lastX;
/* 24 */       double deltaY = currentY - this.lastY;
/* 25 */       double deltaZ = currentZ - this.lastZ;
/* 27 */       this.lastX = currentX;
/* 28 */       this.lastY = currentY;
/* 29 */       this.lastZ = currentZ;
/* 31 */       this.lastDeltaX = deltaX;
/* 32 */       this.lastDeltaY = deltaY;
/* 33 */       this.lastDeltaZ = deltaZ;
/*    */     } 
/*    */   }
/*    */   
/*    */   public double getDeltaXZ(WrappedPacket wrappedPacket) {
/* 39 */     if ((wrappedPacket.isMovingAndRotation() || wrappedPacket.isMoving()) && 
/* 40 */       wrappedPacket.getPacketReceiveEvent() != null) {
/* 41 */       WrapperPlayClientPlayerPositionAndRotation positionPacket = new WrapperPlayClientPlayerPositionAndRotation(wrappedPacket.getPacketReceiveEvent());
/* 44 */       Location location = positionPacket.getLocation();
/* 46 */       double currentX = location.getX();
/* 47 */       double currentZ = location.getZ();
/* 50 */       double deltaX = currentX - this.lastX;
/* 51 */       double deltaZ = currentZ - this.lastZ;
/* 54 */       this.lastX = currentX;
/* 55 */       this.lastZ = currentZ;
/* 58 */       return Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
/*    */     } 
/* 62 */     return 0.0D;
/*    */   }
/*    */   
/*    */   public double getDeltaY() {
/* 66 */     return this.lastDeltaY;
/*    */   }
/*    */   
/*    */   public double getDeltaZ() {
/* 70 */     return this.lastDeltaZ;
/*    */   }
/*    */   
/*    */   public double getDeltaX() {
/* 74 */     return this.lastDeltaX;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\engine\MovementEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */