/*     */ package be.kod3ra.wave.user.engine;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ public class CPSEngine implements Listener {
/*  22 */   private Map<UUID, Long> clickStartTimes = new HashMap<>();
/*     */   
/*  23 */   private Map<UUID, Integer> clickCounters = new HashMap<>();
/*     */   
/*  24 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public CPSEngine(Wave plugin) {
/*  27 */     EXECUTOR.execute(() -> {
/*     */           (new BukkitRunnable() {
/*     */               public void run() {
/*  31 */                 CPSEngine.this.resetClickCounters();
/*     */               }
/*     */             }).runTaskTimer((Plugin)plugin, 20L, 20L);
/*     */           Bukkit.getPluginManager().registerEvents(this, (Plugin)plugin);
/*     */         });
/*     */   }
/*     */   
/*     */   public void startClick(UUID playerId) {
/*  41 */     EXECUTOR.execute(() -> this.clickStartTimes.put(playerId, Long.valueOf(System.currentTimeMillis())));
/*     */   }
/*     */   
/*     */   public void endClick(UUID playerId) {
/*  47 */     EXECUTOR.execute(() -> {
/*     */           this.clickStartTimes.remove(playerId);
/*     */           this.clickCounters.put(playerId, Integer.valueOf(0));
/*     */         });
/*     */   }
/*     */   
/*     */   public void trackPlayerClick(UUID playerId, long clickTime) {
/*  55 */     EXECUTOR.execute(() -> this.clickCounters.put(playerId, Integer.valueOf(((Integer)this.clickCounters.getOrDefault(playerId, Integer.valueOf(0))).intValue() + 1)));
/*     */   }
/*     */   
/*     */   public int getCPS(UUID playerId, long clickTime) {
/*  61 */     return ((Integer)this.clickCounters.getOrDefault(playerId, Integer.valueOf(0))).intValue();
/*     */   }
/*     */   
/*     */   private void resetClickCounters() {
/*  65 */     EXECUTOR.execute(() -> {
/*     */           for (Player player : getOnlinePlayers()) {
/*     */             UUID playerId = player.getUniqueId();
/*     */             this.clickCounters.put(playerId, Integer.valueOf(0));
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   public long getLastClickTime(UUID playerId) {
/*  75 */     return ((Long)this.clickStartTimes.getOrDefault(playerId, Long.valueOf(0L))).longValue();
/*     */   }
/*     */   
/*     */   public boolean isClicking(UUID playerId) {
/*  80 */     return this.clickStartTimes.containsKey(playerId);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/*  86 */     resetClickCounters();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerQuit(PlayerQuitEvent event) {
/*  92 */     resetClickCounters();
/*     */   }
/*     */   
/*     */   public List<Player> getOnlinePlayers() {
/*  97 */     List<Player> onlinePlayers = new ArrayList<>();
/*  98 */     for (Player player : Bukkit.getOnlinePlayers())
/*  99 */       onlinePlayers.add(player); 
/* 101 */     return onlinePlayers;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\engine\CPSEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */