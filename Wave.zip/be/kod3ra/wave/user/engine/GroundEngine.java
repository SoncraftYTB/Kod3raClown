/*    */ package be.kod3ra.wave.user.engine;
/*    */ 
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class GroundEngine {
/*    */   public static boolean isClientOnGround(Player player) {
/* 11 */     return player.isOnGround();
/*    */   }
/*    */   
/*    */   public static boolean isServerOnGround(Player player) {
/* 16 */     Block blockBelow1 = player.getLocation().getBlock().getRelative(0, -1, 0);
/* 17 */     Material materialBelow1 = blockBelow1.getType();
/* 19 */     Block blockBelow2 = player.getLocation().getBlock().getRelative(0, -2, 0);
/* 20 */     Material materialBelow2 = blockBelow2.getType();
/* 22 */     return (!isAir(materialBelow1) || !isAir(materialBelow2) || isSolid(materialBelow1) || isSolid(materialBelow2));
/*    */   }
/*    */   
/*    */   private static boolean isAir(Material material) {
/* 27 */     return (material == Material.AIR);
/*    */   }
/*    */   
/*    */   private static boolean isSolid(Material material) {
/* 31 */     return material.isSolid();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\engine\GroundEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */