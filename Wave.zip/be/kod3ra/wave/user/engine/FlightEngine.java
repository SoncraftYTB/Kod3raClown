/*    */ package be.kod3ra.wave.user.engine;
/*    */ 
/*    */ import be.kod3ra.wave.packet.WrappedPacket;
/*    */ import com.github.retrooper.packetevents.protocol.world.Location;
/*    */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying;
/*    */ 
/*    */ public class FlightEngine {
/*    */   private double lastX;
/*    */   
/*    */   private double lastY;
/*    */   
/*    */   private double lastZ;
/*    */   
/*    */   public boolean isFlying(WrappedPacket wrappedPacket) {
/* 13 */     if (wrappedPacket.isFlying() && 
/* 14 */       wrappedPacket.getPacketReceiveEvent() != null) {
/* 15 */       WrapperPlayClientPlayerFlying positionPacket = new WrapperPlayClientPlayerFlying(wrappedPacket.getPacketReceiveEvent());
/* 18 */       Location location = positionPacket.getLocation();
/* 20 */       double currentX = location.getX();
/* 21 */       double currentY = location.getY();
/* 22 */       double currentZ = location.getZ();
/* 25 */       double deltaX = currentX - this.lastX;
/* 26 */       double deltaY = currentY - this.lastY;
/* 27 */       double deltaZ = currentZ - this.lastZ;
/* 30 */       this.lastX = currentX;
/* 31 */       this.lastY = currentY;
/* 32 */       this.lastZ = currentZ;
/* 35 */       return true;
/*    */     } 
/* 39 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\engine\FlightEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */