/*    */ package be.kod3ra.wave.user.engine;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ReachEngine {
/*    */   public double calculateReach(Player attacker, Player target) {
/*  8 */     return calculateReach(attacker
/*  9 */         .getLocation().getX(), attacker
/* 10 */         .getLocation().getZ(), target
/* 11 */         .getLocation().getX(), target
/* 12 */         .getLocation().getZ());
/*    */   }
/*    */   
/*    */   private double calculateReach(double startX, double startZ, double endX, double endZ) {
/* 17 */     double reachDistance = getHorizontalSpeed(startX, startZ, endX, endZ);
/* 18 */     return reachDistance;
/*    */   }
/*    */   
/*    */   private double getHorizontalSpeed(double startX, double startZ, double endX, double endZ) {
/* 22 */     double deltaX = endX - startX;
/* 23 */     double deltaZ = endZ - startZ;
/* 24 */     double distanceSquared = deltaX * deltaX + deltaZ * deltaZ;
/* 25 */     return Math.sqrt(distanceSquared);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\user\engine\ReachEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */