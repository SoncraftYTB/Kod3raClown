/*    */ package be.kod3ra.wave.user.utilsengine;
/*    */ 
/*    */ import be.kod3ra.wave.utils.MemoryUtil;
/*    */ 
/*    */ public class ReliabilityEngine {
/*    */   public static double calculateReliability(int ping, double tps) {
/*  9 */     double normalizedPing = normalizeValue(ping, 0.0D, 200.0D, 100.0D, 0.0D);
/* 12 */     double normalizedTps = normalizeValue(tps, 15.0D, 20.0D, 0.0D, 100.0D);
/* 15 */     long maxMemoryGB = MemoryUtil.getMaxMemory() / 1024L;
/* 18 */     double normalizedMemory = normalizeMemory(maxMemoryGB);
/* 21 */     double reliability = normalizedTps * 0.7D + normalizedPing * 0.2D + normalizedMemory * 0.1D;
/* 24 */     reliability = Math.max(reliability, 0.0D);
/*    */     try {
/* 28 */       return Double.parseDouble(String.format("%.1f", new Object[] { Double.valueOf(reliability) }));
/* 29 */     } catch (NumberFormatException e) {
/* 31 */       return Double.parseDouble(String.format("%.0f", new Object[] { Double.valueOf(reliability) }));
/*    */     } 
/*    */   }
/*    */   
/*    */   private static double normalizeMemory(long maxMemoryGB) {
/* 37 */     return normalizeValue(maxMemoryGB, 1.0D, 16.0D, 0.0D, 100.0D);
/*    */   }
/*    */   
/*    */   private static double normalizeValue(double value, double minInput, double maxInput, double minOutput, double maxOutput) {
/* 42 */     return (value - minInput) / (maxInput - minInput) * (maxOutput - minOutput) + minOutput;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\use\\utilsengine\ReliabilityEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */