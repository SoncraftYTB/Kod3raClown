/*    */ package be.kod3ra.wave.user.utilsengine;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ public class SetbackEngine {
/*    */   private static boolean enableSetback;
/*    */   
/*    */   static {
/* 17 */     FileConfiguration config = Wave.getInstance().getConfig();
/* 18 */     enableSetback = config.getBoolean("setback", false);
/*    */   }
/*    */   
/*    */   public static void performSetback(Player player) {
/* 22 */     if (enableSetback)
/* 23 */       Wave.getInstance().getServer().getScheduler().runTask((Plugin)Wave.getInstance(), () -> {
/*    */             player.setFlySpeed(0.0F);
/*    */             player.setWalkSpeed(0.0F);
/*    */             player.setFlying(false);
/*    */             player.getLocation().setPitch(-90.0F);
/*    */             player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 15, 255, false, false));
/*    */             player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 15, 0, false, false));
/*    */             Wave.getInstance().getServer().getScheduler().runTaskLater((Plugin)Wave.getInstance(), (), 15L);
/*    */           }); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\use\\utilsengine\SetbackEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */