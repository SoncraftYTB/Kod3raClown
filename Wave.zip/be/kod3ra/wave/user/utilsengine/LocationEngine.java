/*    */ package be.kod3ra.wave.user.utilsengine;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class LocationEngine {
/* 12 */   private Location currentLocation = null;
/*    */   
/* 13 */   private Location previousLocation = null;
/*    */   
/* 14 */   private Location previousGroundLocation = null;
/*    */   
/*    */   public Location getCurrentLocation(Player player) {
/* 18 */     if (player != null)
/* 19 */       this.currentLocation = player.getLocation(); 
/* 21 */     return this.currentLocation;
/*    */   }
/*    */   
/*    */   public Location getPreviousLocation() {
/* 25 */     return this.previousLocation;
/*    */   }
/*    */   
/*    */   public Location getPreviousGroundLocation() {
/* 29 */     return this.previousGroundLocation;
/*    */   }
/*    */   
/*    */   public void updatePreviousLocations(Player player) {
/* 33 */     if (player != null) {
/* 35 */       this.previousLocation = this.currentLocation;
/* 36 */       this.previousGroundLocation = getGroundLocation(player);
/*    */     } 
/*    */   }
/*    */   
/*    */   private Location getGroundLocation(Player player) {
/* 42 */     Location loc = player.getLocation();
/* 43 */     loc.setY((player.getWorld().getHighestBlockYAt(loc) - 1));
/* 44 */     return loc;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\use\\utilsengine\LocationEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */