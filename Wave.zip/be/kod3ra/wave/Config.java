/*    */ package be.kod3ra.wave;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ 
/*    */ public class Config {
/* 10 */   private static Config instance = new Config();
/*    */   
/*    */   private File file;
/*    */   
/*    */   private FileConfiguration config;
/*    */   
/*    */   public static Config getInstance() {
/* 19 */     return instance;
/*    */   }
/*    */   
/*    */   public void load() {
/* 24 */     Wave plugin = Wave.getInstance();
/* 27 */     this.file = new File(plugin.getDataFolder(), "config.yml");
/* 29 */     if (!this.file.exists())
/* 31 */       plugin.saveResource("config.yml", false); 
/* 34 */     this.config = (FileConfiguration)YamlConfiguration.loadConfiguration(this.file);
/*    */   }
/*    */   
/*    */   public void save() {
/*    */     try {
/* 40 */       this.config.save(this.file);
/* 41 */     } catch (Exception ex) {
/* 42 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void set(String path, Object value) {
/* 47 */     this.config.set(path, value);
/* 49 */     save();
/*    */   }
/*    */   
/*    */   public FileConfiguration getConfig() {
/* 53 */     return this.config;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\Config.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */