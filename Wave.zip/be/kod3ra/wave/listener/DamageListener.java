/*    */ package be.kod3ra.wave.listener;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.user.UserData;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ 
/*    */ public class DamageListener implements Listener {
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageEvent event) {
/* 14 */     if (event.getEntity() instanceof Player) {
/* 15 */       Player player = (Player)event.getEntity();
/* 16 */       UserData userData = Wave.getInstance().getUserData();
/* 19 */       if (!player.isOp() && player.getGameMode() != GameMode.CREATIVE && !player.hasPermission("wave.bypass")) {
/* 21 */         userData.setLastDamageTime(player.getUniqueId(), System.currentTimeMillis());
/* 24 */         userData.setLastAttackTime(player.getUniqueId(), System.currentTimeMillis());
/* 27 */         userData.setLastDamageIgnoredTime(player.getUniqueId(), System.currentTimeMillis());
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\listener\DamageListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */