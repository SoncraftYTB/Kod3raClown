/*    */ package be.kod3ra.wave.listener;
/*    */ 
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ 
/*    */ public class MineListener implements Listener {
/*    */   @EventHandler
/*    */   public void onBlockBreak(BlockBreakEvent event) {
/* 13 */     if (event.getPlayer() != null) {
/* 15 */       Block brokenBlock = event.getBlock();
/* 18 */       Material blockType = brokenBlock.getType();
/* 19 */       if (blockType == Material.DIAMOND_ORE || blockType == Material.IRON_ORE || blockType == Material.GOLD_ORE || blockType == Material.COAL_ORE || blockType == Material.REDSTONE_ORE || blockType == Material.LAPIS_ORE);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\listener\MineListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */