/*    */ package be.kod3ra.wave.listener;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.user.UserData;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ public final class PlayerConnectionListener implements Listener {
/*    */   @EventHandler
/*    */   private void onJoin(PlayerJoinEvent playerJoinEvent) {
/* 17 */     Player player = playerJoinEvent.getPlayer();
/* 18 */     UUID uuid = player.getUniqueId();
/* 20 */     UserData userData = Wave.getInstance().getUserData();
/* 22 */     userData.createUserData(player);
/* 25 */     userData.setJoinTime(uuid, System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onQuit(PlayerQuitEvent playerQuitEvent) {
/* 30 */     Player player = playerQuitEvent.getPlayer();
/* 31 */     UUID uuid = player.getUniqueId();
/* 33 */     UserData userData = Wave.getInstance().getUserData();
/* 34 */     userData.deleteUserData(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\listener\PlayerConnectionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */