/*    */ package be.kod3ra.wave.listener;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.user.UserData;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerRespawnEvent;
/*    */ 
/*    */ public class RespawnListener implements Listener {
/*    */   @EventHandler
/*    */   public void onPlayerRespawn(PlayerRespawnEvent event) {
/* 14 */     UserData userData = Wave.getInstance().getUserData();
/* 15 */     userData.setJoinTime(event.getPlayer().getUniqueId(), System.currentTimeMillis());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\listener\RespawnListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */