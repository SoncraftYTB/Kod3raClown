/*    */ package be.kod3ra.wave.listener;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.user.UserData;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerTeleportEvent;
/*    */ 
/*    */ public class TeleportListener implements Listener {
/*    */   @EventHandler
/*    */   public void onPlayerTeleport(PlayerTeleportEvent event) {
/* 14 */     Player player = event.getPlayer();
/* 15 */     UserData userData = Wave.getInstance().getUserData();
/* 18 */     userData.setLastTeleportTime(player.getUniqueId(), System.currentTimeMillis());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\listener\TeleportListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */