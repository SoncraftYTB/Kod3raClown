/*    */ package be.kod3ra.wave.utils;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.scheduler.BukkitRunnable;
/*    */ 
/*    */ public class Ping extends BukkitRunnable {
/* 13 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*    */   
/*    */   private int maxPingThreshold;
/*    */   
/*    */   private String kickMessageFormat;
/*    */   
/*    */   public Ping() {
/* 18 */     FileConfiguration config = Wave.getInstance().getConfig();
/* 19 */     this.maxPingThreshold = config.getInt("ping.max-ping", 600);
/* 20 */     this.kickMessageFormat = config.getString("ping.kick-message", "Disconnected because of high ping, %ping%");
/*    */   }
/*    */   
/*    */   public void run() {
/* 25 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 26 */       int ping = PingUtil.getPing(player);
/* 28 */       if (ping > this.maxPingThreshold) {
/* 30 */         String kickMessage = this.kickMessageFormat.replace("%ping%", String.valueOf(ping));
/* 31 */         player.kickPlayer(kickMessage);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void startChecking() {
/* 37 */     EXECUTOR.execute(() -> runTaskTimer((Plugin)Wave.getInstance(), 0L, 100L));
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\Ping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */