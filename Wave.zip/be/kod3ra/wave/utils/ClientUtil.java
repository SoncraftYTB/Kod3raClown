/*    */ package be.kod3ra.wave.utils;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ClientUtil {
/*    */   public static String getClient(Player player) {
/*  8 */     String brand = player.getListeningPluginChannels().toString().toLowerCase();
/* 10 */     if (brand.contains("lunar") || brand.contains("lunarclient"))
/* 11 */       return "Lunar Client"; 
/* 12 */     if (brand.contains("labymod") || brand.contains("labymod3:main"))
/* 13 */       return "LabyMod"; 
/* 14 */     if (brand.contains("feather:client") || brand.contains("feather"))
/* 15 */       return "Feather Client"; 
/* 16 */     if (brand.contains("badlion") || brand.contains("bdl"))
/* 17 */       return "Badlion Client"; 
/* 18 */     if (brand.contains("forge") || brand.contains("fml"))
/* 19 */       return "Forge"; 
/* 20 */     if (brand.contains("worlddownloader") || brand.contains("wdl"))
/* 21 */       return "World Downloader"; 
/* 22 */     if (brand.contains("optifine") || brand.contains("opt"))
/* 23 */       return "OptiFine"; 
/* 24 */     if (brand.contains("fabric"))
/* 25 */       return "Fabric"; 
/* 26 */     if (brand.contains("vanilla") || brand.contains("mc") || brand.contains("minecraft"))
/* 27 */       return "Vanilla"; 
/* 28 */     if (brand.contains("cheatbreaker"))
/* 29 */       return "CheatBreaker"; 
/* 30 */     if (brand.contains("pvplounge"))
/* 31 */       return "PvPLounge"; 
/* 32 */     if (brand.contains("geyser"))
/* 33 */       return "Geyser"; 
/* 34 */     if (brand.contains("wecui") || brand.contains("wecui"))
/* 35 */       return "Lunar Client or WorldEditCUI"; 
/* 37 */     return "N/A";
/*    */   }
/*    */   
/*    */   public static String getBrand(Player player) {
/* 42 */     String brand = player.getListeningPluginChannels().toString().toLowerCase();
/* 44 */     return brand;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\ClientUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */