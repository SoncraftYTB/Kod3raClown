/*    */ package be.kod3ra.wave.utils;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import java.util.AbstractMap;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerChangedWorldEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ import org.bukkit.event.player.PlayerRespawnEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class Latency implements Listener {
/*    */   private static Map<UUID, Map.Entry<Integer, Long>> packetTicks;
/*    */   
/*    */   private static Map<UUID, Long> lastPacket;
/*    */   
/*    */   private static Map<UUID, Integer> packets;
/*    */   
/*    */   private List<UUID> blacklist;
/*    */   
/*    */   public Latency() {
/* 21 */     packetTicks = new HashMap<>();
/* 22 */     lastPacket = new HashMap<>();
/* 23 */     this.blacklist = new ArrayList<>();
/* 24 */     packets = new HashMap<>();
/* 26 */     Wave.getInstance().getServer().getPluginManager().registerEvents(this, (Plugin)Wave.getInstance());
/*    */   }
/*    */   
/*    */   public static Integer getLag(Player p) {
/* 30 */     return packets.getOrDefault(p.getUniqueId(), Integer.valueOf(0));
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 35 */     this.blacklist.add(event.getPlayer().getUniqueId());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 40 */     UUID uuid = event.getPlayer().getUniqueId();
/* 41 */     packetTicks.remove(uuid);
/* 42 */     lastPacket.remove(uuid);
/* 43 */     this.blacklist.remove(uuid);
/* 44 */     packets.remove(uuid);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerChangedWorld(PlayerChangedWorldEvent event) {
/* 49 */     this.blacklist.add(event.getPlayer().getUniqueId());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerRespawn(PlayerRespawnEvent event) {
/* 54 */     this.blacklist.add(event.getPlayer().getUniqueId());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 59 */     Player player = event.getPlayer();
/* 60 */     UUID uuid = player.getUniqueId();
/* 62 */     if (!Wave.getInstance().isEnabled())
/*    */       return; 
/* 63 */     if (player.getGameMode().equals(GameMode.CREATIVE))
/*    */       return; 
/* 65 */     int count = 0;
/* 66 */     long time = System.currentTimeMillis();
/* 68 */     if (packetTicks.containsKey(uuid)) {
/* 69 */       count = ((Integer)((Map.Entry)packetTicks.get(uuid)).getKey()).intValue();
/* 70 */       time = ((Long)((Map.Entry)packetTicks.get(uuid)).getValue()).longValue();
/*    */     } 
/* 73 */     if (lastPacket.containsKey(uuid)) {
/* 74 */       long ms = System.currentTimeMillis() - ((Long)lastPacket.get(uuid)).longValue();
/* 76 */       if (ms >= 100L) {
/* 77 */         this.blacklist.add(uuid);
/* 78 */       } else if (ms > 1L) {
/* 79 */         this.blacklist.remove(uuid);
/*    */       } 
/*    */     } 
/* 83 */     if (!this.blacklist.contains(uuid)) {
/* 84 */       count++;
/* 86 */       if (packetTicks.containsKey(uuid) && TimeUtil.elapsed(time, 1000L)) {
/* 87 */         packets.put(uuid, Integer.valueOf(count));
/* 88 */         count = 0;
/* 89 */         time = TimeUtil.nowlong();
/*    */       } 
/*    */     } 
/* 93 */     packetTicks.put(uuid, new AbstractMap.SimpleEntry<>(Integer.valueOf(count), Long.valueOf(time)));
/* 94 */     lastPacket.put(uuid, Long.valueOf(System.currentTimeMillis()));
/* 96 */     if (count > 10)
/* 97 */       Wave.getInstance().getLogger().info(player.getName() + " have a high latency. Count: " + count); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\Latency.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */