/*    */ package be.kod3ra.wave.utils;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PingUtil {
/*    */   public static int getPing(Player player) {
/*    */     try {
/* 10 */       int ping = player.getPing();
/* 11 */       return ping;
/* 12 */     } catch (NoSuchMethodError e) {
/*    */       try {
/* 15 */         Object craftPlayer = player.getClass().getMethod("getHandle", new Class[0]).invoke(player, new Object[0]);
/* 16 */         int ping = ((Integer)craftPlayer.getClass().getField("ping").get(craftPlayer)).intValue();
/* 17 */         return ping;
/* 18 */       } catch (Exception ex) {
/* 19 */         ex.printStackTrace();
/* 20 */         return -1;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\PingUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */