/*    */ package be.kod3ra.wave.utils;
/*    */ 
/*    */ public class MemoryUtil {
/*    */   public static long getMaxMemory() {
/*  7 */     long maxMemory = Runtime.getRuntime().maxMemory();
/* 10 */     return maxMemory / 1048576L;
/*    */   }
/*    */   
/*    */   public static long getUsedMemory() {
/* 15 */     long totalMemory = Runtime.getRuntime().totalMemory();
/* 18 */     long freeMemory = Runtime.getRuntime().freeMemory();
/* 21 */     long usedMemory = totalMemory - freeMemory;
/* 24 */     return usedMemory / 1048576L;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\MemoryUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */