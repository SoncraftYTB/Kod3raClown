/*    */ package be.kod3ra.wave.utils;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ 
/*    */ public class TPSUtil {
/*    */   public static double[] getRecentTPS() {
/*    */     try {
/* 10 */       Object minecraftServer = Bukkit.getServer().getClass().getDeclaredMethod("getServer", new Class[0]).invoke(Bukkit.getServer(), new Object[0]);
/* 11 */       double[] recentTps = (double[])minecraftServer.getClass().getField("recentTps").get(minecraftServer);
/* 14 */       for (int i = 0; i < recentTps.length; i++)
/* 15 */         recentTps[i] = Math.min(recentTps[i], 20.0D); 
/* 18 */       return recentTps;
/* 19 */     } catch (Exception e) {
/* 20 */       e.printStackTrace();
/* 21 */       return new double[] { -1.0D, -1.0D, -1.0D };
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\TPSUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */