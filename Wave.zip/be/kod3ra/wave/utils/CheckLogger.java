/*    */ package be.kod3ra.wave.utils;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.logging.FileHandler;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import java.util.logging.SimpleFormatter;
/*    */ 
/*    */ public class CheckLogger {
/* 12 */   private static final Logger logger = Logger.getLogger("CheckLogger");
/*    */   
/*    */   private static FileHandler fileHandler;
/*    */   
/*    */   static {
/*    */     try {
/* 18 */       File logsFolder = new File("plugins/Wave/logs");
/* 19 */       if (!logsFolder.exists())
/* 20 */         logsFolder.mkdirs(); 
/* 24 */       String logFileName = generateLogFileName();
/* 25 */       fileHandler = new FileHandler("plugins/Wave/logs/" + logFileName, true);
/* 28 */       SimpleFormatter formatter = new SimpleFormatter();
/* 29 */       fileHandler.setFormatter(formatter);
/* 32 */       logger.addHandler(fileHandler);
/* 34 */     } catch (IOException e) {
/* 35 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void log(String playerName, String checkName, String details) {
/* 40 */     logger.log(Level.WARNING, String.format("[%s] Check '%s' triggered for player '%s' - %s", new Object[] { getCurrentTimestamp(), checkName, playerName, details }));
/*    */   }
/*    */   
/*    */   private static String getCurrentTimestamp() {
/* 46 */     return String.valueOf(System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   private static String generateLogFileName() {
/* 50 */     SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HH'h'-mm'm'");
/* 51 */     Date currentDate = new Date();
/* 52 */     return dateFormat.format(currentDate);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\CheckLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */