/*   */ package be.kod3ra.wave.utils;
/*   */ 
/*   */ import net.md_5.bungee.api.ChatColor;
/*   */ 
/*   */ public final class ColorUtil {
/*   */   public static String format(String textToTranslate) {
/* 8 */     return ChatColor.translateAlternateColorCodes('&', textToTranslate);
/*   */   }
/*   */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\ColorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */