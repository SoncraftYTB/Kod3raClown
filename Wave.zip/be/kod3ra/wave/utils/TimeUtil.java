/*    */ package be.kod3ra.wave.utils;
/*    */ 
/*    */ public class TimeUtil {
/*    */   public static long nowlong() {
/*  6 */     return System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public static boolean elapsed(long from, long required) {
/* 10 */     return (System.currentTimeMillis() - from > required);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wav\\utils\TimeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */