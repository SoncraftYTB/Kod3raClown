/*    */ package be.kod3ra.wave.commands;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ 
/*    */ public class Macro implements Listener {
/*    */   @EventHandler
/*    */   public void onCommandPreProcess(PlayerCommandPreprocessEvent event) {
/* 12 */     String command = event.getMessage().toLowerCase();
/* 15 */     if (command.startsWith("/wave help")) {
/* 16 */       event.setCancelled(true);
/* 17 */       event.setMessage("/wavehelp");
/* 18 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "wavehelp");
/* 22 */     } else if (command.startsWith("/wave gui")) {
/* 23 */       event.setCancelled(true);
/* 24 */       event.setMessage("/wavegui" + command.substring("/wave gui".length()));
/* 25 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "wavegui" + command.substring("/wave gui".length()));
/* 29 */     } else if (command.startsWith("/wave client")) {
/* 30 */       event.setCancelled(true);
/* 31 */       event.setMessage("/waveclient" + command.substring("/wave client".length()));
/* 32 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "waveclient" + command.substring("/wave client".length()));
/* 36 */     } else if (command.startsWith("/wave notify")) {
/* 37 */       event.setCancelled(true);
/* 38 */       event.setMessage("/wavenotify" + command.substring("/wave notify".length()));
/* 39 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "wavenotify" + command.substring("/wave notify".length()));
/* 43 */     } else if (command.startsWith("/wave server")) {
/* 44 */       event.setCancelled(true);
/* 45 */       event.setMessage("/waveserver" + command.substring("/wave server".length()));
/* 46 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "waveserver" + command.substring("/wave server".length()));
/* 50 */     } else if (command.startsWith("/wave ban")) {
/* 51 */       event.setCancelled(true);
/* 52 */       event.setMessage("/waveban" + command.substring("/wave ban".length()));
/* 53 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "waveban" + command.substring("/wave ban".length()));
/* 57 */     } else if (command.startsWith("/wave tempban")) {
/* 58 */       event.setCancelled(true);
/* 59 */       event.setMessage("/wavetempban" + command.substring("/wave tempban".length()));
/* 60 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "wavetempban" + command.substring("/wave tempban".length()));
/* 64 */     } else if (command.startsWith("/wave kick")) {
/* 65 */       event.setCancelled(true);
/* 66 */       event.setMessage("/wavekick" + command.substring("/wave kick".length()));
/* 67 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "wavekick" + command.substring("/wave kick".length()));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\Macro.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */