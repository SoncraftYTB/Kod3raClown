/*     */ package be.kod3ra.wave.commands.commands;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ public class WaveKickCMD implements CommandExecutor {
/*     */   private final JavaPlugin plugin;
/*     */   
/*  21 */   private final Map<UUID, Long> commandCooldowns = new HashMap<>();
/*     */   
/*     */   public WaveKickCMD(JavaPlugin plugin) {
/*  24 */     this.plugin = plugin;
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/*  30 */     if (args.length != 1) {
/*  31 */       sender.sendMessage(this.plugin.getConfig().getString("wave-kick.usage"));
/*  32 */       return true;
/*     */     } 
/*  36 */     Player target = Bukkit.getPlayer(args[0]);
/*  39 */     if (target == null) {
/*  40 */       sender.sendMessage(this.plugin.getConfig().getString("wave-kick.player-not-online"));
/*  41 */       return true;
/*     */     } 
/*  45 */     if (this.commandCooldowns.containsKey(target.getUniqueId())) {
/*  46 */       long cooldownTime = ((Long)this.commandCooldowns.get(target.getUniqueId())).longValue();
/*  47 */       long currentTime = System.currentTimeMillis();
/*  49 */       if (currentTime - cooldownTime < 3000L) {
/*  50 */         sender.sendMessage("Wait before execute again the command.");
/*  51 */         return true;
/*     */       } 
/*     */     } 
/*  56 */     this.commandCooldowns.put(target.getUniqueId(), Long.valueOf(System.currentTimeMillis()));
/*  59 */     sendKickTitle(target);
/*  62 */     applyEffects(target);
/*  65 */     sendKickMessage(target);
/*  68 */     showKickAnimation(target.getLocation());
/*  71 */     Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
/*     */           target.kickPlayer(this.plugin.getConfig().getString("wave-kick.kick-message"));
/*     */           String confirmationMessage = this.plugin.getConfig().getString("wave-kick.confirmation").replace("%player%", target.getName());
/*     */           sender.sendMessage(confirmationMessage);
/*  71 */         }50L);
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   private void showKickAnimation(Location location) {
/*  85 */     location.getWorld().playEffect(location, Effect.MOBSPAWNER_FLAMES, 0);
/*  86 */     location.getWorld().playEffect(location, Effect.SMOKE, 0);
/*     */   }
/*     */   
/*     */   private void sendKickTitle(Player player) {
/*  90 */     String titleMessage = this.plugin.getConfig().getString("wave-animation.title-message");
/*     */     try {
/*  94 */       player.sendTitle(titleMessage, "Wave Anticheat", 30, 50, 0);
/*  95 */     } catch (NoSuchMethodError e) {
/*     */       try {
/*  99 */         player.sendTitle("", titleMessage);
/* 100 */       } catch (NoSuchMethodError noSuchMethodError) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   private void applyEffects(Player player) {
/* 108 */     player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 70, 1));
/* 111 */     player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 70, 10));
/*     */   }
/*     */   
/*     */   private void sendKickMessage(Player player) {
/* 115 */     String kickMessage = this.plugin.getConfig().getString("wave-animation.message-to-player");
/* 116 */     player.sendMessage("§7§m---------------------------------");
/* 117 */     player.sendMessage("");
/* 118 */     player.sendMessage(kickMessage);
/* 119 */     player.sendMessage("");
/* 120 */     player.sendMessage("§7§m---------------------------------");
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\commands\WaveKickCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */