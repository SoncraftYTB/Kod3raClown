/*    */ package be.kod3ra.wave.commands.commands;
/*    */ 
/*    */ import be.kod3ra.wave.gui.MainGUI;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class WaveGuiCMD implements CommandExecutor {
/*    */   private final Plugin plugin;
/*    */   
/*    */   public WaveGuiCMD(Plugin plugin) {
/* 15 */     this.plugin = plugin;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 20 */     if (!(sender instanceof Player)) {
/* 21 */       sender.sendMessage("§b§lWave §f» §eThis command is only for players!");
/* 22 */       return true;
/*    */     } 
/* 25 */     Player player = (Player)sender;
/* 26 */     MainGUI mainGUI = new MainGUI(this.plugin);
/* 27 */     mainGUI.openGUI(player);
/* 29 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\commands\WaveGuiCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */