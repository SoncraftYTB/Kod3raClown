/*    */ package be.kod3ra.wave.commands.commands;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ 
/*    */ public class WaveCMD implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 15 */     FileConfiguration config = Wave.getInstance().getConfig();
/* 18 */     String message = config.getString("wave-command", "§b§lWave §eBETA 0.2.0 §fis running on the server!");
/* 21 */     sender.sendMessage(message);
/* 22 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\commands\WaveCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */