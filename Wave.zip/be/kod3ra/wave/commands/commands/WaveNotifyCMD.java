/*    */ package be.kod3ra.wave.commands.commands;
/*    */ 
/*    */ import be.kod3ra.wave.utils.ColorUtil;
/*    */ import java.util.Arrays;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class WaveNotifyCMD implements CommandExecutor {
/*    */   private final JavaPlugin plugin;
/*    */   
/*    */   public WaveNotifyCMD(JavaPlugin plugin) {
/* 18 */     this.plugin = plugin;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 23 */     if (args.length < 2) {
/* 24 */       sender.sendMessage(this.plugin.getConfig().getString("wave-notify.usage"));
/* 25 */       return true;
/*    */     } 
/* 28 */     String target = args[0].toLowerCase();
/* 29 */     String message = ColorUtil.format(String.join(" ", Arrays.<CharSequence>copyOfRange((CharSequence[])args, 1, args.length)));
/* 30 */     String prefix = ColorUtil.format(this.plugin.getConfig().getString("wave-notify.prefix"));
/* 32 */     if (target.equals("everyone")) {
/* 33 */       broadcastMessage(prefix + message);
/* 34 */     } else if (target.equals("staff")) {
/* 35 */       sendToStaff(prefix + message);
/*    */     } else {
/* 37 */       sender.sendMessage(prefix + this.plugin.getConfig().getString("wave-notify.invalid-target"));
/*    */     } 
/* 40 */     return true;
/*    */   }
/*    */   
/*    */   private void broadcastMessage(String message) {
/* 44 */     Bukkit.broadcastMessage(message);
/*    */   }
/*    */   
/*    */   private void sendToStaff(String message) {
/* 48 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 49 */       if (player.hasPermission("wave.notify"))
/* 50 */         player.sendMessage(message); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\commands\WaveNotifyCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */