/*    */ package be.kod3ra.wave.commands.commands;
/*    */ 
/*    */ import be.kod3ra.wave.Config;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class WaveHelpCMD implements CommandExecutor {
/*    */   private final Config config;
/*    */   
/*    */   public WaveHelpCMD(Config config) {
/* 14 */     this.config = config;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 19 */     sender.sendMessage("");
/* 20 */     sender.sendMessage("");
/* 21 */     sender.sendMessage(this.config.getConfig().getString("wave-help.header"));
/* 23 */     if (this.config.getConfig().isConfigurationSection("wave-help.commands"))
/* 24 */       for (String key : this.config.getConfig().getConfigurationSection("wave-help.commands").getKeys(false)) {
/* 25 */         String message = this.config.getConfig().getString("wave-help.commands." + key);
/* 26 */         sender.sendMessage(" " + message);
/*    */       }  
/* 30 */     sender.sendMessage("");
/* 32 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\commands\WaveHelpCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */