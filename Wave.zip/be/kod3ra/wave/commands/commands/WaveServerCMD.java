/*    */ package be.kod3ra.wave.commands.commands;
/*    */ 
/*    */ import be.kod3ra.wave.Config;
/*    */ import be.kod3ra.wave.utils.MemoryUtil;
/*    */ import be.kod3ra.wave.utils.PingUtil;
/*    */ import be.kod3ra.wave.utils.TPSUtil;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class WaveServerCMD implements CommandExecutor {
/*    */   private final Config config;
/*    */   
/*    */   public WaveServerCMD(Config config) {
/* 17 */     this.config = config;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/*    */     String lagStatus;
/* 23 */     double[] tps = TPSUtil.getRecentTPS();
/* 24 */     int totalPing = 0;
/* 25 */     int playerCount = 0;
/* 27 */     for (Player onlinePlayer : sender.getServer().getOnlinePlayers()) {
/* 28 */       totalPing += PingUtil.getPing(onlinePlayer);
/* 29 */       playerCount++;
/*    */     } 
/* 32 */     int averagePing = (playerCount > 0) ? (totalPing / playerCount) : 0;
/* 35 */     if (averagePing < 50 && tps[0] > 19.5D) {
/* 36 */       lagStatus = this.config.getConfig().getString("wave-server.lagStatus.noLagging", "§aNo Lagging");
/* 37 */     } else if (averagePing >= 50 && averagePing <= 75 && tps[0] >= 18.5D && tps[0] <= 19.5D) {
/* 38 */       lagStatus = this.config.getConfig().getString("wave-server.lagStatus.aBitLagging", "§eA bit Lagging");
/* 39 */     } else if (averagePing > 75 && averagePing <= 200 && tps[0] >= 17.0D && tps[0] < 18.5D) {
/* 40 */       lagStatus = this.config.getConfig().getString("wave-server.lagStatus.lagging", "§cLagging");
/* 41 */     } else if (averagePing > 200 || (averagePing > 0 && tps[0] < 17.0D)) {
/* 42 */       lagStatus = this.config.getConfig().getString("wave-server.lagStatus.laggingMuch", "§4Lagging Much");
/*    */     } else {
/* 44 */       lagStatus = this.config.getConfig().getString("wave-server.lagStatus.noLagging", "§aNo Lagging");
/*    */     } 
/* 47 */     long usedMemory = MemoryUtil.getUsedMemory();
/* 48 */     long maxMemory = MemoryUtil.getMaxMemory();
/* 50 */     sender.sendMessage("");
/* 51 */     sender.sendMessage(this.config.getConfig().getString("wave-server.header", "&b&lWave Server Information:"));
/* 52 */     sender.sendMessage("");
/* 53 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.tps", "&7TPS (Ticks Per Second): &e%tps0%, %tps1%, %tps2%")
/* 54 */         .replace("%tps0%", String.valueOf(tps[0]))
/* 55 */         .replace("%tps1%", String.valueOf(tps[1]))
/* 56 */         .replace("%tps2%", String.valueOf(tps[2])));
/* 57 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.serverVersion", "&7Server Version: &e%serverVersion%")
/* 58 */         .replace("%serverVersion%", sender.getServer().getVersion()));
/* 59 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.playerCount", "&7Number of Connected Players: &e%playerCount%")
/* 60 */         .replace("%playerCount%", String.valueOf(sender.getServer().getOnlinePlayers().size())));
/* 61 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.averagePing", "&7Average Player Ping: &e%averagePing%")
/* 62 */         .replace("%averagePing%", String.valueOf(averagePing)));
/* 63 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.lagStatus", "&7Lag Status: %lagStatus%")
/* 64 */         .replace("%lagStatus%", lagStatus));
/* 65 */     sender.sendMessage("");
/* 66 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.processors", "&7Number of Available Processors: &e%processors%")
/* 67 */         .replace("%processors%", String.valueOf(Runtime.getRuntime().availableProcessors())));
/* 68 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.maxMemory", "&7Maximum Server Memory: &e%maxMemory% MB")
/* 69 */         .replace("%maxMemory%", String.valueOf(maxMemory)));
/* 70 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.usedMemory", "&7Used Server Memory: &e%usedMemory% MB")
/* 71 */         .replace("%usedMemory%", String.valueOf(usedMemory)));
/* 72 */     sender.sendMessage("");
/* 73 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.jreDirectory", "&7JRE Directory: &e%jreDirectory%")
/* 74 */         .replace("%jreDirectory%", System.getProperty("java.home")));
/* 75 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.jreVersion", "&7JRE Version: &e%jreVersion%")
/* 76 */         .replace("%jreVersion%", System.getProperty("java.version")));
/* 77 */     sender.sendMessage("");
/* 78 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.osArchitecture", "&7OS Architecture: &e%osArchitecture%")
/* 79 */         .replace("%osArchitecture%", System.getProperty("os.arch")));
/* 80 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.osName", "&7OS Name: &e%osName%")
/* 81 */         .replace("%osName%", System.getProperty("os.name")));
/* 82 */     sender.sendMessage(" " + this.config.getConfig().getString("wave-server.osVersion", "&7OS Version: &e%osVersion%")
/* 83 */         .replace("%osVersion%", System.getProperty("os.version")));
/* 84 */     sender.sendMessage("");
/* 86 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\commands\WaveServerCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */