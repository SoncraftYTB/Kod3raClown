/*    */ package be.kod3ra.wave.commands.commands;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.utils.ClientUtil;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class WaveClientCMD implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 15 */     String usageMessage = getConfigMessage("wave-client.usage", "§b§lWave §f» §eUsage: /wave client <player>");
/* 16 */     String playerNotOnlineMessage = getConfigMessage("wave-client.player-not-online", "§b§lWave §f» §eThe specified player is not online.");
/* 17 */     String clientBrandMessage = getConfigMessage("wave-client.client-brand-message", "§b§lWave §f» §e%player% has joined the server using §b%client% §e/// §b%brand%");
/* 19 */     if (args.length != 1) {
/* 20 */       sender.sendMessage(usageMessage);
/* 21 */       return true;
/*    */     } 
/* 24 */     Player targetPlayer = sender.getServer().getPlayer(args[0]);
/* 25 */     if (targetPlayer == null || !targetPlayer.isOnline()) {
/* 26 */       sender.sendMessage(playerNotOnlineMessage);
/* 27 */       return true;
/*    */     } 
/* 30 */     String client = ClientUtil.getClient(targetPlayer);
/* 31 */     String brand = ClientUtil.getBrand(targetPlayer);
/* 32 */     String finalMessage = clientBrandMessage.replace("%player%", targetPlayer.getName()).replace("%client%", client).replace("%brand%", brand);
/* 33 */     sender.sendMessage(finalMessage);
/* 35 */     return true;
/*    */   }
/*    */   
/*    */   private String getConfigMessage(String path, String defaultValue) {
/* 39 */     return Wave.getInstance().getConfig().getString(path, defaultValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\commands\WaveClientCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */