/*     */ package be.kod3ra.wave.commands.commands;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.BanList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ public class WaveTempBanCMD implements CommandExecutor {
/*     */   private final JavaPlugin plugin;
/*     */   
/*  20 */   private final Map<UUID, Long> commandCooldowns = new HashMap<>();
/*     */   
/*     */   public WaveTempBanCMD(JavaPlugin plugin) {
/*  23 */     this.plugin = plugin;
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/*     */     int banHours;
/*  29 */     if (args.length != 2) {
/*  30 */       sender.sendMessage(this.plugin.getConfig().getString("wave-tempban.usage"));
/*  31 */       return true;
/*     */     } 
/*  35 */     Player target = Bukkit.getPlayer(args[0]);
/*  38 */     if (target == null) {
/*  39 */       sender.sendMessage(this.plugin.getConfig().getString("wave-tempban.player-not-online"));
/*  40 */       return true;
/*     */     } 
/*  44 */     if (this.commandCooldowns.containsKey(target.getUniqueId())) {
/*  45 */       long cooldownTime = ((Long)this.commandCooldowns.get(target.getUniqueId())).longValue();
/*  46 */       long currentTime = System.currentTimeMillis();
/*  48 */       if (currentTime - cooldownTime < 3000L) {
/*  49 */         sender.sendMessage("Wait before execute again the command.");
/*  50 */         return true;
/*     */       } 
/*     */     } 
/*  55 */     this.commandCooldowns.put(target.getUniqueId(), Long.valueOf(System.currentTimeMillis()));
/*     */     try {
/*  60 */       banHours = Integer.parseInt(args[1]);
/*  61 */     } catch (NumberFormatException e) {
/*  62 */       sender.sendMessage(this.plugin.getConfig().getString("wave-tempban.invalid-hours"));
/*  63 */       return true;
/*     */     } 
/*  67 */     Calendar calendar = new GregorianCalendar();
/*  68 */     calendar.add(11, banHours);
/*  69 */     Date endDate = calendar.getTime();
/*  72 */     String formattedEndDate = formatDate(endDate);
/*  75 */     Bukkit.getBanList(BanList.Type.NAME).addBan(target.getName(), this.plugin.getConfig().getString("wave-tempban.kick-message"), endDate, null);
/*  78 */     sendBanTitle(target);
/*  81 */     applyEffects(target);
/*  84 */     sendTempBanMessage(target, formattedEndDate);
/*  87 */     showBanAnimation(target.getLocation());
/*  90 */     Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
/*     */           target.kickPlayer(this.plugin.getConfig().getString("wave-tempban.ban-message"));
/*     */           String confirmationMessage = this.plugin.getConfig().getString("wave-tempban.confirmation").replace("%player%", target.getName());
/*     */           sender.sendMessage(confirmationMessage);
/*  90 */         }50L);
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   private void showBanAnimation(Location location) {
/* 104 */     location.getWorld().playEffect(location, Effect.MOBSPAWNER_FLAMES, 0);
/* 105 */     location.getWorld().playEffect(location, Effect.SMOKE, 0);
/*     */   }
/*     */   
/*     */   private void sendBanTitle(Player player) {
/* 109 */     String titleMessage = this.plugin.getConfig().getString("wave-animation.title-message");
/*     */     try {
/* 113 */       player.sendTitle(titleMessage, "Wave AntiCheat", 30, 50, 0);
/* 114 */     } catch (NoSuchMethodError e) {
/*     */       try {
/* 118 */         player.sendTitle("", titleMessage);
/* 119 */       } catch (NoSuchMethodError noSuchMethodError) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   private void applyEffects(Player player) {
/* 127 */     player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 70, 1));
/* 130 */     player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 70, 10));
/*     */   }
/*     */   
/*     */   private void sendTempBanMessage(Player player, String formattedEndDate) {
/* 135 */     String tempBanMessage = this.plugin.getConfig().getString("wave-animation.message-to-player");
/* 137 */     player.sendMessage("§7§m---------------------------------");
/* 138 */     player.sendMessage("");
/* 139 */     player.sendMessage(tempBanMessage.replace("%endtime%", formattedEndDate));
/* 140 */     player.sendMessage("");
/* 141 */     player.sendMessage("§7§m---------------------------------");
/*     */   }
/*     */   
/*     */   private String formatDate(Date date) {
/* 147 */     return date.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\commands\commands\WaveTempBanCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */