/*     */ package be.kod3ra.wave.gui;
/*     */ 
/*     */ import be.kod3ra.wave.utils.ClientUtil;
/*     */ import be.kod3ra.wave.utils.PingUtil;
/*     */ import be.kod3ra.wave.utils.TPSUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.SkullType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class PlayersGUI implements Listener {
/*     */   private final Plugin plugin;
/*     */   
/*     */   public PlayersGUI(Plugin plugin) {
/*  30 */     this.plugin = plugin;
/*  31 */     Bukkit.getPluginManager().registerEvents(this, plugin);
/*     */   }
/*     */   
/*     */   private ItemStack createPlayerSkullItem(Player player) {
/*  35 */     ItemStack skullItem = new ItemStack(Material.valueOf("SKULL_ITEM"), 1, (short)SkullType.PLAYER.ordinal());
/*  36 */     SkullMeta skullMeta = (SkullMeta)skullItem.getItemMeta();
/*  39 */     skullMeta.setOwner(player.getName());
/*  42 */     skullMeta.setDisplayName("§7" + player.getName());
/*  45 */     List<String> lore = new ArrayList<>();
/*  47 */     lore.add("");
/*  48 */     lore.add("§7PING: §e" + PingUtil.getPing(player));
/*  49 */     lore.add("§7CLIENT: §e" + ClientUtil.getClient(player));
/*  50 */     lore.add("§7BRAND: §e" + ClientUtil.getBrand(player));
/*  52 */     double[] tpsArray = TPSUtil.getRecentTPS();
/*  53 */     lore.add("§7TPS: §e" + String.format("%.2f, %.2f, %.2f", new Object[] { Double.valueOf(tpsArray[0]), Double.valueOf(tpsArray[1]), Double.valueOf(tpsArray[2]) }));
/*  55 */     skullMeta.setLore(lore);
/*  57 */     skullItem.setItemMeta((ItemMeta)skullMeta);
/*  58 */     return skullItem;
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  62 */     Inventory gui = Bukkit.createInventory((InventoryHolder)player, 54, "§b§lWave §f» §ePlayers GUI");
/*  65 */     for (int i = 0; i < gui.getSize(); i++) {
/*  66 */       int row = i / 9;
/*  67 */       int col = i % 9;
/*  69 */       if (col == 0 || col == 8 || row == 0 || row == 5) {
/*  70 */         ItemStack glassPane = new ItemStack(Material.valueOf("STAINED_GLASS_PANE"));
/*  71 */         ItemMeta glassPaneMeta = glassPane.getItemMeta();
/*  72 */         glassPaneMeta.setDisplayName(" ");
/*  73 */         glassPane.setItemMeta(glassPaneMeta);
/*  74 */         gui.setItem(i, glassPane);
/*     */       } 
/*     */     } 
/*  79 */     Collection<? extends Player> onlinePlayers = Bukkit.getOnlinePlayers();
/*  80 */     int slot = 10;
/*  82 */     for (Player onlinePlayer : onlinePlayers) {
/*  83 */       ItemStack playerHead = createPlayerSkullItem(onlinePlayer);
/*  84 */       gui.setItem(slot++, playerHead);
/*  86 */       if (slot == 48)
/*  87 */         slot = 19; 
/*     */     } 
/*  92 */     ItemStack backButton = new ItemStack(Material.BARRIER);
/*  93 */     ItemMeta backMeta = backButton.getItemMeta();
/*  94 */     backMeta.setDisplayName("§cBack");
/*  95 */     backButton.setItemMeta(backMeta);
/*  96 */     gui.setItem(49, backButton);
/*  98 */     player.openInventory(gui);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/* 103 */     if (event.getInventory().getHolder() instanceof Player) {
/* 104 */       Player player = (Player)event.getInventory().getHolder();
/* 105 */       if (event.getView().getTitle().equals("§b§lWave §f» §ePlayers GUI")) {
/* 106 */         event.setCancelled(true);
/* 108 */         ItemStack clickedItem = event.getCurrentItem();
/* 109 */         if (clickedItem != null && clickedItem.getType() == Material.BARRIER) {
/* 110 */           ItemMeta meta = clickedItem.getItemMeta();
/* 111 */           if (meta != null && meta.getDisplayName().equals("§cBack")) {
/* 113 */             MainGUI mainGUI = new MainGUI(this.plugin);
/* 114 */             mainGUI.openGUI(player);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\gui\PlayersGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */