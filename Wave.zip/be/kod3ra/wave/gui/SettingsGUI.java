/*    */ package be.kod3ra.wave.gui;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ import org.bukkit.inventory.InventoryHolder;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class SettingsGUI implements Listener {
/*    */   private final Plugin plugin;
/*    */   
/*    */   private final FileConfiguration config;
/*    */   
/*    */   public SettingsGUI(Plugin plugin) {
/* 21 */     this.plugin = plugin;
/* 22 */     this.config = plugin.getConfig();
/* 23 */     Bukkit.getPluginManager().registerEvents(this, plugin);
/*    */   }
/*    */   
/*    */   public void openGUI(Player player) {
/* 27 */     Inventory gui = Bukkit.createInventory((InventoryHolder)player, 27, "§b§lWave §f» §eSettings GUI");
/* 30 */     for (int i = 0; i < gui.getSize(); i++) {
/* 31 */       int row = i / 9;
/* 32 */       int col = i % 9;
/* 34 */       if (col == 0 || col == 8 || row == 0 || row == 2) {
/* 35 */         ItemStack glassPane = new ItemStack(Material.valueOf("STAINED_GLASS_PANE"));
/* 36 */         ItemMeta glassPaneMeta = glassPane.getItemMeta();
/* 37 */         glassPaneMeta.setDisplayName(" ");
/* 38 */         glassPane.setItemMeta(glassPaneMeta);
/* 39 */         gui.setItem(i, glassPane);
/*    */       } 
/*    */     } 
/* 44 */     ItemStack backButton = new ItemStack(Material.BARRIER);
/* 45 */     ItemMeta backMeta = backButton.getItemMeta();
/* 46 */     backMeta.setDisplayName("§cBack");
/* 47 */     backButton.setItemMeta(backMeta);
/* 48 */     gui.setItem(22, backButton);
/* 51 */     boolean setbackValue = this.config.getBoolean("setback");
/* 52 */     ItemStack setbackItem = new ItemStack(Material.ARROW);
/* 53 */     ItemMeta setbackMeta = setbackItem.getItemMeta();
/* 54 */     String setbackDisplayName = setbackValue ? "§aSetback: TRUE" : "§cSetback: FALSE";
/* 55 */     setbackMeta.setDisplayName(setbackDisplayName);
/* 56 */     setbackItem.setItemMeta(setbackMeta);
/* 57 */     gui.setItem(10, setbackItem);
/* 59 */     player.openInventory(gui);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onInventoryClick(InventoryClickEvent event) {
/* 64 */     if (event.getInventory().getHolder() instanceof Player) {
/* 65 */       Player player = (Player)event.getInventory().getHolder();
/* 66 */       if (event.getView().getTitle().equals("§b§lWave §f» §eSettings GUI")) {
/* 67 */         event.setCancelled(true);
/* 70 */         if (event.getClick().isLeftClick() || event.getClick().isRightClick()) {
/* 72 */           ItemStack clickedItem = event.getCurrentItem();
/* 73 */           if (clickedItem != null) {
/* 74 */             ItemMeta meta = clickedItem.getItemMeta();
/* 75 */             if (meta != null)
/* 76 */               if (meta.getDisplayName().equals("§cBack")) {
/* 78 */                 MainGUI mainGUI = new MainGUI(this.plugin);
/* 79 */                 mainGUI.openGUI(player);
/* 80 */               } else if (event.getRawSlot() == 10) {
/* 82 */                 boolean currentStatus = this.config.getBoolean("setback");
/* 83 */                 this.config.set("setback", Boolean.valueOf(!currentStatus));
/* 84 */                 this.plugin.saveConfig();
/* 86 */                 openGUI(player);
/*    */               }  
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\gui\SettingsGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */