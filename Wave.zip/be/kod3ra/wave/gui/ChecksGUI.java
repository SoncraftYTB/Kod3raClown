/*     */ package be.kod3ra.wave.gui;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class ChecksGUI implements Listener {
/*     */   private final Plugin plugin;
/*     */   
/*     */   private final FileConfiguration config;
/*     */   
/*  24 */   private static final Map<Player, ChecksGUI> playerInstances = new HashMap<>();
/*     */   
/*     */   public ChecksGUI(Plugin plugin) {
/*  27 */     this.plugin = plugin;
/*  28 */     this.config = plugin.getConfig();
/*  29 */     Bukkit.getPluginManager().registerEvents(this, plugin);
/*     */   }
/*     */   
/*     */   public static ChecksGUI getInstance(Player player, Plugin plugin) {
/*  33 */     return playerInstances.computeIfAbsent(player, p -> new ChecksGUI(plugin));
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  37 */     ChecksGUI checksGUI = getInstance(player, this.plugin);
/*  38 */     Inventory gui = Bukkit.createInventory((InventoryHolder)player, 54, "§b§lWave §f» §eChecks GUI");
/*  41 */     for (int i = 0; i < gui.getSize(); i++) {
/*  42 */       int row = i / 9;
/*  43 */       int col = i % 9;
/*  45 */       if (col < 1 || col > 7 || row < 1 || row > 4) {
/*     */         ItemStack glassPane;
/*     */         try {
/*  48 */           glassPane = new ItemStack(Material.valueOf("STAINED_GLASS_PANE"));
/*  49 */         } catch (IllegalArgumentException e) {
/*  51 */           glassPane = new ItemStack(Material.WHITE_STAINED_GLASS_PANE);
/*     */         } 
/*  54 */         ItemMeta glassPaneMeta = glassPane.getItemMeta();
/*  55 */         glassPaneMeta.setDisplayName(" ");
/*  56 */         glassPane.setItemMeta(glassPaneMeta);
/*  57 */         gui.setItem(i, glassPane);
/*     */       } 
/*     */     } 
/*  62 */     ItemStack autoClickerAItem = createCustomItem("AutoClickerA");
/*  63 */     gui.setItem(10, autoClickerAItem);
/*  66 */     ItemStack autoClickerBItem = createCustomItem("AutoClickerB");
/*  67 */     gui.setItem(11, autoClickerBItem);
/*  69 */     ItemStack criticalsAItem = createCustomItem("CriticalsA");
/*  70 */     gui.setItem(12, criticalsAItem);
/*  72 */     ItemStack killAuraAItem = createCustomItem("KillAuraA");
/*  73 */     gui.setItem(13, killAuraAItem);
/*  76 */     ItemStack reachAItem = createCustomItem("ReachA");
/*  77 */     gui.setItem(14, reachAItem);
/*  80 */     ItemStack flightAItem = createCustomItem("FlightA");
/*  81 */     gui.setItem(15, flightAItem);
/*  83 */     ItemStack flightBItem = createCustomItem("FlightB");
/*  84 */     gui.setItem(16, flightBItem);
/*  86 */     ItemStack flightCItem = createCustomItem("FlightC");
/*  87 */     gui.setItem(19, flightCItem);
/*  89 */     ItemStack flightDItem = createCustomItem("FlightD");
/*  90 */     gui.setItem(20, flightDItem);
/*  92 */     ItemStack jesusAItem = createCustomItem("JesusA");
/*  93 */     gui.setItem(21, jesusAItem);
/*  95 */     ItemStack noFallAItem = createCustomItem("NoFallA");
/*  96 */     gui.setItem(22, noFallAItem);
/*  99 */     ItemStack speedAItem = createCustomItem("SpeedA");
/* 100 */     gui.setItem(23, speedAItem);
/* 103 */     ItemStack speedA2Item = createCustomItem("SpeedA2");
/* 104 */     gui.setItem(24, speedA2Item);
/* 106 */     ItemStack stepAItem = createCustomItem("StepA");
/* 107 */     gui.setItem(25, stepAItem);
/* 110 */     ItemStack badPacketsAItem = createCustomItem("BadPacketsA");
/* 111 */     gui.setItem(28, badPacketsAItem);
/* 113 */     ItemStack badPacketsBItem = createCustomItem("BadPacketsB");
/* 114 */     gui.setItem(29, badPacketsBItem);
/* 116 */     ItemStack badPacketsCItem = createCustomItem("BadPacketsC");
/* 117 */     gui.setItem(30, badPacketsCItem);
/* 120 */     ItemStack fastBowAItem = createCustomItem("FastBowA");
/* 121 */     gui.setItem(31, fastBowAItem);
/* 124 */     ItemStack timerAItem = createCustomItem("TimerA");
/* 125 */     gui.setItem(32, timerAItem);
/* 128 */     ItemStack backButton = new ItemStack(Material.BARRIER);
/* 129 */     ItemMeta backMeta = backButton.getItemMeta();
/* 130 */     backMeta.setDisplayName("§cBack");
/* 131 */     backButton.setItemMeta(backMeta);
/* 132 */     gui.setItem(49, backButton);
/* 134 */     player.openInventory(gui);
/*     */   }
/*     */   
/*     */   private ItemStack createCustomItem(String check) {
/*     */     Material material;
/* 142 */     if (check.equalsIgnoreCase("AutoClickerA") || check.equalsIgnoreCase("AutoClickerB")) {
/* 143 */       material = Material.IRON_SWORD;
/* 144 */     } else if (check.equalsIgnoreCase("KillAuraA") || check.equalsIgnoreCase("ReachA") || check.equalsIgnoreCase("CriticalsA")) {
/* 145 */       material = Material.DIAMOND_SWORD;
/* 146 */     } else if (check.equalsIgnoreCase("FlightA") || check.equalsIgnoreCase("FlightB") || check.equalsIgnoreCase("FlightC") || check.equalsIgnoreCase("FlightD")) {
/* 147 */       material = Material.FEATHER;
/* 148 */     } else if (check.equalsIgnoreCase("JesusA")) {
/* 149 */       material = Material.WATER_BUCKET;
/* 150 */     } else if (check.equalsIgnoreCase("NoFallA")) {
/* 151 */       material = Material.DIAMOND_BOOTS;
/* 152 */     } else if (check.equalsIgnoreCase("StepA")) {
/* 153 */       material = Material.IRON_BOOTS;
/* 154 */     } else if (check.equalsIgnoreCase("SpeedA") || check.equalsIgnoreCase("SpeedA2")) {
/* 155 */       material = Material.SUGAR;
/* 156 */     } else if (check.equalsIgnoreCase("BadPacketsA") || check.equalsIgnoreCase("BadPacketsB") || check.equalsIgnoreCase("BadPacketsC") || check.equalsIgnoreCase("BadPacketsC2")) {
/* 157 */       material = Material.FERMENTED_SPIDER_EYE;
/* 158 */     } else if (check.equalsIgnoreCase("FastBowA")) {
/* 159 */       material = Material.BOW;
/* 160 */     } else if (check.equalsIgnoreCase("TimerA")) {
/* 161 */       material = Material.COMPASS;
/*     */     } else {
/* 164 */       material = Material.PAPER;
/*     */     } 
/* 168 */     ItemStack item = new ItemStack(material);
/* 170 */     ItemMeta meta = item.getItemMeta();
/* 173 */     int maxViolations = this.config.getInt("Checks." + check + ".MAX-VIOLATIONS");
/* 174 */     boolean enabled = this.config.getBoolean("Checks." + check + ".ENABLED");
/* 177 */     String displayName = enabled ? ("§a" + check) : ("§c" + check);
/* 178 */     meta.setDisplayName(displayName);
/* 181 */     meta.setLore(Arrays.asList(new String[] { "§7ENABLED: " + (enabled ? "§aTRUE" : "§cFALSE"), "§7Max Violations: §e" + maxViolations, "", "§eYou will have to restart/reload to apply this changes." }));
/* 186 */     item.setItemMeta(meta);
/* 187 */     return item;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/* 192 */     if (event.getInventory().getHolder() instanceof Player) {
/* 193 */       Player player = (Player)event.getInventory().getHolder();
/* 194 */       if (event.getView().getTitle().equals("§b§lWave §f» §eChecks GUI")) {
/* 195 */         event.setCancelled(true);
/* 197 */         List<Integer> targetSlots = Arrays.asList(new Integer[] { 
/* 197 */               Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(13), Integer.valueOf(14), Integer.valueOf(15), Integer.valueOf(16), Integer.valueOf(19), Integer.valueOf(20), Integer.valueOf(22), 
/* 197 */               Integer.valueOf(23), Integer.valueOf(24), Integer.valueOf(25), Integer.valueOf(26), Integer.valueOf(27), Integer.valueOf(28), Integer.valueOf(29), Integer.valueOf(30), Integer.valueOf(31), Integer.valueOf(32), 
/* 197 */               Integer.valueOf(49) });
/* 198 */         if (targetSlots.contains(Integer.valueOf(event.getRawSlot()))) {
/* 201 */           String check = event.getCurrentItem().getItemMeta().getDisplayName().substring(2);
/* 204 */           if (event.getClick().isLeftClick() || event.getClick().isRightClick()) {
/* 205 */             boolean currentStatus = this.config.getBoolean("Checks." + check + ".ENABLED");
/* 206 */             this.config.set("Checks." + check + ".ENABLED", Boolean.valueOf(!currentStatus));
/* 207 */             this.plugin.saveConfig();
/* 209 */             openGUI(player);
/*     */           } 
/* 212 */           ItemStack clickedItem = event.getCurrentItem();
/* 213 */           if (clickedItem.getType() == Material.BARRIER) {
/* 214 */             ItemMeta meta = clickedItem.getItemMeta();
/* 215 */             if (meta != null && meta.getDisplayName().equals("§cBack")) {
/* 216 */               MainGUI mainGUI = new MainGUI(this.plugin);
/* 217 */               mainGUI.openGUI(player);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\gui\ChecksGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */