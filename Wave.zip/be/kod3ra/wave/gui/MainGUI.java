/*     */ package be.kod3ra.wave.gui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class MainGUI implements Listener {
/*     */   private final Plugin plugin;
/*     */   
/*  20 */   private static final Map<Player, MainGUI> playerInstances = new HashMap<>();
/*     */   
/*     */   public MainGUI(Plugin plugin) {
/*  23 */     this.plugin = plugin;
/*  24 */     Bukkit.getPluginManager().registerEvents(this, plugin);
/*     */   }
/*     */   
/*     */   public static MainGUI getInstance(Player player, Plugin plugin) {
/*  28 */     return playerInstances.computeIfAbsent(player, p -> new MainGUI(plugin));
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  32 */     MainGUI mainGUI = getInstance(player, this.plugin);
/*  33 */     Inventory gui = Bukkit.createInventory((InventoryHolder)player, 27, "§b§lWave §f» §eMain GUI");
/*  35 */     ItemStack cpsSword = new ItemStack(Material.COMPASS);
/*  36 */     ItemMeta cpsSwordMeta = cpsSword.getItemMeta();
/*  37 */     cpsSwordMeta.setDisplayName("§7Players");
/*  38 */     cpsSword.setItemMeta(cpsSwordMeta);
/*  39 */     gui.setItem(10, cpsSword);
/*  41 */     ItemStack checksBook = new ItemStack(Material.BOOK);
/*  42 */     ItemMeta checksBookMeta = checksBook.getItemMeta();
/*  43 */     checksBookMeta.setDisplayName("§7Checks");
/*  44 */     checksBook.setItemMeta(checksBookMeta);
/*  45 */     gui.setItem(13, checksBook);
/*  47 */     ItemStack settingsAnvil = new ItemStack(Material.ANVIL);
/*  48 */     ItemMeta settingsAnvilMeta = settingsAnvil.getItemMeta();
/*  49 */     settingsAnvilMeta.setDisplayName("§7Settings");
/*  50 */     settingsAnvil.setItemMeta(settingsAnvilMeta);
/*  51 */     gui.setItem(16, settingsAnvil);
/*  54 */     for (int i = 0; i < gui.getSize(); i++) {
/*  55 */       if (gui.getItem(i) == null)
/*     */         try {
/*  57 */           ItemStack glassPane = new ItemStack(Material.valueOf("STAINED_GLASS_PANE"));
/*  58 */           ItemMeta glassPaneMeta = glassPane.getItemMeta();
/*  59 */           glassPaneMeta.setDisplayName(" ");
/*  60 */           glassPane.setItemMeta(glassPaneMeta);
/*  61 */           gui.setItem(i, glassPane);
/*  62 */         } catch (IllegalArgumentException e) {
/*  64 */           ItemStack glassPane = new ItemStack(Material.valueOf("LEGACY_STAINED_GLASS_PANE"));
/*  65 */           ItemMeta glassPaneMeta = glassPane.getItemMeta();
/*  66 */           glassPaneMeta.setDisplayName(" ");
/*  67 */           glassPane.setItemMeta(glassPaneMeta);
/*  68 */           gui.setItem(i, glassPane);
/*     */         }  
/*     */     } 
/*  73 */     player.openInventory(gui);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  78 */     if (event.getInventory().getHolder() instanceof Player) {
/*  79 */       Player player = (Player)event.getInventory().getHolder();
/*  80 */       if (event.getView().getTitle().equals("§b§lWave §f» §eMain GUI")) {
/*  81 */         event.setCancelled(true);
/*  83 */         ItemStack clickedItem = event.getCurrentItem();
/*  84 */         if (clickedItem != null && clickedItem.getType() != Material.AIR) {
/*  85 */           if (clickedItem.getItemMeta().getDisplayName().equals("§7Checks")) {
/*  87 */             ChecksGUI checksGUI = new ChecksGUI(this.plugin);
/*  88 */             checksGUI.openGUI(player);
/*     */           } 
/*  91 */           if (clickedItem.getItemMeta().getDisplayName().equals("§7Settings")) {
/*  93 */             SettingsGUI settingsGUI = new SettingsGUI(this.plugin);
/*  94 */             settingsGUI.openGUI(player);
/*     */           } 
/*  97 */           if (clickedItem.getItemMeta().getDisplayName().equals("§7Players")) {
/*  99 */             PlayersGUI playersGUI = new PlayersGUI(this.plugin);
/* 100 */             playersGUI.openGUI(player);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\gui\MainGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */