/*    */ package be.kod3ra.wave.checks;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*    */ import be.kod3ra.wave.user.User;
/*    */ import be.kod3ra.wave.user.utilsengine.ReliabilityEngine;
/*    */ import be.kod3ra.wave.utils.ColorUtil;
/*    */ import be.kod3ra.wave.utils.PingUtil;
/*    */ import be.kod3ra.wave.utils.TPSUtil;
/*    */ import net.md_5.bungee.api.chat.BaseComponent;
/*    */ import net.md_5.bungee.api.chat.ComponentBuilder;
/*    */ import net.md_5.bungee.api.chat.HoverEvent;
/*    */ import net.md_5.bungee.api.chat.TextComponent;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public abstract class Check implements CheckMethod {
/*    */   private String checkName;
/*    */   
/* 20 */   public int violations = 0;
/*    */   
/*    */   private String alertFormat;
/*    */   
/*    */   public Check() {
/* 24 */     if (!getClass().isAnnotationPresent((Class)CheckInfo.class)) {
/* 25 */       System.out.println("@CheckInfo not found in: " + getClass().getSimpleName());
/*    */       return;
/*    */     } 
/* 29 */     CheckInfo checkInfo = getClass().<CheckInfo>getAnnotation(CheckInfo.class);
/* 30 */     this.checkName = checkInfo.name();
/* 33 */     this.alertFormat = Wave.getInstance().getConfig().getString("alerts.format", "§b§lWave §b// §e%player% §7failed §e%check% (%type%) §8[§7VL: %violations%§8] §8[§7RL: %reliability%%§8]");
/*    */   }
/*    */   
/*    */   public void flag(User user, String type, String information, int violations, String debugInfo) {
/* 38 */     Player player = user.getPlayer();
/* 39 */     if (player == null)
/*    */       return; 
/* 44 */     String playerName = user.getName();
/* 45 */     int playerPing = PingUtil.getPing(player);
/* 46 */     double[] recentTps = TPSUtil.getRecentTPS();
/* 47 */     double reliability = ReliabilityEngine.calculateReliability(playerPing, recentTps[0]);
/* 49 */     String pingInfo = "§7Ping: " + playerPing + "ms";
/* 52 */     String tpsInfo = "§7TPS: §f" + String.format("%.2f", new Object[] { Double.valueOf(recentTps[0]) }) + " §7(1m), " + String.format("%.2f", new Object[] { Double.valueOf(recentTps[1]) }) + " §7(5m), " + String.format("%.2f", new Object[] { Double.valueOf(recentTps[2]) }) + " §7(15m)";
/* 53 */     String reliabilityInfo = "§7Reliability: §f" + reliability + "%";
/* 54 */     String reliabilityNumber = String.valueOf(reliability);
/* 55 */     String message = ColorUtil.format(this.alertFormat
/* 56 */         .replace("%player%", playerName)
/* 57 */         .replace("%check%", this.checkName)
/* 58 */         .replace("%type%", type)
/* 59 */         .replace("%information%", information)
/* 60 */         .replace("%violations%", String.valueOf(violations))
/* 61 */         .replace("%reliability%", reliabilityNumber)
/* 62 */         .replace("%debug%", debugInfo));
/* 64 */     TextComponent textComponent = new TextComponent(message);
/* 65 */     BaseComponent[] baseComponents = (new ComponentBuilder("§7Informations:\n\n" + pingInfo + "\n" + tpsInfo + "\n§7Debug: §f" + debugInfo + "\n" + reliabilityInfo)).create();
/* 66 */     HoverEvent hoverEvent = new HoverEvent(HoverEvent.Action.SHOW_TEXT, baseComponents);
/* 68 */     textComponent.setHoverEvent(hoverEvent);
/* 70 */     Bukkit.getOnlinePlayers().stream().filter(p -> p.hasPermission("wave.notify"))
/* 71 */       .forEach(p -> p.spigot().sendMessage((BaseComponent)textComponent));
/* 73 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\Check.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */