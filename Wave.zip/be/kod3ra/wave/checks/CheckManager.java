/*    */ package be.kod3ra.wave.checks;
/*    */ 
/*    */ import be.kod3ra.wave.Wave;
/*    */ import be.kod3ra.wave.checks.impl.combat.AimAssistA;
/*    */ import be.kod3ra.wave.checks.impl.combat.AutoClickerA;
/*    */ import be.kod3ra.wave.checks.impl.combat.AutoClickerB;
/*    */ import be.kod3ra.wave.checks.impl.combat.CriticalsA;
/*    */ import be.kod3ra.wave.checks.impl.combat.KillAuraA;
/*    */ import be.kod3ra.wave.checks.impl.combat.ReachA;
/*    */ import be.kod3ra.wave.checks.impl.movement.FlightA;
/*    */ import be.kod3ra.wave.checks.impl.movement.FlightB;
/*    */ import be.kod3ra.wave.checks.impl.movement.FlightC;
/*    */ import be.kod3ra.wave.checks.impl.movement.FlightD;
/*    */ import be.kod3ra.wave.checks.impl.movement.JesusA;
/*    */ import be.kod3ra.wave.checks.impl.movement.NoFallA;
/*    */ import be.kod3ra.wave.checks.impl.movement.SpeedA;
/*    */ import be.kod3ra.wave.checks.impl.movement.SpeedA2;
/*    */ import be.kod3ra.wave.checks.impl.movement.StepA;
/*    */ import be.kod3ra.wave.checks.impl.player.BadPacketsA;
/*    */ import be.kod3ra.wave.checks.impl.player.BadPacketsB;
/*    */ import be.kod3ra.wave.checks.impl.player.BadPacketsC;
/*    */ import be.kod3ra.wave.checks.impl.player.FastBowA;
/*    */ import be.kod3ra.wave.checks.impl.player.TimerA;
/*    */ import com.google.common.collect.ImmutableClassToInstanceMap;
/*    */ 
/*    */ public final class CheckManager {
/* 14 */   private final ImmutableClassToInstanceMap<Check> classToInstanceMap = (new ImmutableClassToInstanceMap.Builder())
/*    */     
/* 16 */     .put(AimAssistA.class, new AimAssistA())
/* 17 */     .put(AutoClickerA.class, new AutoClickerA())
/* 18 */     .put(AutoClickerB.class, new AutoClickerB())
/* 19 */     .put(CriticalsA.class, new CriticalsA())
/* 20 */     .put(KillAuraA.class, new KillAuraA())
/* 21 */     .put(ReachA.class, new ReachA())
/*    */     
/* 24 */     .put(FlightA.class, new FlightA())
/* 25 */     .put(FlightB.class, new FlightB())
/* 26 */     .put(FlightC.class, new FlightC())
/* 27 */     .put(FlightD.class, new FlightD())
/* 28 */     .put(JesusA.class, new JesusA())
/* 29 */     .put(NoFallA.class, new NoFallA())
/* 30 */     .put(SpeedA.class, new SpeedA())
/* 31 */     .put(SpeedA2.class, new SpeedA2())
/* 32 */     .put(StepA.class, new StepA())
/*    */     
/* 35 */     .put(BadPacketsA.class, new BadPacketsA())
/* 36 */     .put(BadPacketsB.class, new BadPacketsB())
/* 37 */     .put(BadPacketsC.class, new BadPacketsC())
/* 38 */     .put(FastBowA.class, new FastBowA())
/* 39 */     .put(TimerA.class, new TimerA())
/* 40 */     .build();
/*    */   
/*    */   public CheckManager(Wave wave) {}
/*    */   
/*    */   public ImmutableClassToInstanceMap<Check> getClassToInstanceMap() {
/* 44 */     return this.classToInstanceMap;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\CheckManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */