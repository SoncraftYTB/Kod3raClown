package be.kod3ra.wave.checks.impl;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface CheckInfo {
  String name();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\CheckInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */