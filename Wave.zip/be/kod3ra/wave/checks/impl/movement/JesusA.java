/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.MovementEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "JESUS")
/*     */ public final class JesusA extends Check {
/*  22 */   private MovementEngine movementEngine = new MovementEngine();
/*     */   
/*  23 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private double maxValue;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*  29 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public JesusA() {
/*  32 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  33 */     this.isEnabled = config.getBoolean("Checks.JesusA.ENABLED", true);
/*  34 */     this.maxValue = config.getDouble("Checks.JesusA.MAX-SPEED", 0.15D);
/*  35 */     this.maxViolations = config.getInt("Checks.JesusA.MAX-VIOLATIONS", 20);
/*  36 */     this.action = config.getString("Checks.JesusA.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  37 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  42 */     Player player = user.getPlayer();
/*  43 */     UserData userData = Wave.getInstance().getUserData();
/*  45 */     if (!this.isEnabled || !wrappedPacket.isFlying() || isHighLatency(player) || isBypassed(player))
/*     */       return; 
/*  49 */     if (isHighLatency(user.getPlayer()))
/*     */       return; 
/*  53 */     if (player.getFallDistance() > 0.0F)
/*     */       return; 
/*  57 */     double deltaXZ = this.movementEngine.getDeltaXZ(wrappedPacket);
/*  60 */     if (player.getLocation().getBlock().isLiquid() || player.getLocation().add(0.0D, -1.0D, 0.0D).getBlock().isLiquid() || player.getLocation().add(0.0D, -2.0D, 0.0D).getBlock().isLiquid())
/*  62 */       if (deltaXZ > this.maxValue) {
/*  63 */         this.violations++;
/*  66 */         boolean ignoreCheck = false;
/*  67 */         for (int x = -4; x <= 4 && !ignoreCheck; x++) {
/*  68 */           for (int y = -4; y <= 4 && !ignoreCheck; y++) {
/*  69 */             for (int z = -4; z <= 4 && !ignoreCheck; z++) {
/*  70 */               Block block = player.getLocation().add(x, y, z).getBlock();
/*  71 */               String blockTypeName = block.getType().name();
/*  72 */               if (block.getType().isSolid() || blockTypeName.contains("WATER_LILY") || blockTypeName.contains("LILY_PAD"))
/*  73 */                 ignoreCheck = true; 
/*     */             } 
/*     */           } 
/*     */         } 
/*  79 */         if (!ignoreCheck) {
/*  81 */           String debugInfo = String.valueOf(deltaXZ);
/*  82 */           flag(user, "A", "Anormal speed in/on water", this.violations, debugInfo);
/*  83 */           if (player != null)
/*  84 */             CheckLogger.log(player.getName(), "JESUS", "Type: A Debug:" + debugInfo); 
/*  88 */           if (this.violations >= this.maxViolations)
/*  89 */             handleViolation(user); 
/*     */         } 
/*     */       }  
/*  96 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/*  97 */       this.violations = 0;
/*  98 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleViolation(User user) {
/* 103 */     if (this.violations >= this.maxViolations)
/*     */       try {
/* 105 */         String playerAction = this.action.replace("%player%", user.getName());
/* 108 */         EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 113 */       } catch (Exception e) {
/* 114 */         e.printStackTrace();
/*     */       }  
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 120 */     if (player == null)
/* 121 */       return false; 
/* 125 */     int latency = Latency.getLag(player).intValue();
/* 128 */     return (latency > 200);
/*     */   }
/*     */   
/*     */   private boolean isBypassed(Player player) {
/* 132 */     return (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.jesus"));
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\JesusA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */