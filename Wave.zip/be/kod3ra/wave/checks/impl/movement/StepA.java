/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "STEP")
/*     */ public final class StepA extends Check {
/*     */   private Location lastLocation;
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private double maxYSpeed;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*  25 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*  27 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public StepA() {
/*  31 */     this.isEnabled = Wave.getInstance().getConfig().getBoolean("Checks.StepA.ENABLED", true);
/*  32 */     this.maxYSpeed = Wave.getInstance().getConfig().getDouble("Checks.StepA.MAX-Y-SPEED", 0.999D);
/*  33 */     this.maxViolations = Wave.getInstance().getConfig().getInt("Checks.StepA.MAX-VIOLATIONS", 10);
/*  34 */     this.action = Wave.getInstance().getConfig().getString("Checks.StepA.ACTION", "kick %player% §b§lWave §f» §eUnfair Advantage");
/*  35 */     this.violationsResetTime = Wave.getInstance().getConfig().getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  41 */     if (!this.isEnabled)
/*     */       return; 
/*  43 */     Player player = user.getPlayer();
/*  46 */     if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.step")))
/*     */       return; 
/*  50 */     UserData userData = Wave.getInstance().getUserData();
/*  51 */     Location currentLocation = player.getLocation();
/*  54 */     if (isHighLatency(user.getPlayer()))
/*     */       return; 
/*  58 */     if (this.lastLocation != null && wrappedPacket.isFlying()) {
/*  60 */       double deltaY = currentLocation.getY() - this.lastLocation.getY();
/*  62 */       if (deltaY > 1.0D)
/*     */         return; 
/*  66 */       if (deltaY > this.maxYSpeed && !player.isFlying()) {
/*  68 */         for (int x = -2; x <= 2; x++) {
/*  69 */           for (int y = -2; y <= 2; y++) {
/*  70 */             for (int z = -2; z <= 2; z++) {
/*  71 */               Location nearbyLocation = currentLocation.clone().add(x, y, z);
/*  74 */               String blockName = nearbyLocation.getBlock().getType().name();
/*  77 */               if (blockName.contains("STAIRS"))
/*     */                 return; 
/*     */             } 
/*     */           } 
/*     */         } 
/*  84 */         this.violations++;
/*  85 */         String debugInfo = String.valueOf("DeltaY: " + deltaY);
/*  86 */         flag(user, "A", "Abnormal vertical player movement.", this.violations, debugInfo);
/*  87 */         if (player != null)
/*  88 */           CheckLogger.log(player.getName(), "STEP", "Type: A Debug:" + deltaY); 
/*  91 */         if (this.violations >= this.maxViolations)
/*     */           try {
/*  93 */             String playerAction = this.action.replace("%player%", user.getName());
/*  96 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 101 */           } catch (Exception e) {
/* 102 */             e.printStackTrace();
/*     */           }  
/*     */       } 
/*     */     } 
/* 108 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 109 */       this.violations = 0;
/* 110 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/* 113 */     this.lastLocation = currentLocation;
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 117 */     if (player == null)
/* 118 */       return false; 
/* 122 */     int latency = Latency.getLag(player).intValue();
/* 125 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\StepA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */