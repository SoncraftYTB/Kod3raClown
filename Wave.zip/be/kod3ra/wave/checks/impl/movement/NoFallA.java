/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.GroundEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "NOFALL")
/*     */ public final class NoFallA extends Check {
/*     */   private boolean enabled;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String kickAction;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*  29 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*  30 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public NoFallA() {
/*  34 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  35 */     this.enabled = config.getBoolean("Checks.NoFallA.ENABLED", true);
/*  36 */     this.maxViolations = config.getInt("Checks.NoFallA.MAX-VIOLATIONS", 45);
/*  37 */     this.kickAction = config.getString("Checks.NoFallA.ACTION", "kick %player% §b§lWave §f» §eUnfair Advantage");
/*  38 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  43 */     Player player = user.getPlayer();
/*  44 */     UserData userData = Wave.getInstance().getUserData();
/*  45 */     if (!this.enabled)
/*     */       return; 
/*  49 */     if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.nofall")))
/*     */       return; 
/*  53 */     if (isHighLatency(user.getPlayer()))
/*     */       return; 
/*  57 */     if (hasSolidBlockNearby(user.getPlayer().getLocation()))
/*     */       return; 
/*  62 */     boolean isClientOnGround = GroundEngine.isClientOnGround(user.getPlayer());
/*  63 */     boolean isServerOnGround = GroundEngine.isServerOnGround(user.getPlayer());
/*  66 */     if (isClientOnGround && !isServerOnGround) {
/*  67 */       this.violations++;
/*  69 */       String debugInfo = String.valueOf("Client Ground: " + isClientOnGround + " | Server Ground: " + isServerOnGround);
/*  70 */       flag(user, "A", "Client on ground, but not on server", this.violations, debugInfo);
/*  71 */       if (player != null)
/*  72 */         CheckLogger.log(player.getName(), "NOFALL", "Type: A Debug:" + debugInfo); 
/*  75 */       if (this.violations >= this.maxViolations)
/*     */         try {
/*  77 */           String playerAction = this.kickAction.replace("%player%", user.getName());
/*  80 */           EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/*  85 */         } catch (Exception e) {
/*  86 */           e.printStackTrace();
/*     */         }  
/*     */     } 
/*  91 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/*  92 */       this.violations = 0;
/*  93 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getMaxViolations() {
/*  98 */     return this.maxViolations;
/*     */   }
/*     */   
/*     */   public String getKickAction() {
/* 102 */     return this.kickAction;
/*     */   }
/*     */   
/*     */   private boolean hasSolidBlockNearby(Location location) {
/* 107 */     for (int x = -1; x <= 1; x++) {
/* 108 */       for (int y = -1; y <= 1; y++) {
/* 109 */         for (int z = -1; z <= 1; z++) {
/* 110 */           Block nearbyBlock = location.getBlock().getRelative(x, y, z);
/* 111 */           Material blockType = nearbyBlock.getType();
/* 114 */           if (!isAir(blockType))
/* 115 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 121 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isAir(Material material) {
/* 125 */     return (material == Material.AIR);
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 129 */     if (player == null)
/* 130 */       return false; 
/* 134 */     int latency = Latency.getLag(player).intValue();
/* 137 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\NoFallA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */