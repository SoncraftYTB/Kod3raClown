/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.MovementEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "FLIGHT")
/*     */ public final class FlightB extends Check {
/*  20 */   private final MovementEngine movementEngine = new MovementEngine();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private double maxVerticalSpeed;
/*     */   
/*     */   private int onJoinDisabledTime;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*  26 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private String action;
/*     */   
/*  28 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public FlightB() {
/*  31 */     this.isEnabled = Wave.getInstance().getConfig().getBoolean("Checks.FlightB.ENABLED", true);
/*  32 */     this.maxVerticalSpeed = Wave.getInstance().getConfig().getDouble("Checks.FlightB.MAX-VERTICAL-SPEED", 3.8D);
/*  33 */     this.onJoinDisabledTime = Wave.getInstance().getConfig().getInt("Checks.FlightB.ON-JOIN-DISABLED-TIME", 5);
/*  34 */     this.maxViolations = Wave.getInstance().getConfig().getInt("Checks.FlightB.MAX-VIOLATIONS", 10);
/*  35 */     this.action = Wave.getInstance().getConfig().getString("Checks.FlightB.ACTION", "wavekick %player%");
/*  36 */     this.violationsResetTime = Wave.getInstance().getConfig().getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  41 */     if (this.isEnabled) {
/*  42 */       Player player = user.getPlayer();
/*  43 */       UserData userData = Wave.getInstance().getUserData();
/*  44 */       long joinTime = userData.getJoinTime(player.getUniqueId());
/*  47 */       if (System.currentTimeMillis() - joinTime < (this.onJoinDisabledTime * 1000))
/*     */         return; 
/*  51 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.flight")))
/*     */         return; 
/*  55 */       if (isHighLatency(user.getPlayer()))
/*     */         return; 
/*  59 */       if (wrappedPacket.isFlying()) {
/*  61 */         this.movementEngine.updateCoordinates(wrappedPacket);
/*  64 */         double deltaY = this.movementEngine.getDeltaY();
/*  66 */         String debugInfo = String.valueOf(deltaY);
/*  68 */         if (deltaY > 20.0D)
/*     */           return; 
/*  72 */         if (deltaY > this.maxVerticalSpeed) {
/*  73 */           this.violations++;
/*  75 */           if (this.violations >= this.maxViolations)
/*     */             try {
/*  77 */               String playerAction = this.action.replace("%player%", user.getName());
/*  80 */               EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/*  85 */             } catch (Exception e) {
/*  86 */               e.printStackTrace();
/*     */             }  
/*  90 */           flag(user, "B", "High Y speed", this.violations, debugInfo);
/*  91 */           if (player != null)
/*  92 */             CheckLogger.log(player.getName(), "FLIGHT", "Type: B Debug:" + debugInfo); 
/*     */         } 
/*     */       } 
/*  98 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/*  99 */         this.violations = 0;
/* 100 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 106 */     if (player == null)
/* 107 */       return false; 
/* 111 */     int latency = Latency.getLag(player).intValue();
/* 114 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\FlightB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */