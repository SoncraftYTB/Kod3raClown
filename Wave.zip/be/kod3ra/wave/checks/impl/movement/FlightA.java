/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.FlightEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.LocationEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ @CheckInfo(name = "FLIGHT")
/*     */ public final class FlightA extends Check {
/*  28 */   private FlightEngine flightEngine = new FlightEngine();
/*     */   
/*  29 */   private LocationEngine locationEngine = new LocationEngine();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private int onJoinDisabledTime;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*  35 */   private final int SLIME_IGNORE_RADIUS = 5;
/*     */   
/*  36 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*  37 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public FlightA() {
/*  40 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  41 */     this.isEnabled = config.getBoolean("Checks.FlightA.ENABLED", true);
/*  42 */     this.onJoinDisabledTime = config.getInt("Checks.FlightA.ON-JOIN-DISABLED-TIME", 3);
/*  43 */     this.maxViolations = config.getInt("Checks.FlightA.MAX-VIOLATIONS", 20);
/*  44 */     this.action = config.getString("Checks.FlightA.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  45 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  50 */     if (!this.isEnabled)
/*     */       return; 
/*  54 */     Player player = user.getPlayer();
/*  55 */     UserData userData = Wave.getInstance().getUserData();
/*  57 */     if (player != null && System.currentTimeMillis() - userData.getJoinTime(player.getUniqueId()) > (this.onJoinDisabledTime * 1000)) {
/*  59 */       if (System.currentTimeMillis() - userData.getLastTeleportTime(player.getUniqueId()) < 3000L)
/*     */         return; 
/*  63 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.flight")))
/*     */         return; 
/*  67 */       if (wrappedPacket.isFlying()) {
/*  68 */         Location currentLocation = this.locationEngine.getCurrentLocation(player);
/*  69 */         Location previousGroundLocation = this.locationEngine.getPreviousGroundLocation();
/*  70 */         boolean isFlying = this.flightEngine.isFlying(wrappedPacket);
/*  72 */         if (previousGroundLocation == null || currentLocation == null) {
/*  74 */           this.locationEngine.updatePreviousLocations(player);
/*     */           return;
/*     */         } 
/*  78 */         if (player.getFallDistance() > 0.0F)
/*     */           return; 
/*  82 */         if (isHighLatency(user.getPlayer()))
/*     */           return; 
/*  86 */         Vector velocity = player.getVelocity();
/*  87 */         if (velocity.getY() > -1.0D)
/*     */           return; 
/*  91 */         if (hasSolidBlockNearby(player, currentLocation, 5))
/*     */           return; 
/*  95 */         if (isFlying) {
/*  96 */           this.violations++;
/*  98 */           SetbackEngine.performSetback(user.getPlayer());
/* 100 */           if (this.violations >= this.maxViolations)
/*     */             try {
/* 102 */               String playerAction = this.action.replace("%player%", user.getName());
/* 105 */               EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 110 */             } catch (Exception e) {
/* 111 */               e.printStackTrace();
/*     */             }  
/* 115 */           String debugInfo = "No debug for FlightA";
/* 116 */           flag(user, "A", "Flying in the air", this.violations, debugInfo);
/* 117 */           if (player != null)
/* 118 */             CheckLogger.log(player.getName(), "FLIGHT", "Type: A Debug:" + debugInfo); 
/*     */         } 
/*     */       } 
/* 124 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 125 */         this.violations = 0;
/* 126 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasSolidBlockNearby(Player player, Location location, int radius) {
/* 132 */     double x = location.getX();
/* 133 */     double y = location.getY();
/* 134 */     double z = location.getZ();
/* 137 */     World world = location.getWorld();
/* 140 */     for (int offsetX = -radius; offsetX <= radius; offsetX++) {
/* 141 */       for (int offsetY = -radius; offsetY <= radius; offsetY++) {
/* 142 */         for (int offsetZ = -radius; offsetZ <= radius; offsetZ++) {
/* 144 */           Block block = world.getBlockAt((int)x + offsetX, (int)y + offsetY, (int)z + offsetZ);
/* 146 */           if (isSolidBlock(block))
/* 147 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 153 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isSolidBlock(Block block) {
/* 157 */     return (block.getType().isSolid() || block.isLiquid());
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 161 */     if (player == null)
/* 162 */       return false; 
/* 166 */     int latency = Latency.getLag(player).intValue();
/* 169 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\FlightA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */