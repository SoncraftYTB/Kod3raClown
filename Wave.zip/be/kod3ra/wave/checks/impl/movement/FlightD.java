/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.engine.GroundEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "FLIGHT")
/*     */ public final class FlightD extends Check {
/*     */   private long lastGroundedTime;
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*  26 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private int groundTime;
/*     */   
/*     */   private String action;
/*     */   
/*  30 */   private long ignoreTime = 2000L;
/*     */   
/*     */   private long lastIgnoreTime;
/*     */   
/*  32 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public FlightD() {
/*  35 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  36 */     this.isEnabled = config.getBoolean("Checks.FlightD.ENABLED", true);
/*  37 */     this.maxViolations = config.getInt("Checks.FlightD.MAX-VIOLATIONS", 65);
/*  38 */     this.groundTime = config.getInt("Checks.FlightD.GROUND-TIME", 2750);
/*  39 */     this.action = config.getString("Checks.FlightD.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  40 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  45 */     if (!this.isEnabled)
/*     */       return; 
/*  49 */     Player player = user.getPlayer();
/*  51 */     if (wrappedPacket.isFlying()) {
/*  53 */       if (player.getFallDistance() > 0.0F)
/*     */         return; 
/*  57 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.flight")))
/*     */         return; 
/*  62 */       if (hasSolidBlockNearby(user.getPlayer().getLocation())) {
/*  63 */         this.lastIgnoreTime = System.currentTimeMillis();
/*     */         return;
/*     */       } 
/*  67 */       if (isHighLatency(user.getPlayer()))
/*     */         return; 
/*  71 */       if (GroundEngine.isServerOnGround(player)) {
/*  72 */         this.lastGroundedTime = System.currentTimeMillis();
/*  73 */       } else if (System.currentTimeMillis() - this.lastGroundedTime > this.groundTime && System.currentTimeMillis() - this.lastIgnoreTime > this.ignoreTime) {
/*  74 */         this.violations++;
/*  76 */         String debugInfo = String.valueOf("Last ground time: " + this.lastGroundedTime);
/*  77 */         flag(user, "D", "Is not on the ground for more than 2.75 seconds.", this.violations, debugInfo);
/*  78 */         if (player != null)
/*  79 */           CheckLogger.log(player.getName(), "FLIGHT", "Type: D Debug:" + debugInfo); 
/*  83 */         if (this.violations >= this.maxViolations)
/*     */           try {
/*  85 */             String playerAction = this.action.replace("%player%", user.getName());
/*  88 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/*  93 */           } catch (Exception e) {
/*  94 */             e.printStackTrace();
/*     */           }  
/*     */       } 
/*     */     } 
/* 100 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 101 */       this.violations = 0;
/* 102 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasSolidBlockNearby(Location location) {
/* 108 */     for (int x = -1; x <= 1; x++) {
/* 109 */       for (int y = -1; y <= 1; y++) {
/* 110 */         for (int z = -1; z <= 1; z++) {
/* 111 */           Block nearbyBlock = location.getBlock().getRelative(x, y, z);
/* 112 */           Material blockType = nearbyBlock.getType();
/* 115 */           if (!isAir(blockType))
/* 116 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 122 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isAir(Material material) {
/* 126 */     return (material == Material.AIR);
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 130 */     if (player == null)
/* 131 */       return false; 
/* 135 */     int latency = Latency.getLag(player).intValue();
/* 138 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\FlightD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */