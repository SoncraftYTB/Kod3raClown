/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.MovementEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "FLIGHT")
/*     */ public final class FlightC extends Check {
/*  20 */   private final MovementEngine movementEngine = new MovementEngine();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private double minVerticalSpeed;
/*     */   
/*     */   private int onJoinDisabledTime;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*  26 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private String action;
/*     */   
/*  28 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public FlightC() {
/*  31 */     this.isEnabled = Wave.getInstance().getConfig().getBoolean("Checks.FlightC.ENABLED", true);
/*  32 */     this.minVerticalSpeed = Wave.getInstance().getConfig().getDouble("Checks.FlightC.MAXIMUM-INVERTED-VERTICAL-SPEED", -5.0D);
/*  33 */     this.onJoinDisabledTime = Wave.getInstance().getConfig().getInt("Checks.FlightC.ON-JOIN-DISABLED-TIME", 5);
/*  34 */     this.maxViolations = Wave.getInstance().getConfig().getInt("Checks.FlightC.MAX-VIOLATIONS", 20);
/*  35 */     this.action = Wave.getInstance().getConfig().getString("Checks.FlightC.ACTION", "wavekick %player%");
/*  36 */     this.violationsResetTime = Wave.getInstance().getConfig().getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  41 */     if (this.isEnabled) {
/*  42 */       Player player = user.getPlayer();
/*  43 */       UserData userData = Wave.getInstance().getUserData();
/*  44 */       long joinTime = userData.getJoinTime(player.getUniqueId());
/*  47 */       if (System.currentTimeMillis() - joinTime < (this.onJoinDisabledTime * 1000))
/*     */         return; 
/*  51 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.flight")))
/*     */         return; 
/*  55 */       if (wrappedPacket.isFlying()) {
/*  57 */         this.movementEngine.updateCoordinates(wrappedPacket);
/*  60 */         double deltaY = this.movementEngine.getDeltaY();
/*  62 */         String debugInfo = String.valueOf(deltaY);
/*  64 */         if (deltaY > 20.0D)
/*     */           return; 
/*  68 */         if (isHighLatency(user.getPlayer()))
/*     */           return; 
/*  72 */         if (deltaY < -20.0D)
/*     */           return; 
/*  77 */         if (deltaY < this.minVerticalSpeed) {
/*  78 */           this.violations++;
/*  80 */           if (this.violations >= this.maxViolations)
/*     */             try {
/*  82 */               String playerAction = this.action.replace("%player%", user.getName());
/*  85 */               EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/*  90 */             } catch (Exception e) {
/*  91 */               e.printStackTrace();
/*     */             }  
/*  95 */           flag(user, "C", "High inverted Y speed", this.violations, debugInfo);
/*  96 */           if (player != null)
/*  97 */             CheckLogger.log(player.getName(), "FLIGHT", "Type: C Debug:" + debugInfo); 
/*     */         } 
/*     */       } 
/* 103 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 104 */         this.violations = 0;
/* 105 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 111 */     if (player == null)
/* 112 */       return false; 
/* 116 */     int latency = Latency.getLag(player).intValue();
/* 119 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\FlightC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */