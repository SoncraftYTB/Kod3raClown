/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.MovementEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ @CheckInfo(name = "SPEED")
/*     */ public final class SpeedA extends Check {
/*  26 */   private final MovementEngine movementEngine = new MovementEngine();
/*     */   
/*  27 */   private long ignoreTimeStart = 0L;
/*     */   
/*  28 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private double maxValue;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private int onJoinDisabledTime;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*  35 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public SpeedA() {
/*  38 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  39 */     this.isEnabled = config.getBoolean("Checks.SpeedA.ENABLED", true);
/*  40 */     this.maxValue = config.getDouble("Checks.SpeedA.MAX-SPEED", 0.6141742081626725D);
/*  41 */     this.maxViolations = config.getInt("Checks.SpeedA.MAX-VIOLATIONS", 20);
/*  42 */     this.onJoinDisabledTime = config.getInt("Checks.SpeedA.ON-JOIN-DISABLED-TIME", 15);
/*  43 */     this.action = config.getString("Checks.SpeedA.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  44 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  49 */     if (!this.isEnabled)
/*     */       return; 
/*  51 */     Player player = user.getPlayer();
/*  52 */     UserData userData = Wave.getInstance().getUserData();
/*  54 */     if (player == null)
/*     */       return; 
/*  58 */     if (System.currentTimeMillis() - userData.getLastDamageTime(player.getUniqueId()) < 1500L)
/*     */       return; 
/*  62 */     long joinTime = userData.getJoinTime(player.getUniqueId());
/*  63 */     if (System.currentTimeMillis() - joinTime < (this.onJoinDisabledTime * 1000))
/*     */       return; 
/*  67 */     if (hasIceOrTrapdoorAround(player, 3) || isBlockAboveHeadSolid(player, 3)) {
/*  68 */       this.ignoreTimeStart = System.currentTimeMillis() + 3000L;
/*     */       return;
/*     */     } 
/*  72 */     if (wrappedPacket.isFlying() && !isHighLatency(player) && !isBypassed(player)) {
/*  73 */       double deltaXZ = this.movementEngine.getDeltaXZ(wrappedPacket);
/*  76 */       if (hasSpeedEffect(player)) {
/*  78 */         if (deltaXZ > 0.68D && deltaXZ <= 1.37D) {
/*  79 */           this.violations++;
/*  80 */           flag(user, "A", "High deltaXZ", this.violations, "DeltaXZ: " + deltaXZ);
/*  81 */           this.ignoreTimeStart = System.currentTimeMillis();
/*  83 */           if (this.violations >= this.maxViolations)
/*  84 */             handleViolation(user); 
/*     */         } 
/*  89 */       } else if (deltaXZ > this.maxValue && deltaXZ <= 1.37D) {
/*  90 */         this.violations++;
/*  91 */         flag(user, "A", "High deltaXZ", this.violations, "DeltaXZ: " + deltaXZ);
/*  92 */         if (player != null)
/*  93 */           CheckLogger.log(player.getName(), "SPEED", "Type: A Debug:" + deltaXZ); 
/*  96 */         this.ignoreTimeStart = System.currentTimeMillis();
/*  98 */         if (this.violations >= this.maxViolations)
/*  99 */           handleViolation(user); 
/*     */       } 
/*     */     } 
/* 105 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 106 */       this.violations = 0;
/* 107 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasIceOrTrapdoorAround(Player player, int radius) {
/* 112 */     Location playerLocation = player.getLocation();
/* 113 */     int playerX = playerLocation.getBlockX();
/* 114 */     int playerY = playerLocation.getBlockY();
/* 115 */     int playerZ = playerLocation.getBlockZ();
/* 118 */     for (int x = playerX - radius; x <= playerX + radius; x++) {
/* 119 */       for (int y = playerY - radius; y <= playerY + radius; y++) {
/* 120 */         for (int z = playerZ - radius; z <= playerZ + radius; z++) {
/* 121 */           Block block = player.getWorld().getBlockAt(x, y, z);
/* 124 */           String blockTypeName = block.getType().name();
/* 125 */           if (blockTypeName.contains("TRAPDOOR") || blockTypeName.contains("TRAP_DOOR") || blockTypeName.contains("ICE"))
/* 126 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 132 */     return false;
/*     */   }
/*     */   
/*     */   private boolean hasSpeedEffect(Player player) {
/* 137 */     for (PotionEffect effect : player.getActivePotionEffects()) {
/* 138 */       if (effect.getType().equals(PotionEffectType.SPEED)) {
/* 139 */         int amplifier = effect.getAmplifier();
/* 140 */         if (amplifier == 1 || amplifier == 2)
/* 141 */           return true; 
/* 142 */         if (amplifier >= 3)
/* 143 */           return false; 
/*     */       } 
/*     */     } 
/* 147 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isBlockAboveHeadSolid(Player player, int radius) {
/* 151 */     Location playerLocation = player.getLocation();
/* 152 */     int playerX = playerLocation.getBlockX();
/* 153 */     int playerY = playerLocation.getBlockY();
/* 154 */     int playerZ = playerLocation.getBlockZ();
/* 157 */     for (int y = playerY + 1; y <= playerY + radius; y++) {
/* 158 */       Block blockAboveHead = player.getWorld().getBlockAt(playerX, y, playerZ);
/* 161 */       if (blockAboveHead.getType().isSolid())
/* 162 */         return true; 
/*     */     } 
/* 166 */     return false;
/*     */   }
/*     */   
/*     */   private void handleViolation(User user) {
/* 170 */     if (this.violations >= this.maxViolations)
/*     */       try {
/* 172 */         String playerAction = this.action.replace("%player%", user.getName());
/* 175 */         EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 180 */       } catch (Exception e) {
/* 181 */         e.printStackTrace();
/*     */       }  
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 187 */     if (player == null)
/* 188 */       return false; 
/* 192 */     int latency = Latency.getLag(player).intValue();
/* 195 */     return (latency > 200);
/*     */   }
/*     */   
/*     */   private boolean isBypassed(Player player) {
/* 199 */     return (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.speed"));
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\SpeedA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */