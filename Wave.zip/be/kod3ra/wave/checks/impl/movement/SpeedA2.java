/*     */ package be.kod3ra.wave.checks.impl.movement;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.MovementEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.LocationEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "SPEED")
/*     */ public final class SpeedA2 extends Check {
/*  26 */   private MovementEngine movementEngine = new MovementEngine();
/*     */   
/*  27 */   private LocationEngine locationEngine = new LocationEngine();
/*     */   
/*  28 */   private long lastViolationTime = 0L;
/*     */   
/*  29 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private double maxValue;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*  35 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public SpeedA2() {
/*  38 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  39 */     this.isEnabled = config.getBoolean("Checks.SpeedA2.ENABLED", true);
/*  40 */     this.maxValue = config.getDouble("Checks.SpeedA2.MAX-SPEED", 1.3882D);
/*  41 */     this.maxViolations = config.getInt("Checks.SpeedA2.MAX-VIOLATIONS", 20);
/*  42 */     this.action = config.getString("Checks.SpeedA2.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  43 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  48 */     if (this.isEnabled) {
/*  49 */       Player player = user.getPlayer();
/*  50 */       UserData userData = Wave.getInstance().getUserData();
/*  52 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.speed")))
/*     */         return; 
/*  56 */       if (isHighLatency(user.getPlayer()))
/*     */         return; 
/*  60 */       if (System.currentTimeMillis() - userData.getLastTeleportTime(player.getUniqueId()) < 4500L)
/*     */         return; 
/*  65 */       if (wrappedPacket.isFlying()) {
/*  66 */         double deltaXZ = this.movementEngine.getDeltaXZ(wrappedPacket);
/*  68 */         if (deltaXZ > 190.0D)
/*     */           return; 
/*  72 */         if (deltaXZ > this.maxValue) {
/*  73 */           this.violations++;
/*  75 */           SetbackEngine.performSetback(user.getPlayer());
/*  77 */           if (this.violations >= this.maxViolations)
/*     */             try {
/*  79 */               String playerAction = this.action.replace("%player%", user.getName());
/*  82 */               EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/*  87 */             } catch (Exception e) {
/*  88 */               e.printStackTrace();
/*     */             }  
/*  92 */           String debugInfo = String.valueOf(deltaXZ);
/*  94 */           flag(user, "A2", "Very high BPS and rotation", this.violations, debugInfo);
/*  95 */           if (player != null)
/*  96 */             CheckLogger.log(player.getName(), "SPEED", "Type: A2 Debug:" + debugInfo); 
/*  99 */           this.lastViolationTime = System.currentTimeMillis();
/*     */         } 
/*     */       } 
/* 103 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 104 */         this.violations = 0;
/* 105 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 111 */     if (player == null)
/* 112 */       return false; 
/* 116 */     int latency = Latency.getLag(player).intValue();
/* 119 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\movement\SpeedA2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */