/*     */ package be.kod3ra.wave.checks.impl.player;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "BADPACKETS")
/*     */ public final class BadPacketsB extends Check {
/*     */   private boolean isEnabled;
/*     */   
/*     */   private int maxPitch;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*  28 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*  29 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public BadPacketsB() {
/*  32 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  33 */     this.isEnabled = config.getBoolean("Checks.BadPacketsB.ENABLED");
/*  34 */     this.maxPitch = config.getInt("Checks.BadPacketsB.MAX-PITCH");
/*  35 */     this.maxViolations = config.getInt("Checks.BadPacketsB.MAX-VIOLATIONS");
/*  36 */     this.action = config.getString("Checks.BadPacketsB.ACTION");
/*  37 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  42 */     if (this.isEnabled && (wrappedPacket.isRotation() || wrappedPacket.isMovingAndRotation())) {
/*  43 */       Player player = user.getPlayer();
/*  44 */       UserData userData = Wave.getInstance().getUserData();
/*  46 */       float playerPitch = player.getLocation().getPitch();
/*  48 */       if (isHighLatency(user.getPlayer()))
/*     */         return; 
/*  52 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.badpackets")))
/*     */         return; 
/*  57 */       if (playerPitch > this.maxPitch) {
/*  58 */         this.violations++;
/*  60 */         SetbackEngine.performSetback(user.getPlayer());
/*  62 */         String debugInfo = String.valueOf("Pitch: " + playerPitch);
/*  63 */         flag(user, "B", "Invalid Pitch", this.violations, debugInfo);
/*  64 */         if (player != null)
/*  65 */           CheckLogger.log(player.getName(), "BADPACKETS", "Type: B Debug:" + debugInfo); 
/*  68 */         if (this.violations >= this.maxViolations)
/*     */           try {
/*  70 */             String playerAction = this.action.replace("%player%", user.getName());
/*  73 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/*  78 */           } catch (Exception e) {
/*  79 */             e.printStackTrace();
/*     */           }  
/*     */       } 
/*     */     } 
/*  85 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/*  86 */       this.violations = 0;
/*  87 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/*  92 */     if (player == null)
/*  93 */       return false; 
/*  97 */     int latency = Latency.getLag(player).intValue();
/* 100 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\player\BadPacketsB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */