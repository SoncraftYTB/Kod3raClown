/*     */ package be.kod3ra.wave.checks.impl.player;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.MovementEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.LocationEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "TIMER")
/*     */ public class TimerA extends Check {
/*     */   private MovementEngine movementEngine;
/*     */   
/*  25 */   private LocationEngine locationEngine = new LocationEngine();
/*     */   
/*     */   private int packetCount;
/*     */   
/*     */   private int maxPackets;
/*     */   
/*     */   private String action;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private int onJoinDisabledTime;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*  32 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*  33 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   public TimerA() {
/*  37 */     this.movementEngine = new MovementEngine();
/*  38 */     this.packetCount = 0;
/*  41 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  42 */     this.isEnabled = config.getBoolean("Checks.TimerA.ENABLED", true);
/*  43 */     this.maxPackets = config.getInt("Checks.TimerA.MAX-PACKETS", 26);
/*  44 */     this.maxViolations = config.getInt("Checks.TimerA.MAX-VIOLATIONS", 60);
/*  45 */     this.action = config.getString("Checks.TimerA.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  46 */     this.onJoinDisabledTime = config.getInt("Checks.TimerA.ON-JOIN-DISABLED-TIME", 7);
/*  47 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*  50 */     Bukkit.getScheduler().runTaskTimer((Plugin)Wave.getInstance(), () -> this.packetCount = 0, 0L, 20L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  55 */     if (this.isEnabled && (
/*  56 */       wrappedPacket.isMovingAndRotation() || wrappedPacket.isRotation() || wrappedPacket.isMoving())) {
/*  58 */       Player player = user.getPlayer();
/*  59 */       UserData userData = Wave.getInstance().getUserData();
/*  61 */       Location currentLocation = this.locationEngine.getCurrentLocation(player);
/*  62 */       Location previousGroundLocation = this.locationEngine.getPreviousGroundLocation();
/*  64 */       if (user.getPlayer().getInventory().getItemInHand().getType().toString().contains("BOW"))
/*     */         return; 
/*  68 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.timer")))
/*     */         return; 
/*  72 */       if (previousGroundLocation == null || currentLocation == null) {
/*  74 */         this.locationEngine.updatePreviousLocations(player);
/*     */         return;
/*     */       } 
/*  78 */       long joinTime = userData.getJoinTime(player.getUniqueId());
/*  81 */       if (System.currentTimeMillis() - joinTime < (this.onJoinDisabledTime * 1000))
/*     */         return; 
/*  85 */       this.packetCount++;
/*  87 */       if (this.packetCount > this.maxPackets) {
/*  88 */         this.violations++;
/*  90 */         SetbackEngine.performSetback(user.getPlayer());
/*  92 */         String debugInfo = "Packet count: " + this.packetCount;
/*  93 */         flag(user, "A", "Modified the time", this.violations, debugInfo);
/*  94 */         if (player != null)
/*  95 */           CheckLogger.log(player.getName(), "TIMER", "Type: A Debug:" + debugInfo); 
/*  98 */         if (this.violations >= this.maxViolations)
/*     */           try {
/* 100 */             String playerAction = this.action.replace("%player%", user.getName());
/* 103 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 108 */           } catch (Exception e) {
/* 109 */             e.printStackTrace();
/*     */           }  
/*     */       } 
/* 114 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 115 */         this.violations = 0;
/* 116 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/* 119 */       this.movementEngine.updateCoordinates(wrappedPacket);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 125 */     if (player == null)
/* 126 */       return false; 
/* 130 */     int latency = Latency.getLag(player).intValue();
/* 133 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\player\TimerA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */