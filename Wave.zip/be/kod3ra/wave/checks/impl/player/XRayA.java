/*    */ package be.kod3ra.wave.checks.impl.player;
/*    */ 
/*    */ import be.kod3ra.wave.checks.Check;
/*    */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*    */ import be.kod3ra.wave.packet.WrappedPacket;
/*    */ import be.kod3ra.wave.user.User;
/*    */ import be.kod3ra.wave.user.UserManager;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ 
/*    */ @CheckInfo(name = "XRAY")
/*    */ public final class XRayA extends Check {
/*    */   private final UserManager userManager;
/*    */   
/* 21 */   private final Map<UUID, Integer> diamondCounter = new HashMap<>();
/*    */   
/* 22 */   private final int diamondThreshold = 9;
/*    */   
/* 23 */   private final long detectionInterval = 45000L;
/*    */   
/*    */   public XRayA() {
/* 26 */     this.userManager = new UserManager();
/*    */   }
/*    */   
/*    */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/* 31 */     Player player = user.getPlayer();
/* 32 */     if (wrappedPacket.isDigging())
/* 34 */       handleBlockBreakEvent(user, null); 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onBlockBreakEvent(BlockBreakEvent event) {
/* 40 */     Player player = event.getPlayer();
/* 42 */     if (player != null)
/* 44 */       handleBlockBreakEvent(getUser(player), event); 
/*    */   }
/*    */   
/*    */   private void handleBlockBreakEvent(User user, BlockBreakEvent event) {
/* 49 */     Player player = user.getPlayer();
/* 50 */     UUID playerId = player.getUniqueId();
/* 52 */     Block brokenBlock = player.getTargetBlock(null, 5);
/* 54 */     if (brokenBlock.getType() == Material.DIAMOND_ORE && event.getBlock().getType() == Material.AIR) {
/* 56 */       this.diamondCounter.put(playerId, Integer.valueOf(((Integer)this.diamondCounter.getOrDefault(playerId, Integer.valueOf(0))).intValue() + 1));
/* 59 */       if (((Integer)this.diamondCounter.getOrDefault(playerId, (V)Integer.valueOf(0))).intValue() >= 9) {
/* 61 */         String debugInfo = "Player mined 9 diamond ores within 45 seconds";
/* 63 */         flag(user, "A", "XRay", 1, debugInfo);
/* 66 */         this.diamondCounter.put(playerId, Integer.valueOf(0));
/*    */       } 
/*    */     } 
/* 71 */     if (System.currentTimeMillis() - user.getLastXRayDetectionTime() > 45000L) {
/* 72 */       this.diamondCounter.put(playerId, Integer.valueOf(0));
/* 73 */       user.setLastXRayDetectionTime(System.currentTimeMillis());
/*    */     } 
/*    */   }
/*    */   
/*    */   private User getUser(Player player) {
/* 79 */     return this.userManager.getUser(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\player\XRayA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */