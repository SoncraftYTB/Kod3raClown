/*     */ package be.kod3ra.wave.checks.impl.player;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.engine.MovementEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "FASTBOW")
/*     */ public class FastBowA extends Check {
/*     */   private MovementEngine movementEngine;
/*     */   
/*     */   private int packetCount;
/*     */   
/*     */   private int maxPackets;
/*     */   
/*     */   private Timer timer;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private String action;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*  31 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*  32 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public FastBowA() {
/*  35 */     this.movementEngine = new MovementEngine();
/*  36 */     this.packetCount = 0;
/*  38 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  39 */     this.maxPackets = config.getInt("Checks.FastBowA.MAX-PACKETS", 30);
/*  40 */     this.maxViolations = config.getInt("Checks.FastBowA.MAX-VIOLATIONS", 60);
/*  41 */     this.action = config.getString("Checks.FastBowA.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  42 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*  45 */     this.timer = new Timer();
/*  46 */     this.timer.scheduleAtFixedRate(new TimerTask() {
/*     */           public void run() {
/*  49 */             FastBowA.this.packetCount = 0;
/*     */           }
/*     */         },  1000L, 1000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*     */     ItemStack item;
/*  56 */     Player player = user.getPlayer();
/*     */     try {
/*  61 */       item = player.getInventory().getItemInMainHand();
/*  62 */     } catch (NoSuchMethodError e) {
/*  64 */       item = player.getItemInHand();
/*     */     } 
/*  67 */     if (item != null && !item.getType().toString().contains("BOW"))
/*     */       return; 
/*  71 */     if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.fastbow")))
/*     */       return; 
/*  75 */     if (isHighLatency(user.getPlayer()))
/*     */       return; 
/*  80 */     if (wrappedPacket.isMovingAndRotation() || wrappedPacket.isRotation()) {
/*  81 */       this.packetCount++;
/*  83 */       if (this.packetCount > this.maxPackets) {
/*  84 */         this.violations++;
/*  86 */         SetbackEngine.performSetback(user.getPlayer());
/*  88 */         String debugInfo = "Packet count: " + this.packetCount;
/*  89 */         flag(user, "A", "Modified bow shoot time", this.violations, debugInfo);
/*  90 */         if (player != null)
/*  91 */           CheckLogger.log(player.getName(), "FASTBOW", "Type: A Debug:" + debugInfo); 
/*  95 */         if (this.violations >= this.maxViolations)
/*     */           try {
/*  97 */             String playerAction = this.action.replace("%player%", user.getName());
/* 100 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 105 */           } catch (Exception e) {
/* 106 */             e.printStackTrace();
/*     */           }  
/*     */       } 
/* 111 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 112 */         this.violations = 0;
/* 113 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/* 117 */       this.movementEngine.updateCoordinates(wrappedPacket);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 122 */     if (player == null)
/* 123 */       return false; 
/* 127 */     int latency = Latency.getLag(player).intValue();
/* 130 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\player\FastBowA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */