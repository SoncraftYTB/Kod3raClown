/*     */ package be.kod3ra.wave.checks.impl.player;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import java.util.LinkedList;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "BADPACKETS")
/*     */ public final class BadPacketsA extends Check {
/*     */   private static final int MAX_HISTORY_SIZE = 20000;
/*     */   
/*  23 */   private final LinkedList<Long> packetTimes = new LinkedList<>();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private int maxPacketsPerSecond;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*  30 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*  31 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public BadPacketsA() {
/*  34 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  35 */     this.isEnabled = config.getBoolean("Checks.BadPacketsA.ENABLED", true);
/*  36 */     this.maxPacketsPerSecond = config.getInt("Checks.BadPacketsA.MAX-PACKETS-PER-SECOND", 100);
/*  37 */     this.maxViolations = config.getInt("Checks.BadPacketsA.MAX-VIOLATIONS", 40);
/*  38 */     this.action = config.getString("Checks.BadPacketsA.ACTION", "wavekick %player%");
/*  39 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  44 */     if (this.isEnabled && wrappedPacket.allPackets()) {
/*  45 */       this.packetTimes.add(Long.valueOf(System.currentTimeMillis()));
/*  47 */       Player player = user.getPlayer();
/*  48 */       UserData userData = Wave.getInstance().getUserData();
/*  50 */       while (this.packetTimes.size() > 20000)
/*  51 */         this.packetTimes.removeFirst(); 
/*  54 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.badpackets")))
/*     */         return; 
/*  58 */       if (isHighLatency(user.getPlayer()))
/*     */         return; 
/*  62 */       int packetsPerSecond = calculatePacketsPerSecond();
/*  64 */       if (packetsPerSecond > this.maxPacketsPerSecond) {
/*  66 */         String debugInfo = "Packets per second: " + packetsPerSecond;
/*  67 */         flag(user, "A", "High packet rate", this.violations, debugInfo);
/*  68 */         this.violations++;
/*  70 */         SetbackEngine.performSetback(user.getPlayer());
/*  72 */         if (player != null)
/*  73 */           CheckLogger.log(player.getName(), "BADPACKETS", "Type: A Debug:" + debugInfo); 
/*  77 */         if (this.violations >= this.maxViolations)
/*     */           try {
/*  79 */             String playerAction = this.action.replace("%player%", user.getName());
/*  82 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/*  87 */           } catch (Exception e) {
/*  88 */             e.printStackTrace();
/*     */           }  
/*     */       } 
/*  93 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/*  94 */         this.violations = 0;
/*  95 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int calculatePacketsPerSecond() {
/* 101 */     long currentTime = System.currentTimeMillis();
/* 102 */     long oldestTime = (this.packetTimes.size() > 0) ? ((Long)this.packetTimes.getFirst()).longValue() : currentTime;
/* 104 */     while (!this.packetTimes.isEmpty() && currentTime - oldestTime > 1000L) {
/* 105 */       this.packetTimes.removeFirst();
/* 106 */       oldestTime = (this.packetTimes.size() > 0) ? ((Long)this.packetTimes.getFirst()).longValue() : currentTime;
/*     */     } 
/* 109 */     return this.packetTimes.size();
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 113 */     if (player == null)
/* 114 */       return false; 
/* 118 */     int latency = Latency.getLag(player).intValue();
/* 121 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\player\BadPacketsA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */