/*     */ package be.kod3ra.wave.checks.impl.player;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import com.github.retrooper.packetevents.protocol.player.DiggingAction;
/*     */ import com.github.retrooper.packetevents.protocol.world.Location;
/*     */ import com.github.retrooper.packetevents.util.Vector3d;
/*     */ import com.github.retrooper.packetevents.util.Vector3i;
/*     */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerDigging;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "BADPACKETS")
/*     */ public final class BadPacketsC extends Check {
/*  24 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private String action;
/*     */   
/*  28 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   public BadPacketsC() {
/*  32 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  33 */     this.isEnabled = config.getBoolean("Checks.BadPacketsC.ENABLED", true);
/*  34 */     this.maxViolations = config.getInt("Checks.BadPacketsC.MAX-VIOLATIONS", 60);
/*  35 */     this.action = config.getString("Checks.BadPacketsC.ACTION", "wavekick %player%");
/*  36 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   private double distance(Location loc1, Location loc2) {
/*  40 */     if (loc1 == null || loc2 == null)
/*  41 */       return 0.0D; 
/*  44 */     double dx = loc1.getX() - loc2.getX();
/*  45 */     double dy = loc1.getY() - loc2.getY();
/*  46 */     double dz = loc1.getZ() - loc2.getZ();
/*  48 */     return Math.sqrt(dx * dx + dy * dy + dz * dz);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  53 */     Player player = user.getPlayer();
/*  54 */     UserData userData = Wave.getInstance().getUserData();
/*  55 */     if (!this.isEnabled)
/*     */       return; 
/*  59 */     if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.badpackets")))
/*     */       return; 
/*  63 */     if (wrappedPacket.isDigging()) {
/*  64 */       WrapperPlayClientPlayerDigging blockPosition = new WrapperPlayClientPlayerDigging(wrappedPacket.getPacketReceiveEvent());
/*  65 */       WrapperPlayClientPlayerDigging blockAction = new WrapperPlayClientPlayerDigging(wrappedPacket.getPacketReceiveEvent());
/*  67 */       if (blockAction.getAction() != DiggingAction.START_DIGGING)
/*     */         return; 
/*  71 */       Vector3i vector = blockPosition.getBlockPosition();
/*  72 */       Vector3d vectorD = new Vector3d(vector.getX(), vector.getY(), vector.getZ());
/*  73 */       Location location = new Location(vectorD, 0.0F, 0.0F);
/*  76 */       Location bukkitLocation = user.getPlayer().getLocation();
/*  82 */       Location packetEventsLocation = new Location(bukkitLocation.getX(), bukkitLocation.getY(), bukkitLocation.getZ(), bukkitLocation.getYaw(), bukkitLocation.getPitch());
/*  85 */       if (isHighLatency(user.getPlayer()))
/*     */         return; 
/*  90 */       if (location != null && distance(packetEventsLocation, location) > 7.0D) {
/*  91 */         this.violations++;
/*  93 */         SetbackEngine.performSetback(user.getPlayer());
/*  95 */         String debugInfo = "Location: " + location + " | Player Location: " + packetEventsLocation;
/*  96 */         flag(user, "C", "Invalid digging location packet. Distance > 6 blocks.", this.violations, debugInfo);
/*  97 */         if (player != null)
/*  98 */           CheckLogger.log(player.getName(), "BADPACKETS", "Type: C Debug:" + debugInfo); 
/* 101 */         if (this.violations >= this.maxViolations)
/*     */           try {
/* 103 */             String playerAction = this.action.replace("%player%", user.getName());
/* 106 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 111 */           } catch (Exception e) {
/* 112 */             e.printStackTrace();
/*     */           }  
/*     */       } 
/*     */     } 
/* 118 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 119 */       this.violations = 0;
/* 120 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 125 */     if (player == null)
/* 126 */       return false; 
/* 130 */     int latency = Latency.getLag(player).intValue();
/* 133 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\player\BadPacketsC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */