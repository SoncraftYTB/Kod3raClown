/*     */ package be.kod3ra.wave.checks.impl.combat;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "CRITICALS")
/*     */ public final class CriticalsA extends Check {
/*     */   private long lastFlyingTime;
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private int timeDifference;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*  30 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private String action;
/*     */   
/*  32 */   private long lastAttackTime = 0L;
/*     */   
/*  33 */   private long attackToleranceWindow = 3000L;
/*     */   
/*  34 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public CriticalsA() {
/*  37 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  38 */     this.isEnabled = config.getBoolean("Checks.CriticalsA.ENABLED", true);
/*  39 */     this.timeDifference = config.getInt("Checks.CriticalsA.TIME-DIFFERENCE", 1);
/*  40 */     this.maxViolations = config.getInt("Checks.CriticalsA.MAX-VIOLATIONS", 15);
/*  41 */     this.action = config.getString("Checks.CriticalsA.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  42 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  47 */     Player player = user.getPlayer();
/*  48 */     UserData userData = Wave.getInstance().getUserData();
/*  49 */     if (!this.isEnabled)
/*     */       return; 
/*  53 */     if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.criticals")))
/*     */       return; 
/*  57 */     if (isHighLatency(user.getPlayer()))
/*     */       return; 
/*  61 */     if (wrappedPacket.isAttacking()) {
/*  62 */       WrapperPlayClientInteractEntity wrapperPlayClientInteractEntity = new WrapperPlayClientInteractEntity(wrappedPacket.getPacketReceiveEvent());
/*  63 */       WrapperPlayClientInteractEntity.InteractAction attackaction = wrapperPlayClientInteractEntity.getAction();
/*  65 */       if (attackaction.equals(WrapperPlayClientInteractEntity.InteractAction.INTERACT) || attackaction.equals(WrapperPlayClientInteractEntity.InteractAction.INTERACT_AT)) {
/*  67 */         if (System.currentTimeMillis() - this.lastAttackTime < this.attackToleranceWindow)
/*     */           return; 
/*  71 */         if (!attackaction.equals(WrapperPlayClientInteractEntity.InteractAction.ATTACK))
/*     */           return; 
/*     */       } 
/*  76 */       if (attackaction.equals(WrapperPlayClientInteractEntity.InteractAction.ATTACK))
/*  77 */         this.lastAttackTime = System.currentTimeMillis(); 
/*     */     } 
/*  82 */     if (wrappedPacket.isFlying()) {
/*  83 */       this.lastFlyingTime = System.currentTimeMillis();
/*  84 */     } else if (wrappedPacket.isAttacking()) {
/*  86 */       long timeDifference = System.currentTimeMillis() - this.lastFlyingTime;
/*  88 */       if (timeDifference < this.timeDifference) {
/*  89 */         this.violations++;
/*  90 */         String debugInfo = String.valueOf(timeDifference);
/*  92 */         flag(user, "A", "Very fast flying packets when attacking", this.violations, debugInfo);
/*  93 */         if (player != null)
/*  94 */           CheckLogger.log(player.getName(), "CRITICALS", "Type: A Debug:" + debugInfo); 
/*  98 */         SetbackEngine.performSetback(user.getPlayer());
/* 100 */         if (this.violations >= this.maxViolations)
/*     */           try {
/* 102 */             String playerAction = this.action.replace("%player%", user.getName());
/* 105 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 110 */           } catch (Exception e) {
/* 111 */             e.printStackTrace();
/*     */           }  
/*     */       } 
/*     */     } 
/* 117 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 118 */       this.violations = 0;
/* 119 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 124 */     if (player == null)
/* 125 */       return false; 
/* 129 */     int latency = Latency.getLag(player).intValue();
/* 132 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\combat\CriticalsA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */