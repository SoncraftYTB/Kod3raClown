/*    */ package be.kod3ra.wave.checks.impl.combat;
/*    */ 
/*    */ import be.kod3ra.wave.checks.Check;
/*    */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*    */ import be.kod3ra.wave.packet.WrappedPacket;
/*    */ import be.kod3ra.wave.user.User;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ @CheckInfo(name = "AIM_ASSIST")
/*    */ public final class AimAssistA extends Check {
/* 14 */   private final Map<Player, Long> lastClickTimes = new HashMap<>();
/*    */   
/*    */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/* 18 */     Player player = user.getPlayer();
/* 19 */     if (!wrappedPacket.isAttacking() || wrappedPacket.isMovingAndRotation());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\combat\AimAssistA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */