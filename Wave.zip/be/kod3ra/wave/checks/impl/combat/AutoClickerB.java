/*     */ package be.kod3ra.wave.checks.impl.combat;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.CPSEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "AUTOCLICKER")
/*     */ public final class AutoClickerB extends Check {
/*     */   private CPSEngine cpsEngine;
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private int maxCps;
/*     */   
/*     */   private int Time;
/*     */   
/*     */   private String action;
/*     */   
/*  33 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*  34 */   private final Map<UUID, Long> ignoredPlayers = new HashMap<>();
/*     */   
/*  35 */   private final long ignoreDuration = 4000L;
/*     */   
/*  36 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public AutoClickerB() {
/*  39 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  40 */     this.isEnabled = config.getBoolean("Checks.AutoClickerB.ENABLED", true);
/*  41 */     this.maxCps = config.getInt("Checks.AutoClickerB.MAX-CPS-IN-FIRST-CLICKING", 5);
/*  42 */     this.Time = config.getInt("Checks.AutoClickerB.TIME-FOR-MAX-CPS-IN-FIRST-CLICKING", 175);
/*  43 */     this.maxViolations = config.getInt("Checks.AutoClickerB.MAX-VIOLATIONS", 5);
/*  44 */     this.action = config.getString("Checks.AutoClickerB.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  45 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*  47 */     this.cpsEngine = new CPSEngine(Wave.getInstance());
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  51 */     UUID userUUID = user.getPlayer().getUniqueId();
/*  52 */     Player player = user.getPlayer();
/*  53 */     UserData userData = Wave.getInstance().getUserData();
/*  55 */     if (this.isEnabled && wrappedPacket.isAttacking()) {
/*  56 */       if (shouldIgnorePlayer(userUUID))
/*     */         return; 
/*  60 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.autoclicker")))
/*     */         return; 
/*  64 */       if (wrappedPacket.isDigging() || isHighLatency(user.getPlayer())) {
/*  65 */         ignorePlayer(userUUID);
/*     */         return;
/*     */       } 
/*  69 */       if (wrappedPacket.isAttacking()) {
/*  70 */         WrapperPlayClientInteractEntity wrapperPlayClientInteractEntity = new WrapperPlayClientInteractEntity(wrappedPacket.getPacketReceiveEvent());
/*  71 */         WrapperPlayClientInteractEntity.InteractAction attackaction = wrapperPlayClientInteractEntity.getAction();
/*  73 */         if (!attackaction.equals(WrapperPlayClientInteractEntity.InteractAction.ATTACK))
/*     */           return; 
/*     */       } 
/*  78 */       long clickTime = System.currentTimeMillis();
/*  81 */       if (!this.cpsEngine.isClicking(userUUID))
/*  82 */         this.cpsEngine.startClick(userUUID); 
/*  85 */       this.cpsEngine.trackPlayerClick(userUUID, clickTime);
/*  86 */       int cps = this.cpsEngine.getCPS(userUUID, clickTime);
/*  88 */       String debugInfo = String.valueOf(cps);
/*  90 */       if (cps >= this.maxCps && clickTime - this.cpsEngine.getLastClickTime(userUUID) <= this.Time) {
/*  91 */         this.violations++;
/*  93 */         SetbackEngine.performSetback(user.getPlayer());
/*  95 */         if (this.violations >= this.maxViolations)
/*     */           try {
/*  97 */             String playerAction = this.action.replace("%player%", user.getName());
/* 100 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 105 */           } catch (Exception e) {
/* 106 */             e.printStackTrace();
/*     */           }  
/* 110 */         flag(user, "B", "High CPS in a short time", this.violations, debugInfo);
/* 111 */         if (player != null)
/* 112 */           CheckLogger.log(player.getName(), "AUTOCLICKER", "Type: B Debug:" + debugInfo); 
/*     */       } 
/* 117 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 118 */         this.violations = 0;
/* 119 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/* 122 */       if (!wrappedPacket.isAttacking())
/* 123 */         this.cpsEngine.endClick(userUUID); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean shouldIgnorePlayer(UUID userUUID) {
/* 129 */     return (this.ignoredPlayers.containsKey(userUUID) && System.currentTimeMillis() < ((Long)this.ignoredPlayers.get(userUUID)).longValue());
/*     */   }
/*     */   
/*     */   private void ignorePlayer(UUID userUUID) {
/* 133 */     this.ignoredPlayers.put(userUUID, Long.valueOf(System.currentTimeMillis() + 4000L));
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 137 */     if (player == null)
/* 138 */       return false; 
/* 142 */     int latency = Latency.getLag(player).intValue();
/* 145 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\combat\AutoClickerB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */