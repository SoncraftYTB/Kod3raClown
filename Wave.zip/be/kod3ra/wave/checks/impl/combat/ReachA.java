/*     */ package be.kod3ra.wave.checks.impl.combat;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.engine.ReachEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ @CheckInfo(name = "REACH")
/*     */ public class ReachA extends Check {
/*  28 */   private ReachEngine reachEngine = new ReachEngine();
/*     */   
/*  29 */   private Map<UUID, Player> lastAttackedPositions = new HashMap<>();
/*     */   
/*  30 */   private Map<UUID, Long> lastDetectionTimes = new HashMap<>();
/*     */   
/*     */   private static final long DETECTION_DELAY = 2000L;
/*     */   
/*  32 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private double maxReachDistance;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*  38 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public ReachA() {
/*  41 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  42 */     this.isEnabled = config.getBoolean("Checks.ReachA.ENABLED", true);
/*  43 */     this.maxReachDistance = config.getDouble("Checks.ReachA.MAX-REACH-DISTANCE", 4.0D);
/*  44 */     this.maxViolations = config.getInt("Checks.ReachA.MAX-VIOLATIONS", 20);
/*  45 */     this.action = config.getString("Checks.ReachA.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  46 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  51 */     Player player = user.getPlayer();
/*  52 */     if (this.isEnabled && wrappedPacket.isAttacking()) {
/*  53 */       Player attacker = user.getPlayer();
/*  55 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.reach")))
/*     */         return; 
/*  59 */       if (wrappedPacket.isAttacking()) {
/*  60 */         WrapperPlayClientInteractEntity wrapperPlayClientInteractEntity = new WrapperPlayClientInteractEntity(wrappedPacket.getPacketReceiveEvent());
/*  61 */         WrapperPlayClientInteractEntity.InteractAction attackaction = wrapperPlayClientInteractEntity.getAction();
/*  63 */         if (!attackaction.equals(WrapperPlayClientInteractEntity.InteractAction.ATTACK))
/*     */           return; 
/*     */       } 
/*  68 */       if (this.lastDetectionTimes.containsKey(attacker.getUniqueId())) {
/*  69 */         long lastDetectionTime = ((Long)this.lastDetectionTimes.get(attacker.getUniqueId())).longValue();
/*  70 */         long cooldownDuration = 2000L;
/*  72 */         if (System.currentTimeMillis() - lastDetectionTime < cooldownDuration)
/*     */           return; 
/*     */       } 
/*  77 */       if (isHighLatency(user.getPlayer()))
/*     */         return; 
/*  81 */       Player target = getTargetPlayer(attacker);
/*  83 */       if (target != null && (target.isOnGround() || target instanceof LivingEntity)) {
/*  84 */         this.lastAttackedPositions.put(target.getUniqueId(), target);
/*  86 */         double reachDistance = this.reachEngine.calculateReach(attacker, target);
/*  88 */         if (reachDistance > this.maxReachDistance && reachDistance <= 10.0D) {
/*  89 */           this.violations++;
/*  91 */           SetbackEngine.performSetback(user.getPlayer());
/*  93 */           if (this.violations >= this.maxViolations)
/*     */             try {
/*  95 */               String playerAction = this.action.replace("%player%", user.getName());
/*  98 */               EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 103 */             } catch (Exception e) {
/* 104 */               e.printStackTrace();
/*     */             }  
/* 108 */           String debugInfo = String.valueOf(reachDistance);
/* 110 */           flag(user, "A", "High Reach", this.violations, debugInfo);
/* 111 */           if (player != null)
/* 112 */             CheckLogger.log(player.getName(), "REACH", "Type: A Debug:" + debugInfo); 
/*     */         } 
/* 117 */         this.lastDetectionTimes.put(attacker.getUniqueId(), Long.valueOf(System.currentTimeMillis()));
/*     */       } 
/* 120 */       if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 121 */         this.violations = 0;
/* 122 */         this.lastResetTime = System.currentTimeMillis();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Player getTargetPlayer(Player attacker) {
/* 128 */     return this.lastAttackedPositions.getOrDefault(attacker.getUniqueId(), findPotentialTarget(attacker));
/*     */   }
/*     */   
/*     */   private Player findPotentialTarget(Player attacker) {
/* 132 */     Vector attackerDirection = attacker.getEyeLocation().getDirection();
/* 133 */     Player[] target = { null };
/* 136 */     Wave.getInstance().getServer().getScheduler().runTask((Plugin)Wave.getInstance(), () -> {
/*     */           for (Entity potentialTarget : attacker.getNearbyEntities(10.0D, 10.0D, 10.0D)) {
/*     */             if (potentialTarget.equals(attacker) || !(potentialTarget instanceof LivingEntity))
/*     */               continue; 
/*     */             LivingEntity livingEntity = (LivingEntity)potentialTarget;
/*     */             Vector targetDirection = livingEntity.getEyeLocation().toVector().subtract(attacker.getEyeLocation().toVector());
/*     */             if (attackerDirection.angle(targetDirection) < 0.3D)
/*     */               if (livingEntity instanceof Player) {
/*     */                 target[0] = (Player)livingEntity;
/*     */                 break;
/*     */               }  
/*     */           } 
/*     */         });
/* 155 */     return target[0];
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 160 */     if (player == null)
/* 161 */       return false; 
/* 165 */     int latency = Latency.getLag(player).intValue();
/* 168 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\combat\ReachA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */