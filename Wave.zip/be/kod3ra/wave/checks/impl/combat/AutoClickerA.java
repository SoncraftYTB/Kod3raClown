/*     */ package be.kod3ra.wave.checks.impl.combat;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.engine.CPSEngine;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "AUTOCLICKER")
/*     */ public final class AutoClickerA extends Check {
/*     */   private CPSEngine cpsEngine;
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private int maxCps;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String action;
/*     */   
/*  32 */   private final Map<UUID, Long> ignoredPlayers = new HashMap<>();
/*     */   
/*  33 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*  34 */   private final long ignoreDuration = 4000L;
/*     */   
/*  35 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public AutoClickerA() {
/*  38 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  39 */     this.isEnabled = config.getBoolean("Checks.AutoClickerA.ENABLED", true);
/*  40 */     this.maxCps = config.getInt("Checks.AutoClickerA.MAX-CPS", 18);
/*  41 */     this.maxViolations = config.getInt("Checks.AutoClickerA.MAX-VIOLATIONS", 5);
/*  42 */     this.action = config.getString("Checks.AutoClickerA.ACTION", "kick %player% §b§lWave §7» §eUnfair Advantage.");
/*  43 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*  44 */     this.cpsEngine = new CPSEngine(Wave.getInstance());
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  48 */     UUID userUUID = user.getPlayer().getUniqueId();
/*  49 */     Player player = user.getPlayer();
/*  50 */     UserData userData = Wave.getInstance().getUserData();
/*  52 */     if (this.isEnabled && wrappedPacket.isAttacking()) {
/*  53 */       if (shouldIgnorePlayer(userUUID))
/*     */         return; 
/*  57 */       if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.autoclicker")))
/*     */         return; 
/*  61 */       if (wrappedPacket.isDigging() || isHighLatency(user.getPlayer())) {
/*  62 */         ignorePlayer(userUUID);
/*     */         return;
/*     */       } 
/*  66 */       if (wrappedPacket.isAttacking()) {
/*  67 */         WrapperPlayClientInteractEntity wrapperPlayClientInteractEntity = new WrapperPlayClientInteractEntity(wrappedPacket.getPacketReceiveEvent());
/*  68 */         WrapperPlayClientInteractEntity.InteractAction attackaction = wrapperPlayClientInteractEntity.getAction();
/*  70 */         if (!attackaction.equals(WrapperPlayClientInteractEntity.InteractAction.ATTACK))
/*     */           return; 
/*     */       } 
/*  75 */       long clickTime = System.currentTimeMillis();
/*  76 */       this.cpsEngine.trackPlayerClick(userUUID, clickTime);
/*  77 */       int cps = this.cpsEngine.getCPS(userUUID, clickTime);
/*  79 */       String debugInfo = String.valueOf(cps);
/*  80 */       if (cps > this.maxCps) {
/*  81 */         this.violations++;
/*  83 */         SetbackEngine.performSetback(user.getPlayer());
/*  85 */         if (this.violations >= this.maxViolations)
/*     */           try {
/*  87 */             String playerAction = this.action.replace("%player%", user.getName());
/*  90 */             EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/*  95 */           } catch (Exception e) {
/*  96 */             e.printStackTrace();
/*     */           }  
/* 100 */         flag(user, "A", "High CPS", this.violations, debugInfo);
/* 101 */         if (player != null)
/* 102 */           CheckLogger.log(player.getName(), "AUTOCLICKER", "Type: A Debug:" + debugInfo); 
/*     */       } 
/*     */     } 
/* 108 */     if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 109 */       this.violations = 0;
/* 110 */       this.lastResetTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean shouldIgnorePlayer(UUID userUUID) {
/* 115 */     return (this.ignoredPlayers.containsKey(userUUID) && System.currentTimeMillis() < ((Long)this.ignoredPlayers.get(userUUID)).longValue());
/*     */   }
/*     */   
/*     */   private void ignorePlayer(UUID userUUID) {
/* 119 */     this.ignoredPlayers.put(userUUID, Long.valueOf(System.currentTimeMillis() + 4000L));
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 123 */     if (player == null)
/* 124 */       return false; 
/* 128 */     int latency = Latency.getLag(player).intValue();
/* 131 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\combat\AutoClickerA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */