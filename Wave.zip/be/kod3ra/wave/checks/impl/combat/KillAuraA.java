/*     */ package be.kod3ra.wave.checks.impl.combat;
/*     */ 
/*     */ import be.kod3ra.wave.Wave;
/*     */ import be.kod3ra.wave.checks.Check;
/*     */ import be.kod3ra.wave.checks.impl.CheckInfo;
/*     */ import be.kod3ra.wave.packet.WrappedPacket;
/*     */ import be.kod3ra.wave.user.User;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.utilsengine.SetbackEngine;
/*     */ import be.kod3ra.wave.utils.CheckLogger;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ @CheckInfo(name = "KILLAURA")
/*     */ public final class KillAuraA extends Check {
/*     */   private int usePackets;
/*     */   
/*     */   private int flyPackets;
/*     */   
/*     */   private int ratioThreshold;
/*     */   
/*     */   private long lastCheckTime;
/*     */   
/*  26 */   private long lastResetTime = System.currentTimeMillis();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private long violationsResetTime;
/*     */   
/*     */   private String action;
/*     */   
/*  30 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   public KillAuraA() {
/*  34 */     FileConfiguration config = Wave.getInstance().getConfig();
/*  35 */     this.usePackets = 0;
/*  36 */     this.flyPackets = 0;
/*  37 */     this.lastCheckTime = System.currentTimeMillis();
/*  38 */     this.isEnabled = config.getBoolean("Checks.KillAuraA.ENABLED", true);
/*  39 */     this.maxViolations = config.getInt("Checks.KillAuraA.MAX-VIOLATIONS", 5);
/*  40 */     this.ratioThreshold = config.getInt("Checks.KillAuraA.RATIO-THRESHOLD", 1);
/*  41 */     this.action = config.getString("Checks.KillAuraA.ACTION", "wavekick %player%");
/*  42 */     this.violationsResetTime = config.getLong("violations-reset", 120000L);
/*     */   }
/*     */   
/*     */   public void onPacket(User user, WrappedPacket wrappedPacket) {
/*  47 */     Player player = user.getPlayer();
/*  48 */     UserData userData = Wave.getInstance().getUserData();
/*  49 */     if (!this.isEnabled)
/*     */       return; 
/*  53 */     if (player != null && (player.isOp() || player.getGameMode() == GameMode.CREATIVE || player.hasPermission("wave.bypass.killaura")))
/*     */       return; 
/*  57 */     if (isHighLatency(user.getPlayer()))
/*     */       return; 
/*  61 */     if (wrappedPacket.isFlying()) {
/*  62 */       this.flyPackets++;
/*  63 */     } else if (wrappedPacket.isAttacking()) {
/*  64 */       WrapperPlayClientInteractEntity wrapperPlayClientInteractEntity = new WrapperPlayClientInteractEntity(wrappedPacket.getPacketReceiveEvent());
/*  65 */       WrapperPlayClientInteractEntity.InteractAction attackAction = wrapperPlayClientInteractEntity.getAction();
/*  67 */       if (!attackAction.equals(WrapperPlayClientInteractEntity.InteractAction.ATTACK))
/*     */         return; 
/*  70 */       this.usePackets++;
/*     */     } 
/*  73 */     long currentTime = System.currentTimeMillis();
/*  76 */     if (currentTime - this.lastCheckTime > 1000L) {
/*  77 */       if (this.flyPackets > 0 && this.usePackets > 0) {
/*  78 */         double flyUseRatio = this.usePackets / this.flyPackets;
/*  80 */         if (flyUseRatio > this.ratioThreshold) {
/*  81 */           this.violations++;
/*  83 */           String debugInfo = "FlyPackets: " + this.flyPackets + " UsePackets: " + this.usePackets + " FlyUseRatio: " + flyUseRatio;
/*  84 */           flag(user, "A", "Use packets sent at the same time as flying packets", this.violations, debugInfo);
/*  85 */           if (player != null)
/*  86 */             CheckLogger.log(player.getName(), "KILLAURA", "Type: A Debug:" + debugInfo); 
/*  89 */           SetbackEngine.performSetback(user.getPlayer());
/*  91 */           if (this.violations >= this.maxViolations)
/*     */             try {
/*  93 */               String playerAction = this.action.replace("%player%", user.getName());
/*  96 */               EXECUTOR.execute(() -> Bukkit.getScheduler().runTask((Plugin)Wave.getInstance(), ()));
/* 101 */             } catch (Exception e) {
/* 102 */               e.printStackTrace();
/*     */             }  
/*     */         } 
/* 107 */         if (System.currentTimeMillis() - this.lastResetTime > this.violationsResetTime) {
/* 108 */           this.violations = 0;
/* 109 */           this.lastResetTime = System.currentTimeMillis();
/*     */         } 
/*     */       } 
/* 114 */       this.usePackets = 0;
/* 115 */       this.flyPackets = 0;
/* 116 */       this.lastCheckTime = currentTime;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isHighLatency(Player player) {
/* 121 */     if (player == null)
/* 122 */       return false; 
/* 126 */     int latency = Latency.getLag(player).intValue();
/* 129 */     return (latency > 200);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\checks\impl\combat\KillAuraA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */