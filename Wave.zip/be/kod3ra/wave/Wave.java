/*     */ package be.kod3ra.wave;
/*     */ 
/*     */ import be.kod3ra.wave.commands.Macro;
/*     */ import be.kod3ra.wave.commands.commands.WaveBanCMD;
/*     */ import be.kod3ra.wave.commands.commands.WaveCMD;
/*     */ import be.kod3ra.wave.commands.commands.WaveClientCMD;
/*     */ import be.kod3ra.wave.commands.commands.WaveGuiCMD;
/*     */ import be.kod3ra.wave.commands.commands.WaveHelpCMD;
/*     */ import be.kod3ra.wave.commands.commands.WaveKickCMD;
/*     */ import be.kod3ra.wave.commands.commands.WaveNotifyCMD;
/*     */ import be.kod3ra.wave.commands.commands.WaveServerCMD;
/*     */ import be.kod3ra.wave.commands.commands.WaveTempBanCMD;
/*     */ import be.kod3ra.wave.listener.DamageListener;
/*     */ import be.kod3ra.wave.listener.MineListener;
/*     */ import be.kod3ra.wave.listener.PlayerConnectionListener;
/*     */ import be.kod3ra.wave.listener.RespawnListener;
/*     */ import be.kod3ra.wave.listener.TeleportListener;
/*     */ import be.kod3ra.wave.user.UserData;
/*     */ import be.kod3ra.wave.user.UserPacketListener;
/*     */ import be.kod3ra.wave.utils.Latency;
/*     */ import be.kod3ra.wave.utils.Ping;
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.event.PacketListenerCommon;
/*     */ import io.github.retrooper.waveanticheat.packetevents.bstats.Metrics;
/*     */ import io.github.retrooper.waveanticheat.packetevents.factory.spigot.SpigotPacketEventsBuilder;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public final class Wave extends JavaPlugin {
/*     */   private static Wave instance;
/*     */   
/*  22 */   private final UserData userData = new UserData();
/*     */   
/*  23 */   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
/*     */   
/*     */   public static final String ANSI_RESET = "\033[0m";
/*     */   
/*     */   public static final String ANSI_YELLOW = "\033[33m";
/*     */   
/*     */   public static final String ANSI_BOLD = "\033[1m";
/*     */   
/*     */   public static final String ANSI_RED = "\033[31m";
/*     */   
/*     */   public static final String ANSI_GREEN = "\033[32m";
/*     */   
/*     */   public void onLoad() {
/*  33 */     PacketEvents.setAPI(SpigotPacketEventsBuilder.build((Plugin)this));
/*  34 */     PacketEvents.getAPI().getSettings()
/*  35 */       .checkForUpdates(false)
/*  36 */       .bStats(false);
/*  38 */     PacketEvents.getAPI().load();
/*     */   }
/*     */   
/*     */   public void onEnable() {
/*  43 */     instance = this;
/*  45 */     Updater updater = new Updater(this, 114804);
/*     */     try {
/*  47 */       if (updater.checkForUpdates())
/*  48 */         getLogger().info("\033[31mAn update was found! New version: " + updater.getLatestVersion() + " download: " + updater.getResourceURL() + "\033[0m"); 
/*  49 */     } catch (Exception e) {
/*  50 */       getLogger().info("\033[32mCould not check for updates!\033[0m");
/*     */     } 
/*  53 */     Config.getInstance().load();
/*  55 */     PacketEvents.getAPI().getEventManager().registerListener((PacketListenerCommon)new UserPacketListener());
/*  56 */     PacketEvents.getAPI().init();
/*  58 */     getServer().getPluginManager().registerEvents((Listener)new TeleportListener(), (Plugin)this);
/*  59 */     getServer().getPluginManager().registerEvents((Listener)new RespawnListener(), (Plugin)this);
/*  60 */     getServer().getPluginManager().registerEvents((Listener)new DamageListener(), (Plugin)this);
/*  61 */     getServer().getPluginManager().registerEvents((Listener)new MineListener(), (Plugin)this);
/*  63 */     getServer().getPluginManager().registerEvents((Listener)new Macro(), (Plugin)this);
/*  65 */     new Latency();
/*  66 */     EXECUTOR.execute(() -> {
/*     */           Ping pingChecker = new Ping();
/*     */           pingChecker.startChecking();
/*     */         });
/*  72 */     PluginManager pluginManager = Bukkit.getPluginManager();
/*  73 */     pluginManager.registerEvents((Listener)new PlayerConnectionListener(), (Plugin)getInstance());
/*  76 */     getCommand("wave").setExecutor((CommandExecutor)new WaveCMD());
/*  77 */     getCommand("wavehelp").setExecutor((CommandExecutor)new WaveHelpCMD(Config.getInstance()));
/*  78 */     getCommand("wavegui").setExecutor((CommandExecutor)new WaveGuiCMD((Plugin)this));
/*  79 */     getCommand("waveclient").setExecutor((CommandExecutor)new WaveClientCMD());
/*  80 */     getCommand("wavenotify").setExecutor((CommandExecutor)new WaveNotifyCMD(this));
/*  81 */     getCommand("waveserver").setExecutor((CommandExecutor)new WaveServerCMD(Config.getInstance()));
/*  82 */     getCommand("wavekick").setExecutor((CommandExecutor)new WaveKickCMD(this));
/*  83 */     getCommand("waveban").setExecutor((CommandExecutor)new WaveBanCMD(this));
/*  84 */     getCommand("wavetempban").setExecutor((CommandExecutor)new WaveTempBanCMD(this));
/*  87 */     saveDefaultConfig();
/*  89 */     getLogger().info("\033[33m  __          __\033[0m");
/*  90 */     getLogger().info("\033[33m  \\ \\        / /\033[0m");
/*  91 */     getLogger().info("\033[33m   \\ \\  /\\  / /_ ___   _____\033[0m");
/*  92 */     getLogger().info("\033[33m    \\ \\/  \\/ / _` \\ \\ / / _ \\\033[0m");
/*  93 */     getLogger().info("\033[33m     \\  /\\  / (_| |\\ V /  __/\033[0m");
/*  94 */     getLogger().info("\033[33m      \\/  \\/ \\__,_| \\_/ \\___|\033[0m");
/*  95 */     getLogger().info("");
/*  96 */     getLogger().info("\033[33m\033[1m +---------------------------+\033[0m");
/*  97 */     getLogger().info("\033[33m\033[1m | Authors: Kod3ra, bedike16 |\033[0m");
/*  98 */     getLogger().info("\033[33m\033[1m | Version: BETA 0.2.0       |\033[0m");
/*  99 */     getLogger().info("\033[33m\033[1m +---------------------------+\033[0m");
/* 100 */     getLogger().info("");
/* 102 */     int pluginId = 20787;
/* 103 */     Metrics metrics = new Metrics(this, pluginId);
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 108 */     PacketEvents.getAPI().terminate();
/*     */   }
/*     */   
/*     */   public static Wave getInstance() {
/* 112 */     return instance;
/*     */   }
/*     */   
/*     */   public UserData getUserData() {
/* 116 */     return this.userData;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\Wave.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */