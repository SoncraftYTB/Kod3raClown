/*     */ package be.kod3ra.wave.packet;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public final class WrappedPacket {
/*     */   private PacketSendEvent packetSendEvent;
/*     */   
/*     */   private PacketReceiveEvent packetReceiveEvent;
/*     */   
/*     */   private final PacketTypeCommon packetTypeCommon;
/*     */   
/*     */   private final int packetId;
/*     */   
/*     */   private final long timeStamp;
/*     */   
/*     */   private Player attacker;
/*     */   
/*     */   private Player attackedPlayer;
/*     */   
/*     */   private float yaw;
/*     */   
/*     */   private float pitch;
/*     */   
/*     */   public PacketReceiveEvent getPacketReceiveEvent() {
/*  26 */     return this.packetReceiveEvent;
/*     */   }
/*     */   
/*     */   public WrappedPacket(PacketReceiveEvent packetReceiveEvent, PacketTypeCommon packetTypeCommon, int packetId, long timeStamp) {
/*  30 */     this.packetReceiveEvent = packetReceiveEvent;
/*  31 */     this.packetTypeCommon = packetTypeCommon;
/*  32 */     this.packetId = packetId;
/*  33 */     this.timeStamp = timeStamp;
/*     */   }
/*     */   
/*     */   public WrappedPacket(PacketSendEvent packetSendEvent, PacketTypeCommon packetTypeCommon, int packetId, long timeStamp) {
/*  37 */     this.packetSendEvent = packetSendEvent;
/*  38 */     this.packetTypeCommon = packetTypeCommon;
/*  39 */     this.packetId = packetId;
/*  40 */     this.timeStamp = timeStamp;
/*     */   }
/*     */   
/*     */   public boolean isFlying() {
/*  44 */     return WrapperPlayClientPlayerFlying.isFlying(this.packetTypeCommon);
/*     */   }
/*     */   
/*     */   public boolean movementEngine() {
/*  48 */     return WrapperPlayClientPlayerFlying.isFlying(this.packetTypeCommon);
/*     */   }
/*     */   
/*     */   public boolean isMoving() {
/*  52 */     return this.packetTypeCommon.equals(PacketType.Play.Client.PLAYER_POSITION);
/*     */   }
/*     */   
/*     */   public boolean isMovingAndRotation() {
/*  56 */     return this.packetTypeCommon.equals(PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION);
/*     */   }
/*     */   
/*     */   public boolean isRotation() {
/*  60 */     return (this.packetTypeCommon.equals(PacketType.Play.Client.PLAYER_ROTATION) || this.packetTypeCommon.equals(PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION));
/*     */   }
/*     */   
/*     */   public boolean isAttacking() {
/*  64 */     return this.packetTypeCommon.equals(PacketType.Play.Client.INTERACT_ENTITY);
/*     */   }
/*     */   
/*     */   public boolean ArmAnimation() {
/*  68 */     return this.packetTypeCommon.equals(PacketType.Play.Client.ANIMATION);
/*     */   }
/*     */   
/*     */   public boolean isDigging() {
/*  72 */     return this.packetTypeCommon.equals(PacketType.Play.Client.PLAYER_DIGGING);
/*     */   }
/*     */   
/*     */   public boolean isPlacing() {
/*  76 */     return this.packetTypeCommon.equals(PacketType.Play.Client.PLAYER_BLOCK_PLACEMENT);
/*     */   }
/*     */   
/*     */   public boolean UseItem() {
/*  80 */     return this.packetTypeCommon.equals(PacketType.Play.Client.USE_ITEM);
/*     */   }
/*     */   
/*     */   public boolean allPackets() {
/*  84 */     return (this.packetTypeCommon.equals(PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION) || this.packetTypeCommon
/*  85 */       .equals(PacketType.Play.Client.PLAYER_POSITION) || this.packetTypeCommon
/*  86 */       .equals(PacketType.Play.Client.ADVANCEMENT_TAB) || this.packetTypeCommon
/*  87 */       .equals(PacketType.Play.Client.CHAT_PREVIEW) || this.packetTypeCommon
/*  88 */       .equals(PacketType.Play.Client.CHAT_SESSION_UPDATE) || this.packetTypeCommon
/*  89 */       .equals(PacketType.Play.Client.CLICK_WINDOW) || this.packetTypeCommon
/*  90 */       .equals(PacketType.Play.Client.CLICK_WINDOW_BUTTON) || this.packetTypeCommon
/*  91 */       .equals(PacketType.Play.Client.CLIENT_STATUS) || this.packetTypeCommon
/*  92 */       .equals(PacketType.Play.Client.CLOSE_WINDOW) || this.packetTypeCommon
/*  93 */       .equals(PacketType.Play.Client.CRAFT_RECIPE_REQUEST) || this.packetTypeCommon
/*  94 */       .equals(PacketType.Play.Client.PLAYER_ABILITIES) || this.packetTypeCommon
/*  95 */       .equals(PacketType.Play.Client.PLAYER_BLOCK_PLACEMENT) || this.packetTypeCommon
/*  96 */       .equals(PacketType.Play.Client.PLAYER_DIGGING) || this.packetTypeCommon
/*  97 */       .equals(PacketType.Play.Client.PLAYER_FLYING) || this.packetTypeCommon
/*  98 */       .equals(PacketType.Play.Client.PLAYER_POSITION) || this.packetTypeCommon
/*  99 */       .equals(PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION) || this.packetTypeCommon
/* 100 */       .equals(PacketType.Play.Client.PLAYER_ROTATION) || this.packetTypeCommon
/* 101 */       .equals(PacketType.Play.Client.PLUGIN_MESSAGE) || this.packetTypeCommon
/* 102 */       .equals(PacketType.Play.Client.PONG) || this.packetTypeCommon
/* 103 */       .equals(PacketType.Play.Client.QUERY_BLOCK_NBT) || this.packetTypeCommon
/* 104 */       .equals(PacketType.Play.Client.QUERY_ENTITY_NBT) || this.packetTypeCommon
/* 105 */       .equals(PacketType.Play.Client.RESOURCE_PACK_STATUS) || this.packetTypeCommon
/* 106 */       .equals(PacketType.Play.Client.SELECT_TRADE) || this.packetTypeCommon
/* 107 */       .equals(PacketType.Play.Client.SET_BEACON_EFFECT) || this.packetTypeCommon
/* 108 */       .equals(PacketType.Play.Client.SET_DIFFICULTY) || this.packetTypeCommon
/* 109 */       .equals(PacketType.Play.Client.SET_DISPLAYED_RECIPE) || this.packetTypeCommon
/* 110 */       .equals(PacketType.Play.Client.SET_RECIPE_BOOK_STATE) || this.packetTypeCommon
/* 111 */       .equals(PacketType.Play.Client.SLOT_STATE_CHANGE) || this.packetTypeCommon
/* 112 */       .equals(PacketType.Play.Client.SPECTATE) || this.packetTypeCommon
/* 113 */       .equals(PacketType.Play.Client.STEER_BOAT) || this.packetTypeCommon
/* 114 */       .equals(PacketType.Play.Client.STEER_VEHICLE) || this.packetTypeCommon
/* 115 */       .equals(PacketType.Play.Client.TAB_COMPLETE) || this.packetTypeCommon
/* 116 */       .equals(PacketType.Play.Client.TELEPORT_CONFIRM) || this.packetTypeCommon
/* 117 */       .equals(PacketType.Play.Client.UPDATE_COMMAND_BLOCK) || this.packetTypeCommon
/* 118 */       .equals(PacketType.Play.Client.UPDATE_COMMAND_BLOCK_MINECART) || this.packetTypeCommon
/* 119 */       .equals(PacketType.Play.Client.UPDATE_JIGSAW_BLOCK) || this.packetTypeCommon
/* 120 */       .equals(PacketType.Play.Client.UPDATE_SIGN) || this.packetTypeCommon
/* 121 */       .equals(PacketType.Play.Client.USE_ITEM) || this.packetTypeCommon
/* 122 */       .equals(PacketType.Play.Client.VEHICLE_MOVE) || this.packetTypeCommon
/* 123 */       .equals(PacketType.Play.Client.WINDOW_CONFIRMATION));
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\be\kod3ra\wave\packet\WrappedPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */