/*     */ package io.github.retrooper.waveanticheat.packetevents.injector.handlers;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.exception.CancelPacketException;
/*     */ import com.github.retrooper.packetevents.exception.InvalidDisconnectPacketSend;
/*     */ import com.github.retrooper.packetevents.exception.PacketProcessException;
/*     */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*     */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import com.github.retrooper.packetevents.util.ExceptionUtil;
/*     */ import com.github.retrooper.packetevents.util.PacketEventsImplHelper;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.connection.ServerConnectionInitializer;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.viaversion.CustomPipelineUtil;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelPromise;
/*     */ import io.netty.handler.codec.MessageToMessageEncoder;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.List;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class PacketEventsEncoder extends MessageToMessageEncoder<ByteBuf> {
/*     */   public User user;
/*     */   
/*     */   public Player player;
/*     */   
/*  49 */   private boolean handledCompression = (COMPRESSION_ENABLED_EVENT != null);
/*     */   
/*     */   private ChannelPromise promise;
/*     */   
/*  51 */   public static final Object COMPRESSION_ENABLED_EVENT = paperCompressionEnabledEvent();
/*     */   
/*     */   public PacketEventsEncoder(User user) {
/*  54 */     this.user = user;
/*     */   }
/*     */   
/*     */   public PacketEventsEncoder(ChannelHandler encoder) {
/*  58 */     this.user = ((PacketEventsEncoder)encoder).user;
/*  59 */     this.player = ((PacketEventsEncoder)encoder).player;
/*  60 */     this.handledCompression = ((PacketEventsEncoder)encoder).handledCompression;
/*  61 */     this.promise = ((PacketEventsEncoder)encoder).promise;
/*     */   }
/*     */   
/*     */   protected void encode(ChannelHandlerContext ctx, ByteBuf byteBuf, List<Object> list) throws Exception {
/*  66 */     boolean needsRecompression = (!this.handledCompression && handleCompression(ctx, byteBuf));
/*  67 */     handleClientBoundPacket(ctx.channel(), this.user, this.player, byteBuf, this.promise);
/*  69 */     if (needsRecompression)
/*  70 */       compress(ctx, byteBuf); 
/*  74 */     if (!ByteBufHelper.isReadable(byteBuf))
/*  75 */       throw CancelPacketException.INSTANCE; 
/*  78 */     list.add(byteBuf.retain());
/*     */   }
/*     */   
/*     */   private PacketSendEvent handleClientBoundPacket(Channel channel, User user, Object player, ByteBuf buffer, ChannelPromise promise) throws Exception {
/*  82 */     PacketSendEvent packetSendEvent = PacketEventsImplHelper.handleClientBoundPacket(channel, user, player, buffer, true);
/*  83 */     if (packetSendEvent.hasTasksAfterSend())
/*  84 */       promise.addListener(p -> {
/*     */             for (Runnable task : packetSendEvent.getTasksAfterSend())
/*     */               task.run(); 
/*     */           }); 
/*  90 */     return packetSendEvent;
/*     */   }
/*     */   
/*     */   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
/*  97 */     ChannelPromise oldPromise = (this.promise != null && !this.promise.isSuccess()) ? this.promise : null;
/*  98 */     promise.addListener(p -> this.promise = oldPromise);
/* 100 */     this.promise = promise;
/* 101 */     super.write(ctx, msg, promise);
/*     */   }
/*     */   
/*     */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 108 */     if (ExceptionUtil.isException(cause, CancelPacketException.class))
/*     */       return; 
/* 112 */     if (ExceptionUtil.isException(cause, InvalidDisconnectPacketSend.class))
/*     */       return; 
/* 116 */     boolean didWeCauseThis = ExceptionUtil.isException(cause, PacketProcessException.class);
/* 118 */     if (didWeCauseThis && this.user != null && this.user.getEncoderState() != ConnectionState.HANDSHAKING) {
/* 120 */       cause.printStackTrace();
/*     */       return;
/*     */     } 
/* 124 */     super.exceptionCaught(ctx, cause);
/*     */   }
/*     */   
/*     */   private static Object paperCompressionEnabledEvent() {
/*     */     try {
/* 129 */       Class<?> eventClass = Class.forName("io.papermc.paper.network.ConnectionEvent");
/* 130 */       return eventClass.getDeclaredField("COMPRESSION_THRESHOLD_SET").get(null);
/* 131 */     } catch (ReflectiveOperationException e) {
/* 132 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void compress(ChannelHandlerContext ctx, ByteBuf input) throws InvocationTargetException {
/* 137 */     ChannelHandler compressor = ctx.pipeline().get("compress");
/* 138 */     ByteBuf temp = ctx.alloc().buffer();
/*     */     try {
/* 140 */       if (compressor != null)
/* 141 */         CustomPipelineUtil.callEncode(compressor, ctx, input, temp); 
/*     */     } finally {
/* 144 */       input.clear().writeBytes(temp);
/* 145 */       temp.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void decompress(ChannelHandlerContext ctx, ByteBuf input, ByteBuf output) throws InvocationTargetException {
/* 150 */     ChannelHandler decompressor = ctx.pipeline().get("decompress");
/* 151 */     if (decompressor != null) {
/* 152 */       ByteBuf temp = CustomPipelineUtil.callDecode(decompressor, ctx, input).get(0);
/*     */       try {
/* 154 */         output.clear().writeBytes(temp);
/*     */       } finally {
/* 156 */         temp.release();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean handleCompression(ChannelHandlerContext ctx, ByteBuf buffer) throws InvocationTargetException {
/* 162 */     if (this.handledCompression)
/* 162 */       return false; 
/* 163 */     int compressIndex = ctx.pipeline().names().indexOf("compress");
/* 164 */     if (compressIndex == -1)
/* 164 */       return false; 
/* 165 */     this.handledCompression = true;
/* 166 */     int peEncoderIndex = ctx.pipeline().names().indexOf(PacketEvents.ENCODER_NAME);
/* 167 */     if (peEncoderIndex == -1)
/* 167 */       return false; 
/* 168 */     if (compressIndex > peEncoderIndex) {
/* 171 */       decompress(ctx, buffer, buffer);
/* 173 */       PacketEventsDecoder decoder = (PacketEventsDecoder)ctx.pipeline().get(PacketEvents.DECODER_NAME);
/* 174 */       ServerConnectionInitializer.relocateHandlers(ctx.channel(), decoder, this.user);
/* 175 */       return true;
/*     */     } 
/* 177 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\injector\handlers\PacketEventsEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */