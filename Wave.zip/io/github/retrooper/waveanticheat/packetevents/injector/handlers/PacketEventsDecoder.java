/*    */ package io.github.retrooper.waveanticheat.packetevents.injector.handlers;
/*    */ 
/*    */ import com.github.retrooper.packetevents.exception.PacketProcessException;
/*    */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ import com.github.retrooper.packetevents.util.ExceptionUtil;
/*    */ import com.github.retrooper.packetevents.util.PacketEventsImplHelper;
/*    */ import io.github.retrooper.waveanticheat.packetevents.injector.connection.ServerConnectionInitializer;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.SpigotReflectionUtil;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.MessageToMessageDecoder;
/*    */ import java.util.List;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PacketEventsDecoder extends MessageToMessageDecoder<ByteBuf> {
/*    */   public User user;
/*    */   
/*    */   public Player player;
/*    */   
/*    */   public boolean hasBeenRelocated;
/*    */   
/*    */   public PacketEventsDecoder(User user) {
/* 41 */     this.user = user;
/*    */   }
/*    */   
/*    */   public PacketEventsDecoder(PacketEventsDecoder decoder) {
/* 45 */     this.user = decoder.user;
/* 46 */     this.player = decoder.player;
/* 47 */     this.hasBeenRelocated = decoder.hasBeenRelocated;
/*    */   }
/*    */   
/*    */   public void read(ChannelHandlerContext ctx, ByteBuf input, List<Object> out) throws Exception {
/* 51 */     PacketEventsImplHelper.handleServerBoundPacket(ctx.channel(), this.user, this.player, input, true);
/* 52 */     out.add(input.retain());
/*    */   }
/*    */   
/*    */   public void decode(ChannelHandlerContext ctx, ByteBuf buffer, List<Object> out) throws Exception {
/* 57 */     if (buffer.isReadable())
/* 58 */       read(ctx, buffer, out); 
/*    */   }
/*    */   
/*    */   public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
/* 64 */     super.exceptionCaught(ctx, cause);
/* 67 */     if (ExceptionUtil.isException(cause, PacketProcessException.class) && 
/* 68 */       !SpigotReflectionUtil.isMinecraftServerInstanceDebugging() && this.user != null && this.user
/* 69 */       .getDecoderState() != ConnectionState.HANDSHAKING)
/* 70 */       cause.printStackTrace(); 
/*    */   }
/*    */   
/*    */   public void userEventTriggered(ChannelHandlerContext ctx, Object event) throws Exception {
/* 76 */     if (PacketEventsEncoder.COMPRESSION_ENABLED_EVENT == null || event != PacketEventsEncoder.COMPRESSION_ENABLED_EVENT) {
/* 77 */       super.userEventTriggered(ctx, event);
/*    */       return;
/*    */     } 
/* 82 */     ServerConnectionInitializer.relocateHandlers(ctx.channel(), this, this.user);
/* 83 */     super.userEventTriggered(ctx, event);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\injector\handlers\PacketEventsDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */