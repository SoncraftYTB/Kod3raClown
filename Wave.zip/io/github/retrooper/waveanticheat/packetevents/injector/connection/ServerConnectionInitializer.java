/*     */ package io.github.retrooper.waveanticheat.packetevents.injector.connection;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.event.PacketEvent;
/*     */ import com.github.retrooper.packetevents.event.UserConnectEvent;
/*     */ import com.github.retrooper.packetevents.netty.channel.ChannelHelper;
/*     */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import com.github.retrooper.packetevents.protocol.player.UserProfile;
/*     */ import com.github.retrooper.packetevents.util.FakeChannelUtil;
/*     */ import com.github.retrooper.packetevents.util.PacketEventsImplHelper;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.handlers.PacketEventsDecoder;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.handlers.PacketEventsEncoder;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.util.concurrent.GenericFutureListener;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class ServerConnectionInitializer {
/*     */   public static void initChannel(Object ch, ConnectionState connectionState) {
/*  41 */     Channel channel = (Channel)ch;
/*  42 */     if (FakeChannelUtil.isFakeChannel(channel))
/*     */       return; 
/*  45 */     User user = new User(channel, connectionState, null, new UserProfile(null, null));
/*  47 */     if (connectionState == ConnectionState.PLAY) {
/*  49 */       user.setClientVersion(PacketEvents.getAPI().getServerManager().getVersion().toClientVersion());
/*  50 */       PacketEvents.getAPI().getLogManager().warn("Late injection detected, we missed packets so some functionality may break!");
/*     */     } 
/*  53 */     synchronized (channel) {
/*  61 */       if (channel.pipeline().get("splitter") == null) {
/*  62 */         channel.close();
/*     */         return;
/*     */       } 
/*  66 */       UserConnectEvent connectEvent = new UserConnectEvent(user);
/*  67 */       PacketEvents.getAPI().getEventManager().callEvent((PacketEvent)connectEvent);
/*  68 */       if (connectEvent.isCancelled()) {
/*  69 */         channel.unsafe().closeForcibly();
/*     */         return;
/*     */       } 
/*  73 */       relocateHandlers(channel, null, user);
/*  75 */       channel.closeFuture().addListener((GenericFutureListener)(future -> PacketEventsImplHelper.handleDisconnection(user.getChannel(), user.getUUID())));
/*  76 */       PacketEvents.getAPI().getProtocolManager().setUser(channel, user);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void destroyHandlers(Object ch) {
/*  81 */     Channel channel = (Channel)ch;
/*  82 */     if (channel.pipeline().get(PacketEvents.DECODER_NAME) != null) {
/*  83 */       channel.pipeline().remove(PacketEvents.DECODER_NAME);
/*     */     } else {
/*  85 */       PacketEvents.getAPI().getLogger().warning("Could not find decoder handler in channel pipeline!");
/*     */     } 
/*  88 */     if (channel.pipeline().get(PacketEvents.ENCODER_NAME) != null) {
/*  89 */       channel.pipeline().remove(PacketEvents.ENCODER_NAME);
/*     */     } else {
/*  91 */       PacketEvents.getAPI().getLogger().warning("Could not find encoder handler in channel pipeline!");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void relocateHandlers(Channel ctx, PacketEventsDecoder decoder, User user) {
/*     */     try {
/*     */       PacketEventsEncoder packetEventsEncoder;
/*  99 */       if (decoder != null) {
/* 101 */         if (decoder.hasBeenRelocated)
/*     */           return; 
/* 103 */         decoder.hasBeenRelocated = true;
/* 104 */         decoder = (PacketEventsDecoder)ctx.pipeline().remove(PacketEvents.DECODER_NAME);
/* 105 */         ChannelHandler encoder = ctx.pipeline().remove(PacketEvents.ENCODER_NAME);
/* 106 */         decoder = new PacketEventsDecoder(decoder);
/* 107 */         packetEventsEncoder = new PacketEventsEncoder(encoder);
/*     */       } else {
/* 109 */         packetEventsEncoder = new PacketEventsEncoder(user);
/* 110 */         decoder = new PacketEventsDecoder(user);
/*     */       } 
/* 115 */       ctx.pipeline().addBefore("decoder", PacketEvents.DECODER_NAME, (ChannelHandler)decoder);
/* 116 */       ctx.pipeline().addBefore("encoder", PacketEvents.ENCODER_NAME, (ChannelHandler)packetEventsEncoder);
/* 117 */     } catch (NoSuchElementException ex) {
/* 118 */       String handlers = ChannelHelper.pipelineHandlerNamesAsString(ctx);
/* 119 */       throw new IllegalStateException("PacketEvents failed to add a decoder to the netty pipeline. Pipeline handlers: " + handlers, ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\injector\connection\ServerConnectionInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */