/*    */ package io.github.retrooper.waveanticheat.packetevents.injector.connection;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*    */ import io.netty.channel.Channel;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelInitializer;
/*    */ 
/*    */ public class PreChannelInitializer_v1_8 extends ChannelInitializer<Channel> {
/*    */   protected void initChannel(Channel channel) {
/* 28 */     channel.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)new ChannelInitializer<Channel>() {
/*    */             protected void initChannel(Channel channel) {
/* 31 */               ServerConnectionInitializer.initChannel(channel, ConnectionState.HANDSHAKING);
/*    */             }
/*    */           } });
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\injector\connection\PreChannelInitializer_v1_8.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */