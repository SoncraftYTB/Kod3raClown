/*    */ package io.github.retrooper.waveanticheat.packetevents.injector.connection;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.util.PEVersion;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.SpigotReflectionUtil;
/*    */ import io.netty.channel.Channel;
/*    */ import io.netty.channel.ChannelHandler;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.channel.ChannelInboundHandlerAdapter;
/*    */ import io.netty.util.Version;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ServerChannelHandler extends ChannelInboundHandlerAdapter {
/*    */   public static boolean CHECKED_NETTY_VERSION;
/*    */   
/*    */   public static PEVersion NETTY_VERSION;
/*    */   
/* 34 */   public static final PEVersion MODERN_NETTY_VERSION = new PEVersion(new int[] { 4, 1, 24 });
/*    */   
/*    */   private static PEVersion resolveNettyVersion() {
/* 37 */     Map<String, Version> nettyArtifacts = Version.identify();
/* 38 */     Version version = nettyArtifacts.getOrDefault("netty-common", nettyArtifacts.get("netty-all"));
/* 39 */     if (version != null) {
/* 40 */       String stringVersion = version.artifactVersion();
/* 42 */       stringVersion = stringVersion.replaceAll("[^\\d.]", "");
/* 43 */       if (stringVersion.endsWith("."))
/* 45 */         stringVersion = stringVersion.substring(0, stringVersion.length() - 1); 
/* 47 */       return new PEVersion(stringVersion);
/*    */     } 
/* 49 */     return null;
/*    */   }
/*    */   
/*    */   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
/* 54 */     Channel channel = (Channel)msg;
/* 56 */     if (NETTY_VERSION == null && !CHECKED_NETTY_VERSION) {
/* 57 */       NETTY_VERSION = resolveNettyVersion();
/* 58 */       CHECKED_NETTY_VERSION = true;
/*    */     } 
/* 62 */     if ((NETTY_VERSION != null && NETTY_VERSION.isNewerThan(MODERN_NETTY_VERSION)) || SpigotReflectionUtil.V_1_12_OR_HIGHER) {
/* 64 */       channel.pipeline().addLast(PacketEvents.SERVER_CHANNEL_HANDLER_NAME, (ChannelHandler)new PreChannelInitializer_v1_12());
/*    */     } else {
/* 66 */       channel.pipeline().addFirst(PacketEvents.SERVER_CHANNEL_HANDLER_NAME, (ChannelHandler)new PreChannelInitializer_v1_8());
/*    */     } 
/* 68 */     super.channelRead(ctx, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\injector\connection\ServerChannelHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */