/*     */ package io.github.retrooper.waveanticheat.packetevents.injector;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.event.PacketEvent;
/*     */ import com.github.retrooper.packetevents.event.UserLoginEvent;
/*     */ import com.github.retrooper.packetevents.injector.ChannelInjector;
/*     */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import com.github.retrooper.packetevents.util.reflection.ReflectionObject;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.connection.ServerChannelHandler;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.connection.ServerConnectionInitializer;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.handlers.PacketEventsDecoder;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.handlers.PacketEventsEncoder;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.InjectedList;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.SpigotReflectionUtil;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelPipeline;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class SpigotChannelInjector implements ChannelInjector {
/*  45 */   public final Set<Channel> injectedConnectionChannels = new HashSet<>();
/*     */   
/*     */   public List<Object> networkManagers;
/*     */   
/*  47 */   private int connectionChannelsListIndex = -1;
/*     */   
/*     */   public boolean inboundAheadProtocolTranslation = false;
/*     */   
/*     */   public boolean outboundAheadProtocolTranslation = false;
/*     */   
/*     */   public void updatePlayer(User user, Object player) {
/*  52 */     PacketEvents.getAPI().getEventManager().callEvent((PacketEvent)new UserLoginEvent(user, player));
/*  53 */     Object channel = user.getChannel();
/*  54 */     if (channel == null)
/*  55 */       channel = PacketEvents.getAPI().getPlayerManager().getChannel(player); 
/*  57 */     setPlayer(channel, player);
/*     */   }
/*     */   
/*     */   public boolean isServerBound() {
/*  63 */     Object serverConnection = SpigotReflectionUtil.getMinecraftServerConnectionInstance();
/*  64 */     if (serverConnection != null) {
/*  65 */       ReflectionObject reflectServerConnection = new ReflectionObject(serverConnection);
/*  67 */       for (int i = 0; i < 2; i++) {
/*  68 */         List<?> list = reflectServerConnection.readList(i);
/*  69 */         for (Object value : list) {
/*  70 */           if (value instanceof ChannelFuture) {
/*  71 */             this.connectionChannelsListIndex = i;
/*  74 */             return true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   public void inject() {
/*  84 */     Object serverConnection = SpigotReflectionUtil.getMinecraftServerConnectionInstance();
/*  85 */     if (serverConnection != null) {
/*  86 */       ReflectionObject reflectServerConnection = new ReflectionObject(serverConnection);
/*  87 */       List<ChannelFuture> connectionChannelFutures = reflectServerConnection.readList(this.connectionChannelsListIndex);
/*  88 */       InjectedList<ChannelFuture> wrappedList = new InjectedList(connectionChannelFutures, future -> {
/*     */             Channel channel = future.channel();
/*     */             injectServerChannel(channel);
/*     */             this.injectedConnectionChannels.add(channel);
/*     */           });
/*  98 */       reflectServerConnection.writeList(this.connectionChannelsListIndex, (List)wrappedList);
/* 101 */       if (this.networkManagers == null)
/* 102 */         this.networkManagers = SpigotReflectionUtil.getNetworkManagers(); 
/* 104 */       synchronized (this.networkManagers) {
/* 105 */         if (!this.networkManagers.isEmpty())
/* 106 */           PacketEvents.getAPI().getLogManager().debug("Late bind not enabled, injecting into existing channel"); 
/* 109 */         for (Object networkManager : this.networkManagers) {
/* 110 */           ReflectionObject networkManagerWrapper = new ReflectionObject(networkManager);
/* 111 */           Channel channel = (Channel)networkManagerWrapper.readObject(0, Channel.class);
/* 112 */           if (channel == null)
/*     */             continue; 
/*     */           try {
/* 116 */             ServerConnectionInitializer.initChannel(channel, ConnectionState.PLAY);
/* 117 */           } catch (Exception e) {
/* 118 */             System.out.println("Spigot injector failed to inject into an existing channel.");
/* 119 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void uninject() {
/* 129 */     for (Channel connectionChannel : this.injectedConnectionChannels)
/* 130 */       uninjectServerChannel(connectionChannel); 
/* 132 */     this.injectedConnectionChannels.clear();
/* 133 */     Object serverConnection = SpigotReflectionUtil.getMinecraftServerConnectionInstance();
/* 134 */     if (serverConnection != null) {
/* 135 */       ReflectionObject reflectServerConnection = new ReflectionObject(serverConnection);
/* 136 */       List<ChannelFuture> connectionChannelFutures = reflectServerConnection.readList(this.connectionChannelsListIndex);
/* 137 */       if (connectionChannelFutures instanceof InjectedList)
/* 139 */         reflectServerConnection.writeList(this.connectionChannelsListIndex, ((InjectedList)connectionChannelFutures)
/* 140 */             .originalList()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void injectServerChannel(Channel serverChannel) {
/* 146 */     ChannelPipeline pipeline = serverChannel.pipeline();
/* 147 */     ChannelHandler connectionHandler = pipeline.get(PacketEvents.CONNECTION_HANDLER_NAME);
/* 148 */     if (connectionHandler != null)
/* 150 */       pipeline.remove(PacketEvents.CONNECTION_HANDLER_NAME); 
/* 153 */     if (pipeline.get("SpigotNettyServerChannelHandler#0") != null) {
/* 154 */       pipeline.addAfter("SpigotNettyServerChannelHandler#0", PacketEvents.CONNECTION_HANDLER_NAME, (ChannelHandler)new ServerChannelHandler());
/* 157 */     } else if (pipeline.get("floodgate-init") != null) {
/* 158 */       pipeline.addAfter("floodgate-init", PacketEvents.CONNECTION_HANDLER_NAME, (ChannelHandler)new ServerChannelHandler());
/* 161 */     } else if (pipeline.get("MinecraftPipeline#0") != null) {
/* 162 */       pipeline.addAfter("MinecraftPipeline#0", PacketEvents.CONNECTION_HANDLER_NAME, (ChannelHandler)new ServerChannelHandler());
/*     */     } else {
/* 166 */       pipeline.addFirst(PacketEvents.CONNECTION_HANDLER_NAME, (ChannelHandler)new ServerChannelHandler());
/*     */     } 
/* 169 */     if (this.networkManagers == null)
/* 170 */       this.networkManagers = SpigotReflectionUtil.getNetworkManagers(); 
/* 173 */     synchronized (this.networkManagers) {
/* 174 */       for (Object networkManager : this.networkManagers) {
/* 175 */         ReflectionObject networkManagerWrapper = new ReflectionObject(networkManager);
/* 176 */         Channel channel = (Channel)networkManagerWrapper.readObject(0, Channel.class);
/* 178 */         if (channel != null && channel.isOpen() && 
/* 179 */           channel.localAddress().equals(serverChannel.localAddress()))
/* 180 */           channel.close(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void uninjectServerChannel(Channel serverChannel) {
/* 188 */     if (serverChannel.pipeline().get(PacketEvents.CONNECTION_HANDLER_NAME) != null) {
/* 189 */       serverChannel.pipeline().remove(PacketEvents.CONNECTION_HANDLER_NAME);
/*     */     } else {
/* 191 */       PacketEvents.getAPI().getLogManager().warn("Failed to uninject server channel, handler not found");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateUser(Object channel, User user) {
/* 197 */     PacketEventsEncoder encoder = getEncoder((Channel)channel);
/* 198 */     if (encoder != null)
/* 199 */       encoder.user = user; 
/* 202 */     PacketEventsDecoder decoder = getDecoder((Channel)channel);
/* 203 */     if (decoder != null)
/* 204 */       decoder.user = user; 
/*     */   }
/*     */   
/*     */   public void setPlayer(Object channel, Object player) {
/* 210 */     PacketEventsEncoder encoder = getEncoder((Channel)channel);
/* 211 */     if (encoder != null)
/* 212 */       encoder.player = (Player)player; 
/* 215 */     PacketEventsDecoder decoder = getDecoder((Channel)channel);
/* 216 */     if (decoder != null) {
/* 217 */       decoder.player = (Player)player;
/* 218 */       decoder.user.getProfile().setName(((Player)player).getName());
/* 219 */       decoder.user.getProfile().setUUID(((Player)player).getUniqueId());
/*     */     } 
/*     */   }
/*     */   
/*     */   private PacketEventsEncoder getEncoder(Channel channel) {
/* 224 */     return (PacketEventsEncoder)channel.pipeline().get(PacketEvents.ENCODER_NAME);
/*     */   }
/*     */   
/*     */   private PacketEventsDecoder getDecoder(Channel channel) {
/* 228 */     return (PacketEventsDecoder)channel.pipeline().get(PacketEvents.DECODER_NAME);
/*     */   }
/*     */   
/*     */   public boolean isProxy() {
/* 233 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\injector\SpigotChannelInjector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */