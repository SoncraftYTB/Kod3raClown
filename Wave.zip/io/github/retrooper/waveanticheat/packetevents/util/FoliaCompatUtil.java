/*     */ package io.github.retrooper.waveanticheat.packetevents.util;
/*     */ 
/*     */ import com.github.retrooper.packetevents.util.reflection.Reflection;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.function.Consumer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventException;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class FoliaCompatUtil {
/*     */   private static boolean folia;
/*     */   
/*     */   static {
/*     */     try {
/*  21 */       Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
/*  22 */       folia = true;
/*  23 */     } catch (ClassNotFoundException e) {
/*  24 */       folia = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isFolia() {
/*  32 */     return folia;
/*     */   }
/*     */   
/*     */   public static void runTaskAsync(Plugin plugin, Runnable run) {
/*  41 */     if (!folia) {
/*  42 */       Bukkit.getScheduler().runTaskAsynchronously(plugin, run);
/*     */       return;
/*     */     } 
/*  45 */     Executors.defaultThreadFactory().newThread(run).start();
/*     */   }
/*     */   
/*     */   public static void runTaskTimerAsync(Plugin plugin, Consumer<Object> run, long delay, long period) {
/*  56 */     if (!folia) {
/*  57 */       Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> run.accept(null), delay, period);
/*     */       return;
/*     */     } 
/*     */     try {
/*  61 */       Method getSchedulerMethod = Reflection.getMethod(Server.class, "getGlobalRegionScheduler", 0);
/*  62 */       Object globalRegionScheduler = getSchedulerMethod.invoke(Bukkit.getServer(), new Object[0]);
/*  64 */       Class<?> schedulerClass = globalRegionScheduler.getClass();
/*  65 */       Method executeMethod = schedulerClass.getMethod("runAtFixedRate", new Class[] { Plugin.class, Consumer.class, long.class, long.class });
/*  67 */       executeMethod.invoke(globalRegionScheduler, new Object[] { plugin, run, Long.valueOf(delay), Long.valueOf(period) });
/*  68 */     } catch (Exception e) {
/*  69 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void runTask(Plugin plugin, Consumer<Object> run) {
/*  79 */     if (!folia) {
/*  80 */       Bukkit.getScheduler().runTask(plugin, () -> run.accept(null));
/*     */       return;
/*     */     } 
/*     */     try {
/*  84 */       Method getSchedulerMethod = Reflection.getMethod(Server.class, "getGlobalRegionScheduler", 0);
/*  85 */       Object globalRegionScheduler = getSchedulerMethod.invoke(Bukkit.getServer(), new Object[0]);
/*  87 */       Class<?> schedulerClass = globalRegionScheduler.getClass();
/*  88 */       Method executeMethod = schedulerClass.getMethod("run", new Class[] { Plugin.class, Consumer.class });
/*  90 */       executeMethod.invoke(globalRegionScheduler, new Object[] { plugin, run });
/*  91 */     } catch (Exception e) {
/*  92 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void runTaskOnInit(Plugin plugin, Runnable run) {
/*     */     Class<? extends Event> serverInitEventClass;
/* 104 */     if (!folia) {
/* 105 */       Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, run);
/*     */       return;
/*     */     } 
/*     */     try {
/* 113 */       serverInitEventClass = (Class)Class.forName("io.papermc.paper.threadedregions.RegionizedServerInitEvent");
/* 114 */     } catch (ReflectiveOperationException e) {
/* 115 */       throw new RuntimeException(e);
/*     */     } 
/* 118 */     Bukkit.getServer().getPluginManager().registerEvent(serverInitEventClass, new Listener() {
/*     */         
/* 118 */         },  EventPriority.HIGHEST, (listener, event) -> run.run(), plugin);
/*     */   }
/*     */   
/*     */   public static void runTaskForEntity(Entity entity, Plugin plugin, Runnable run, Runnable retired, long delay) {
/* 131 */     if (!folia) {
/* 132 */       Bukkit.getScheduler().runTaskLater(plugin, run, delay);
/*     */       return;
/*     */     } 
/*     */     try {
/* 138 */       Method getSchedulerMethod = Reflection.getMethod(Entity.class, "getScheduler", 0);
/* 139 */       Object entityScheduler = getSchedulerMethod.invoke(entity, new Object[0]);
/* 141 */       Class<?> schedulerClass = entityScheduler.getClass();
/* 142 */       Method executeMethod = schedulerClass.getMethod("execute", new Class[] { Plugin.class, Runnable.class, Runnable.class, long.class });
/* 144 */       executeMethod.invoke(entityScheduler, new Object[] { plugin, run, retired, Long.valueOf(delay) });
/* 145 */     } catch (Exception e) {
/* 146 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\FoliaCompatUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */