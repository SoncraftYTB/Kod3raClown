/*    */ package io.github.retrooper.waveanticheat.packetevents.util;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerPingAccessorModern {
/*    */   public static int getPing(Player player) {
/* 25 */     return player.getPing();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\PlayerPingAccessorModern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */