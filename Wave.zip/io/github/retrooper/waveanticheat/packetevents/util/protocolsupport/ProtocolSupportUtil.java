/*    */ package io.github.retrooper.waveanticheat.packetevents.util.protocolsupport;
/*    */ 
/*    */ import java.net.SocketAddress;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import protocolsupport.api.ProtocolSupportAPI;
/*    */ 
/*    */ public class ProtocolSupportUtil {
/* 28 */   private static ProtocolSupportState available = ProtocolSupportState.UNKNOWN;
/*    */   
/*    */   public static boolean isAvailable() {
/* 31 */     if (available == ProtocolSupportState.UNKNOWN)
/*    */       try {
/* 33 */         Class.forName("protocolsupport.api.ProtocolSupportAPI");
/* 34 */         available = ProtocolSupportState.ENABLED;
/* 35 */         return true;
/* 36 */       } catch (Exception e) {
/* 37 */         available = ProtocolSupportState.DISABLED;
/* 38 */         return false;
/*    */       }  
/* 41 */     return (available == ProtocolSupportState.ENABLED);
/*    */   }
/*    */   
/*    */   public static void checkIfProtocolSupportIsPresent() {
/* 46 */     boolean present = Bukkit.getPluginManager().isPluginEnabled("ProtocolSupport");
/* 47 */     available = present ? ProtocolSupportState.ENABLED : ProtocolSupportState.DISABLED;
/*    */   }
/*    */   
/*    */   public static int getProtocolVersion(SocketAddress address) {
/* 51 */     return ProtocolSupportAPI.getProtocolVersion(address).getId();
/*    */   }
/*    */   
/*    */   public static int getProtocolVersion(Player player) {
/* 55 */     return ProtocolSupportAPI.getProtocolVersion(player).getId();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\protocolsupport\ProtocolSupportUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */