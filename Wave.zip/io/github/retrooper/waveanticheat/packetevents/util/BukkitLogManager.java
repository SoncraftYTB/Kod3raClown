/*    */ package io.github.retrooper.waveanticheat.packetevents.util;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.util.ColorUtil;
/*    */ import com.github.retrooper.packetevents.util.LogManager;
/*    */ import java.util.logging.Level;
/*    */ import net.kyori.adventure.text.format.NamedTextColor;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class BukkitLogManager extends LogManager {
/* 31 */   private final String prefixText = ColorUtil.toString(NamedTextColor.AQUA) + "[packetevents] " + ColorUtil.toString(NamedTextColor.WHITE);
/*    */   
/*    */   protected void log(Level level, @Nullable NamedTextColor color, String message) {
/* 35 */     Bukkit.getConsoleSender().sendMessage(this.prefixText + ColorUtil.toString(color) + message);
/*    */   }
/*    */   
/*    */   public void info(String message) {
/* 40 */     log(Level.INFO, NamedTextColor.WHITE, message);
/*    */   }
/*    */   
/*    */   public void warn(String message) {
/* 45 */     log(Level.WARNING, NamedTextColor.YELLOW, message);
/*    */   }
/*    */   
/*    */   public void severe(String message) {
/* 50 */     log(Level.SEVERE, NamedTextColor.RED, message);
/*    */   }
/*    */   
/*    */   public void debug(String message) {
/* 55 */     if (PacketEvents.getAPI().getSettings().isDebugEnabled())
/* 56 */       log(Level.FINE, NamedTextColor.GRAY, message); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\BukkitLogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */