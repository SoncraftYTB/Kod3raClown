/*     */ package io.github.retrooper.waveanticheat.packetevents.util;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*     */ import com.github.retrooper.packetevents.netty.buffer.UnpooledByteBufAllocationHelper;
/*     */ import com.github.retrooper.packetevents.protocol.item.ItemStack;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*     */ import com.github.retrooper.packetevents.protocol.particle.type.ParticleType;
/*     */ import com.github.retrooper.packetevents.protocol.particle.type.ParticleTypes;
/*     */ import com.github.retrooper.packetevents.protocol.player.TextureProperty;
/*     */ import com.github.retrooper.packetevents.util.reflection.Reflection;
/*     */ import com.github.retrooper.packetevents.util.reflection.ReflectionObject;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import com.google.common.collect.BiMap;
/*     */ import com.google.common.collect.MapMaker;
/*     */ import io.netty.buffer.PooledByteBufAllocator;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.material.MaterialData;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public final class SpigotReflectionUtil {
/*  53 */   private static final String MODIFIED_PACKAGE_NAME = Bukkit.getServer().getClass().getPackage().getName()
/*  54 */     .replace(".", ",").split(",")[3];
/*     */   
/*  56 */   public static final String LEGACY_NMS_PACKAGE = "net.minecraft.server." + MODIFIED_PACKAGE_NAME + ".";
/*     */   
/*  58 */   public static final String OBC_PACKAGE = "org.bukkit.craftbukkit." + MODIFIED_PACKAGE_NAME + ".";
/*     */   
/*     */   public static ServerVersion VERSION;
/*     */   
/*     */   public static boolean V_1_19_OR_HIGHER;
/*     */   
/*     */   public static boolean V_1_17_OR_HIGHER;
/*     */   
/*     */   public static boolean V_1_12_OR_HIGHER;
/*     */   
/*     */   public static Class<?> MINECRAFT_SERVER_CLASS;
/*     */   
/*     */   public static Class<?> NMS_PACKET_DATA_SERIALIZER_CLASS;
/*     */   
/*     */   public static Class<?> NMS_ITEM_STACK_CLASS;
/*     */   
/*     */   public static Class<?> NMS_IMATERIAL_CLASS;
/*     */   
/*     */   public static Class<?> NMS_ENTITY_CLASS;
/*     */   
/*     */   public static Class<?> ENTITY_PLAYER_CLASS;
/*     */   
/*     */   public static Class<?> BOUNDING_BOX_CLASS;
/*     */   
/*     */   public static Class<?> NMS_MINECRAFT_KEY_CLASS;
/*     */   
/*     */   public static Class<?> ENTITY_HUMAN_CLASS;
/*     */   
/*     */   public static Class<?> PLAYER_CONNECTION_CLASS;
/*     */   
/*     */   public static Class<?> SERVER_COMMON_PACKETLISTENER_IMPL_CLASS;
/*     */   
/*     */   public static Class<?> SERVER_CONNECTION_CLASS;
/*     */   
/*     */   public static Class<?> NETWORK_MANAGER_CLASS;
/*     */   
/*     */   public static Class<?> NMS_ENUM_PARTICLE_CLASS;
/*     */   
/*     */   public static Class<?> MOB_EFFECT_LIST_CLASS;
/*     */   
/*     */   public static Class<?> NMS_ITEM_CLASS;
/*     */   
/*     */   public static Class<?> DEDICATED_SERVER_CLASS;
/*     */   
/*     */   public static Class<?> NMS_WORLD_CLASS;
/*     */   
/*     */   public static Class<?> WORLD_SERVER_CLASS;
/*     */   
/*     */   public static Class<?> ENUM_PROTOCOL_DIRECTION_CLASS;
/*     */   
/*     */   public static Class<?> GAME_PROFILE_CLASS;
/*     */   
/*     */   public static Class<?> CRAFT_WORLD_CLASS;
/*     */   
/*     */   public static Class<?> CRAFT_SERVER_CLASS;
/*     */   
/*     */   public static Class<?> CRAFT_PLAYER_CLASS;
/*     */   
/*     */   public static Class<?> CRAFT_ENTITY_CLASS;
/*     */   
/*     */   public static Class<?> CRAFT_ITEM_STACK_CLASS;
/*     */   
/*     */   public static Class<?> CRAFT_PARTICLE_CLASS;
/*     */   
/*     */   public static Class<?> LEVEL_ENTITY_GETTER_CLASS;
/*     */   
/*     */   public static Class<?> PERSISTENT_ENTITY_SECTION_MANAGER_CLASS;
/*     */   
/*     */   public static Class<?> CRAFT_MAGIC_NUMBERS_CLASS;
/*     */   
/*     */   public static Class<?> IBLOCK_DATA_CLASS;
/*     */   
/*     */   public static Class<?> BLOCK_CLASS;
/*     */   
/*     */   public static Class<?> CRAFT_BLOCK_DATA_CLASS;
/*     */   
/*     */   public static Class<?> PROPERTY_MAP_CLASS;
/*     */   
/*     */   public static Class<?> DIMENSION_MANAGER_CLASS;
/*     */   
/*     */   public static Class<?> MOJANG_CODEC_CLASS;
/*     */   
/*     */   public static Class<?> MOJANG_ENCODER_CLASS;
/*     */   
/*     */   public static Class<?> DATA_RESULT_CLASS;
/*     */   
/*     */   public static Class<?> DYNAMIC_OPS_NBT_CLASS;
/*     */   
/*     */   public static Class<?> NMS_NBT_COMPOUND_CLASS;
/*     */   
/*     */   public static Class<?> NBT_COMPRESSION_STREAM_TOOLS_CLASS;
/*     */   
/*     */   public static Class<?> CHANNEL_CLASS;
/*     */   
/*     */   public static Class<?> BYTE_BUF_CLASS;
/*     */   
/*     */   public static Class<?> BYTE_TO_MESSAGE_DECODER;
/*     */   
/*     */   public static Class<?> MESSAGE_TO_BYTE_ENCODER;
/*     */   
/*     */   public static Field ENTITY_PLAYER_PING_FIELD;
/*     */   
/*     */   public static Field ENTITY_BOUNDING_BOX_FIELD;
/*     */   
/*     */   public static Field BYTE_BUF_IN_PACKET_DATA_SERIALIZER;
/*     */   
/*     */   public static Field DIMENSION_CODEC_FIELD;
/*     */   
/*     */   public static Field DYNAMIC_OPS_NBT_INSTANCE_FIELD;
/*     */   
/*     */   public static Field CRAFT_PARTICLE_PARTICLES_FIELD;
/*     */   
/*     */   public static Field NMS_MK_KEY_FIELD;
/*     */   
/*     */   public static Field LEGACY_NMS_PARTICLE_KEY_FIELD;
/*     */   
/*     */   public static Field LEGACY_NMS_KEY_TO_NMS_PARTICLE;
/*     */   
/*     */   public static Method IS_DEBUGGING;
/*     */   
/*     */   public static Method GET_CRAFT_PLAYER_HANDLE_METHOD;
/*     */   
/*     */   public static Method GET_CRAFT_ENTITY_HANDLE_METHOD;
/*     */   
/*     */   public static Method GET_CRAFT_WORLD_HANDLE_METHOD;
/*     */   
/*     */   public static Method GET_MOB_EFFECT_LIST_ID_METHOD;
/*     */   
/*     */   public static Method GET_MOB_EFFECT_LIST_BY_ID_METHOD;
/*     */   
/*     */   public static Method GET_ITEM_ID_METHOD;
/*     */   
/*     */   public static Method GET_ITEM_BY_ID_METHOD;
/*     */   
/*     */   public static Method GET_BUKKIT_ENTITY_METHOD;
/*     */   
/*     */   public static Method GET_LEVEL_ENTITY_GETTER_ITERABLE_METHOD;
/*     */   
/*     */   public static Method GET_ENTITY_BY_ID_METHOD;
/*     */   
/*     */   public static Method CRAFT_ITEM_STACK_AS_BUKKIT_COPY;
/*     */   
/*     */   public static Method CRAFT_ITEM_STACK_AS_NMS_COPY;
/*     */   
/*     */   public static Method BUKKIT_PARTICLE_TO_NMS_ENUM_PARTICLE;
/*     */   
/*     */   public static Method NMS_ENUM_PARTICLE_TO_BUKKIT_PARTICLE;
/*     */   
/*     */   public static Method READ_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD;
/*     */   
/*     */   public static Method WRITE_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD;
/*     */   
/*     */   public static Method GET_COMBINED_ID;
/*     */   
/*     */   public static Method GET_BY_COMBINED_ID;
/*     */   
/*     */   public static Method GET_CRAFT_BLOCK_DATA_FROM_IBLOCKDATA;
/*     */   
/*     */   public static Method PROPERTY_MAP_GET_METHOD;
/*     */   
/*     */   public static Method GET_DIMENSION_MANAGER;
/*     */   
/*     */   public static Method GET_DIMENSION_ID;
/*     */   
/*     */   public static Method GET_DIMENSION_KEY;
/*     */   
/*     */   public static Method CODEC_ENCODE_METHOD;
/*     */   
/*     */   public static Method DATA_RESULT_GET_METHOD;
/*     */   
/*     */   public static Method READ_NBT_FROM_STREAM_METHOD;
/*     */   
/*     */   public static Method WRITE_NBT_TO_STREAM_METHOD;
/*     */   
/*     */   private static Constructor<?> NMS_ITEM_STACK_CONSTRUCTOR;
/*     */   
/*     */   private static Constructor<?> NMS_PACKET_DATA_SERIALIZER_CONSTRUCTOR;
/*     */   
/*     */   private static Constructor<?> NMS_MINECRAFT_KEY_CONSTRUCTOR;
/*     */   
/*     */   private static Object MINECRAFT_SERVER_INSTANCE;
/*     */   
/*     */   private static Object MINECRAFT_SERVER_CONNECTION_INSTANCE;
/*     */   
/*  99 */   public static Map<Integer, Entity> ENTITY_ID_CACHE = (new MapMaker()).weakValues().makeMap();
/*     */   
/*     */   private static void initConstructors() {
/* 102 */     Class<?> itemClass = (NMS_IMATERIAL_CLASS != null) ? NMS_IMATERIAL_CLASS : NMS_ITEM_CLASS;
/*     */     try {
/* 104 */       NMS_ITEM_STACK_CONSTRUCTOR = NMS_ITEM_STACK_CLASS.getConstructor(new Class[] { itemClass, int.class });
/* 105 */       NMS_PACKET_DATA_SERIALIZER_CONSTRUCTOR = NMS_PACKET_DATA_SERIALIZER_CLASS.getConstructor(new Class[] { BYTE_BUF_CLASS });
/* 107 */       if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_9))
/* 108 */         NMS_MINECRAFT_KEY_CONSTRUCTOR = NMS_MINECRAFT_KEY_CLASS.getConstructor(new Class[] { String.class, String.class }); 
/* 110 */     } catch (NoSuchMethodException e) {
/* 111 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void initMethods() {
/* 116 */     IS_DEBUGGING = Reflection.getMethod(MINECRAFT_SERVER_CLASS, "isDebugging", 0);
/* 117 */     GET_BUKKIT_ENTITY_METHOD = Reflection.getMethod(NMS_ENTITY_CLASS, CRAFT_ENTITY_CLASS, 0);
/* 118 */     GET_CRAFT_PLAYER_HANDLE_METHOD = Reflection.getMethod(CRAFT_PLAYER_CLASS, "getHandle", 0);
/* 119 */     GET_CRAFT_ENTITY_HANDLE_METHOD = Reflection.getMethod(CRAFT_ENTITY_CLASS, "getHandle", 0);
/* 120 */     GET_CRAFT_WORLD_HANDLE_METHOD = Reflection.getMethod(CRAFT_WORLD_CLASS, "getHandle", 0);
/* 121 */     GET_MOB_EFFECT_LIST_ID_METHOD = Reflection.getMethod(MOB_EFFECT_LIST_CLASS, V_1_19_OR_HIGHER ? "g" : "getId", 0);
/* 122 */     GET_MOB_EFFECT_LIST_BY_ID_METHOD = Reflection.getMethod(MOB_EFFECT_LIST_CLASS, V_1_19_OR_HIGHER ? "a" : "fromId", 0);
/* 123 */     GET_ITEM_ID_METHOD = Reflection.getMethod(NMS_ITEM_CLASS, V_1_19_OR_HIGHER ? "g" : "getId", 0);
/* 124 */     GET_ITEM_BY_ID_METHOD = Reflection.getMethod(NMS_ITEM_CLASS, NMS_ITEM_CLASS, 0);
/* 125 */     if (V_1_17_OR_HIGHER)
/* 126 */       GET_LEVEL_ENTITY_GETTER_ITERABLE_METHOD = Reflection.getMethod(LEVEL_ENTITY_GETTER_CLASS, Iterable.class, 0); 
/* 128 */     if (DIMENSION_MANAGER_CLASS != null) {
/* 129 */       if (PacketEvents.getAPI().getServerManager().getVersion() == ServerVersion.V_1_16 || 
/* 130 */         PacketEvents.getAPI().getServerManager().getVersion() == ServerVersion.V_1_16_1)
/* 131 */         GET_DIMENSION_KEY = Reflection.getMethod(NMS_WORLD_CLASS, "getTypeKey", 0); 
/* 133 */       GET_DIMENSION_MANAGER = Reflection.getMethod(NMS_WORLD_CLASS, DIMENSION_MANAGER_CLASS, 0);
/* 134 */       GET_DIMENSION_ID = Reflection.getMethod(DIMENSION_MANAGER_CLASS, int.class, 0);
/*     */     } 
/* 136 */     if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_16_2)) {
/* 137 */       CODEC_ENCODE_METHOD = Reflection.getMethod(MOJANG_ENCODER_CLASS, "encodeStart", 0);
/* 138 */       DATA_RESULT_GET_METHOD = Reflection.getMethod(DATA_RESULT_CLASS, "result", 0);
/*     */     } 
/* 141 */     String getEntityByIdMethodName = (VERSION.getProtocolVersion() == 47 || V_1_19_OR_HIGHER) ? "a" : "getEntity";
/* 142 */     GET_ENTITY_BY_ID_METHOD = Reflection.getMethodExact(WORLD_SERVER_CLASS, getEntityByIdMethodName, NMS_ENTITY_CLASS, new Class[] { int.class });
/* 143 */     if (GET_ENTITY_BY_ID_METHOD == null)
/* 144 */       GET_ENTITY_BY_ID_METHOD = Reflection.getMethodExact(WORLD_SERVER_CLASS, "getEntity", NMS_ENTITY_CLASS, new Class[] { int.class }); 
/* 147 */     if (PacketEvents.getAPI().getServerManager().getVersion().isOlderThanOrEquals(ServerVersion.V_1_12_2)) {
/* 148 */       BUKKIT_PARTICLE_TO_NMS_ENUM_PARTICLE = Reflection.getMethod(CRAFT_PARTICLE_CLASS, "toNMS", new Class[] { NMS_ENUM_PARTICLE_CLASS });
/* 150 */       if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_9)) {
/* 151 */         Class<?> particleClass = Reflection.getClassByNameWithoutException("org.bukkit.Particle");
/* 152 */         NMS_ENUM_PARTICLE_TO_BUKKIT_PARTICLE = Reflection.getMethod(CRAFT_PARTICLE_CLASS, "toBukkit", new Class[] { particleClass });
/*     */       } 
/*     */     } 
/* 156 */     CRAFT_ITEM_STACK_AS_BUKKIT_COPY = Reflection.getMethod(CRAFT_ITEM_STACK_CLASS, "asBukkitCopy", 0);
/* 157 */     CRAFT_ITEM_STACK_AS_NMS_COPY = Reflection.getMethod(CRAFT_ITEM_STACK_CLASS, "asNMSCopy", new Class[] { ItemStack.class });
/* 160 */     READ_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD = Reflection.getMethodExact(NMS_PACKET_DATA_SERIALIZER_CLASS, "k", NMS_ITEM_STACK_CLASS, new Class[0]);
/* 161 */     if (READ_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD == null)
/* 162 */       READ_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD = Reflection.getMethod(NMS_PACKET_DATA_SERIALIZER_CLASS, NMS_ITEM_STACK_CLASS, 0); 
/* 164 */     WRITE_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD = Reflection.getMethodExact(NMS_PACKET_DATA_SERIALIZER_CLASS, "a", NMS_PACKET_DATA_SERIALIZER_CLASS, new Class[] { NMS_ITEM_STACK_CLASS });
/* 165 */     if (WRITE_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD == null)
/* 166 */       WRITE_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD = Reflection.getMethod(NMS_PACKET_DATA_SERIALIZER_CLASS, 0, new Class[] { NMS_ITEM_STACK_CLASS }); 
/* 169 */     GET_COMBINED_ID = Reflection.getMethod(BLOCK_CLASS, IBLOCK_DATA_CLASS, 0, new Class[] { int.class });
/* 170 */     GET_BY_COMBINED_ID = Reflection.getMethod(BLOCK_CLASS, IBLOCK_DATA_CLASS, 0, new Class[] { int.class });
/* 171 */     if (CRAFT_BLOCK_DATA_CLASS != null)
/* 172 */       GET_CRAFT_BLOCK_DATA_FROM_IBLOCKDATA = Reflection.getMethodExact(CRAFT_BLOCK_DATA_CLASS, "fromData", CRAFT_BLOCK_DATA_CLASS, new Class[] { IBLOCK_DATA_CLASS }); 
/* 175 */     READ_NBT_FROM_STREAM_METHOD = Reflection.getMethod(NBT_COMPRESSION_STREAM_TOOLS_CLASS, 0, new Class[] { DataInputStream.class });
/* 176 */     if (READ_NBT_FROM_STREAM_METHOD == null)
/* 177 */       READ_NBT_FROM_STREAM_METHOD = Reflection.getMethod(NBT_COMPRESSION_STREAM_TOOLS_CLASS, 0, new Class[] { DataInput.class }); 
/* 179 */     WRITE_NBT_TO_STREAM_METHOD = Reflection.getMethod(NBT_COMPRESSION_STREAM_TOOLS_CLASS, 0, new Class[] { NMS_NBT_COMPOUND_CLASS, DataOutput.class });
/*     */   }
/*     */   
/*     */   private static void initFields() {
/* 183 */     ENTITY_BOUNDING_BOX_FIELD = Reflection.getField(NMS_ENTITY_CLASS, BOUNDING_BOX_CLASS, 0, true);
/* 184 */     ENTITY_PLAYER_PING_FIELD = Reflection.getField(ENTITY_PLAYER_CLASS, "ping");
/* 185 */     BYTE_BUF_IN_PACKET_DATA_SERIALIZER = Reflection.getField(NMS_PACKET_DATA_SERIALIZER_CLASS, BYTE_BUF_CLASS, 0, true);
/* 186 */     CRAFT_PARTICLE_PARTICLES_FIELD = Reflection.getField(CRAFT_PARTICLE_CLASS, "particles");
/* 187 */     NMS_MK_KEY_FIELD = Reflection.getField(NMS_MINECRAFT_KEY_CLASS, "key");
/* 188 */     if (PacketEvents.getAPI().getServerManager().getVersion().isOlderThanOrEquals(ServerVersion.V_1_12_2)) {
/* 189 */       LEGACY_NMS_PARTICLE_KEY_FIELD = Reflection.getField(NMS_ENUM_PARTICLE_CLASS, "X");
/* 190 */       LEGACY_NMS_KEY_TO_NMS_PARTICLE = Reflection.getField(NMS_ENUM_PARTICLE_CLASS, "ac");
/*     */     } 
/* 192 */     if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_16_2)) {
/* 193 */       DIMENSION_CODEC_FIELD = Reflection.getField(DIMENSION_MANAGER_CLASS, MOJANG_CODEC_CLASS, 0);
/* 194 */       DYNAMIC_OPS_NBT_INSTANCE_FIELD = Reflection.getField(DYNAMIC_OPS_NBT_CLASS, DYNAMIC_OPS_NBT_CLASS, 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void initClasses() {
/* 199 */     MINECRAFT_SERVER_CLASS = getServerClass("server.MinecraftServer", "MinecraftServer");
/* 200 */     NMS_PACKET_DATA_SERIALIZER_CLASS = getServerClass("network.PacketDataSerializer", "PacketDataSerializer");
/* 201 */     NMS_ITEM_STACK_CLASS = getServerClass("world.item.ItemStack", "ItemStack");
/* 202 */     NMS_IMATERIAL_CLASS = getServerClass("world.level.IMaterial", "IMaterial");
/* 203 */     NMS_ENTITY_CLASS = getServerClass("world.entity.Entity", "Entity");
/* 204 */     ENTITY_PLAYER_CLASS = getServerClass("server.level.EntityPlayer", "EntityPlayer");
/* 205 */     BOUNDING_BOX_CLASS = getServerClass("world.phys.AxisAlignedBB", "AxisAlignedBB");
/* 206 */     NMS_MINECRAFT_KEY_CLASS = getServerClass("resources.MinecraftKey", "MinecraftKey");
/* 207 */     ENTITY_HUMAN_CLASS = getServerClass("world.entity.player.EntityHuman", "EntityHuman");
/* 208 */     PLAYER_CONNECTION_CLASS = getServerClass("server.network.PlayerConnection", "PlayerConnection");
/* 211 */     SERVER_COMMON_PACKETLISTENER_IMPL_CLASS = getServerClass("server.network.ServerCommonPacketListenerImpl", "ServerCommonPacketListenerImpl");
/* 213 */     SERVER_CONNECTION_CLASS = getServerClass("server.network.ServerConnection", "ServerConnection");
/* 214 */     NETWORK_MANAGER_CLASS = getServerClass("network.NetworkManager", "NetworkManager");
/* 215 */     MOB_EFFECT_LIST_CLASS = getServerClass("world.effect.MobEffectList", "MobEffectList");
/* 216 */     NMS_ITEM_CLASS = getServerClass("world.item.Item", "Item");
/* 217 */     DEDICATED_SERVER_CLASS = getServerClass("server.dedicated.DedicatedServer", "DedicatedServer");
/* 218 */     NMS_WORLD_CLASS = getServerClass("world.level.World", "World");
/* 219 */     WORLD_SERVER_CLASS = getServerClass("server.level.WorldServer", "WorldServer");
/* 220 */     ENUM_PROTOCOL_DIRECTION_CLASS = getServerClass("network.protocol.EnumProtocolDirection", "EnumProtocolDirection");
/* 221 */     if (V_1_17_OR_HIGHER) {
/* 222 */       LEVEL_ENTITY_GETTER_CLASS = getServerClass("world.level.entity.LevelEntityGetter", "");
/* 223 */       PERSISTENT_ENTITY_SECTION_MANAGER_CLASS = getServerClass("world.level.entity.PersistentEntitySectionManager", "");
/*     */     } 
/* 225 */     DIMENSION_MANAGER_CLASS = getServerClass("world.level.dimension.DimensionManager", "DimensionManager");
/* 226 */     if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_16_2)) {
/* 227 */       MOJANG_CODEC_CLASS = Reflection.getClassByNameWithoutException("com.mojang.serialization.Codec");
/* 228 */       MOJANG_ENCODER_CLASS = Reflection.getClassByNameWithoutException("com.mojang.serialization.Encoder");
/* 229 */       DATA_RESULT_CLASS = Reflection.getClassByNameWithoutException("com.mojang.serialization.DataResult");
/* 230 */       DYNAMIC_OPS_NBT_CLASS = getServerClass("nbt.DynamicOpsNBT", "DynamicOpsNBT");
/*     */     } 
/* 232 */     if (PacketEvents.getAPI().getServerManager().getVersion().isOlderThanOrEquals(ServerVersion.V_1_12_2))
/* 233 */       NMS_ENUM_PARTICLE_CLASS = getServerClass(null, "EnumParticle"); 
/* 236 */     CRAFT_MAGIC_NUMBERS_CLASS = getOBCClass("util.CraftMagicNumbers");
/* 238 */     IBLOCK_DATA_CLASS = getServerClass("world.level.block.state.IBlockData", "IBlockData");
/* 239 */     BLOCK_CLASS = getServerClass("world.level.block.Block", "Block");
/* 240 */     CRAFT_BLOCK_DATA_CLASS = getOBCClass("block.data.CraftBlockData");
/* 242 */     GAME_PROFILE_CLASS = Reflection.getClassByNameWithoutException("com.mojang.authlib.GameProfile");
/* 244 */     CRAFT_WORLD_CLASS = getOBCClass("CraftWorld");
/* 245 */     CRAFT_PLAYER_CLASS = getOBCClass("entity.CraftPlayer");
/* 246 */     CRAFT_SERVER_CLASS = getOBCClass("CraftServer");
/* 247 */     CRAFT_ENTITY_CLASS = getOBCClass("entity.CraftEntity");
/* 248 */     CRAFT_ITEM_STACK_CLASS = getOBCClass("inventory.CraftItemStack");
/* 249 */     CRAFT_PARTICLE_CLASS = getOBCClass("CraftParticle");
/* 251 */     CHANNEL_CLASS = getNettyClass("channel.Channel");
/* 252 */     BYTE_BUF_CLASS = getNettyClass("buffer.ByteBuf");
/* 253 */     BYTE_TO_MESSAGE_DECODER = getNettyClass("handler.codec.ByteToMessageDecoder");
/* 254 */     MESSAGE_TO_BYTE_ENCODER = getNettyClass("handler.codec.MessageToByteEncoder");
/* 255 */     NMS_NBT_COMPOUND_CLASS = getServerClass("nbt.NBTTagCompound", "NBTTagCompound");
/* 256 */     NBT_COMPRESSION_STREAM_TOOLS_CLASS = getServerClass("nbt.NBTCompressedStreamTools", "NBTCompressedStreamTools");
/*     */   }
/*     */   
/*     */   public static void init() {
/* 260 */     VERSION = PacketEvents.getAPI().getServerManager().getVersion();
/* 261 */     V_1_19_OR_HIGHER = VERSION.isNewerThanOrEquals(ServerVersion.V_1_19);
/* 262 */     V_1_17_OR_HIGHER = VERSION.isNewerThanOrEquals(ServerVersion.V_1_17);
/* 263 */     V_1_12_OR_HIGHER = VERSION.isNewerThanOrEquals(ServerVersion.V_1_12);
/* 265 */     initClasses();
/* 266 */     initFields();
/* 267 */     initMethods();
/* 268 */     initConstructors();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static Class<?> getServerClass(String modern, String legacy) {
/* 274 */     if (V_1_17_OR_HIGHER)
/* 275 */       return Reflection.getClassByNameWithoutException("net.minecraft." + modern); 
/* 277 */     return Reflection.getClassByNameWithoutException(LEGACY_NMS_PACKAGE + legacy);
/*     */   }
/*     */   
/*     */   public static boolean isMinecraftServerInstanceDebugging() {
/* 282 */     Object minecraftServerInstance = getMinecraftServerInstance(Bukkit.getServer());
/* 283 */     if (minecraftServerInstance != null && IS_DEBUGGING != null)
/*     */       try {
/* 285 */         return ((Boolean)IS_DEBUGGING.invoke(minecraftServerInstance, new Object[0])).booleanValue();
/* 286 */       } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 287 */         IS_DEBUGGING = null;
/* 288 */         return false;
/*     */       }  
/* 291 */     return false;
/*     */   }
/*     */   
/*     */   public static Object getMinecraftServerInstance(Server server) {
/* 295 */     if (MINECRAFT_SERVER_INSTANCE == null)
/*     */       try {
/* 298 */         MINECRAFT_SERVER_INSTANCE = Reflection.getField(CRAFT_SERVER_CLASS, MINECRAFT_SERVER_CLASS, 0).get(server);
/* 299 */       } catch (IllegalAccessException e) {
/* 300 */         e.printStackTrace();
/*     */       }  
/* 303 */     return MINECRAFT_SERVER_INSTANCE;
/*     */   }
/*     */   
/*     */   public static Object getMinecraftServerConnectionInstance() {
/* 307 */     if (MINECRAFT_SERVER_CONNECTION_INSTANCE == null)
/*     */       try {
/* 309 */         MINECRAFT_SERVER_CONNECTION_INSTANCE = Reflection.getField(MINECRAFT_SERVER_CLASS, SERVER_CONNECTION_CLASS, 0).get(getMinecraftServerInstance(Bukkit.getServer()));
/* 310 */       } catch (IllegalAccessException e) {
/* 311 */         e.printStackTrace();
/*     */       }  
/* 314 */     return MINECRAFT_SERVER_CONNECTION_INSTANCE;
/*     */   }
/*     */   
/*     */   public static double getTPS() {
/* 318 */     return recentTPS()[0];
/*     */   }
/*     */   
/*     */   public static double[] recentTPS() {
/* 322 */     return (new ReflectionObject(getMinecraftServerInstance(Bukkit.getServer()), MINECRAFT_SERVER_CLASS)).readDoubleArray(0);
/*     */   }
/*     */   
/*     */   public static Class<?> getNMSClass(String name) throws ClassNotFoundException {
/* 326 */     return Class.forName(LEGACY_NMS_PACKAGE + name);
/*     */   }
/*     */   
/*     */   public static Class<?> getOBCClass(String name) {
/* 330 */     return Reflection.getClassByNameWithoutException(OBC_PACKAGE + name);
/*     */   }
/*     */   
/*     */   public static Class<?> getNettyClass(String name) {
/* 334 */     return Reflection.getClassByNameWithoutException("io.netty." + name);
/*     */   }
/*     */   
/*     */   public static Entity getBukkitEntity(Object nmsEntity) {
/* 338 */     Object craftEntity = null;
/*     */     try {
/* 340 */       craftEntity = GET_BUKKIT_ENTITY_METHOD.invoke(nmsEntity, new Object[0]);
/* 341 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 342 */       e.printStackTrace();
/*     */     } 
/* 344 */     return (Entity)craftEntity;
/*     */   }
/*     */   
/*     */   public static Object getNMSEntity(Entity entity) {
/* 348 */     Object craftEntity = CRAFT_ENTITY_CLASS.cast(entity);
/*     */     try {
/* 350 */       return GET_CRAFT_ENTITY_HANDLE_METHOD.invoke(craftEntity, new Object[0]);
/* 351 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 352 */       e.printStackTrace();
/* 354 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object getNMSAxisAlignedBoundingBox(Object nmsEntity) {
/*     */     try {
/* 359 */       return ENTITY_BOUNDING_BOX_FIELD.get(NMS_ENTITY_CLASS.cast(nmsEntity));
/* 360 */     } catch (IllegalAccessException e) {
/* 361 */       e.printStackTrace();
/* 363 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object getCraftPlayer(Player player) {
/* 367 */     return CRAFT_PLAYER_CLASS.cast(player);
/*     */   }
/*     */   
/*     */   public static Object getEntityPlayer(Player player) {
/* 371 */     Object craftPlayer = getCraftPlayer(player);
/*     */     try {
/* 373 */       return GET_CRAFT_PLAYER_HANDLE_METHOD.invoke(craftPlayer, new Object[0]);
/* 374 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 375 */       e.printStackTrace();
/* 377 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object getPlayerConnection(Player player) {
/* 381 */     Object entityPlayer = getEntityPlayer(player);
/* 382 */     if (entityPlayer == null)
/* 383 */       return null; 
/* 385 */     ReflectionObject wrappedEntityPlayer = new ReflectionObject(entityPlayer, ENTITY_PLAYER_CLASS);
/* 386 */     return wrappedEntityPlayer.readObject(0, PLAYER_CONNECTION_CLASS);
/*     */   }
/*     */   
/*     */   public static Object getGameProfile(Player player) {
/* 390 */     Object entityPlayer = getEntityPlayer(player);
/* 391 */     ReflectionObject entityHumanWrapper = new ReflectionObject(entityPlayer, ENTITY_HUMAN_CLASS);
/* 392 */     return entityHumanWrapper.readObject(0, GAME_PROFILE_CLASS);
/*     */   }
/*     */   
/*     */   public static List<TextureProperty> getUserProfile(Player player) {
/* 396 */     if (PROPERTY_MAP_CLASS == null) {
/* 397 */       PROPERTY_MAP_CLASS = Reflection.getClassByNameWithoutException("com.mojang.authlib.properties.PropertyMap");
/* 399 */       PROPERTY_MAP_GET_METHOD = Reflection.getMethodExact(PROPERTY_MAP_CLASS, "get", Collection.class, new Class[] { Object.class });
/*     */     } 
/* 403 */     Object nmsGameProfile = getGameProfile(player);
/* 404 */     ReflectionObject reflectGameProfile = new ReflectionObject(nmsGameProfile);
/* 405 */     Object nmsPropertyMap = reflectGameProfile.readObject(0, PROPERTY_MAP_CLASS);
/* 407 */     Collection<Object> nmsProperties = null;
/*     */     try {
/* 410 */       nmsProperties = (Collection<Object>)PROPERTY_MAP_GET_METHOD.invoke(nmsPropertyMap, new Object[] { "textures" });
/* 411 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 412 */       e.printStackTrace();
/*     */     } 
/* 414 */     List<TextureProperty> properties = new ArrayList<>();
/* 416 */     for (Object nmsProperty : nmsProperties) {
/* 418 */       ReflectionObject reflectProperty = new ReflectionObject(nmsProperty);
/* 419 */       String name = "textures";
/* 420 */       String value = reflectProperty.readString(1);
/* 421 */       String signature = reflectProperty.readString(2);
/* 422 */       TextureProperty textureProperty = new TextureProperty(name, value, signature);
/* 424 */       properties.add(textureProperty);
/*     */     } 
/* 427 */     return properties;
/*     */   }
/*     */   
/*     */   public static Object getNetworkManager(Player player) {
/* 431 */     Object playerConnection = getPlayerConnection(player);
/* 432 */     if (playerConnection == null)
/* 433 */       return null; 
/* 436 */     Class<?> playerConnectionClass = (SERVER_COMMON_PACKETLISTENER_IMPL_CLASS != null) ? SERVER_COMMON_PACKETLISTENER_IMPL_CLASS : PLAYER_CONNECTION_CLASS;
/* 437 */     ReflectionObject wrapper = new ReflectionObject(playerConnection, playerConnectionClass);
/*     */     try {
/* 439 */       return wrapper.readObject(0, NETWORK_MANAGER_CLASS);
/* 440 */     } catch (Exception ex) {
/*     */       try {
/* 443 */         playerConnection = wrapper.read(0, PLAYER_CONNECTION_CLASS);
/* 444 */         wrapper = new ReflectionObject(playerConnection, PLAYER_CONNECTION_CLASS);
/* 445 */         return wrapper.readObject(0, NETWORK_MANAGER_CLASS);
/* 447 */       } catch (Exception ex2) {
/* 449 */         ex.printStackTrace();
/* 452 */         return null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object getChannel(Player player) {
/* 456 */     Object networkManager = getNetworkManager(player);
/* 457 */     if (networkManager == null)
/* 458 */       return null; 
/* 460 */     ReflectionObject wrapper = new ReflectionObject(networkManager, NETWORK_MANAGER_CLASS);
/* 461 */     return wrapper.readObject(0, CHANNEL_CLASS);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static int getPlayerPingLegacy(Player player) {
/* 466 */     if (V_1_17_OR_HIGHER)
/* 467 */       return -1; 
/* 469 */     if (ENTITY_PLAYER_PING_FIELD != null) {
/* 470 */       Object entityPlayer = getEntityPlayer(player);
/*     */       try {
/* 472 */         return ENTITY_PLAYER_PING_FIELD.getInt(entityPlayer);
/* 473 */       } catch (IllegalAccessException e) {
/* 474 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/* 477 */     return -1;
/*     */   }
/*     */   
/*     */   public static List<Object> getNetworkManagers() {
/* 481 */     ReflectionObject serverConnectionWrapper = new ReflectionObject(getMinecraftServerConnectionInstance());
/* 482 */     for (int i = 0;; i++) {
/*     */       try {
/* 484 */         List<?> list = (List)serverConnectionWrapper.readObject(i, List.class);
/* 485 */         for (Object obj : list) {
/* 486 */           if (obj.getClass().isAssignableFrom(NETWORK_MANAGER_CLASS))
/* 487 */             return (List)list; 
/*     */         } 
/* 490 */       } catch (Exception ex) {
/*     */         break;
/*     */       } 
/*     */     } 
/* 495 */     return (List<Object>)serverConnectionWrapper.readObject(1, List.class);
/*     */   }
/*     */   
/*     */   public static Object convertBukkitServerToNMSServer(Server server) {
/* 499 */     Object craftServer = CRAFT_SERVER_CLASS.cast(server);
/* 500 */     ReflectionObject wrapper = new ReflectionObject(craftServer);
/*     */     try {
/* 502 */       return wrapper.readObject(0, MINECRAFT_SERVER_CLASS);
/* 503 */     } catch (Exception ex) {
/* 504 */       wrapper.readObject(0, DEDICATED_SERVER_CLASS);
/* 506 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object convertBukkitWorldToWorldServer(World world) {
/* 510 */     Object craftWorld = CRAFT_WORLD_CLASS.cast(world);
/*     */     try {
/* 512 */       return GET_CRAFT_WORLD_HANDLE_METHOD.invoke(craftWorld, new Object[0]);
/* 513 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 514 */       e.printStackTrace();
/* 516 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object convertWorldServerDimensionToNMSNbt(Object worldServer) {
/*     */     try {
/* 521 */       Object dimension = GET_DIMENSION_MANAGER.invoke(worldServer, new Object[0]);
/* 522 */       Object dynamicNbtOps = DYNAMIC_OPS_NBT_INSTANCE_FIELD.get(null);
/* 523 */       Object dataResult = CODEC_ENCODE_METHOD.invoke(DIMENSION_CODEC_FIELD.get(null), new Object[] { dynamicNbtOps, dimension });
/* 524 */       Optional<?> optional = (Optional)DATA_RESULT_GET_METHOD.invoke(dataResult, new Object[0]);
/* 525 */       return optional.orElse(null);
/* 526 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 527 */       e.printStackTrace();
/* 529 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int getDimensionId(Object worldServer) {
/*     */     try {
/* 534 */       Object dimension = GET_DIMENSION_MANAGER.invoke(worldServer, new Object[0]);
/* 535 */       return ((Integer)GET_DIMENSION_ID.invoke(dimension, new Object[0])).intValue();
/* 536 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 537 */       e.printStackTrace();
/* 539 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getDimensionKey(Object worldServer) {
/*     */     try {
/* 544 */       return GET_DIMENSION_KEY.invoke(worldServer, new Object[0]).toString();
/* 545 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 546 */       e.printStackTrace();
/* 548 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String fromStringToJSON(String message) {
/* 552 */     if (message == null)
/* 553 */       return null; 
/* 555 */     return "{\"text\": \"" + message + "\"}";
/*     */   }
/*     */   
/*     */   public static int generateEntityId() {
/* 559 */     Field field = Reflection.getField(NMS_ENTITY_CLASS, "entityCount");
/* 560 */     if (field == null)
/* 561 */       field = Reflection.getField(NMS_ENTITY_CLASS, AtomicInteger.class, 0); 
/*     */     try {
/* 564 */       if (field.getType().equals(AtomicInteger.class)) {
/* 566 */         AtomicInteger atomicInteger = (AtomicInteger)field.get(null);
/* 567 */         return atomicInteger.incrementAndGet();
/*     */       } 
/* 569 */       int id = field.getInt(null) + 1;
/* 570 */       field.set(null, Integer.valueOf(id));
/* 571 */       return id;
/* 573 */     } catch (IllegalAccessException ex) {
/* 574 */       ex.printStackTrace();
/* 576 */       throw new IllegalStateException("Failed to generate a new unique entity ID!");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int getEffectId(Object nmsMobEffectList) {
/*     */     try {
/* 581 */       return ((Integer)GET_MOB_EFFECT_LIST_ID_METHOD.invoke(null, new Object[] { nmsMobEffectList })).intValue();
/* 582 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 583 */       e.printStackTrace();
/* 585 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object getMobEffectListById(int effectID) {
/*     */     try {
/* 590 */       return GET_MOB_EFFECT_LIST_BY_ID_METHOD.invoke(null, new Object[] { Integer.valueOf(effectID) });
/* 591 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 592 */       e.printStackTrace();
/* 594 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int getNMSItemId(Object nmsItem) {
/*     */     try {
/* 599 */       return ((Integer)GET_ITEM_ID_METHOD.invoke(null, new Object[] { nmsItem })).intValue();
/* 600 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 601 */       e.printStackTrace();
/* 603 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object getNMSItemById(int id) {
/*     */     try {
/* 608 */       return GET_ITEM_BY_ID_METHOD.invoke(null, new Object[] { Integer.valueOf(id) });
/* 609 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 610 */       e.printStackTrace();
/* 612 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object createNMSItemStack(Object nmsItem, int count) {
/*     */     try {
/* 617 */       return NMS_ITEM_STACK_CONSTRUCTOR.newInstance(new Object[] { nmsItem, Integer.valueOf(count) });
/* 618 */     } catch (InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 619 */       e.printStackTrace();
/* 621 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ItemStack decodeBukkitItemStack(ItemStack in) {
/* 625 */     Object buffer = PooledByteBufAllocator.DEFAULT.buffer();
/* 627 */     Object packetDataSerializer = createPacketDataSerializer(buffer);
/* 628 */     Object nmsItemStack = toNMSItemStack(in);
/* 629 */     writeNMSItemStackPacketDataSerializer(packetDataSerializer, nmsItemStack);
/* 631 */     PacketWrapper<?> wrapper = PacketWrapper.createUniversalPacketWrapper(buffer);
/* 632 */     ItemStack stack = wrapper.readItemStack();
/* 633 */     ByteBufHelper.release(buffer);
/* 634 */     return stack;
/*     */   }
/*     */   
/*     */   public static ItemStack encodeBukkitItemStack(ItemStack in) {
/* 638 */     Object buffer = PooledByteBufAllocator.DEFAULT.buffer();
/* 639 */     PacketWrapper<?> wrapper = PacketWrapper.createUniversalPacketWrapper(buffer);
/* 640 */     wrapper.writeItemStack(in);
/* 642 */     Object packetDataSerializer = createPacketDataSerializer(wrapper.getBuffer());
/* 643 */     Object nmsItemStack = readNMSItemStackPacketDataSerializer(packetDataSerializer);
/* 644 */     ItemStack stack = toBukkitItemStack(nmsItemStack);
/* 645 */     ByteBufHelper.release(buffer);
/* 646 */     return stack;
/*     */   }
/*     */   
/*     */   public static int getBlockDataCombinedId(MaterialData materialData) {
/*     */     int combinedID;
/* 650 */     if (PacketEvents.getAPI().getServerManager().getVersion() == ServerVersion.V_1_7_10)
/* 652 */       throw new IllegalStateException("This operation is not supported yet on 1.7.10!"); 
/* 656 */     if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_13)) {
/* 657 */       combinedID = -1;
/*     */     } else {
/* 659 */       combinedID = materialData.getItemType().getId() << 4 | materialData.getData();
/*     */     } 
/* 662 */     return combinedID;
/*     */   }
/*     */   
/*     */   public static MaterialData getBlockDataByCombinedId(int combinedID) {
/* 675 */     if (PacketEvents.getAPI().getServerManager().getVersion() == ServerVersion.V_1_7_10)
/* 677 */       throw new IllegalStateException("This operation is not supported yet on 1.7.10!"); 
/* 692 */     return null;
/*     */   }
/*     */   
/*     */   public static Object createNMSItemStack(int itemID, int count) {
/*     */     try {
/* 697 */       Object nmsItem = getNMSItemById(itemID);
/* 698 */       return NMS_ITEM_STACK_CONSTRUCTOR.newInstance(new Object[] { nmsItem, Integer.valueOf(count) });
/* 699 */     } catch (InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 700 */       e.printStackTrace();
/* 702 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object createPacketDataSerializer(Object byteBuf) {
/*     */     try {
/* 707 */       return NMS_PACKET_DATA_SERIALIZER_CONSTRUCTOR.newInstance(new Object[] { byteBuf });
/* 708 */     } catch (InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 709 */       e.printStackTrace();
/* 711 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ItemStack toBukkitItemStack(Object nmsItemStack) {
/*     */     try {
/* 716 */       return (ItemStack)CRAFT_ITEM_STACK_AS_BUKKIT_COPY.invoke(null, new Object[] { nmsItemStack });
/* 717 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 718 */       e.printStackTrace();
/* 720 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object toNMSItemStack(ItemStack itemStack) {
/*     */     try {
/* 725 */       return CRAFT_ITEM_STACK_AS_NMS_COPY.invoke(null, new Object[] { itemStack });
/* 726 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 727 */       e.printStackTrace();
/* 729 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object readNMSItemStackPacketDataSerializer(Object packetDataSerializer) {
/*     */     try {
/* 735 */       return READ_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD.invoke(packetDataSerializer, new Object[0]);
/* 736 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 737 */       e.printStackTrace();
/* 739 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object writeNMSItemStackPacketDataSerializer(Object packetDataSerializer, Object nmsItemStack) {
/*     */     try {
/* 744 */       return WRITE_ITEM_STACK_IN_PACKET_DATA_SERIALIZER_METHOD.invoke(packetDataSerializer, new Object[] { nmsItemStack });
/* 745 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 746 */       e.printStackTrace();
/* 748 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static NBTCompound fromMinecraftNBT(Object nbtCompound) {
/*     */     byte[] bytes;
/*     */     try {
/* 753 */       ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
/*     */       try {
/* 754 */         DataOutputStream stream = new DataOutputStream(byteStream);
/*     */         try {
/* 755 */           writeNmsNbtToStream(nbtCompound, stream);
/* 756 */           bytes = byteStream.toByteArray();
/* 757 */           stream.close();
/*     */         } catch (Throwable throwable) {
/*     */           try {
/*     */             stream.close();
/*     */           } catch (Throwable throwable1) {
/*     */             throwable.addSuppressed(throwable1);
/*     */           } 
/*     */           throw throwable;
/*     */         } 
/* 757 */         byteStream.close();
/*     */       } catch (Throwable throwable) {
/*     */         try {
/*     */           byteStream.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */         throw throwable;
/*     */       } 
/* 757 */     } catch (IOException e) {
/* 758 */       e.printStackTrace();
/* 759 */       return null;
/*     */     } 
/* 762 */     Object buffer = UnpooledByteBufAllocationHelper.wrappedBuffer(bytes);
/* 763 */     PacketWrapper<?> wrapper = PacketWrapper.createUniversalPacketWrapper(buffer);
/* 764 */     NBTCompound nbt = wrapper.readNBT();
/* 765 */     ByteBufHelper.release(buffer);
/* 766 */     return nbt;
/*     */   }
/*     */   
/*     */   public static Object toMinecraftNBT(NBTCompound nbtCompound) {
/* 770 */     Object buffer = UnpooledByteBufAllocationHelper.buffer();
/* 771 */     PacketWrapper<?> wrapper = PacketWrapper.createUniversalPacketWrapper(buffer);
/* 772 */     wrapper.writeNBT(nbtCompound);
/* 773 */     byte[] bytes = ByteBufHelper.copyBytes(buffer);
/* 774 */     ByteBufHelper.release(buffer);
/*     */     try {
/* 775 */       ByteArrayInputStream byteStream = new ByteArrayInputStream(bytes);
/*     */       try {
/* 776 */         DataInputStream stream = new DataInputStream(byteStream);
/*     */         try {
/* 777 */           Object object = readNmsNbtFromStream(stream);
/* 778 */           stream.close();
/* 778 */           byteStream.close();
/*     */           return object;
/*     */         } catch (Throwable throwable) {
/*     */           try {
/*     */             stream.close();
/*     */           } catch (Throwable throwable1) {
/*     */             throwable.addSuppressed(throwable1);
/*     */           } 
/*     */           throw throwable;
/*     */         } 
/*     */       } catch (Throwable throwable) {
/*     */         try {
/*     */           byteStream.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */         throw throwable;
/*     */       } 
/* 778 */     } catch (IOException e) {
/* 779 */       e.printStackTrace();
/* 780 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void writeNmsNbtToStream(Object compound, DataOutput out) {
/*     */     try {
/* 786 */       WRITE_NBT_TO_STREAM_METHOD.invoke(null, new Object[] { compound, out });
/* 787 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 788 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object readNmsNbtFromStream(DataInputStream in) {
/*     */     try {
/* 794 */       return READ_NBT_FROM_STREAM_METHOD.invoke(null, new Object[] { in });
/* 795 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 796 */       e.printStackTrace();
/* 798 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Entity getEntityByIdWithWorldUnsafe(World world, int id) {
/* 802 */     if (world == null)
/* 803 */       return null; 
/* 806 */     Object craftWorld = CRAFT_WORLD_CLASS.cast(world);
/*     */     try {
/* 809 */       Object worldServer = GET_CRAFT_WORLD_HANDLE_METHOD.invoke(craftWorld, new Object[0]);
/* 810 */       Object nmsEntity = GET_ENTITY_BY_ID_METHOD.invoke(worldServer, new Object[] { Integer.valueOf(id) });
/* 811 */       if (nmsEntity == null)
/* 812 */         return null; 
/* 814 */       return getBukkitEntity(nmsEntity);
/* 815 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 816 */       e.printStackTrace();
/* 818 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static Entity getEntityByIdUnsafe(World origin, int id) {
/* 824 */     Entity e = getEntityByIdWithWorldUnsafe(origin, id);
/* 825 */     if (e != null)
/* 826 */       return e; 
/* 828 */     for (World world : Bukkit.getWorlds()) {
/* 829 */       Entity entity = getEntityByIdWithWorldUnsafe(world, id);
/* 830 */       if (entity != null)
/* 831 */         return entity; 
/*     */     } 
/* 834 */     for (World world : Bukkit.getWorlds()) {
/*     */       try {
/* 836 */         for (Entity entity : world.getEntities()) {
/* 837 */           if (entity.getEntityId() == id)
/* 838 */             return entity; 
/*     */         } 
/* 841 */       } catch (ConcurrentModificationException ex) {
/* 842 */         return null;
/*     */       } 
/*     */     } 
/* 845 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static Entity getEntityById(@Nullable World world, int entityID) {
/* 850 */     Entity e = ENTITY_ID_CACHE.get(Integer.valueOf(entityID));
/* 851 */     if (e != null)
/* 852 */       return e; 
/* 855 */     if (V_1_17_OR_HIGHER) {
/*     */       try {
/* 857 */         if (world != null)
/* 860 */           for (Entity entity : getEntityList(world)) {
/* 861 */             if (entity.getEntityId() == entityID) {
/* 862 */               ENTITY_ID_CACHE.putIfAbsent(Integer.valueOf(entity.getEntityId()), entity);
/* 863 */               return entity;
/*     */             } 
/*     */           }  
/* 867 */       } catch (Exception ex) {
/* 868 */         System.out.println("Failed to find entity by id on 1.19.3!");
/* 869 */         throw ex;
/*     */       } 
/*     */       try {
/* 873 */         for (World w : Bukkit.getWorlds()) {
/* 874 */           for (Entity entity : getEntityList(w)) {
/* 875 */             if (entity.getEntityId() == entityID) {
/* 876 */               ENTITY_ID_CACHE.putIfAbsent(Integer.valueOf(entity.getEntityId()), entity);
/* 877 */               return entity;
/*     */             } 
/*     */           } 
/*     */         } 
/* 881 */       } catch (Exception ex) {
/* 883 */         return null;
/*     */       } 
/*     */     } else {
/* 886 */       return getEntityByIdUnsafe(world, entityID);
/*     */     } 
/* 888 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static Entity getEntityById(int entityID) {
/* 893 */     return getEntityById(null, entityID);
/*     */   }
/*     */   
/*     */   public static List<Entity> getEntityList(World world) {
/* 897 */     if (V_1_17_OR_HIGHER) {
/* 898 */       Object worldServer = convertBukkitWorldToWorldServer(world);
/* 899 */       ReflectionObject wrappedWorldServer = new ReflectionObject(worldServer);
/* 900 */       Object persistentEntitySectionManager = wrappedWorldServer.readObject(0, PERSISTENT_ENTITY_SECTION_MANAGER_CLASS);
/* 901 */       ReflectionObject wrappedPersistentEntitySectionManager = new ReflectionObject(persistentEntitySectionManager);
/* 902 */       Object levelEntityGetter = wrappedPersistentEntitySectionManager.readObject(0, LEVEL_ENTITY_GETTER_CLASS);
/* 903 */       Iterable<Object> nmsEntitiesIterable = null;
/*     */       try {
/* 905 */         nmsEntitiesIterable = (Iterable<Object>)GET_LEVEL_ENTITY_GETTER_ITERABLE_METHOD.invoke(levelEntityGetter, new Object[0]);
/* 906 */       } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 907 */         e.printStackTrace();
/*     */       } 
/* 909 */       List<Entity> entityList = new ArrayList<>();
/* 910 */       if (nmsEntitiesIterable != null)
/* 911 */         for (Object nmsEntity : nmsEntitiesIterable) {
/* 912 */           Entity bukkitEntity = getBukkitEntity(nmsEntity);
/* 913 */           entityList.add(bukkitEntity);
/*     */         }  
/* 916 */       return entityList;
/*     */     } 
/* 918 */     return world.getEntities();
/*     */   }
/*     */   
/*     */   public static ParticleType toPacketEventsParticle(Enum<?> particle) {
/*     */     try {
/* 924 */       if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_13)) {
/* 925 */         BiMap<?, ?> map = (BiMap<?, ?>)CRAFT_PARTICLE_PARTICLES_FIELD.get(null);
/* 928 */         if (particle.name().equals("BLOCK_DUST"))
/* 929 */           particle = Enum.valueOf(particle.getClass(), "BLOCK_CRACK"); 
/* 931 */         Object object = map.get(particle);
/* 932 */         return ParticleTypes.getByName(object.toString());
/*     */       } 
/* 934 */       Object nmsParticle = BUKKIT_PARTICLE_TO_NMS_ENUM_PARTICLE.invoke(null, new Object[] { particle });
/* 935 */       String key = (String)LEGACY_NMS_PARTICLE_KEY_FIELD.get(nmsParticle);
/* 936 */       Object minecraftKey = NMS_MINECRAFT_KEY_CONSTRUCTOR.newInstance(new Object[] { "minecraft", key });
/* 937 */       return ParticleTypes.getByName(minecraftKey.toString());
/* 939 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException|InstantiationException e) {
/* 940 */       e.printStackTrace();
/* 942 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Enum<?> fromPacketEventsParticle(ParticleType particle) {
/*     */     try {
/* 947 */       if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_13)) {
/* 948 */         BiMap<?, ?> map = (BiMap<?, ?>)CRAFT_PARTICLE_PARTICLES_FIELD.get(null);
/* 949 */         Object minecraftKey = NMS_MINECRAFT_KEY_CONSTRUCTOR.newInstance(new Object[] { particle.getName().getNamespace(), particle.getName().getKey() });
/* 950 */         Object object1 = map.inverse().get(minecraftKey);
/* 951 */         return (Enum)object1;
/*     */       } 
/* 953 */       Map<String, ?> keyToParticleMap = (Map<String, ?>)LEGACY_NMS_KEY_TO_NMS_PARTICLE.get(null);
/* 954 */       Object enumParticle = keyToParticleMap.get(particle.getName().getKey());
/* 955 */       Object bukkitParticle = NMS_ENUM_PARTICLE_TO_BUKKIT_PARTICLE.invoke(null, new Object[] { enumParticle });
/* 956 */       return (Enum)bukkitParticle;
/* 958 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException|InstantiationException e) {
/* 959 */       e.printStackTrace();
/* 961 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\SpigotReflectionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */