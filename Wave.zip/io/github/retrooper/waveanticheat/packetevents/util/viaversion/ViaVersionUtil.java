/*     */ package io.github.retrooper.waveanticheat.packetevents.util.viaversion;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import com.github.retrooper.packetevents.util.reflection.Reflection;
/*     */ import io.netty.channel.Channel;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class ViaVersionUtil {
/*  28 */   private static ViaState available = ViaState.UNKNOWN;
/*     */   
/*     */   private static ViaVersionAccessor viaVersionAccessor;
/*     */   
/*     */   private static void load() {
/*  35 */     if (viaVersionAccessor == null)
/*     */       try {
/*  37 */         Class.forName("com.viaversion.viaversion.api.Via");
/*  38 */         viaVersionAccessor = new ViaVersionAccessorImpl();
/*  39 */       } catch (Exception e) {
/*     */         try {
/*  41 */           Class.forName("us.myles.ViaVersion.api.Via");
/*  42 */           viaVersionAccessor = new ViaVersionAccessorImplLegacy();
/*  43 */         } catch (ClassNotFoundException ex) {
/*  44 */           viaVersionAccessor = null;
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   public static void checkIfViaIsPresent() {
/*  51 */     boolean present = Bukkit.getPluginManager().isPluginEnabled("ViaVersion");
/*  52 */     available = present ? ViaState.ENABLED : ViaState.DISABLED;
/*     */   }
/*     */   
/*     */   public static boolean isAvailable() {
/*  56 */     if (available == ViaState.UNKNOWN)
/*  57 */       return (getViaVersionAccessor() != null); 
/*  59 */     return (available == ViaState.ENABLED);
/*     */   }
/*     */   
/*     */   public static ViaVersionAccessor getViaVersionAccessor() {
/*  63 */     load();
/*  64 */     return viaVersionAccessor;
/*     */   }
/*     */   
/*     */   public static int getProtocolVersion(User user) {
/*     */     try {
/*  69 */       if (user.getUUID() != null) {
/*  70 */         Player player = Bukkit.getPlayer(user.getUUID());
/*  71 */         if (player != null) {
/*  72 */           int version = getProtocolVersion(player);
/*  74 */           if (version != -1)
/*  74 */             return version; 
/*     */         } 
/*     */       } 
/*  77 */       Object viaEncoder = ((Channel)user.getChannel()).pipeline().get("via-encoder");
/*  78 */       Object connection = Reflection.getField(viaEncoder.getClass(), "connection").get(viaEncoder);
/*  79 */       Object protocolInfo = Reflection.getField(connection.getClass(), "protocolInfo").get(connection);
/*  80 */       return ((Integer)Reflection.getField(protocolInfo.getClass(), "protocolVersion").get(protocolInfo)).intValue();
/*  81 */     } catch (Exception e) {
/*  82 */       System.out.println("Unable to grab ViaVersion client version for player!");
/*  83 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int getProtocolVersion(Player player) {
/*  88 */     return getViaVersionAccessor().getProtocolVersion(player);
/*     */   }
/*     */   
/*     */   public static Class<?> getUserConnectionClass() {
/*  92 */     return getViaVersionAccessor().getUserConnectionClass();
/*     */   }
/*     */   
/*     */   public static Class<?> getBukkitDecodeHandlerClass() {
/*  96 */     return getViaVersionAccessor().getBukkitDecodeHandlerClass();
/*     */   }
/*     */   
/*     */   public static Class<?> getBukkitEncodeHandlerClass() {
/* 100 */     return getViaVersionAccessor().getBukkitEncodeHandlerClass();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\viaversion\ViaVersionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */