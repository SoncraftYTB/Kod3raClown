package io.github.retrooper.waveanticheat.packetevents.util.viaversion;

import org.bukkit.entity.Player;

public interface ViaVersionAccessor {
  int getProtocolVersion(Player paramPlayer);
  
  Class<?> getUserConnectionClass();
  
  Class<?> getBukkitDecodeHandlerClass();
  
  Class<?> getBukkitEncodeHandlerClass();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\viaversion\ViaVersionAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */