/*    */ package io.github.retrooper.waveanticheat.packetevents.util.viaversion;
/*    */ 
/*    */ import com.viaversion.viaversion.api.Via;
/*    */ import com.viaversion.viaversion.api.connection.UserConnection;
/*    */ import com.viaversion.viaversion.bukkit.handlers.BukkitDecodeHandler;
/*    */ import com.viaversion.viaversion.bukkit.handlers.BukkitEncodeHandler;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ViaVersionAccessorImpl implements ViaVersionAccessor {
/*    */   public int getProtocolVersion(Player player) {
/* 30 */     return Via.getAPI().getPlayerVersion(player);
/*    */   }
/*    */   
/*    */   public Class<?> getUserConnectionClass() {
/* 35 */     return UserConnection.class;
/*    */   }
/*    */   
/*    */   public Class<?> getBukkitDecodeHandlerClass() {
/* 40 */     return BukkitDecodeHandler.class;
/*    */   }
/*    */   
/*    */   public Class<?> getBukkitEncodeHandlerClass() {
/* 45 */     return BukkitEncodeHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\viaversion\ViaVersionAccessorImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */