/*     */ package io.github.retrooper.waveanticheat.packetevents.util.viaversion;
/*     */ 
/*     */ enum ViaState {
/* 105 */   UNKNOWN, DISABLED, ENABLED;
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\viaversion\ViaState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */