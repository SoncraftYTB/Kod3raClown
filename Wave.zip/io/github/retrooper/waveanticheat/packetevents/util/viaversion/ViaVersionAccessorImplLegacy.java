/*    */ package io.github.retrooper.waveanticheat.packetevents.util.viaversion;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ViaVersionAccessorImplLegacy implements ViaVersionAccessor {
/*    */   private Class<?> viaClass;
/*    */   
/*    */   private Class<?> bukkitDecodeHandlerClass;
/*    */   
/*    */   private Class<?> bukkitEncodeHandlerClass;
/*    */   
/*    */   private Field viaManagerField;
/*    */   
/*    */   private Method apiAccessor;
/*    */   
/*    */   private Method getPlayerVersionMethod;
/*    */   
/*    */   private Class<?> userConnectionClass;
/*    */   
/*    */   private void load() {
/* 38 */     if (this.viaClass == null)
/*    */       try {
/* 40 */         this.viaClass = Class.forName("us.myles.ViaVersion.api.Via");
/* 41 */         this.viaManagerField = this.viaClass.getDeclaredField("manager");
/* 42 */         this.bukkitDecodeHandlerClass = Class.forName("us.myles.ViaVersion.bukkit.handlers.BukkitDecodeHandler");
/* 43 */         this.bukkitEncodeHandlerClass = Class.forName("us.myles.ViaVersion.bukkit.handlers.BukkitEncodeHandler");
/* 44 */         Class<?> viaAPIClass = Class.forName("us.myles.ViaVersion.api.ViaAPI");
/* 45 */         this.apiAccessor = this.viaClass.getMethod("getAPI", new Class[0]);
/* 46 */         this.getPlayerVersionMethod = viaAPIClass.getMethod("getPlayerVersion", new Class[] { Object.class });
/* 47 */       } catch (ClassNotFoundException|NoSuchMethodException|NoSuchFieldException e) {
/* 48 */         e.printStackTrace();
/*    */       }  
/* 52 */     if (this.userConnectionClass == null)
/*    */       try {
/* 54 */         this.userConnectionClass = Class.forName("us.myles.ViaVersion.api.data.UserConnection");
/* 55 */       } catch (ClassNotFoundException e) {
/* 56 */         e.printStackTrace();
/*    */       }  
/*    */   }
/*    */   
/*    */   public int getProtocolVersion(Player player) {
/* 63 */     load();
/*    */     try {
/* 65 */       Object viaAPI = this.apiAccessor.invoke(null, new Object[0]);
/* 66 */       return ((Integer)this.getPlayerVersionMethod.invoke(viaAPI, new Object[] { player })).intValue();
/* 67 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 68 */       e.printStackTrace();
/* 70 */       return -1;
/*    */     } 
/*    */   }
/*    */   
/*    */   public Class<?> getUserConnectionClass() {
/* 74 */     load();
/* 75 */     return this.userConnectionClass;
/*    */   }
/*    */   
/*    */   public Class<?> getBukkitDecodeHandlerClass() {
/* 80 */     load();
/* 81 */     return this.bukkitDecodeHandlerClass;
/*    */   }
/*    */   
/*    */   public Class<?> getBukkitEncodeHandlerClass() {
/* 86 */     load();
/* 87 */     return this.bukkitEncodeHandlerClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevent\\util\viaversion\ViaVersionAccessorImplLegacy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */