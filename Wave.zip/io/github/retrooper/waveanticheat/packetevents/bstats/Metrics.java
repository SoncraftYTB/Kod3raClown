/*     */ package io.github.retrooper.waveanticheat.packetevents.bstats;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.logging.Level;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class Metrics {
/*     */   private final Plugin plugin;
/*     */   
/*     */   private final MetricsBase metricsBase;
/*     */   
/*     */   public Metrics(JavaPlugin plugin, int serviceId) {
/*  40 */     this.plugin = (Plugin)plugin;
/*  42 */     File bStatsFolder = new File(plugin.getDataFolder().getParentFile(), "bStats");
/*  43 */     File configFile = new File(bStatsFolder, "config.yml");
/*  44 */     YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
/*  45 */     if (!config.isSet("serverUuid")) {
/*  46 */       config.addDefault("enabled", Boolean.valueOf(true));
/*  47 */       config.addDefault("serverUuid", UUID.randomUUID().toString());
/*  48 */       config.addDefault("logFailedRequests", Boolean.valueOf(false));
/*  49 */       config.addDefault("logSentData", Boolean.valueOf(false));
/*  50 */       config.addDefault("logResponseStatusText", Boolean.valueOf(false));
/*  52 */       config
/*  53 */         .options()
/*  54 */         .header("bStats (https://bStats.org) collects some basic information for plugin authors, like how\nmany people use their plugin and their total player count. It's recommended to keep bStats\nenabled, but if you're not comfortable with this, you can turn this setting off. There is no\nperformance penalty associated with having metrics enabled, and data sent to bStats is fully\nanonymous.")
/*     */         
/*  60 */         .copyDefaults(true);
/*     */       try {
/*  62 */         config.save(configFile);
/*  63 */       } catch (IOException iOException) {}
/*     */     } 
/*  67 */     boolean enabled = config.getBoolean("enabled", true);
/*  68 */     String serverUUID = config.getString("serverUuid");
/*  69 */     boolean logErrors = config.getBoolean("logFailedRequests", false);
/*  70 */     boolean logSentData = config.getBoolean("logSentData", false);
/*  71 */     boolean logResponseStatusText = config.getBoolean("logResponseStatusText", false);
/*  81 */     Objects.requireNonNull(plugin);
/*  81 */     this.metricsBase = new MetricsBase("bukkit", serverUUID, serviceId, enabled, this::appendPlatformData, this::appendServiceData, null, plugin::isEnabled, (message, error) -> this.plugin.getLogger().log(Level.WARNING, message, error), message -> this.plugin.getLogger().log(Level.INFO, message), logErrors, logSentData, logResponseStatusText);
/*     */   }
/*     */   
/*     */   public void addCustomChart(CustomChart chart) {
/*  95 */     this.metricsBase.addCustomChart(chart);
/*     */   }
/*     */   
/*     */   private void appendPlatformData(JsonObjectBuilder builder) {
/*  99 */     builder.appendField("playerAmount", getPlayerAmount());
/* 100 */     builder.appendField("onlineMode", Bukkit.getOnlineMode() ? 1 : 0);
/* 101 */     builder.appendField("bukkitVersion", Bukkit.getVersion());
/* 102 */     builder.appendField("bukkitName", Bukkit.getName());
/* 103 */     builder.appendField("javaVersion", System.getProperty("java.version"));
/* 104 */     builder.appendField("osName", System.getProperty("os.name"));
/* 105 */     builder.appendField("osArch", System.getProperty("os.arch"));
/* 106 */     builder.appendField("osVersion", System.getProperty("os.version"));
/* 107 */     builder.appendField("coreCount", Runtime.getRuntime().availableProcessors());
/*     */   }
/*     */   
/*     */   private void appendServiceData(JsonObjectBuilder builder) {
/* 112 */     builder.appendField("pluginVersion", this.plugin.getDescription().getVersion());
/*     */   }
/*     */   
/*     */   private int getPlayerAmount() {
/*     */     try {
/* 120 */       Method onlinePlayersMethod = Class.forName("org.bukkit.Server").getMethod("getOnlinePlayers", new Class[0]);
/* 121 */       return onlinePlayersMethod.getReturnType().equals(Collection.class) ? (
/* 122 */         (Collection)onlinePlayersMethod.invoke(Bukkit.getServer(), new Object[0])).size() : (
/* 123 */         (Player[])onlinePlayersMethod.invoke(Bukkit.getServer(), new Object[0])).length;
/* 124 */     } catch (Exception e) {
/* 126 */       return Bukkit.getOnlinePlayers().size();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class MetricsBase {
/*     */     public static final String METRICS_VERSION = "2.2.1";
/*     */     
/*     */     private static final ScheduledExecutorService scheduler;
/*     */     
/*     */     private static final String REPORT_URL = "https://bStats.org/api/v2/data/%s";
/*     */     
/*     */     private final String platform;
/*     */     
/*     */     private final String serverUuid;
/*     */     
/*     */     private final int serviceId;
/*     */     
/*     */     private final Consumer<Metrics.JsonObjectBuilder> appendPlatformDataConsumer;
/*     */     
/*     */     private final Consumer<Metrics.JsonObjectBuilder> appendServiceDataConsumer;
/*     */     
/*     */     private final Consumer<Runnable> submitTaskConsumer;
/*     */     
/*     */     private final Supplier<Boolean> checkServiceEnabledSupplier;
/*     */     
/*     */     private final BiConsumer<String, Throwable> errorLogger;
/*     */     
/*     */     private final Consumer<String> infoLogger;
/*     */     
/*     */     private final boolean logErrors;
/*     */     
/*     */     private final boolean logSentData;
/*     */     
/*     */     private final boolean logResponseStatusText;
/*     */     
/*     */     static {
/* 138 */       scheduler = Executors.newScheduledThreadPool(1, task -> new Thread(task, "bStats-Metrics"));
/*     */     }
/*     */     
/* 166 */     private final Set<Metrics.CustomChart> customCharts = new HashSet<>();
/*     */     
/*     */     private final boolean enabled;
/*     */     
/*     */     public MetricsBase(String platform, String serverUuid, int serviceId, boolean enabled, Consumer<Metrics.JsonObjectBuilder> appendPlatformDataConsumer, Consumer<Metrics.JsonObjectBuilder> appendServiceDataConsumer, Consumer<Runnable> submitTaskConsumer, Supplier<Boolean> checkServiceEnabledSupplier, BiConsumer<String, Throwable> errorLogger, Consumer<String> infoLogger, boolean logErrors, boolean logSentData, boolean logResponseStatusText) {
/* 205 */       this.platform = platform;
/* 206 */       this.serverUuid = serverUuid;
/* 207 */       this.serviceId = serviceId;
/* 208 */       this.enabled = enabled;
/* 209 */       this.appendPlatformDataConsumer = appendPlatformDataConsumer;
/* 210 */       this.appendServiceDataConsumer = appendServiceDataConsumer;
/* 211 */       this.submitTaskConsumer = submitTaskConsumer;
/* 212 */       this.checkServiceEnabledSupplier = checkServiceEnabledSupplier;
/* 213 */       this.errorLogger = errorLogger;
/* 214 */       this.infoLogger = infoLogger;
/* 215 */       this.logErrors = logErrors;
/* 216 */       this.logSentData = logSentData;
/* 217 */       this.logResponseStatusText = logResponseStatusText;
/* 218 */       checkRelocation();
/* 219 */       if (enabled)
/* 220 */         startSubmitting(); 
/*     */     }
/*     */     
/*     */     private static byte[] compress(String str) throws IOException {
/* 231 */       if (str == null)
/* 232 */         return null; 
/* 234 */       ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
/* 235 */       GZIPOutputStream gzip = new GZIPOutputStream(outputStream);
/*     */       try {
/* 236 */         gzip.write(str.getBytes(StandardCharsets.UTF_8));
/* 237 */         gzip.close();
/*     */       } catch (Throwable throwable) {
/*     */         try {
/*     */           gzip.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */         throw throwable;
/*     */       } 
/* 238 */       return outputStream.toByteArray();
/*     */     }
/*     */     
/*     */     public void addCustomChart(Metrics.CustomChart chart) {
/* 242 */       this.customCharts.add(chart);
/*     */     }
/*     */     
/*     */     private void startSubmitting() {
/* 246 */       Runnable submitTask = () -> {
/*     */           if (!this.enabled || !((Boolean)this.checkServiceEnabledSupplier.get()).booleanValue()) {
/*     */             scheduler.shutdown();
/*     */             return;
/*     */           } 
/*     */           if (this.submitTaskConsumer != null) {
/*     */             this.submitTaskConsumer.accept(this::submitData);
/*     */           } else {
/*     */             submitData();
/*     */           } 
/*     */         };
/* 266 */       long initialDelay = (long)(60000.0D * (3.0D + Math.random() * 3.0D));
/* 267 */       long secondDelay = (long)(60000.0D * Math.random() * 30.0D);
/* 268 */       scheduler.schedule(submitTask, initialDelay, TimeUnit.MILLISECONDS);
/* 269 */       scheduler.scheduleAtFixedRate(submitTask, initialDelay + secondDelay, 1800000L, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     
/*     */     private void submitData() {
/* 274 */       Metrics.JsonObjectBuilder baseJsonBuilder = new Metrics.JsonObjectBuilder();
/* 275 */       this.appendPlatformDataConsumer.accept(baseJsonBuilder);
/* 276 */       Metrics.JsonObjectBuilder serviceJsonBuilder = new Metrics.JsonObjectBuilder();
/* 277 */       this.appendServiceDataConsumer.accept(serviceJsonBuilder);
/* 282 */       Metrics.JsonObjectBuilder.JsonObject[] chartData = (Metrics.JsonObjectBuilder.JsonObject[])this.customCharts.stream().map(customChart -> customChart.getRequestJsonObject(this.errorLogger, this.logErrors)).filter(Objects::nonNull).toArray(x$0 -> new Metrics.JsonObjectBuilder.JsonObject[x$0]);
/* 283 */       serviceJsonBuilder.appendField("id", this.serviceId);
/* 284 */       serviceJsonBuilder.appendField("customCharts", chartData);
/* 285 */       baseJsonBuilder.appendField("service", serviceJsonBuilder.build());
/* 286 */       baseJsonBuilder.appendField("serverUUID", this.serverUuid);
/* 287 */       baseJsonBuilder.appendField("metricsVersion", "2.2.1");
/* 288 */       Metrics.JsonObjectBuilder.JsonObject data = baseJsonBuilder.build();
/* 289 */       scheduler.execute(() -> {
/*     */             try {
/*     */               sendData(data);
/* 294 */             } catch (Exception e) {
/*     */               if (this.logErrors)
/*     */                 this.errorLogger.accept("Could not submit bStats metrics data", e); 
/*     */             } 
/*     */           });
/*     */     }
/*     */     
/*     */     private void sendData(Metrics.JsonObjectBuilder.JsonObject data) throws Exception {
/* 304 */       if (this.logSentData)
/* 305 */         this.infoLogger.accept("Sent bStats metrics data: " + data.toString()); 
/* 307 */       String url = String.format("https://bStats.org/api/v2/data/%s", new Object[] { this.platform });
/* 308 */       HttpsURLConnection connection = (HttpsURLConnection)(new URL(url)).openConnection();
/* 310 */       byte[] compressedData = compress(data.toString());
/* 311 */       connection.setRequestMethod("POST");
/* 312 */       connection.addRequestProperty("Accept", "application/json");
/* 313 */       connection.addRequestProperty("Connection", "close");
/* 314 */       connection.addRequestProperty("Content-Encoding", "gzip");
/* 315 */       connection.addRequestProperty("Content-Length", String.valueOf(compressedData.length));
/* 316 */       connection.setRequestProperty("Content-Type", "application/json");
/* 317 */       connection.setRequestProperty("User-Agent", "Metrics-Service/1");
/* 318 */       connection.setDoOutput(true);
/* 319 */       DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
/*     */       try {
/* 320 */         outputStream.write(compressedData);
/* 321 */         outputStream.close();
/*     */       } catch (Throwable throwable) {
/*     */         try {
/*     */           outputStream.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */         throw throwable;
/*     */       } 
/* 322 */       StringBuilder builder = new StringBuilder();
/* 324 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*     */       try {
/*     */         String line;
/* 326 */         while ((line = bufferedReader.readLine()) != null)
/* 327 */           builder.append(line); 
/* 329 */         bufferedReader.close();
/*     */       } catch (Throwable throwable) {
/*     */         try {
/*     */           bufferedReader.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */         throw throwable;
/*     */       } 
/* 330 */       if (this.logResponseStatusText)
/* 331 */         this.infoLogger.accept("Sent data to bStats and received response: " + builder); 
/*     */     }
/*     */     
/*     */     private void checkRelocation() {
/* 340 */       if (System.getProperty("bstats.relocatecheck") == null || 
/* 341 */         !System.getProperty("bstats.relocatecheck").equals("false")) {
/* 344 */         String defaultPackage = new String(new byte[] { 111, 114, 103, 46, 98, 115, 116, 97, 116, 115 });
/* 346 */         String examplePackage = new String(new byte[] { 
/* 346 */               121, 111, 117, 114, 46, 112, 97, 99, 107, 97, 
/* 346 */               103, 101 });
/* 350 */         if (MetricsBase.class.getPackage().getName().startsWith(defaultPackage) || MetricsBase.class
/* 351 */           .getPackage().getName().startsWith(examplePackage))
/* 352 */           throw new IllegalStateException("bStats Metrics class has not been relocated correctly!"); 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AdvancedBarChart extends CustomChart {
/*     */     private final Callable<Map<String, int[]>> callable;
/*     */     
/*     */     public AdvancedBarChart(String chartId, Callable<Map<String, int[]>> callable) {
/* 369 */       super(chartId);
/* 370 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 375 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 376 */       Map<String, int[]> map = this.callable.call();
/* 377 */       if (map == null || map.isEmpty())
/* 379 */         return null; 
/* 381 */       boolean allSkipped = true;
/* 382 */       for (Map.Entry<String, int[]> entry : map.entrySet()) {
/* 383 */         if (((int[])entry.getValue()).length == 0)
/*     */           continue; 
/* 387 */         allSkipped = false;
/* 388 */         valuesBuilder.appendField(entry.getKey(), entry.getValue());
/*     */       } 
/* 390 */       if (allSkipped)
/* 392 */         return null; 
/* 394 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SimpleBarChart extends CustomChart {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */     
/*     */     public SimpleBarChart(String chartId, Callable<Map<String, Integer>> callable) {
/* 409 */       super(chartId);
/* 410 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 415 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 416 */       Map<String, Integer> map = this.callable.call();
/* 417 */       if (map == null || map.isEmpty())
/* 419 */         return null; 
/* 421 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 422 */         valuesBuilder.appendField(entry.getKey(), new int[] { ((Integer)entry.getValue()).intValue() });
/*     */       } 
/* 424 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MultiLineChart extends CustomChart {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */     
/*     */     public MultiLineChart(String chartId, Callable<Map<String, Integer>> callable) {
/* 439 */       super(chartId);
/* 440 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 445 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 446 */       Map<String, Integer> map = this.callable.call();
/* 447 */       if (map == null || map.isEmpty())
/* 449 */         return null; 
/* 451 */       boolean allSkipped = true;
/* 452 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 453 */         if (((Integer)entry.getValue()).intValue() == 0)
/*     */           continue; 
/* 457 */         allSkipped = false;
/* 458 */         valuesBuilder.appendField(entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */       } 
/* 460 */       if (allSkipped)
/* 462 */         return null; 
/* 464 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AdvancedPie extends CustomChart {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */     
/*     */     public AdvancedPie(String chartId, Callable<Map<String, Integer>> callable) {
/* 479 */       super(chartId);
/* 480 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 485 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 486 */       Map<String, Integer> map = this.callable.call();
/* 487 */       if (map == null || map.isEmpty())
/* 489 */         return null; 
/* 491 */       boolean allSkipped = true;
/* 492 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 493 */         if (((Integer)entry.getValue()).intValue() == 0)
/*     */           continue; 
/* 497 */         allSkipped = false;
/* 498 */         valuesBuilder.appendField(entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */       } 
/* 500 */       if (allSkipped)
/* 502 */         return null; 
/* 504 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class CustomChart {
/*     */     private final String chartId;
/*     */     
/*     */     protected CustomChart(String chartId) {
/* 513 */       if (chartId == null)
/* 514 */         throw new IllegalArgumentException("chartId must not be null"); 
/* 516 */       this.chartId = chartId;
/*     */     }
/*     */     
/*     */     public Metrics.JsonObjectBuilder.JsonObject getRequestJsonObject(BiConsumer<String, Throwable> errorLogger, boolean logErrors) {
/* 521 */       Metrics.JsonObjectBuilder builder = new Metrics.JsonObjectBuilder();
/* 522 */       builder.appendField("chartId", this.chartId);
/*     */       try {
/* 524 */         Metrics.JsonObjectBuilder.JsonObject data = getChartData();
/* 525 */         if (data == null)
/* 527 */           return null; 
/* 529 */         builder.appendField("data", data);
/* 530 */       } catch (Throwable t) {
/* 531 */         if (logErrors)
/* 532 */           errorLogger.accept("Failed to get data for custom chart with id " + this.chartId, t); 
/* 534 */         return null;
/*     */       } 
/* 536 */       return builder.build();
/*     */     }
/*     */     
/*     */     protected abstract Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception;
/*     */   }
/*     */   
/*     */   public static class SingleLineChart extends CustomChart {
/*     */     private final Callable<Integer> callable;
/*     */     
/*     */     public SingleLineChart(String chartId, Callable<Integer> callable) {
/* 553 */       super(chartId);
/* 554 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 559 */       int value = ((Integer)this.callable.call()).intValue();
/* 560 */       if (value == 0)
/* 562 */         return null; 
/* 564 */       return (new Metrics.JsonObjectBuilder()).appendField("value", value).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SimplePie extends CustomChart {
/*     */     private final Callable<String> callable;
/*     */     
/*     */     public SimplePie(String chartId, Callable<String> callable) {
/* 579 */       super(chartId);
/* 580 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 585 */       String value = this.callable.call();
/* 586 */       if (value == null || value.isEmpty())
/* 588 */         return null; 
/* 590 */       return (new Metrics.JsonObjectBuilder()).appendField("value", value).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DrilldownPie extends CustomChart {
/*     */     private final Callable<Map<String, Map<String, Integer>>> callable;
/*     */     
/*     */     public DrilldownPie(String chartId, Callable<Map<String, Map<String, Integer>>> callable) {
/* 605 */       super(chartId);
/* 606 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     public Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 611 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 612 */       Map<String, Map<String, Integer>> map = this.callable.call();
/* 613 */       if (map == null || map.isEmpty())
/* 615 */         return null; 
/* 617 */       boolean reallyAllSkipped = true;
/* 618 */       for (Map.Entry<String, Map<String, Integer>> entryValues : map.entrySet()) {
/* 619 */         Metrics.JsonObjectBuilder valueBuilder = new Metrics.JsonObjectBuilder();
/* 620 */         boolean allSkipped = true;
/* 621 */         for (Map.Entry<String, Integer> valueEntry : (Iterable<Map.Entry<String, Integer>>)((Map)map.get(entryValues.getKey())).entrySet()) {
/* 622 */           valueBuilder.appendField(valueEntry.getKey(), ((Integer)valueEntry.getValue()).intValue());
/* 623 */           allSkipped = false;
/*     */         } 
/* 625 */         if (!allSkipped) {
/* 626 */           reallyAllSkipped = false;
/* 627 */           valuesBuilder.appendField(entryValues.getKey(), valueBuilder.build());
/*     */         } 
/*     */       } 
/* 630 */       if (reallyAllSkipped)
/* 632 */         return null; 
/* 634 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class JsonObjectBuilder {
/* 646 */     private StringBuilder builder = new StringBuilder();
/*     */     
/*     */     private boolean hasAtLeastOneField = false;
/*     */     
/*     */     public JsonObjectBuilder() {
/* 651 */       this.builder.append("{");
/*     */     }
/*     */     
/*     */     private static String escape(String value) {
/* 664 */       StringBuilder builder = new StringBuilder();
/* 665 */       for (int i = 0; i < value.length(); i++) {
/* 666 */         char c = value.charAt(i);
/* 667 */         if (c == '"') {
/* 668 */           builder.append("\\\"");
/* 669 */         } else if (c == '\\') {
/* 670 */           builder.append("\\\\");
/* 671 */         } else if (c <= '\017') {
/* 672 */           builder.append("\\u000").append(Integer.toHexString(c));
/* 673 */         } else if (c <= '\037') {
/* 674 */           builder.append("\\u00").append(Integer.toHexString(c));
/*     */         } else {
/* 676 */           builder.append(c);
/*     */         } 
/*     */       } 
/* 679 */       return builder.toString();
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendNull(String key) {
/* 689 */       appendFieldUnescaped(key, "null");
/* 690 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, String value) {
/* 701 */       if (value == null)
/* 702 */         throw new IllegalArgumentException("JSON value must not be null"); 
/* 704 */       appendFieldUnescaped(key, "\"" + escape(value) + "\"");
/* 705 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, int value) {
/* 716 */       appendFieldUnescaped(key, String.valueOf(value));
/* 717 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, JsonObject object) {
/* 728 */       if (object == null)
/* 729 */         throw new IllegalArgumentException("JSON object must not be null"); 
/* 731 */       appendFieldUnescaped(key, object.toString());
/* 732 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, String[] values) {
/* 743 */       if (values == null)
/* 744 */         throw new IllegalArgumentException("JSON values must not be null"); 
/* 749 */       String escapedValues = Arrays.<String>stream(values).map(value -> "\"" + escape(value) + "\"").collect(Collectors.joining(","));
/* 750 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 751 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, int[] values) {
/* 762 */       if (values == null)
/* 763 */         throw new IllegalArgumentException("JSON values must not be null"); 
/* 766 */       String escapedValues = Arrays.stream(values).<CharSequence>mapToObj(String::valueOf).collect(Collectors.joining(","));
/* 767 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 768 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, JsonObject[] values) {
/* 779 */       if (values == null)
/* 780 */         throw new IllegalArgumentException("JSON values must not be null"); 
/* 783 */       String escapedValues = Arrays.<JsonObject>stream(values).map(JsonObject::toString).collect(Collectors.joining(","));
/* 784 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 785 */       return this;
/*     */     }
/*     */     
/*     */     private void appendFieldUnescaped(String key, String escapedValue) {
/* 795 */       if (this.builder == null)
/* 796 */         throw new IllegalStateException("JSON has already been built"); 
/* 798 */       if (key == null)
/* 799 */         throw new IllegalArgumentException("JSON key must not be null"); 
/* 801 */       if (this.hasAtLeastOneField)
/* 802 */         this.builder.append(","); 
/* 804 */       this.builder.append("\"").append(escape(key)).append("\":").append(escapedValue);
/* 805 */       this.hasAtLeastOneField = true;
/*     */     }
/*     */     
/*     */     public JsonObject build() {
/* 814 */       if (this.builder == null)
/* 815 */         throw new IllegalStateException("JSON has already been built"); 
/* 817 */       JsonObject object = new JsonObject(this.builder.append("}").toString());
/* 818 */       this.builder = null;
/* 819 */       return object;
/*     */     }
/*     */     
/*     */     public static class JsonObject {
/*     */       private final String value;
/*     */       
/*     */       private JsonObject(String value) {
/* 834 */         this.value = value;
/*     */       }
/*     */       
/*     */       public String toString() {
/* 839 */         return this.value;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\bstats\Metrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */