package io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson;

import net.kyori.adventure.text.serializer.json.LegacyHoverEventSerializer;
import org.jetbrains.annotations.ApiStatus.ScheduledForRemoval;

@Deprecated
@ScheduledForRemoval(inVersion = "5.0.0")
public interface LegacyHoverEventSerializer extends LegacyHoverEventSerializer {}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\adventure\serializer\gson\LegacyHoverEventSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */