/*    */ package io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson;
/*    */ 
/*    */ import com.google.gson.TypeAdapter;
/*    */ import net.kyori.adventure.text.format.TextDecoration;
/*    */ 
/*    */ final class TextDecorationSerializer {
/* 30 */   static final TypeAdapter<TextDecoration> INSTANCE = IndexedSerializer.strict("text decoration", TextDecoration.NAMES);
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\adventure\serializer\gson\TextDecorationSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */