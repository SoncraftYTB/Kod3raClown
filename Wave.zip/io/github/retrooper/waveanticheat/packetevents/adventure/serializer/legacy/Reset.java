/*    */ package io.github.retrooper.waveanticheat.packetevents.adventure.serializer.legacy;
/*    */ 
/*    */ import net.kyori.adventure.text.format.TextFormat;
/*    */ 
/*    */ public enum Reset implements TextFormat {
/* 34 */   INSTANCE;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\adventure\serializer\legacy\Reset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */