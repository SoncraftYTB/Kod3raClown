/*     */ package io.github.retrooper.waveanticheat.packetevents.netty.buffer;
/*     */ 
/*     */ import com.github.retrooper.packetevents.netty.buffer.ByteBufOperator;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ public class ByteBufOperatorModernImpl implements ByteBufOperator {
/*     */   public int capacity(Object buffer) {
/*  29 */     return ((ByteBuf)buffer).capacity();
/*     */   }
/*     */   
/*     */   public Object capacity(Object buffer, int capacity) {
/*  34 */     return ((ByteBuf)buffer).capacity(capacity);
/*     */   }
/*     */   
/*     */   public int readerIndex(Object buffer) {
/*  39 */     return ((ByteBuf)buffer).readerIndex();
/*     */   }
/*     */   
/*     */   public Object readerIndex(Object buffer, int readerIndex) {
/*  44 */     return ((ByteBuf)buffer).readerIndex(readerIndex);
/*     */   }
/*     */   
/*     */   public int writerIndex(Object buffer) {
/*  49 */     return ((ByteBuf)buffer).writerIndex();
/*     */   }
/*     */   
/*     */   public Object writerIndex(Object buffer, int writerIndex) {
/*  54 */     return ((ByteBuf)buffer).writerIndex(writerIndex);
/*     */   }
/*     */   
/*     */   public int readableBytes(Object buffer) {
/*  59 */     return ((ByteBuf)buffer).readableBytes();
/*     */   }
/*     */   
/*     */   public int writableBytes(Object buffer) {
/*  64 */     return ((ByteBuf)buffer).writableBytes();
/*     */   }
/*     */   
/*     */   public Object clear(Object buffer) {
/*  69 */     return ((ByteBuf)buffer).clear();
/*     */   }
/*     */   
/*     */   public byte readByte(Object buffer) {
/*  74 */     return ((ByteBuf)buffer).readByte();
/*     */   }
/*     */   
/*     */   public short readShort(Object buffer) {
/*  79 */     return ((ByteBuf)buffer).readShort();
/*     */   }
/*     */   
/*     */   public int readInt(Object buffer) {
/*  84 */     return ((ByteBuf)buffer).readInt();
/*     */   }
/*     */   
/*     */   public long readUnsignedInt(Object buffer) {
/*  89 */     return ((ByteBuf)buffer).readUnsignedInt();
/*     */   }
/*     */   
/*     */   public long readLong(Object buffer) {
/*  94 */     return ((ByteBuf)buffer).readLong();
/*     */   }
/*     */   
/*     */   public void writeByte(Object buffer, int value) {
/* 100 */     ((ByteBuf)buffer).writeByte(value);
/*     */   }
/*     */   
/*     */   public void writeShort(Object buffer, int value) {
/* 105 */     ((ByteBuf)buffer).writeShort(value);
/*     */   }
/*     */   
/*     */   public void writeInt(Object buffer, int value) {
/* 110 */     ((ByteBuf)buffer).writeInt(value);
/*     */   }
/*     */   
/*     */   public void writeLong(Object buffer, long value) {
/* 115 */     ((ByteBuf)buffer).writeLong(value);
/*     */   }
/*     */   
/*     */   public Object getBytes(Object buffer, int index, byte[] destination) {
/* 120 */     return ((ByteBuf)buffer).getBytes(index, destination);
/*     */   }
/*     */   
/*     */   public short getUnsignedByte(Object buffer, int index) {
/* 125 */     return ((ByteBuf)buffer).getUnsignedByte(index);
/*     */   }
/*     */   
/*     */   public boolean isReadable(Object buffer) {
/* 130 */     return ((ByteBuf)buffer).isReadable();
/*     */   }
/*     */   
/*     */   public Object copy(Object buffer) {
/* 135 */     return ((ByteBuf)buffer).copy();
/*     */   }
/*     */   
/*     */   public Object duplicate(Object buffer) {
/* 140 */     return ((ByteBuf)buffer).duplicate();
/*     */   }
/*     */   
/*     */   public boolean hasArray(Object buffer) {
/* 145 */     return ((ByteBuf)buffer).hasArray();
/*     */   }
/*     */   
/*     */   public byte[] array(Object buffer) {
/* 150 */     return ((ByteBuf)buffer).array();
/*     */   }
/*     */   
/*     */   public Object retain(Object buffer) {
/* 155 */     return ((ByteBuf)buffer).retain();
/*     */   }
/*     */   
/*     */   public Object retainedDuplicate(Object buffer) {
/* 160 */     return ((ByteBuf)buffer).duplicate().retain();
/*     */   }
/*     */   
/*     */   public Object readSlice(Object buffer, int length) {
/* 165 */     return ((ByteBuf)buffer).readSlice(length);
/*     */   }
/*     */   
/*     */   public Object readBytes(Object buffer, byte[] destination, int destinationIndex, int length) {
/* 170 */     return ((ByteBuf)buffer).readBytes(destination, destinationIndex, length);
/*     */   }
/*     */   
/*     */   public Object readBytes(Object buffer, int length) {
/* 175 */     return ((ByteBuf)buffer).readBytes(length);
/*     */   }
/*     */   
/*     */   public Object writeBytes(Object buffer, Object src) {
/* 180 */     return ((ByteBuf)buffer).writeBytes((ByteBuf)src);
/*     */   }
/*     */   
/*     */   public Object writeBytes(Object buffer, byte[] bytes) {
/* 185 */     return ((ByteBuf)buffer).writeBytes(bytes);
/*     */   }
/*     */   
/*     */   public Object writeBytes(Object buffer, byte[] bytes, int offset, int length) {
/* 190 */     return ((ByteBuf)buffer).writeBytes(bytes, offset, length);
/*     */   }
/*     */   
/*     */   public void readBytes(Object buffer, byte[] bytes) {
/* 195 */     ((ByteBuf)buffer).readBytes(bytes);
/*     */   }
/*     */   
/*     */   public boolean release(Object buffer) {
/* 200 */     return ((ByteBuf)buffer).release();
/*     */   }
/*     */   
/*     */   public int refCnt(Object buffer) {
/* 205 */     return ((ByteBuf)buffer).refCnt();
/*     */   }
/*     */   
/*     */   public Object skipBytes(Object buffer, int length) {
/* 210 */     return ((ByteBuf)buffer).skipBytes(length);
/*     */   }
/*     */   
/*     */   public String toString(Object buffer, int index, int length, Charset charset) {
/* 215 */     return ((ByteBuf)buffer).toString(index, length, charset);
/*     */   }
/*     */   
/*     */   public Object markReaderIndex(Object buffer) {
/* 220 */     return ((ByteBuf)buffer).markReaderIndex();
/*     */   }
/*     */   
/*     */   public Object resetReaderIndex(Object buffer) {
/* 225 */     return ((ByteBuf)buffer).resetReaderIndex();
/*     */   }
/*     */   
/*     */   public Object markWriterIndex(Object buffer) {
/* 230 */     return ((ByteBuf)buffer).markWriterIndex();
/*     */   }
/*     */   
/*     */   public Object resetWriterIndex(Object buffer) {
/* 235 */     return ((ByteBuf)buffer).resetWriterIndex();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\netty\buffer\ByteBufOperatorModernImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */