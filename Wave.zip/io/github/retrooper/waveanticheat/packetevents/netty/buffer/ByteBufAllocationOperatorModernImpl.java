/*    */ package io.github.retrooper.waveanticheat.packetevents.netty.buffer;
/*    */ 
/*    */ import com.github.retrooper.packetevents.netty.buffer.ByteBufAllocationOperator;
/*    */ import io.netty.buffer.Unpooled;
/*    */ 
/*    */ public class ByteBufAllocationOperatorModernImpl implements ByteBufAllocationOperator {
/*    */   public Object wrappedBuffer(byte[] bytes) {
/* 27 */     return Unpooled.wrappedBuffer(bytes);
/*    */   }
/*    */   
/*    */   public Object copiedBuffer(byte[] bytes) {
/* 32 */     return Unpooled.copiedBuffer(bytes);
/*    */   }
/*    */   
/*    */   public Object buffer() {
/* 37 */     return Unpooled.buffer();
/*    */   }
/*    */   
/*    */   public Object directBuffer() {
/* 42 */     return Unpooled.directBuffer();
/*    */   }
/*    */   
/*    */   public Object compositeBuffer() {
/* 47 */     return Unpooled.compositeBuffer();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\netty\buffer\ByteBufAllocationOperatorModernImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */