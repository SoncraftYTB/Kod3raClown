/*    */ package io.github.retrooper.waveanticheat.packetevents.netty;
/*    */ 
/*    */ import com.github.retrooper.packetevents.netty.NettyManager;
/*    */ import com.github.retrooper.packetevents.netty.buffer.ByteBufAllocationOperator;
/*    */ import com.github.retrooper.packetevents.netty.buffer.ByteBufOperator;
/*    */ import com.github.retrooper.packetevents.netty.channel.ChannelOperator;
/*    */ import io.github.retrooper.waveanticheat.packetevents.netty.buffer.ByteBufAllocationOperatorModernImpl;
/*    */ import io.github.retrooper.waveanticheat.packetevents.netty.buffer.ByteBufOperatorModernImpl;
/*    */ import io.github.retrooper.waveanticheat.packetevents.netty.channel.ChannelOperatorModernImpl;
/*    */ 
/*    */ public class NettyManagerImpl implements NettyManager {
/* 30 */   private static final ByteBufOperator BYTE_BUF_OPERATOR = (ByteBufOperator)new ByteBufOperatorModernImpl();
/*    */   
/* 31 */   private static final ByteBufAllocationOperator BYTE_BUF_ALLOCATION_OPERATOR = (ByteBufAllocationOperator)new ByteBufAllocationOperatorModernImpl();
/*    */   
/* 32 */   private static final ChannelOperator CHANNEL_OPERATOR = (ChannelOperator)new ChannelOperatorModernImpl();
/*    */   
/*    */   public ChannelOperator getChannelOperator() {
/* 36 */     return CHANNEL_OPERATOR;
/*    */   }
/*    */   
/*    */   public ByteBufOperator getByteBufOperator() {
/* 41 */     return BYTE_BUF_OPERATOR;
/*    */   }
/*    */   
/*    */   public ByteBufAllocationOperator getByteBufAllocationOperator() {
/* 46 */     return BYTE_BUF_ALLOCATION_OPERATOR;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\netty\NettyManagerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */