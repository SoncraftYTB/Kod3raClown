/*    */ package io.github.retrooper.waveanticheat.packetevents.bukkit;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ import com.github.retrooper.packetevents.util.FakeChannelUtil;
/*    */ import io.github.retrooper.waveanticheat.packetevents.injector.SpigotChannelInjector;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.FoliaCompatUtil;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class InternalBukkitListener implements Listener {
/*    */   private final Plugin plugin;
/*    */   
/*    */   public InternalBukkitListener(Plugin plugin) {
/* 38 */     this.plugin = plugin;
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.HIGH)
/*    */   public void onJoin(PlayerJoinEvent e) {
/* 43 */     Player player = e.getPlayer();
/* 44 */     SpigotChannelInjector injector = (SpigotChannelInjector)PacketEvents.getAPI().getInjector();
/* 46 */     User user = PacketEvents.getAPI().getPlayerManager().getUser(player);
/* 47 */     if (user == null) {
/* 49 */       Object channel = PacketEvents.getAPI().getPlayerManager().getChannel(player);
/* 51 */       if (!FakeChannelUtil.isFakeChannel(channel))
/* 53 */         FoliaCompatUtil.runTaskForEntity((Entity)player, this.plugin, () -> player.kickPlayer("PacketEvents 2.0 failed to inject"), null, 0L); 
/*    */       return;
/*    */     } 
/* 59 */     injector.updatePlayer(user, player);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\bukkit\InternalBukkitListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */