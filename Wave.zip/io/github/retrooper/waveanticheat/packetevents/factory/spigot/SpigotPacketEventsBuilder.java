/*     */ package io.github.retrooper.waveanticheat.packetevents.factory.spigot;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.PacketEventsAPI;
/*     */ import com.github.retrooper.packetevents.event.PacketListenerCommon;
/*     */ import com.github.retrooper.packetevents.injector.ChannelInjector;
/*     */ import com.github.retrooper.packetevents.manager.player.PlayerManager;
/*     */ import com.github.retrooper.packetevents.manager.protocol.ProtocolManager;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerManager;
/*     */ import com.github.retrooper.packetevents.netty.NettyManager;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import com.github.retrooper.packetevents.settings.PacketEventsSettings;
/*     */ import com.github.retrooper.packetevents.util.LogManager;
/*     */ import io.github.retrooper.waveanticheat.packetevents.bstats.Metrics;
/*     */ import io.github.retrooper.waveanticheat.packetevents.bukkit.InternalBukkitListener;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.SpigotChannelInjector;
/*     */ import io.github.retrooper.waveanticheat.packetevents.injector.connection.ServerConnectionInitializer;
/*     */ import io.github.retrooper.waveanticheat.packetevents.manager.InternalBukkitPacketListener;
/*     */ import io.github.retrooper.waveanticheat.packetevents.manager.player.PlayerManagerImpl;
/*     */ import io.github.retrooper.waveanticheat.packetevents.manager.protocol.ProtocolManagerImpl;
/*     */ import io.github.retrooper.waveanticheat.packetevents.manager.server.ServerManagerImpl;
/*     */ import io.github.retrooper.waveanticheat.packetevents.netty.NettyManagerImpl;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.BukkitLogManager;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.FoliaCompatUtil;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.SpigotReflectionUtil;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.protocolsupport.ProtocolSupportUtil;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.viaversion.CustomPipelineUtil;
/*     */ import io.github.retrooper.waveanticheat.packetevents.util.viaversion.ViaVersionUtil;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class SpigotPacketEventsBuilder {
/*     */   private static PacketEventsAPI<Plugin> API_INSTANCE;
/*     */   
/*     */   public static void clearBuildCache() {
/*  57 */     API_INSTANCE = null;
/*     */   }
/*     */   
/*     */   public static PacketEventsAPI<Plugin> build(Plugin plugin) {
/*  61 */     if (API_INSTANCE == null)
/*  62 */       API_INSTANCE = buildNoCache(plugin); 
/*  64 */     return API_INSTANCE;
/*     */   }
/*     */   
/*     */   public static PacketEventsAPI<Plugin> build(Plugin plugin, PacketEventsSettings settings) {
/*  68 */     if (API_INSTANCE == null)
/*  69 */       API_INSTANCE = buildNoCache(plugin, settings); 
/*  71 */     return API_INSTANCE;
/*     */   }
/*     */   
/*     */   public static PacketEventsAPI<Plugin> buildNoCache(Plugin plugin) {
/*  75 */     return buildNoCache(plugin, new PacketEventsSettings());
/*     */   }
/*     */   
/*     */   public static PacketEventsAPI<Plugin> buildNoCache(final Plugin plugin, final PacketEventsSettings inSettings) {
/*  79 */     return new PacketEventsAPI<Plugin>() {
/*  80 */         private final PacketEventsSettings settings = inSettings;
/*     */         
/*  81 */         private final ProtocolManager protocolManager = (ProtocolManager)new ProtocolManagerImpl();
/*     */         
/*  82 */         private final ServerManager serverManager = (ServerManager)new ServerManagerImpl();
/*     */         
/*  83 */         private final PlayerManager playerManager = (PlayerManager)new PlayerManagerImpl();
/*     */         
/*  84 */         private final NettyManager nettyManager = (NettyManager)new NettyManagerImpl();
/*     */         
/*  85 */         private final SpigotChannelInjector injector = new SpigotChannelInjector();
/*     */         
/*  86 */         private final LogManager logManager = (LogManager)new BukkitLogManager();
/*     */         
/*     */         private boolean loaded;
/*     */         
/*     */         private boolean initialized;
/*     */         
/*     */         private boolean lateBind = false;
/*     */         
/*     */         public void load() {
/*  93 */           if (!this.loaded) {
/*  95 */             String id = plugin.getName().toLowerCase();
/*  96 */             PacketEvents.IDENTIFIER = "pe-" + id;
/*  97 */             PacketEvents.ENCODER_NAME = "pe-encoder-" + id;
/*  98 */             PacketEvents.DECODER_NAME = "pe-decoder-" + id;
/*  99 */             PacketEvents.CONNECTION_HANDLER_NAME = "pe-connection-handler-" + id;
/* 100 */             PacketEvents.SERVER_CHANNEL_HANDLER_NAME = "pe-connection-initializer-" + id;
/* 101 */             PacketEvents.TIMEOUT_HANDLER_NAME = "pe-timeout-handler-" + id;
/*     */             try {
/* 103 */               SpigotReflectionUtil.init();
/* 104 */               CustomPipelineUtil.init();
/* 105 */             } catch (Exception ex) {
/* 106 */               throw new IllegalStateException(ex);
/*     */             } 
/* 109 */             if (!PacketType.isPrepared())
/* 110 */               PacketType.prepare(); 
/* 114 */             this.lateBind = !this.injector.isServerBound();
/* 116 */             if (!this.lateBind)
/* 117 */               this.injector.inject(); 
/* 120 */             this.loaded = true;
/* 124 */             getEventManager().registerListener((PacketListenerCommon)new InternalBukkitPacketListener());
/*     */           } 
/*     */         }
/*     */         
/*     */         public boolean isLoaded() {
/* 130 */           return this.loaded;
/*     */         }
/*     */         
/*     */         public void init() {
/* 136 */           load();
/* 137 */           if (!this.initialized) {
/* 138 */             if (this.settings.shouldCheckForUpdates())
/* 139 */               getUpdateChecker().handleUpdateCheck(); 
/* 142 */             if (this.settings.isbStatsEnabled()) {
/* 143 */               Metrics metrics = new Metrics((JavaPlugin)plugin, 11327);
/* 145 */               metrics.addCustomChart((Metrics.CustomChart)new Metrics.SimplePie("packetevents_version", () -> getVersion().toString()));
/*     */             } 
/* 150 */             Bukkit.getPluginManager().registerEvents((Listener)new InternalBukkitListener(plugin), plugin);
/* 152 */             if (this.lateBind) {
/* 154 */               Runnable lateBindTask = () -> {
/*     */                   if (this.injector.isServerBound())
/*     */                     this.injector.inject(); 
/*     */                 };
/* 159 */               FoliaCompatUtil.runTaskOnInit(plugin, lateBindTask);
/*     */             } 
/* 163 */             if (!"true".equalsIgnoreCase(System.getenv("PE_IGNORE_INCOMPATIBILITY")))
/* 164 */               checkCompatibility(); 
/* 167 */             this.initialized = true;
/*     */           } 
/*     */         }
/*     */         
/*     */         private void checkCompatibility() {
/* 173 */           ViaVersionUtil.checkIfViaIsPresent();
/* 174 */           ProtocolSupportUtil.checkIfProtocolSupportIsPresent();
/* 176 */           Plugin viaPlugin = Bukkit.getPluginManager().getPlugin("ViaVersion");
/* 177 */           if (viaPlugin != null) {
/* 178 */             String[] ver = viaPlugin.getDescription().getVersion().split("\\.", 3);
/* 179 */             int major = Integer.parseInt(ver[0]);
/* 180 */             int minor = Integer.parseInt(ver[1]);
/* 181 */             if (major < 4 || (major == 4 && minor < 5)) {
/* 182 */               PacketEvents.getAPI().getLogManager().severe("You are attempting to combine 2.0 PacketEvents with a ViaVersion older than 4.5.0, please update your ViaVersion!");
/* 184 */               Plugin ourPlugin = getPlugin();
/* 185 */               Bukkit.getPluginManager().disablePlugin(ourPlugin);
/* 186 */               throw new IllegalStateException("ViaVersion incompatibility! Update to v4.5.0 or newer!");
/*     */             } 
/*     */           } 
/* 190 */           Plugin protocolLibPlugin = Bukkit.getPluginManager().getPlugin("ProtocolLib");
/* 191 */           if (protocolLibPlugin != null) {
/* 192 */             int majorVersion = Integer.parseInt(protocolLibPlugin.getDescription().getVersion().split("\\.", 2)[0]);
/* 193 */             if (majorVersion < 5) {
/* 194 */               PacketEvents.getAPI().getLogManager().severe("You are attempting to combine 2.0 PacketEvents with a ProtocolLib version older than v5.0.0. This is no longer works, please update to their dev builds. https://ci.dmulloy2.net/job/ProtocolLib/lastBuild/");
/* 198 */               Plugin ourPlugin = getPlugin();
/* 199 */               Bukkit.getPluginManager().disablePlugin(ourPlugin);
/* 200 */               throw new IllegalStateException("ProtocolLib incompatibility! Update to v5.0.0 or newer!");
/*     */             } 
/*     */           } 
/*     */         }
/*     */         
/*     */         public boolean isInitialized() {
/* 207 */           return this.initialized;
/*     */         }
/*     */         
/*     */         public void terminate() {
/* 212 */           if (this.initialized) {
/* 214 */             this.injector.uninject();
/* 215 */             for (User user : ProtocolManager.USERS.values())
/* 216 */               ServerConnectionInitializer.destroyHandlers(user.getChannel()); 
/* 219 */             getEventManager().unregisterAllListeners();
/* 220 */             this.initialized = false;
/*     */           } 
/*     */         }
/*     */         
/*     */         public Plugin getPlugin() {
/* 226 */           return plugin;
/*     */         }
/*     */         
/*     */         public ProtocolManager getProtocolManager() {
/* 231 */           return this.protocolManager;
/*     */         }
/*     */         
/*     */         public ServerManager getServerManager() {
/* 236 */           return this.serverManager;
/*     */         }
/*     */         
/*     */         public PlayerManager getPlayerManager() {
/* 241 */           return this.playerManager;
/*     */         }
/*     */         
/*     */         public PacketEventsSettings getSettings() {
/* 246 */           return this.settings;
/*     */         }
/*     */         
/*     */         public NettyManager getNettyManager() {
/* 251 */           return this.nettyManager;
/*     */         }
/*     */         
/*     */         public ChannelInjector getInjector() {
/* 256 */           return (ChannelInjector)this.injector;
/*     */         }
/*     */         
/*     */         public LogManager getLogManager() {
/* 261 */           return this.logManager;
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\factory\spigot\SpigotPacketEventsBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */