/*    */ package io.github.retrooper.waveanticheat.packetevents.manager.server;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerManager;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.util.PEVersion;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class ServerManagerImpl implements ServerManager {
/*    */   private ServerVersion serverVersion;
/*    */   
/*    */   private ServerVersion resolveVersionNoCache() {
/* 32 */     Plugin plugin = (Plugin)PacketEvents.getAPI().getPlugin();
/* 33 */     String bukkitVersion = Bukkit.getBukkitVersion();
/* 34 */     ServerVersion fallbackVersion = ServerVersion.V_1_8_8;
/* 35 */     if (bukkitVersion.contains("Unknown"))
/* 36 */       return fallbackVersion; 
/* 40 */     PEVersion version = new PEVersion(bukkitVersion.substring(0, bukkitVersion.indexOf("-")));
/* 41 */     PEVersion latestVersion = new PEVersion(ServerVersion.getLatest().getReleaseName());
/* 42 */     if (version.isNewerThan(latestVersion)) {
/* 44 */       plugin.getLogger().warning("[packetevents] We currently do not support the minecraft version " + version
/* 45 */           .toString() + ", so things might break. PacketEvents will behave as if the minecraft version were " + latestVersion
/* 46 */           .toString() + "!");
/* 47 */       return ServerVersion.getLatest();
/*    */     } 
/* 49 */     for (ServerVersion val : ServerVersion.reversedValues()) {
/* 51 */       if (bukkitVersion.contains(val.getReleaseName()))
/* 52 */         return val; 
/*    */     } 
/* 56 */     plugin.getLogger().warning("[packetevents] Your server software is preventing us from checking the server version. This is what we found: " + Bukkit.getBukkitVersion() + ". We will assume the server version is " + fallbackVersion.name() + "...");
/* 57 */     return fallbackVersion;
/*    */   }
/*    */   
/*    */   public ServerVersion getVersion() {
/* 62 */     if (this.serverVersion == null)
/* 63 */       this.serverVersion = resolveVersionNoCache(); 
/* 65 */     return this.serverVersion;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\manager\server\ServerManagerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */