/*    */ package io.github.retrooper.waveanticheat.packetevents.manager.player;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.manager.player.PlayerManager;
/*    */ import com.github.retrooper.packetevents.manager.protocol.ProtocolManager;
/*    */ import com.github.retrooper.packetevents.netty.channel.ChannelHelper;
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.PlayerPingAccessorModern;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.SpigotReflectionUtil;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.protocolsupport.ProtocolSupportUtil;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.viaversion.ViaVersionUtil;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class PlayerManagerImpl implements PlayerManager {
/*    */   public int getPing(@NotNull Object player) {
/* 40 */     if (SpigotReflectionUtil.V_1_17_OR_HIGHER)
/* 41 */       return PlayerPingAccessorModern.getPing((Player)player); 
/* 43 */     return SpigotReflectionUtil.getPlayerPingLegacy((Player)player);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public ClientVersion getClientVersion(@NotNull Object p) {
/* 49 */     Player player = (Player)p;
/* 50 */     User user = getUser(player);
/* 51 */     if (user == null)
/* 51 */       return ClientVersion.UNKNOWN; 
/* 52 */     if (user.getClientVersion() == null) {
/*    */       int protocolVersion;
/* 54 */       if (ProtocolSupportUtil.isAvailable()) {
/* 55 */         protocolVersion = ProtocolSupportUtil.getProtocolVersion(user.getAddress());
/* 56 */         PacketEvents.getAPI().getLogManager().debug("Requested ProtocolSupport for user " + user.getName() + "'s protocol version. Protocol version: " + protocolVersion);
/* 57 */       } else if (ViaVersionUtil.isAvailable()) {
/* 58 */         protocolVersion = ViaVersionUtil.getProtocolVersion(player);
/* 59 */         PacketEvents.getAPI().getLogManager().debug("Requested ViaVersion for " + player.getName() + "'s protocol version. Protocol version: " + protocolVersion);
/*    */       } else {
/* 63 */         protocolVersion = PacketEvents.getAPI().getServerManager().getVersion().getProtocolVersion();
/* 64 */         PacketEvents.getAPI().getLogManager().debug("No protocol translation plugins are available. We will assume " + user.getName() + "'s protocol version is the same as the server's protocol version. Protocol version: " + protocolVersion);
/*    */       } 
/* 66 */       ClientVersion version = ClientVersion.getById(protocolVersion);
/* 67 */       user.setClientVersion(version);
/*    */     } 
/* 69 */     return user.getClientVersion();
/*    */   }
/*    */   
/*    */   public Object getChannel(@NotNull Object player) {
/* 74 */     UUID uuid = ((Player)player).getUniqueId();
/* 75 */     Object channel = PacketEvents.getAPI().getProtocolManager().getChannel(uuid);
/* 76 */     if (channel == null) {
/* 77 */       channel = SpigotReflectionUtil.getChannel((Player)player);
/* 80 */       if (channel != null)
/* 81 */         synchronized (channel) {
/* 82 */           if (ChannelHelper.isOpen(channel))
/* 83 */             ProtocolManager.CHANNELS.put(uuid, channel); 
/*    */         }  
/*    */     } 
/* 88 */     return channel;
/*    */   }
/*    */   
/*    */   public User getUser(@NotNull Object player) {
/* 93 */     Player p = (Player)player;
/* 94 */     Object channel = getChannel(p);
/* 96 */     if (channel == null)
/* 96 */       return null; 
/* 97 */     return PacketEvents.getAPI().getProtocolManager().getUser(channel);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\manager\player\PlayerManagerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */