/*    */ package io.github.retrooper.waveanticheat.packetevents.manager;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*    */ import com.github.retrooper.packetevents.manager.InternalPacketListener;
/*    */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ import com.github.retrooper.packetevents.wrapper.handshaking.client.WrapperHandshakingClientHandshake;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.protocolsupport.ProtocolSupportUtil;
/*    */ import io.github.retrooper.waveanticheat.packetevents.util.viaversion.ViaVersionUtil;
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ public class InternalBukkitPacketListener extends InternalPacketListener {
/*    */   public void onPacketReceive(PacketReceiveEvent event) {
/* 18 */     User user = event.getUser();
/* 20 */     if (event.getPacketType() == PacketType.Handshaking.Client.HANDSHAKE) {
/* 21 */       InetSocketAddress address = event.getSocketAddress();
/* 22 */       WrapperHandshakingClientHandshake handshake = new WrapperHandshakingClientHandshake(event);
/* 23 */       ConnectionState nextState = handshake.getNextConnectionState();
/* 24 */       ClientVersion clientVersion = handshake.getClientVersion();
/* 26 */       PacketEvents.getAPI().getLogManager().debug("Read handshake version for " + address.getHostString() + ":" + address.getPort() + " as " + clientVersion);
/* 28 */       if (ViaVersionUtil.isAvailable()) {
/* 29 */         clientVersion = ClientVersion.getById(ViaVersionUtil.getProtocolVersion(user));
/* 30 */         PacketEvents.getAPI().getLogManager().debug("Read ViaVersion version for " + address.getHostString() + ":" + address.getPort() + " as " + clientVersion + " with UUID=" + user.getUUID());
/* 31 */       } else if (ProtocolSupportUtil.isAvailable()) {
/* 32 */         clientVersion = ClientVersion.getById(ProtocolSupportUtil.getProtocolVersion(user.getAddress()));
/* 33 */         PacketEvents.getAPI().getLogManager().debug("Read ProtocolSupport version for " + address.getHostString() + ":" + address.getPort() + " as " + clientVersion);
/*    */       } 
/* 35 */       if (clientVersion == ClientVersion.UNKNOWN)
/* 36 */         PacketEvents.getAPI().getLogManager().debug("Client version for " + address.getHostString() + ":" + address.getPort() + " is unknown!"); 
/* 39 */       user.setClientVersion(clientVersion);
/* 40 */       PacketEvents.getAPI().getLogManager().debug("Processed " + address.getHostString() + ":" + address.getPort() + "'s client version. Client Version: " + clientVersion.getReleaseName());
/* 42 */       user.setConnectionState(nextState);
/*    */     } else {
/* 44 */       super.onPacketReceive(event);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\io\github\retrooper\waveanticheat\packetevents\manager\InternalBukkitPacketListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */