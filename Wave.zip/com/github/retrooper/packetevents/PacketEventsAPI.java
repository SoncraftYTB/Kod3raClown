/*    */ package com.github.retrooper.packetevents;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.EventManager;
/*    */ import com.github.retrooper.packetevents.injector.ChannelInjector;
/*    */ import com.github.retrooper.packetevents.manager.player.PlayerManager;
/*    */ import com.github.retrooper.packetevents.manager.protocol.ProtocolManager;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerManager;
/*    */ import com.github.retrooper.packetevents.netty.NettyManager;
/*    */ import com.github.retrooper.packetevents.settings.PacketEventsSettings;
/*    */ import com.github.retrooper.packetevents.util.LogManager;
/*    */ import com.github.retrooper.packetevents.util.PEVersion;
/*    */ import com.github.retrooper.packetevents.util.updatechecker.UpdateChecker;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public abstract class PacketEventsAPI<T> {
/* 35 */   private static final EventManager EVENT_MANAGER = new EventManager();
/*    */   
/* 36 */   private static final PacketEventsSettings SETTINGS = new PacketEventsSettings();
/*    */   
/* 37 */   private static final UpdateChecker UPDATE_CHECKER = new UpdateChecker();
/*    */   
/* 38 */   private final Logger LOGGER = Logger.getLogger(PacketEventsAPI.class.getName());
/*    */   
/* 39 */   private static final LogManager LOG_MANAGER = new LogManager();
/*    */   
/* 41 */   private static final PEVersion VERSION = new PEVersion(new int[] { 2, 2, 0 });
/*    */   
/*    */   public EventManager getEventManager() {
/* 44 */     return EVENT_MANAGER;
/*    */   }
/*    */   
/*    */   public PacketEventsSettings getSettings() {
/* 48 */     return SETTINGS;
/*    */   }
/*    */   
/*    */   public UpdateChecker getUpdateChecker() {
/* 52 */     return UPDATE_CHECKER;
/*    */   }
/*    */   
/*    */   public PEVersion getVersion() {
/* 56 */     return VERSION;
/*    */   }
/*    */   
/*    */   public Logger getLogger() {
/* 60 */     return this.LOGGER;
/*    */   }
/*    */   
/*    */   public LogManager getLogManager() {
/* 64 */     return LOG_MANAGER;
/*    */   }
/*    */   
/*    */   public abstract void load();
/*    */   
/*    */   public abstract boolean isLoaded();
/*    */   
/*    */   public abstract void init();
/*    */   
/*    */   public abstract boolean isInitialized();
/*    */   
/*    */   public abstract void terminate();
/*    */   
/*    */   public abstract T getPlugin();
/*    */   
/*    */   public abstract ServerManager getServerManager();
/*    */   
/*    */   public abstract ProtocolManager getProtocolManager();
/*    */   
/*    */   public abstract PlayerManager getPlayerManager();
/*    */   
/*    */   public abstract NettyManager getNettyManager();
/*    */   
/*    */   public abstract ChannelInjector getInjector();
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\PacketEventsAPI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */