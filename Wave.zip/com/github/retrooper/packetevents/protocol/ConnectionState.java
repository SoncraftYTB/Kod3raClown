/*    */ package com.github.retrooper.packetevents.protocol;
/*    */ 
/*    */ public enum ConnectionState {
/* 26 */   HANDSHAKING, STATUS, LOGIN, PLAY, CONFIGURATION;
/*    */   
/*    */   public static ConnectionState getById(int id) {
/* 29 */     if (id >= (values()).length || id < 0)
/* 30 */       return null; 
/* 32 */     return values()[id];
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\ConnectionState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */