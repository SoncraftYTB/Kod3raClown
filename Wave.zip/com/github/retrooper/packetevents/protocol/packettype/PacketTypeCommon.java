/*    */ package com.github.retrooper.packetevents.protocol.packettype;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.PacketSide;
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ 
/*    */ public interface PacketTypeCommon {
/*    */   default String getName() {
/* 27 */     return ((Enum<Enum>)this).name();
/*    */   }
/*    */   
/*    */   int getId(ClientVersion paramClientVersion);
/*    */   
/*    */   PacketSide getSide();
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\packettype\PacketTypeCommon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */