/*    */ package com.github.retrooper.packetevents.protocol.packettype.serverbound;
/*    */ 
/*    */ public enum ServerboundPacketType_1_8 {
/* 22 */   KEEP_ALIVE, CHAT_MESSAGE, INTERACT_ENTITY, PLAYER_FLYING, PLAYER_POSITION, PLAYER_ROTATION, PLAYER_POSITION_AND_ROTATION, PLAYER_DIGGING, PLAYER_BLOCK_PLACEMENT, HELD_ITEM_CHANGE, ANIMATION, ENTITY_ACTION, STEER_VEHICLE, CLOSE_WINDOW, CLICK_WINDOW, WINDOW_CONFIRMATION, CREATIVE_INVENTORY_ACTION, CLICK_WINDOW_BUTTON, UPDATE_SIGN, PLAYER_ABILITIES, TAB_COMPLETE, CLIENT_SETTINGS, CLIENT_STATUS, PLUGIN_MESSAGE, SPECTATE, RESOURCE_PACK_STATUS;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\packettype\serverbound\ServerboundPacketType_1_8.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */