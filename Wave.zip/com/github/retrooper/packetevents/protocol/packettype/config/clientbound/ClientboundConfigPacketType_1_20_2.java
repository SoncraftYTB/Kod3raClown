/*    */ package com.github.retrooper.packetevents.protocol.packettype.config.clientbound;
/*    */ 
/*    */ public enum ClientboundConfigPacketType_1_20_2 {
/* 23 */   PLUGIN_MESSAGE, DISCONNECT, CONFIGURATION_END, KEEP_ALIVE, PING, REGISTRY_DATA, RESOURCE_PACK_SEND, UPDATE_ENABLED_FEATURES, UPDATE_TAGS;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\packettype\config\clientbound\ClientboundConfigPacketType_1_20_2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */