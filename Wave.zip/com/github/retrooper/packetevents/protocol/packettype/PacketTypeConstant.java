/*    */ package com.github.retrooper.packetevents.protocol.packettype;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ 
/*    */ public interface PacketTypeConstant extends PacketTypeCommon {
/*    */   default int getId(ClientVersion version) {
/* 25 */     return getId();
/*    */   }
/*    */   
/*    */   int getId();
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\packettype\PacketTypeConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */