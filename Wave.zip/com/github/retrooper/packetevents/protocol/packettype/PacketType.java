/*     */ package com.github.retrooper.packetevents.protocol.packettype;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*     */ import com.github.retrooper.packetevents.protocol.PacketSide;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_12;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_12_1;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_13;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_14;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_14_4;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_15;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_15_2;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_16;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_16_2;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_17;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_18;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_19;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_19_1;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_19_3;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_19_4;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_20_2;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_20_3;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_7_10;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_8;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_9;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.clientbound.ClientboundPacketType_1_9_3;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.config.clientbound.ClientboundConfigPacketType_1_20_2;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.config.clientbound.ClientboundConfigPacketType_1_20_3;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_12;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_12_1;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_13;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_14;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_15_2;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_16;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_16_2;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_17;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_19;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_19_1;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_19_3;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_19_4;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_20_2;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_20_3;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_7_10;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_8;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.serverbound.ServerboundPacketType_1_9;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.util.VersionMapper;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public final class PacketType {
/*     */   private static boolean PREPARED = false;
/*     */   
/*  74 */   private static final VersionMapper CLIENTBOUND_PLAY_VERSION_MAPPER = new VersionMapper(new ClientVersion[] { 
/*  74 */         ClientVersion.V_1_7_10, ClientVersion.V_1_8, ClientVersion.V_1_9, ClientVersion.V_1_10, ClientVersion.V_1_12, ClientVersion.V_1_12_1, ClientVersion.V_1_13, ClientVersion.V_1_14, ClientVersion.V_1_14_4, ClientVersion.V_1_15, 
/*  74 */         ClientVersion.V_1_15_2, ClientVersion.V_1_16, ClientVersion.V_1_16_2, ClientVersion.V_1_17, ClientVersion.V_1_18, ClientVersion.V_1_19, ClientVersion.V_1_19_1, ClientVersion.V_1_19_3, ClientVersion.V_1_19_4, ClientVersion.V_1_20_2, 
/*  74 */         ClientVersion.V_1_20_3 });
/*     */   
/*  98 */   private static final VersionMapper SERVERBOUND_PLAY_VERSION_MAPPER = new VersionMapper(new ClientVersion[] { 
/*  98 */         ClientVersion.V_1_7_10, ClientVersion.V_1_8, ClientVersion.V_1_9, ClientVersion.V_1_12, ClientVersion.V_1_12_1, ClientVersion.V_1_13, ClientVersion.V_1_14, ClientVersion.V_1_15_2, ClientVersion.V_1_16, ClientVersion.V_1_16_2, 
/*  98 */         ClientVersion.V_1_17, ClientVersion.V_1_19, ClientVersion.V_1_19_1, ClientVersion.V_1_19_3, ClientVersion.V_1_19_4, ClientVersion.V_1_20_2, ClientVersion.V_1_20_3 });
/*     */   
/* 118 */   private static final VersionMapper CLIENTBOUND_CONFIG_VERSION_MAPPER = new VersionMapper(new ClientVersion[] { ClientVersion.V_1_20_2, ClientVersion.V_1_20_3 });
/*     */   
/*     */   public static void prepare() {
/* 123 */     Play.Client.load();
/* 124 */     Play.Server.load();
/* 125 */     Configuration.Server.load();
/* 126 */     PREPARED = true;
/*     */   }
/*     */   
/*     */   public static boolean isPrepared() {
/* 130 */     return PREPARED;
/*     */   }
/*     */   
/*     */   public static PacketTypeCommon getById(PacketSide side, ConnectionState state, ClientVersion version, int packetID) {
/* 134 */     switch (state) {
/*     */       case HANDSHAKING:
/* 136 */         if (side == PacketSide.CLIENT)
/* 137 */           return Handshaking.Client.getById(packetID); 
/* 139 */         return Handshaking.Server.getById(packetID);
/*     */       case STATUS:
/* 142 */         if (side == PacketSide.CLIENT)
/* 143 */           return Status.Client.getById(packetID); 
/* 145 */         return Status.Server.getById(packetID);
/*     */       case LOGIN:
/* 148 */         if (side == PacketSide.CLIENT)
/* 149 */           return Login.Client.getById(packetID); 
/* 151 */         return Login.Server.getById(packetID);
/*     */       case PLAY:
/* 154 */         if (side == PacketSide.CLIENT)
/* 155 */           return Play.Client.getById(version, packetID); 
/* 157 */         return Play.Server.getById(version, packetID);
/*     */       case CONFIGURATION:
/* 160 */         if (side == PacketSide.CLIENT)
/* 161 */           return Configuration.Client.getById(packetID); 
/* 163 */         return Configuration.Server.getById(version, packetID);
/*     */     } 
/* 166 */     return null;
/*     */   }
/*     */   
/*     */   public static class Handshaking {
/*     */     public enum Client implements PacketTypeConstant, ServerBoundPacket {
/* 172 */       HANDSHAKE(0),
/* 177 */       LEGACY_SERVER_LIST_PING(254);
/*     */       
/*     */       private final int id;
/*     */       
/*     */       Client(int id) {
/* 182 */         this.id = id;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(int packetID) {
/* 187 */         if (packetID == 0)
/* 188 */           return HANDSHAKE; 
/* 189 */         if (packetID == 254)
/* 190 */           return LEGACY_SERVER_LIST_PING; 
/* 192 */         return null;
/*     */       }
/*     */       
/*     */       public int getId() {
/* 197 */         return this.id;
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 202 */         return PacketSide.CLIENT;
/*     */       }
/*     */     }
/*     */     
/*     */     public enum Server implements PacketTypeConstant, ClientBoundPacket {
/* 207 */       LEGACY_SERVER_LIST_RESPONSE(254);
/*     */       
/*     */       private final int id;
/*     */       
/*     */       Server(int id) {
/* 212 */         this.id = id;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(int packetID) {
/* 217 */         return (packetID == 254) ? LEGACY_SERVER_LIST_RESPONSE : null;
/*     */       }
/*     */       
/*     */       public int getId() {
/* 221 */         return this.id;
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 226 */         return PacketSide.SERVER;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Client implements PacketTypeConstant, ServerBoundPacket {
/*     */     HANDSHAKE(0),
/*     */     LEGACY_SERVER_LIST_PING(254);
/*     */     
/*     */     private final int id;
/*     */     
/*     */     Client(int id) {
/*     */       this.id = id;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(int packetID) {
/*     */       if (packetID == 0)
/*     */         return HANDSHAKE; 
/*     */       if (packetID == 254)
/*     */         return LEGACY_SERVER_LIST_PING; 
/*     */       return null;
/*     */     }
/*     */     
/*     */     public int getId() {
/*     */       return this.id;
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/*     */       return PacketSide.CLIENT;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Server implements PacketTypeConstant, ClientBoundPacket {
/*     */     LEGACY_SERVER_LIST_RESPONSE(254);
/*     */     
/*     */     private final int id;
/*     */     
/*     */     Server(int id) {
/*     */       this.id = id;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(int packetID) {
/*     */       return (packetID == 254) ? LEGACY_SERVER_LIST_RESPONSE : null;
/*     */     }
/*     */     
/*     */     public int getId() {
/*     */       return this.id;
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/* 226 */       return PacketSide.SERVER;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Status {
/*     */     public enum Client implements PacketTypeConstant, ServerBoundPacket {
/* 233 */       REQUEST(0),
/* 234 */       PING(1);
/*     */       
/*     */       private final int id;
/*     */       
/*     */       Client(int id) {
/* 239 */         this.id = id;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(int packetId) {
/* 244 */         if (packetId == 0)
/* 245 */           return REQUEST; 
/* 246 */         if (packetId == 1)
/* 247 */           return PING; 
/* 249 */         return null;
/*     */       }
/*     */       
/*     */       public int getId() {
/* 254 */         return this.id;
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 260 */         return PacketSide.CLIENT;
/*     */       }
/*     */     }
/*     */     
/*     */     public enum Server implements PacketTypeConstant, ClientBoundPacket {
/* 265 */       RESPONSE(0),
/* 266 */       PONG(1);
/*     */       
/*     */       private final int id;
/*     */       
/*     */       Server(int id) {
/* 271 */         this.id = id;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(int packetID) {
/* 276 */         if (packetID == 0)
/* 277 */           return RESPONSE; 
/* 278 */         if (packetID == 1)
/* 279 */           return PONG; 
/* 281 */         return null;
/*     */       }
/*     */       
/*     */       public int getId() {
/* 286 */         return this.id;
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 291 */         return PacketSide.SERVER;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Client implements PacketTypeConstant, ServerBoundPacket {
/*     */     REQUEST(0),
/*     */     PING(1);
/*     */     
/*     */     private final int id;
/*     */     
/*     */     Client(int id) {
/*     */       this.id = id;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(int packetId) {
/*     */       if (packetId == 0)
/*     */         return REQUEST; 
/*     */       if (packetId == 1)
/*     */         return PING; 
/*     */       return null;
/*     */     }
/*     */     
/*     */     public int getId() {
/*     */       return this.id;
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/*     */       return PacketSide.CLIENT;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Server implements PacketTypeConstant, ClientBoundPacket {
/*     */     RESPONSE(0),
/*     */     PONG(1);
/*     */     
/*     */     private final int id;
/*     */     
/*     */     Server(int id) {
/*     */       this.id = id;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(int packetID) {
/*     */       if (packetID == 0)
/*     */         return RESPONSE; 
/*     */       if (packetID == 1)
/*     */         return PONG; 
/*     */       return null;
/*     */     }
/*     */     
/*     */     public int getId() {
/*     */       return this.id;
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/* 291 */       return PacketSide.SERVER;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Login {
/*     */     public enum Client implements PacketTypeConstant, ServerBoundPacket {
/* 298 */       LOGIN_START(0),
/* 299 */       ENCRYPTION_RESPONSE(1),
/* 301 */       LOGIN_PLUGIN_RESPONSE(2),
/* 303 */       LOGIN_SUCCESS_ACK(3);
/*     */       
/*     */       private final int id;
/*     */       
/*     */       Client(int id) {
/* 308 */         this.id = id;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(int packetID) {
/* 313 */         if (packetID == 0)
/* 314 */           return LOGIN_START; 
/* 315 */         if (packetID == 1)
/* 316 */           return ENCRYPTION_RESPONSE; 
/* 317 */         if (packetID == 2)
/* 318 */           return LOGIN_PLUGIN_RESPONSE; 
/* 319 */         if (packetID == 3)
/* 320 */           return LOGIN_SUCCESS_ACK; 
/* 322 */         return null;
/*     */       }
/*     */       
/*     */       public int getId() {
/* 327 */         return this.id;
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 332 */         return PacketSide.CLIENT;
/*     */       }
/*     */     }
/*     */     
/*     */     public enum Server implements PacketTypeConstant, ClientBoundPacket {
/* 337 */       DISCONNECT(0),
/* 338 */       ENCRYPTION_REQUEST(1),
/* 339 */       LOGIN_SUCCESS(2),
/* 341 */       SET_COMPRESSION(3),
/* 343 */       LOGIN_PLUGIN_REQUEST(4);
/*     */       
/*     */       private final int id;
/*     */       
/*     */       Server(int id) {
/* 348 */         this.id = id;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(int packetID) {
/* 353 */         switch (packetID) {
/*     */           case 0:
/* 355 */             return DISCONNECT;
/*     */           case 1:
/* 357 */             return ENCRYPTION_REQUEST;
/*     */           case 2:
/* 359 */             return LOGIN_SUCCESS;
/*     */           case 3:
/* 361 */             return SET_COMPRESSION;
/*     */           case 4:
/* 363 */             return LOGIN_PLUGIN_REQUEST;
/*     */         } 
/* 365 */         return null;
/*     */       }
/*     */       
/*     */       public int getId() {
/* 370 */         return this.id;
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 375 */         return PacketSide.SERVER;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Client implements PacketTypeConstant, ServerBoundPacket {
/*     */     LOGIN_START(0),
/*     */     ENCRYPTION_RESPONSE(1),
/*     */     LOGIN_PLUGIN_RESPONSE(2),
/*     */     LOGIN_SUCCESS_ACK(3);
/*     */     
/*     */     private final int id;
/*     */     
/*     */     Client(int id) {
/*     */       this.id = id;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(int packetID) {
/*     */       if (packetID == 0)
/*     */         return LOGIN_START; 
/*     */       if (packetID == 1)
/*     */         return ENCRYPTION_RESPONSE; 
/*     */       if (packetID == 2)
/*     */         return LOGIN_PLUGIN_RESPONSE; 
/*     */       if (packetID == 3)
/*     */         return LOGIN_SUCCESS_ACK; 
/*     */       return null;
/*     */     }
/*     */     
/*     */     public int getId() {
/*     */       return this.id;
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/*     */       return PacketSide.CLIENT;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Server implements PacketTypeConstant, ClientBoundPacket {
/*     */     DISCONNECT(0),
/*     */     ENCRYPTION_REQUEST(1),
/*     */     LOGIN_SUCCESS(2),
/*     */     SET_COMPRESSION(3),
/*     */     LOGIN_PLUGIN_REQUEST(4);
/*     */     
/*     */     private final int id;
/*     */     
/*     */     Server(int id) {
/*     */       this.id = id;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(int packetID) {
/*     */       switch (packetID) {
/*     */         case 0:
/*     */           return DISCONNECT;
/*     */         case 1:
/*     */           return ENCRYPTION_REQUEST;
/*     */         case 2:
/*     */           return LOGIN_SUCCESS;
/*     */         case 3:
/*     */           return SET_COMPRESSION;
/*     */         case 4:
/*     */           return LOGIN_PLUGIN_REQUEST;
/*     */       } 
/*     */       return null;
/*     */     }
/*     */     
/*     */     public int getId() {
/*     */       return this.id;
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/* 375 */       return PacketSide.SERVER;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Configuration {
/*     */     public enum Client implements PacketTypeConstant, ServerBoundPacket {
/* 385 */       CLIENT_SETTINGS(0),
/* 386 */       PLUGIN_MESSAGE(1),
/* 387 */       CONFIGURATION_END_ACK(2),
/* 388 */       KEEP_ALIVE(3),
/* 389 */       PONG(4),
/* 390 */       RESOURCE_PACK_STATUS(5);
/*     */       
/*     */       private final int id;
/*     */       
/*     */       Client(int id) {
/* 395 */         this.id = id;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(int packetId) {
/* 399 */         switch (packetId) {
/*     */           case 0:
/* 401 */             return CLIENT_SETTINGS;
/*     */           case 1:
/* 403 */             return PLUGIN_MESSAGE;
/*     */           case 2:
/* 405 */             return CONFIGURATION_END_ACK;
/*     */           case 3:
/* 407 */             return KEEP_ALIVE;
/*     */           case 4:
/* 409 */             return PONG;
/*     */           case 5:
/* 411 */             return RESOURCE_PACK_STATUS;
/*     */         } 
/* 413 */         return null;
/*     */       }
/*     */       
/*     */       public int getId() {
/* 419 */         return this.id;
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 424 */         return PacketSide.CLIENT;
/*     */       }
/*     */     }
/*     */     
/*     */     public enum Server implements PacketTypeCommon, ClientBoundPacket {
/* 430 */       PLUGIN_MESSAGE, DISCONNECT, CONFIGURATION_END, KEEP_ALIVE, PING, REGISTRY_DATA, RESOURCE_PACK_SEND, UPDATE_ENABLED_FEATURES, UPDATE_TAGS, RESOURCE_PACK_REMOVE;
/*     */       
/* 443 */       private static int INDEX = 0;
/*     */       
/* 444 */       private static final Map<Byte, Map<Integer, PacketTypeCommon>> PACKET_TYPE_ID_MAP = new HashMap<>();
/*     */       
/*     */       private final int[] ids;
/*     */       
/*     */       static {
/*     */       
/*     */       }
/*     */       
/*     */       Server() {
/* 448 */         this.ids = new int[(PacketType.CLIENTBOUND_CONFIG_VERSION_MAPPER.getVersions()).length];
/* 449 */         Arrays.fill(this.ids, -1);
/*     */       }
/*     */       
/*     */       public static void load() {
/* 453 */         INDEX = 0;
/* 454 */         loadPacketIds((Enum<?>[])ClientboundConfigPacketType_1_20_2.values());
/* 455 */         loadPacketIds((Enum<?>[])ClientboundConfigPacketType_1_20_3.values());
/*     */       }
/*     */       
/*     */       private static void loadPacketIds(Enum<?>[] enumConstants) {
/* 460 */         int index = INDEX;
/* 461 */         for (Enum<?> constant : enumConstants) {
/* 462 */           int id = constant.ordinal();
/* 463 */           Server value = valueOf(constant.name());
/* 464 */           value.ids[index] = id;
/* 465 */           Map<Integer, PacketTypeCommon> packetIdMap = PACKET_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/* 466 */           packetIdMap.put(Integer.valueOf(id), value);
/*     */         } 
/* 468 */         INDEX++;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(int packetId) {
/* 472 */         return getById(ClientVersion.getLatest(), packetId);
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(ClientVersion version, int packetId) {
/* 476 */         if (!PacketType.PREPARED)
/* 477 */           PacketType.prepare(); 
/* 479 */         int index = PacketType.CLIENTBOUND_CONFIG_VERSION_MAPPER.getIndex(version);
/* 480 */         Map<Integer, PacketTypeCommon> map = PACKET_TYPE_ID_MAP.get(Byte.valueOf((byte)index));
/* 481 */         return map.get(Integer.valueOf(packetId));
/*     */       }
/*     */       
/*     */       @Deprecated
/*     */       public int getId() {
/* 486 */         return getId(ClientVersion.getLatest());
/*     */       }
/*     */       
/*     */       public int getId(ClientVersion version) {
/* 491 */         if (!PacketType.PREPARED)
/* 492 */           PacketType.prepare(); 
/* 494 */         int index = PacketType.CLIENTBOUND_CONFIG_VERSION_MAPPER.getIndex(version);
/* 495 */         return this.ids[index];
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 500 */         return PacketSide.SERVER;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Client implements PacketTypeConstant, ServerBoundPacket {
/*     */     CLIENT_SETTINGS(0),
/*     */     PLUGIN_MESSAGE(1),
/*     */     CONFIGURATION_END_ACK(2),
/*     */     KEEP_ALIVE(3),
/*     */     PONG(4),
/*     */     RESOURCE_PACK_STATUS(5);
/*     */     
/*     */     private final int id;
/*     */     
/*     */     Client(int id) {
/*     */       this.id = id;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(int packetId) {
/*     */       switch (packetId) {
/*     */         case 0:
/*     */           return CLIENT_SETTINGS;
/*     */         case 1:
/*     */           return PLUGIN_MESSAGE;
/*     */         case 2:
/*     */           return CONFIGURATION_END_ACK;
/*     */         case 3:
/*     */           return KEEP_ALIVE;
/*     */         case 4:
/*     */           return PONG;
/*     */         case 5:
/*     */           return RESOURCE_PACK_STATUS;
/*     */       } 
/*     */       return null;
/*     */     }
/*     */     
/*     */     public int getId() {
/*     */       return this.id;
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/*     */       return PacketSide.CLIENT;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Server implements PacketTypeCommon, ClientBoundPacket {
/*     */     PLUGIN_MESSAGE, DISCONNECT, CONFIGURATION_END, KEEP_ALIVE, PING, REGISTRY_DATA, RESOURCE_PACK_SEND, UPDATE_ENABLED_FEATURES, UPDATE_TAGS, RESOURCE_PACK_REMOVE;
/*     */     
/*     */     private static int INDEX = 0;
/*     */     
/*     */     private static final Map<Byte, Map<Integer, PacketTypeCommon>> PACKET_TYPE_ID_MAP = new HashMap<>();
/*     */     
/*     */     private final int[] ids;
/*     */     
/*     */     static {
/*     */     
/*     */     }
/*     */     
/*     */     Server() {
/*     */       this.ids = new int[(PacketType.CLIENTBOUND_CONFIG_VERSION_MAPPER.getVersions()).length];
/*     */       Arrays.fill(this.ids, -1);
/*     */     }
/*     */     
/*     */     public static void load() {
/*     */       INDEX = 0;
/*     */       loadPacketIds((Enum<?>[])ClientboundConfigPacketType_1_20_2.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundConfigPacketType_1_20_3.values());
/*     */     }
/*     */     
/*     */     private static void loadPacketIds(Enum<?>[] enumConstants) {
/*     */       int index = INDEX;
/*     */       for (Enum<?> constant : enumConstants) {
/*     */         int id = constant.ordinal();
/*     */         Server value = valueOf(constant.name());
/*     */         value.ids[index] = id;
/*     */         Map<Integer, PacketTypeCommon> packetIdMap = PACKET_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/*     */         packetIdMap.put(Integer.valueOf(id), value);
/*     */       } 
/*     */       INDEX++;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(int packetId) {
/*     */       return getById(ClientVersion.getLatest(), packetId);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(ClientVersion version, int packetId) {
/*     */       if (!PacketType.PREPARED)
/*     */         PacketType.prepare(); 
/*     */       int index = PacketType.CLIENTBOUND_CONFIG_VERSION_MAPPER.getIndex(version);
/*     */       Map<Integer, PacketTypeCommon> map = PACKET_TYPE_ID_MAP.get(Byte.valueOf((byte)index));
/*     */       return map.get(Integer.valueOf(packetId));
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public int getId() {
/*     */       return getId(ClientVersion.getLatest());
/*     */     }
/*     */     
/*     */     public int getId(ClientVersion version) {
/*     */       if (!PacketType.PREPARED)
/*     */         PacketType.prepare(); 
/*     */       int index = PacketType.CLIENTBOUND_CONFIG_VERSION_MAPPER.getIndex(version);
/*     */       return this.ids[index];
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/* 500 */       return PacketSide.SERVER;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Play {
/*     */     public enum Client implements PacketTypeCommon, ServerBoundPacket {
/* 508 */       CHAT_PREVIEW, TELEPORT_CONFIRM, QUERY_BLOCK_NBT, SET_DIFFICULTY, CHAT_MESSAGE, CLIENT_STATUS, CLIENT_SETTINGS, TAB_COMPLETE, WINDOW_CONFIRMATION, CLICK_WINDOW_BUTTON, CLICK_WINDOW, CLOSE_WINDOW, PLUGIN_MESSAGE, EDIT_BOOK, QUERY_ENTITY_NBT, INTERACT_ENTITY, GENERATE_STRUCTURE, KEEP_ALIVE, LOCK_DIFFICULTY, PLAYER_POSITION, PLAYER_POSITION_AND_ROTATION, PLAYER_ROTATION, PLAYER_FLYING, VEHICLE_MOVE, STEER_BOAT, PICK_ITEM, CRAFT_RECIPE_REQUEST, PLAYER_ABILITIES, PLAYER_DIGGING, ENTITY_ACTION, STEER_VEHICLE, PONG, RECIPE_BOOK_DATA, SET_DISPLAYED_RECIPE, SET_RECIPE_BOOK_STATE, NAME_ITEM, RESOURCE_PACK_STATUS, ADVANCEMENT_TAB, SELECT_TRADE, SET_BEACON_EFFECT, HELD_ITEM_CHANGE, UPDATE_COMMAND_BLOCK, UPDATE_COMMAND_BLOCK_MINECART, CREATIVE_INVENTORY_ACTION, UPDATE_JIGSAW_BLOCK, UPDATE_STRUCTURE_BLOCK, UPDATE_SIGN, ANIMATION, SPECTATE, PLAYER_BLOCK_PLACEMENT, USE_ITEM, CHAT_COMMAND, CHAT_ACK, CHAT_SESSION_UPDATE, CHUNK_BATCH_ACK, CONFIGURATION_ACK, DEBUG_PING, SLOT_STATE_CHANGE;
/*     */       
/* 573 */       private static int INDEX = 0;
/*     */       
/* 574 */       private static final Map<Byte, Map<Integer, PacketTypeCommon>> PACKET_TYPE_ID_MAP = new HashMap<>();
/*     */       
/*     */       private final int[] ids;
/*     */       
/*     */       static {
/*     */       
/*     */       }
/*     */       
/*     */       Client() {
/* 578 */         this.ids = new int[(PacketType.SERVERBOUND_PLAY_VERSION_MAPPER.getVersions()).length];
/* 579 */         Arrays.fill(this.ids, -1);
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(ClientVersion version, int packetId) {
/* 584 */         if (!PacketType.PREPARED)
/* 585 */           PacketType.prepare(); 
/* 587 */         int index = PacketType.SERVERBOUND_PLAY_VERSION_MAPPER.getIndex(version);
/* 588 */         Map<Integer, PacketTypeCommon> packetIdMap = PACKET_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/* 589 */         return packetIdMap.get(Integer.valueOf(packetId));
/*     */       }
/*     */       
/*     */       private static void loadPacketIds(Enum<?>[] enumConstants) {
/* 593 */         int index = INDEX;
/* 594 */         for (Enum<?> constant : enumConstants) {
/* 595 */           int id = constant.ordinal();
/* 596 */           Client value = valueOf(constant.name());
/* 597 */           value.ids[index] = id;
/* 598 */           Map<Integer, PacketTypeCommon> packetIdMap = PACKET_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/* 600 */           packetIdMap.put(Integer.valueOf(id), value);
/*     */         } 
/* 602 */         INDEX++;
/*     */       }
/*     */       
/*     */       public static void load() {
/* 606 */         INDEX = 0;
/* 607 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_7_10.values());
/* 608 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_8.values());
/* 609 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_9.values());
/* 610 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_12.values());
/* 611 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_12_1.values());
/* 612 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_13.values());
/* 613 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_14.values());
/* 614 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_15_2.values());
/* 615 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_16.values());
/* 616 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_16_2.values());
/* 617 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_17.values());
/* 618 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_19.values());
/* 619 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_19_1.values());
/* 620 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_19_3.values());
/* 621 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_19_4.values());
/* 622 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_20_2.values());
/* 623 */         loadPacketIds((Enum<?>[])ServerboundPacketType_1_20_3.values());
/*     */       }
/*     */       
/*     */       public int getId(ClientVersion version) {
/* 628 */         if (!PacketType.PREPARED)
/* 629 */           PacketType.prepare(); 
/* 631 */         int index = PacketType.SERVERBOUND_PLAY_VERSION_MAPPER.getIndex(version);
/* 632 */         return this.ids[index];
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 637 */         return PacketSide.CLIENT;
/*     */       }
/*     */     }
/*     */     
/*     */     public enum Server implements PacketTypeCommon, ClientBoundPacket {
/* 643 */       SET_COMPRESSION, MAP_CHUNK_BULK, UPDATE_ENTITY_NBT, UPDATE_SIGN, USE_BED, SPAWN_WEATHER_ENTITY, TITLE, WORLD_BORDER, COMBAT_EVENT, ENTITY_MOVEMENT, SPAWN_LIVING_ENTITY, SPAWN_PAINTING, SCULK_VIBRATION_SIGNAL, ACKNOWLEDGE_PLAYER_DIGGING, CHAT_PREVIEW_PACKET, NAMED_SOUND_EFFECT, PLAYER_CHAT_HEADER, PLAYER_INFO, DISPLAY_CHAT_PREVIEW, UPDATE_ENABLED_FEATURES, SPAWN_PLAYER, WINDOW_CONFIRMATION, SPAWN_ENTITY, SPAWN_EXPERIENCE_ORB, ENTITY_ANIMATION, STATISTICS, BLOCK_BREAK_ANIMATION, BLOCK_ENTITY_DATA, BLOCK_ACTION, BLOCK_CHANGE, BOSS_BAR, SERVER_DIFFICULTY, CLEAR_TITLES, TAB_COMPLETE, MULTI_BLOCK_CHANGE, DECLARE_COMMANDS, CLOSE_WINDOW, WINDOW_ITEMS, WINDOW_PROPERTY, SET_SLOT, SET_COOLDOWN, PLUGIN_MESSAGE, DISCONNECT, ENTITY_STATUS, EXPLOSION, UNLOAD_CHUNK, CHANGE_GAME_STATE, OPEN_HORSE_WINDOW, INITIALIZE_WORLD_BORDER, KEEP_ALIVE, CHUNK_DATA, EFFECT, PARTICLE, UPDATE_LIGHT, JOIN_GAME, MAP_DATA, MERCHANT_OFFERS, ENTITY_RELATIVE_MOVE, ENTITY_RELATIVE_MOVE_AND_ROTATION, ENTITY_ROTATION, VEHICLE_MOVE, OPEN_BOOK, OPEN_WINDOW, OPEN_SIGN_EDITOR, PING, CRAFT_RECIPE_RESPONSE, PLAYER_ABILITIES, END_COMBAT_EVENT, ENTER_COMBAT_EVENT, DEATH_COMBAT_EVENT, FACE_PLAYER, PLAYER_POSITION_AND_LOOK, UNLOCK_RECIPES, DESTROY_ENTITIES, REMOVE_ENTITY_EFFECT, RESOURCE_PACK_SEND, RESPAWN, ENTITY_HEAD_LOOK, SELECT_ADVANCEMENTS_TAB, ACTION_BAR, WORLD_BORDER_CENTER, WORLD_BORDER_LERP_SIZE, WORLD_BORDER_SIZE, WORLD_BORDER_WARNING_DELAY, WORLD_BORDER_WARNING_REACH, CAMERA, HELD_ITEM_CHANGE, UPDATE_VIEW_POSITION, UPDATE_VIEW_DISTANCE, SPAWN_POSITION, DISPLAY_SCOREBOARD, ENTITY_METADATA, ATTACH_ENTITY, ENTITY_VELOCITY, ENTITY_EQUIPMENT, SET_EXPERIENCE, UPDATE_HEALTH, SCOREBOARD_OBJECTIVE, SET_PASSENGERS, TEAMS, UPDATE_SCORE, UPDATE_SIMULATION_DISTANCE, SET_TITLE_SUBTITLE, TIME_UPDATE, SET_TITLE_TEXT, SET_TITLE_TIMES, ENTITY_SOUND_EFFECT, SOUND_EFFECT, STOP_SOUND, PLAYER_LIST_HEADER_AND_FOOTER, NBT_QUERY_RESPONSE, COLLECT_ITEM, ENTITY_TELEPORT, UPDATE_ADVANCEMENTS, UPDATE_ATTRIBUTES, ENTITY_EFFECT, DECLARE_RECIPES, TAGS, CHAT_MESSAGE, ACKNOWLEDGE_BLOCK_CHANGES, SERVER_DATA, SYSTEM_CHAT_MESSAGE, DELETE_CHAT, CUSTOM_CHAT_COMPLETIONS, DISGUISED_CHAT, PLAYER_INFO_REMOVE, PLAYER_INFO_UPDATE, DAMAGE_EVENT, HURT_ANIMATION, BUNDLE, CHUNK_BIOMES, CHUNK_BATCH_END, CHUNK_BATCH_BEGIN, DEBUG_PONG, CONFIGURATION_START, RESET_SCORE, RESOURCE_PACK_REMOVE, TICKING_STATE, TICKING_STEP;
/*     */       
/* 797 */       private static int INDEX = 0;
/*     */       
/* 798 */       private static final Map<Byte, Map<Integer, PacketTypeCommon>> PACKET_TYPE_ID_MAP = new HashMap<>();
/*     */       
/*     */       private final int[] ids;
/*     */       
/*     */       static {
/*     */       
/*     */       }
/*     */       
/*     */       Server() {
/* 802 */         this.ids = new int[(PacketType.CLIENTBOUND_PLAY_VERSION_MAPPER.getVersions()).length];
/* 803 */         Arrays.fill(this.ids, -1);
/*     */       }
/*     */       
/*     */       public int getId(ClientVersion version) {
/* 807 */         if (!PacketType.PREPARED)
/* 808 */           PacketType.prepare(); 
/* 810 */         int index = PacketType.CLIENTBOUND_PLAY_VERSION_MAPPER.getIndex(version);
/* 811 */         return this.ids[index];
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public static PacketTypeCommon getById(ClientVersion version, int packetId) {
/* 816 */         if (!PacketType.PREPARED)
/* 817 */           PacketType.prepare(); 
/* 819 */         int index = PacketType.CLIENTBOUND_PLAY_VERSION_MAPPER.getIndex(version);
/* 820 */         Map<Integer, PacketTypeCommon> map = PACKET_TYPE_ID_MAP.get(Byte.valueOf((byte)index));
/* 821 */         return map.get(Integer.valueOf(packetId));
/*     */       }
/*     */       
/*     */       public PacketSide getSide() {
/* 826 */         return PacketSide.SERVER;
/*     */       }
/*     */       
/*     */       private static void loadPacketIds(Enum<?>[] enumConstants) {
/* 830 */         int index = INDEX;
/* 831 */         for (Enum<?> constant : enumConstants) {
/* 832 */           int id = constant.ordinal();
/* 833 */           Server value = valueOf(constant.name());
/* 834 */           value.ids[index] = id;
/* 835 */           Map<Integer, PacketTypeCommon> packetIdMap = PACKET_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/* 836 */           packetIdMap.put(Integer.valueOf(id), value);
/*     */         } 
/* 838 */         INDEX++;
/*     */       }
/*     */       
/*     */       public static void load() {
/* 842 */         INDEX = 0;
/* 843 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_7_10.values());
/* 844 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_8.values());
/* 845 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_9.values());
/* 846 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_9_3.values());
/* 847 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_12.values());
/* 848 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_12_1.values());
/* 849 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_13.values());
/* 850 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_14.values());
/* 851 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_14_4.values());
/* 852 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_15.values());
/* 853 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_15_2.values());
/* 854 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_16.values());
/* 855 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_16_2.values());
/* 856 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_17.values());
/* 857 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_18.values());
/* 858 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_19.values());
/* 859 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_19_1.values());
/* 860 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_19_3.values());
/* 861 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_19_4.values());
/* 862 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_20_2.values());
/* 863 */         loadPacketIds((Enum<?>[])ClientboundPacketType_1_20_3.values());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Client implements PacketTypeCommon, ServerBoundPacket {
/*     */     CHAT_PREVIEW, TELEPORT_CONFIRM, QUERY_BLOCK_NBT, SET_DIFFICULTY, CHAT_MESSAGE, CLIENT_STATUS, CLIENT_SETTINGS, TAB_COMPLETE, WINDOW_CONFIRMATION, CLICK_WINDOW_BUTTON, CLICK_WINDOW, CLOSE_WINDOW, PLUGIN_MESSAGE, EDIT_BOOK, QUERY_ENTITY_NBT, INTERACT_ENTITY, GENERATE_STRUCTURE, KEEP_ALIVE, LOCK_DIFFICULTY, PLAYER_POSITION, PLAYER_POSITION_AND_ROTATION, PLAYER_ROTATION, PLAYER_FLYING, VEHICLE_MOVE, STEER_BOAT, PICK_ITEM, CRAFT_RECIPE_REQUEST, PLAYER_ABILITIES, PLAYER_DIGGING, ENTITY_ACTION, STEER_VEHICLE, PONG, RECIPE_BOOK_DATA, SET_DISPLAYED_RECIPE, SET_RECIPE_BOOK_STATE, NAME_ITEM, RESOURCE_PACK_STATUS, ADVANCEMENT_TAB, SELECT_TRADE, SET_BEACON_EFFECT, HELD_ITEM_CHANGE, UPDATE_COMMAND_BLOCK, UPDATE_COMMAND_BLOCK_MINECART, CREATIVE_INVENTORY_ACTION, UPDATE_JIGSAW_BLOCK, UPDATE_STRUCTURE_BLOCK, UPDATE_SIGN, ANIMATION, SPECTATE, PLAYER_BLOCK_PLACEMENT, USE_ITEM, CHAT_COMMAND, CHAT_ACK, CHAT_SESSION_UPDATE, CHUNK_BATCH_ACK, CONFIGURATION_ACK, DEBUG_PING, SLOT_STATE_CHANGE;
/*     */     
/*     */     private static int INDEX = 0;
/*     */     
/*     */     private static final Map<Byte, Map<Integer, PacketTypeCommon>> PACKET_TYPE_ID_MAP = new HashMap<>();
/*     */     
/*     */     private final int[] ids;
/*     */     
/*     */     static {
/*     */     
/*     */     }
/*     */     
/*     */     Client() {
/*     */       this.ids = new int[(PacketType.SERVERBOUND_PLAY_VERSION_MAPPER.getVersions()).length];
/*     */       Arrays.fill(this.ids, -1);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(ClientVersion version, int packetId) {
/*     */       if (!PacketType.PREPARED)
/*     */         PacketType.prepare(); 
/*     */       int index = PacketType.SERVERBOUND_PLAY_VERSION_MAPPER.getIndex(version);
/*     */       Map<Integer, PacketTypeCommon> packetIdMap = PACKET_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/*     */       return packetIdMap.get(Integer.valueOf(packetId));
/*     */     }
/*     */     
/*     */     private static void loadPacketIds(Enum<?>[] enumConstants) {
/*     */       int index = INDEX;
/*     */       for (Enum<?> constant : enumConstants) {
/*     */         int id = constant.ordinal();
/*     */         Client value = valueOf(constant.name());
/*     */         value.ids[index] = id;
/*     */         Map<Integer, PacketTypeCommon> packetIdMap = PACKET_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/*     */         packetIdMap.put(Integer.valueOf(id), value);
/*     */       } 
/*     */       INDEX++;
/*     */     }
/*     */     
/*     */     public static void load() {
/*     */       INDEX = 0;
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_7_10.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_8.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_9.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_12.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_12_1.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_13.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_14.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_15_2.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_16.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_16_2.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_17.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_19.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_19_1.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_19_3.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_19_4.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_20_2.values());
/*     */       loadPacketIds((Enum<?>[])ServerboundPacketType_1_20_3.values());
/*     */     }
/*     */     
/*     */     public int getId(ClientVersion version) {
/*     */       if (!PacketType.PREPARED)
/*     */         PacketType.prepare(); 
/*     */       int index = PacketType.SERVERBOUND_PLAY_VERSION_MAPPER.getIndex(version);
/*     */       return this.ids[index];
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/*     */       return PacketSide.CLIENT;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum Server implements PacketTypeCommon, ClientBoundPacket {
/*     */     SET_COMPRESSION, MAP_CHUNK_BULK, UPDATE_ENTITY_NBT, UPDATE_SIGN, USE_BED, SPAWN_WEATHER_ENTITY, TITLE, WORLD_BORDER, COMBAT_EVENT, ENTITY_MOVEMENT, SPAWN_LIVING_ENTITY, SPAWN_PAINTING, SCULK_VIBRATION_SIGNAL, ACKNOWLEDGE_PLAYER_DIGGING, CHAT_PREVIEW_PACKET, NAMED_SOUND_EFFECT, PLAYER_CHAT_HEADER, PLAYER_INFO, DISPLAY_CHAT_PREVIEW, UPDATE_ENABLED_FEATURES, SPAWN_PLAYER, WINDOW_CONFIRMATION, SPAWN_ENTITY, SPAWN_EXPERIENCE_ORB, ENTITY_ANIMATION, STATISTICS, BLOCK_BREAK_ANIMATION, BLOCK_ENTITY_DATA, BLOCK_ACTION, BLOCK_CHANGE, BOSS_BAR, SERVER_DIFFICULTY, CLEAR_TITLES, TAB_COMPLETE, MULTI_BLOCK_CHANGE, DECLARE_COMMANDS, CLOSE_WINDOW, WINDOW_ITEMS, WINDOW_PROPERTY, SET_SLOT, SET_COOLDOWN, PLUGIN_MESSAGE, DISCONNECT, ENTITY_STATUS, EXPLOSION, UNLOAD_CHUNK, CHANGE_GAME_STATE, OPEN_HORSE_WINDOW, INITIALIZE_WORLD_BORDER, KEEP_ALIVE, CHUNK_DATA, EFFECT, PARTICLE, UPDATE_LIGHT, JOIN_GAME, MAP_DATA, MERCHANT_OFFERS, ENTITY_RELATIVE_MOVE, ENTITY_RELATIVE_MOVE_AND_ROTATION, ENTITY_ROTATION, VEHICLE_MOVE, OPEN_BOOK, OPEN_WINDOW, OPEN_SIGN_EDITOR, PING, CRAFT_RECIPE_RESPONSE, PLAYER_ABILITIES, END_COMBAT_EVENT, ENTER_COMBAT_EVENT, DEATH_COMBAT_EVENT, FACE_PLAYER, PLAYER_POSITION_AND_LOOK, UNLOCK_RECIPES, DESTROY_ENTITIES, REMOVE_ENTITY_EFFECT, RESOURCE_PACK_SEND, RESPAWN, ENTITY_HEAD_LOOK, SELECT_ADVANCEMENTS_TAB, ACTION_BAR, WORLD_BORDER_CENTER, WORLD_BORDER_LERP_SIZE, WORLD_BORDER_SIZE, WORLD_BORDER_WARNING_DELAY, WORLD_BORDER_WARNING_REACH, CAMERA, HELD_ITEM_CHANGE, UPDATE_VIEW_POSITION, UPDATE_VIEW_DISTANCE, SPAWN_POSITION, DISPLAY_SCOREBOARD, ENTITY_METADATA, ATTACH_ENTITY, ENTITY_VELOCITY, ENTITY_EQUIPMENT, SET_EXPERIENCE, UPDATE_HEALTH, SCOREBOARD_OBJECTIVE, SET_PASSENGERS, TEAMS, UPDATE_SCORE, UPDATE_SIMULATION_DISTANCE, SET_TITLE_SUBTITLE, TIME_UPDATE, SET_TITLE_TEXT, SET_TITLE_TIMES, ENTITY_SOUND_EFFECT, SOUND_EFFECT, STOP_SOUND, PLAYER_LIST_HEADER_AND_FOOTER, NBT_QUERY_RESPONSE, COLLECT_ITEM, ENTITY_TELEPORT, UPDATE_ADVANCEMENTS, UPDATE_ATTRIBUTES, ENTITY_EFFECT, DECLARE_RECIPES, TAGS, CHAT_MESSAGE, ACKNOWLEDGE_BLOCK_CHANGES, SERVER_DATA, SYSTEM_CHAT_MESSAGE, DELETE_CHAT, CUSTOM_CHAT_COMPLETIONS, DISGUISED_CHAT, PLAYER_INFO_REMOVE, PLAYER_INFO_UPDATE, DAMAGE_EVENT, HURT_ANIMATION, BUNDLE, CHUNK_BIOMES, CHUNK_BATCH_END, CHUNK_BATCH_BEGIN, DEBUG_PONG, CONFIGURATION_START, RESET_SCORE, RESOURCE_PACK_REMOVE, TICKING_STATE, TICKING_STEP;
/*     */     
/*     */     private static int INDEX = 0;
/*     */     
/*     */     private static final Map<Byte, Map<Integer, PacketTypeCommon>> PACKET_TYPE_ID_MAP = new HashMap<>();
/*     */     
/*     */     private final int[] ids;
/*     */     
/*     */     static {
/*     */     
/*     */     }
/*     */     
/*     */     Server() {
/*     */       this.ids = new int[(PacketType.CLIENTBOUND_PLAY_VERSION_MAPPER.getVersions()).length];
/*     */       Arrays.fill(this.ids, -1);
/*     */     }
/*     */     
/*     */     public int getId(ClientVersion version) {
/*     */       if (!PacketType.PREPARED)
/*     */         PacketType.prepare(); 
/*     */       int index = PacketType.CLIENTBOUND_PLAY_VERSION_MAPPER.getIndex(version);
/*     */       return this.ids[index];
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PacketTypeCommon getById(ClientVersion version, int packetId) {
/*     */       if (!PacketType.PREPARED)
/*     */         PacketType.prepare(); 
/*     */       int index = PacketType.CLIENTBOUND_PLAY_VERSION_MAPPER.getIndex(version);
/*     */       Map<Integer, PacketTypeCommon> map = PACKET_TYPE_ID_MAP.get(Byte.valueOf((byte)index));
/*     */       return map.get(Integer.valueOf(packetId));
/*     */     }
/*     */     
/*     */     public PacketSide getSide() {
/*     */       return PacketSide.SERVER;
/*     */     }
/*     */     
/*     */     private static void loadPacketIds(Enum<?>[] enumConstants) {
/*     */       int index = INDEX;
/*     */       for (Enum<?> constant : enumConstants) {
/*     */         int id = constant.ordinal();
/*     */         Server value = valueOf(constant.name());
/*     */         value.ids[index] = id;
/*     */         Map<Integer, PacketTypeCommon> packetIdMap = PACKET_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/*     */         packetIdMap.put(Integer.valueOf(id), value);
/*     */       } 
/*     */       INDEX++;
/*     */     }
/*     */     
/*     */     public static void load() {
/*     */       INDEX = 0;
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_7_10.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_8.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_9.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_9_3.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_12.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_12_1.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_13.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_14.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_14_4.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_15.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_15_2.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_16.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_16_2.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_17.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_18.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_19.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_19_1.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_19_3.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_19_4.values());
/*     */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_20_2.values());
/* 863 */       loadPacketIds((Enum<?>[])ClientboundPacketType_1_20_3.values());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\packettype\PacketType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */