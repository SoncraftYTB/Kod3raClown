/*    */ package com.github.retrooper.packetevents.protocol.nbt;
/*    */ 
/*    */ public class NBTByte extends NBTNumber {
/*    */   protected final byte value;
/*    */   
/*    */   public NBTByte(byte value) {
/* 26 */     this.value = value;
/*    */   }
/*    */   
/*    */   public NBTByte(boolean value) {
/* 30 */     this((byte)(value ? 1 : 0));
/*    */   }
/*    */   
/*    */   public NBTType<NBTByte> getType() {
/* 35 */     return NBTType.BYTE;
/*    */   }
/*    */   
/*    */   public Number getAsNumber() {
/* 40 */     return Byte.valueOf(this.value);
/*    */   }
/*    */   
/*    */   public byte getAsByte() {
/* 45 */     return this.value;
/*    */   }
/*    */   
/*    */   public short getAsShort() {
/* 50 */     return (short)this.value;
/*    */   }
/*    */   
/*    */   public int getAsInt() {
/* 55 */     return this.value;
/*    */   }
/*    */   
/*    */   public long getAsLong() {
/* 60 */     return this.value;
/*    */   }
/*    */   
/*    */   public float getAsFloat() {
/* 65 */     return this.value;
/*    */   }
/*    */   
/*    */   public double getAsDouble() {
/* 70 */     return this.value;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 75 */     return Byte.hashCode(this.value);
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 80 */     if (this == obj)
/* 81 */       return true; 
/* 83 */     if (obj == null)
/* 84 */       return false; 
/* 86 */     if (getClass() != obj.getClass())
/* 87 */       return false; 
/* 89 */     NBTByte other = (NBTByte)obj;
/* 90 */     return (this.value == other.value);
/*    */   }
/*    */   
/*    */   public NBTByte copy() {
/* 95 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\nbt\NBTByte.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */