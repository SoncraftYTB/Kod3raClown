package com.github.retrooper.packetevents.protocol.nbt;

public abstract class NBTNumber extends NBT {
  public abstract Number getAsNumber();
  
  public abstract byte getAsByte();
  
  public abstract short getAsShort();
  
  public abstract int getAsInt();
  
  public abstract long getAsLong();
  
  public abstract float getAsFloat();
  
  public abstract double getAsDouble();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\nbt\NBTNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */