/*     */ package com.github.retrooper.packetevents.protocol.nbt;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ public class NBTList<T extends NBT> extends NBT {
/*     */   protected final NBTType<T> type;
/*     */   
/*  30 */   protected final List<T> tags = new ArrayList<>();
/*     */   
/*     */   public NBTList(NBTType<T> type) {
/*  33 */     this.type = type;
/*     */   }
/*     */   
/*     */   public NBTList(NBTType<T> type, List<T> tags) {
/*  37 */     this.type = type;
/*  38 */     this.tags.addAll(tags);
/*     */   }
/*     */   
/*     */   public static NBTList<NBTCompound> createCompoundList() {
/*  42 */     return new NBTList<>(NBTType.COMPOUND);
/*     */   }
/*     */   
/*     */   public static NBTList<NBTString> createStringList() {
/*  46 */     return new NBTList<>(NBTType.STRING);
/*     */   }
/*     */   
/*     */   public NBTType<NBTList> getType() {
/*  52 */     return NBTType.LIST;
/*     */   }
/*     */   
/*     */   public NBTType<T> getTagsType() {
/*  56 */     return this.type;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  60 */     return this.tags.isEmpty();
/*     */   }
/*     */   
/*     */   public int size() {
/*  64 */     return this.tags.size();
/*     */   }
/*     */   
/*     */   public List<T> getTags() {
/*  68 */     return Collections.unmodifiableList(this.tags);
/*     */   }
/*     */   
/*     */   public T getTag(int index) {
/*  72 */     return this.tags.get(index);
/*     */   }
/*     */   
/*     */   public void setTag(int index, T tag) {
/*  76 */     validateAddTag(tag);
/*  77 */     this.tags.set(index, tag);
/*     */   }
/*     */   
/*     */   public void addTag(int index, T tag) {
/*  81 */     validateAddTag(tag);
/*  82 */     this.tags.add(index, tag);
/*     */   }
/*     */   
/*     */   public void addTag(T tag) {
/*  86 */     validateAddTag(tag);
/*  87 */     this.tags.add(tag);
/*     */   }
/*     */   
/*     */   public void addTagUnsafe(NBT nbt) {
/*  91 */     addTag((T)nbt);
/*     */   }
/*     */   
/*     */   protected void validateAddTag(T tag) {
/*  95 */     if (this.type != tag.getType())
/*  96 */       throw new IllegalArgumentException(MessageFormat.format("Invalid tag type. Expected {0}, got {1}.", new Object[] { this.type.getNBTClass(), tag.getClass() })); 
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 103 */     if (this == obj)
/* 104 */       return true; 
/* 106 */     if (obj == null)
/* 107 */       return false; 
/* 109 */     if (getClass() != obj.getClass())
/* 110 */       return false; 
/* 112 */     NBTList<T> other = (NBTList<T>)obj;
/* 113 */     return (Objects.equals(this.type, other.type) && Objects.equals(this.tags, other.tags));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 118 */     return Objects.hash(new Object[] { this.type, this.tags });
/*     */   }
/*     */   
/*     */   public NBTList<T> copy() {
/* 123 */     List<T> newTags = new ArrayList<>();
/* 124 */     for (NBT nBT : this.tags)
/* 125 */       newTags.add((T)nBT.copy()); 
/* 127 */     return new NBTList(this.type, newTags);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\nbt\NBTList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */