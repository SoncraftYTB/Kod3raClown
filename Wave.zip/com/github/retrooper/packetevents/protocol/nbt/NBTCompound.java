/*     */ package com.github.retrooper.packetevents.protocol.nbt;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class NBTCompound extends NBT {
/*  29 */   protected final Map<String, NBT> tags = new LinkedHashMap<>();
/*     */   
/*     */   public NBTType<NBTCompound> getType() {
/*  33 */     return NBTType.COMPOUND;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  37 */     return this.tags.isEmpty();
/*     */   }
/*     */   
/*     */   public Set<String> getTagNames() {
/*  41 */     return Collections.unmodifiableSet(this.tags.keySet());
/*     */   }
/*     */   
/*     */   public Map<String, NBT> getTags() {
/*  45 */     return Collections.unmodifiableMap(this.tags);
/*     */   }
/*     */   
/*     */   public NBT getTagOrThrow(String key) {
/*  49 */     NBT tag = getTagOrNull(key);
/*  50 */     if (tag == null)
/*  51 */       throw new IllegalStateException(MessageFormat.format("NBT {0} does not exist", new Object[] { key })); 
/*  53 */     return tag;
/*     */   }
/*     */   
/*     */   public NBT getTagOrNull(String key) {
/*  57 */     return this.tags.get(key);
/*     */   }
/*     */   
/*     */   public <T extends NBT> T getTagOfTypeOrThrow(String key, Class<T> type) {
/*  62 */     NBT tag = getTagOrThrow(key);
/*  63 */     if (type.isInstance(tag))
/*  64 */       return (T)tag; 
/*  66 */     throw new IllegalStateException(MessageFormat.format("NBT {0} has unexpected type, expected {1}, but got {2}", new Object[] { key, type, tag.getClass() }));
/*     */   }
/*     */   
/*     */   public <T extends NBT> T getTagOfTypeOrNull(String key, Class<T> type) {
/*  72 */     NBT tag = getTagOrNull(key);
/*  73 */     if (type.isInstance(tag))
/*  74 */       return (T)tag; 
/*  76 */     return null;
/*     */   }
/*     */   
/*     */   public <T extends NBT> NBTList<T> getTagListOfTypeOrThrow(String key, Class<T> type) {
/*  81 */     NBTList<? extends NBT> list = getTagOfTypeOrThrow(key, (Class)NBTList.class);
/*  82 */     if (!type.isAssignableFrom(list.getTagsType().getNBTClass()))
/*  83 */       throw new IllegalStateException(MessageFormat.format("NBTList {0} tags type has unexpected type, expected {1}, but got {2}", new Object[] { key, type, list.getTagsType().getNBTClass() })); 
/*  85 */     return (NBTList)list;
/*     */   }
/*     */   
/*     */   public <T extends NBT> NBTList<T> getTagListOfTypeOrNull(String key, Class<T> type) {
/*  90 */     NBTList<? extends NBT> list = getTagOfTypeOrNull(key, (Class)NBTList.class);
/*  91 */     if (list != null && type.isAssignableFrom(list.getTagsType().getNBTClass()))
/*  92 */       return (NBTList)list; 
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public NBTCompound getCompoundTagOrThrow(String key) {
/*  98 */     return getTagOfTypeOrThrow(key, NBTCompound.class);
/*     */   }
/*     */   
/*     */   public NBTCompound getCompoundTagOrNull(String key) {
/* 102 */     return getTagOfTypeOrNull(key, NBTCompound.class);
/*     */   }
/*     */   
/*     */   public NBTNumber getNumberTagOrThrow(String key) {
/* 106 */     return getTagOfTypeOrThrow(key, NBTNumber.class);
/*     */   }
/*     */   
/*     */   public NBTNumber getNumberTagOrNull(String key) {
/* 110 */     return getTagOfTypeOrNull(key, NBTNumber.class);
/*     */   }
/*     */   
/*     */   public NBTString getStringTagOrThrow(String key) {
/* 114 */     return getTagOfTypeOrThrow(key, NBTString.class);
/*     */   }
/*     */   
/*     */   public NBTString getStringTagOrNull(String key) {
/* 118 */     return getTagOfTypeOrNull(key, NBTString.class);
/*     */   }
/*     */   
/*     */   public NBTList<NBTCompound> getCompoundListTagOrThrow(String key) {
/* 122 */     return getTagListOfTypeOrThrow(key, NBTCompound.class);
/*     */   }
/*     */   
/*     */   public NBTList<NBTCompound> getCompoundListTagOrNull(String key) {
/* 126 */     return getTagListOfTypeOrNull(key, NBTCompound.class);
/*     */   }
/*     */   
/*     */   public NBTList<NBTNumber> getNumberTagListTagOrThrow(String key) {
/* 130 */     return getTagListOfTypeOrThrow(key, NBTNumber.class);
/*     */   }
/*     */   
/*     */   public NBTList<NBTNumber> getNumberListTagOrNull(String key) {
/* 134 */     return getTagListOfTypeOrNull(key, NBTNumber.class);
/*     */   }
/*     */   
/*     */   public NBTList<NBTString> getStringListTagOrThrow(String key) {
/* 138 */     return getTagListOfTypeOrThrow(key, NBTString.class);
/*     */   }
/*     */   
/*     */   public NBTList<NBTString> getStringListTagOrNull(String key) {
/* 142 */     return getTagListOfTypeOrNull(key, NBTString.class);
/*     */   }
/*     */   
/*     */   public String getStringTagValueOrThrow(String key) {
/* 146 */     return getStringTagOrThrow(key).getValue();
/*     */   }
/*     */   
/*     */   public String getStringTagValueOrNull(String key) {
/* 150 */     NBT tag = getTagOrNull(key);
/* 151 */     if (tag instanceof NBTString)
/* 152 */       return ((NBTString)tag).getValue(); 
/* 154 */     return null;
/*     */   }
/*     */   
/*     */   public String getStringTagValueOrDefault(String key, String defaultValue) {
/* 158 */     NBT tag = getTagOrNull(key);
/* 159 */     if (tag instanceof NBTString)
/* 160 */       return ((NBTString)tag).getValue(); 
/* 162 */     return defaultValue;
/*     */   }
/*     */   
/*     */   public NBT removeTag(String key) {
/* 166 */     return this.tags.remove(key);
/*     */   }
/*     */   
/*     */   public <T extends NBT> T removeTagAndReturnIfType(String key, Class<T> type) {
/* 171 */     NBT tag = removeTag(key);
/* 172 */     if (type.isInstance(tag))
/* 173 */       return (T)tag; 
/* 175 */     return null;
/*     */   }
/*     */   
/*     */   public <T extends NBT> NBTList<T> removeTagAndReturnIfListType(String key, Class<T> type) {
/* 180 */     NBTList<?> list = removeTagAndReturnIfType(key, NBTList.class);
/* 181 */     if (list != null && type.isAssignableFrom(list.getTagsType().getNBTClass()))
/* 182 */       return (NBTList)list; 
/* 184 */     return null;
/*     */   }
/*     */   
/*     */   public void setTag(String key, NBT tag) {
/* 188 */     if (tag != null) {
/* 189 */       this.tags.put(key, tag);
/*     */     } else {
/* 191 */       this.tags.remove(key);
/*     */     } 
/*     */   }
/*     */   
/*     */   public NBTCompound copy() {
/* 196 */     NBTCompound clone = new NBTCompound();
/* 197 */     for (Map.Entry<String, NBT> entry : this.tags.entrySet())
/* 198 */       clone.setTag(entry.getKey(), ((NBT)entry.getValue()).copy()); 
/* 200 */     return clone;
/*     */   }
/*     */   
/*     */   public boolean getBoolean(String string) {
/* 204 */     NBTByte nbtByte = getTagOfTypeOrNull(string, NBTByte.class);
/* 206 */     return (nbtByte != null && nbtByte.getAsByte() != 0);
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 211 */     if (other instanceof NBTCompound) {
/* 212 */       if (isEmpty() && ((NBTCompound)other).isEmpty())
/* 213 */         return true; 
/* 215 */       return this.tags.equals(((NBTCompound)other).tags);
/*     */     } 
/* 217 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 222 */     return this.tags.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\nbt\NBTCompound.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */