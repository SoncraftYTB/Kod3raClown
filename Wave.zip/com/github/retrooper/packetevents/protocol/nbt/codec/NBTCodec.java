/*     */ package com.github.retrooper.packetevents.protocol.nbt.codec;
/*     */ 
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*     */ import com.github.retrooper.packetevents.netty.buffer.ByteBufInputStream;
/*     */ import com.github.retrooper.packetevents.netty.buffer.ByteBufOutputStream;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBT;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTByte;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTDouble;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTEnd;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTFloat;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTInt;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTList;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTLong;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTNumber;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTShort;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTString;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTType;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.serializer.DefaultNBTSerializer;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ 
/*     */ public class NBTCodec {
/*     */   public static NBT jsonToNBT(JsonElement element) {
/*  44 */     if (element instanceof JsonPrimitive) {
/*  45 */       if (((JsonPrimitive)element).isBoolean())
/*  46 */         return (NBT)new NBTByte(element.getAsBoolean()); 
/*  48 */       if (((JsonPrimitive)element).isString())
/*  49 */         return (NBT)new NBTString(element.getAsString()); 
/*  51 */       if (((JsonPrimitive)element).isNumber()) {
/*  52 */         Number num = element.getAsNumber();
/*  53 */         if (num instanceof Float)
/*  54 */           return (NBT)new NBTFloat(num.floatValue()); 
/*  56 */         if (num instanceof Double)
/*  57 */           return (NBT)new NBTDouble(num.doubleValue()); 
/*  59 */         if (num instanceof Byte)
/*  60 */           return (NBT)new NBTByte(num.byteValue()); 
/*  62 */         if (num instanceof Short)
/*  63 */           return (NBT)new NBTShort(num.shortValue()); 
/*  65 */         if (num instanceof Integer || num instanceof com.google.gson.internal.LazilyParsedNumber)
/*  66 */           return (NBT)new NBTInt(num.intValue()); 
/*  68 */         if (num instanceof Long)
/*  69 */           return (NBT)new NBTLong(num.longValue()); 
/*     */       } 
/*     */     } else {
/*  74 */       if (element instanceof JsonArray) {
/*  75 */         List<NBT> list = new ArrayList<>();
/*  76 */         for (JsonElement var : element)
/*  77 */           list.add(jsonToNBT(var)); 
/*  79 */         if (list.isEmpty())
/*  80 */           return (NBT)new NBTList(NBTType.COMPOUND); 
/*  82 */         NBTList<? extends NBT> l = new NBTList(((NBT)list.get(0)).getType());
/*  83 */         for (NBT nbt : list)
/*  84 */           l.addTagUnsafe(nbt); 
/*  86 */         return (NBT)l;
/*     */       } 
/*  89 */       if (element instanceof JsonObject) {
/*  90 */         JsonObject obj = (JsonObject)element;
/*  91 */         NBTCompound compound = new NBTCompound();
/*  92 */         for (Map.Entry<String, JsonElement> jsonEntry : (Iterable<Map.Entry<String, JsonElement>>)obj.entrySet())
/*  93 */           compound.setTag(jsonEntry.getKey(), jsonToNBT(jsonEntry.getValue())); 
/*  95 */         return (NBT)compound;
/*     */       } 
/*  97 */       if (element instanceof com.google.gson.JsonNull || element == null)
/*  98 */         return (NBT)new NBTCompound(); 
/*     */     } 
/* 100 */     throw new IllegalStateException("Failed to convert JSON to NBT " + element.toString());
/*     */   }
/*     */   
/*     */   public static JsonElement nbtToJson(NBT nbt, boolean parseByteAsBool) {
/* 107 */     if (nbt instanceof NBTNumber) {
/* 108 */       if (nbt instanceof NBTByte && parseByteAsBool) {
/* 109 */         byte val = ((NBTByte)nbt).getAsByte();
/* 110 */         if (val == 0)
/* 111 */           return (JsonElement)new JsonPrimitive(Boolean.valueOf(false)); 
/* 113 */         if (val == 1)
/* 114 */           return (JsonElement)new JsonPrimitive(Boolean.valueOf(true)); 
/*     */       } 
/* 117 */       return (JsonElement)new JsonPrimitive(((NBTNumber)nbt).getAsNumber());
/*     */     } 
/* 119 */     if (nbt instanceof NBTString)
/* 120 */       return (JsonElement)new JsonPrimitive(((NBTString)nbt).getValue()); 
/* 122 */     if (nbt instanceof NBTList) {
/* 123 */       NBTList<? extends NBT> list = (NBTList<? extends NBT>)nbt;
/* 124 */       JsonArray jsonArray = new JsonArray();
/* 126 */       list.getTags().forEach(tag -> jsonArray.add(nbtToJson(tag, parseByteAsBool)));
/* 129 */       return (JsonElement)jsonArray;
/*     */     } 
/* 131 */     if (nbt instanceof NBTEnd)
/* 132 */       throw new IllegalStateException("Encountered the NBTEnd tag during the NBT to JSON conversion: " + nbt.toString()); 
/* 134 */     if (nbt instanceof NBTCompound) {
/* 135 */       JsonObject jsonObject = new JsonObject();
/* 136 */       Map<String, NBT> compoundTags = ((NBTCompound)nbt).getTags();
/* 137 */       for (String tagName : compoundTags.keySet()) {
/* 138 */         NBT tag = compoundTags.get(tagName);
/* 139 */         JsonElement jsonValue = nbtToJson(tag, parseByteAsBool);
/* 140 */         jsonObject.add(tagName, jsonValue);
/*     */       } 
/* 142 */       return (JsonElement)jsonObject;
/*     */     } 
/* 145 */     throw new IllegalStateException("Failed to convert NBT to JSON.");
/*     */   }
/*     */   
/*     */   public static NBTCompound readNBTFromBuffer(Object byteBuf, ServerVersion serverVersion) {
/* 151 */     return (NBTCompound)readRawNBTFromBuffer(byteBuf, serverVersion);
/*     */   }
/*     */   
/*     */   public static NBT readRawNBTFromBuffer(Object byteBuf, ServerVersion serverVersion) {
/* 155 */     if (serverVersion.isNewerThanOrEquals(ServerVersion.V_1_8))
/*     */       try {
/* 157 */         boolean named = serverVersion.isOlderThan(ServerVersion.V_1_20_2);
/* 158 */         return DefaultNBTSerializer.INSTANCE.deserializeTag(new ByteBufInputStream(byteBuf), named);
/* 160 */       } catch (IOException e) {
/* 161 */         e.printStackTrace();
/* 180 */         return null;
/*     */       }  
/*     */     try {
/*     */       short length = ByteBufHelper.readShort(byteBuf);
/*     */       if (length < 0)
/*     */         return null; 
/*     */       Object slicedBuffer = ByteBufHelper.readSlice(byteBuf, length);
/*     */       DataInputStream stream = new DataInputStream(new GZIPInputStream((InputStream)new ByteBufInputStream(slicedBuffer)));
/*     */       try {
/*     */         NBT nBT = DefaultNBTSerializer.INSTANCE.deserializeTag(stream);
/*     */         stream.close();
/*     */         return nBT;
/*     */       } catch (Throwable throwable) {
/*     */         try {
/*     */           stream.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */         throw throwable;
/*     */       } 
/*     */     } catch (IOException ex) {
/*     */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void writeNBTToBuffer(Object byteBuf, ServerVersion serverVersion, NBTCompound tag) {
/* 184 */     writeNBTToBuffer(byteBuf, serverVersion, (NBT)tag);
/*     */   }
/*     */   
/*     */   public static void writeNBTToBuffer(Object byteBuf, ServerVersion serverVersion, NBT tag) {
/* 188 */     if (serverVersion.isNewerThanOrEquals(ServerVersion.V_1_8)) {
/*     */       try {
/* 189 */         ByteBufOutputStream outputStream = new ByteBufOutputStream(byteBuf);
/*     */         try {
/* 190 */           if (tag != null) {
/* 191 */             boolean named = serverVersion.isOlderThan(ServerVersion.V_1_20_2);
/* 192 */             DefaultNBTSerializer.INSTANCE.serializeTag(outputStream, tag, named);
/*     */           } else {
/* 194 */             DefaultNBTSerializer.INSTANCE.serializeTag(outputStream, (NBT)NBTEnd.INSTANCE);
/*     */           } 
/* 196 */           outputStream.close();
/*     */         } catch (Throwable throwable) {
/*     */           try {
/*     */             outputStream.close();
/*     */           } catch (Throwable throwable1) {
/*     */             throwable.addSuppressed(throwable1);
/*     */           } 
/*     */           throw throwable;
/*     */         } 
/* 196 */       } catch (IOException e) {
/* 197 */         throw new IllegalStateException(e);
/*     */       } 
/* 201 */     } else if (tag == null) {
/* 202 */       ByteBufHelper.writeShort(byteBuf, -1);
/*     */     } else {
/* 204 */       int lengthWriterIndex = ByteBufHelper.writerIndex(byteBuf);
/* 205 */       ByteBufHelper.writeShort(byteBuf, 0);
/* 206 */       int writerIndexDataStart = ByteBufHelper.writerIndex(byteBuf);
/*     */       try {
/* 207 */         DataOutputStream outputstream = new DataOutputStream(new GZIPOutputStream((OutputStream)new ByteBufOutputStream(byteBuf)));
/*     */         try {
/* 208 */           DefaultNBTSerializer.INSTANCE.serializeTag(outputstream, tag);
/* 209 */           outputstream.close();
/*     */         } catch (Throwable throwable) {
/*     */           try {
/*     */             outputstream.close();
/*     */           } catch (Throwable throwable1) {
/*     */             throwable.addSuppressed(throwable1);
/*     */           } 
/*     */           throw throwable;
/*     */         } 
/* 209 */       } catch (Exception e) {
/* 210 */         throw new IllegalStateException(e);
/*     */       } 
/* 212 */       int writerIndexDataEnd = ByteBufHelper.writerIndex(byteBuf);
/* 213 */       ByteBufHelper.writerIndex(byteBuf, lengthWriterIndex);
/* 214 */       ByteBufHelper.writeShort(byteBuf, writerIndexDataEnd - writerIndexDataStart);
/* 215 */       ByteBufHelper.writerIndex(byteBuf, writerIndexDataEnd);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\nbt\codec\NBTCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */