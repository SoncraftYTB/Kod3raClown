/*     */ package com.github.retrooper.packetevents.protocol.nbt.serializer;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBT;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTType;
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class NBTSerializer<IN, OUT> {
/*     */   protected final IdReader<IN> idReader;
/*     */   
/*     */   protected final IdWriter<OUT> idWriter;
/*     */   
/*     */   protected final NameReader<IN> nameReader;
/*     */   
/*     */   protected final NameWriter<OUT> nameWriter;
/*     */   
/*  35 */   protected final Map<Integer, NBTType<? extends NBT>> idToType = new HashMap<>();
/*     */   
/*  36 */   protected final Map<NBTType<? extends NBT>, Integer> typeToId = new HashMap<>();
/*     */   
/*  37 */   protected final Map<NBTType<? extends NBT>, TagReader<IN, ? extends NBT>> typeReaders = new HashMap<>();
/*     */   
/*  38 */   protected final Map<NBTType<? extends NBT>, TagWriter<OUT, ? extends NBT>> typeWriters = new HashMap<>();
/*     */   
/*     */   public NBTSerializer(IdReader<IN> idReader, IdWriter<OUT> idWriter, NameReader<IN> nameReader, NameWriter<OUT> nameWriter) {
/*  43 */     this.idReader = idReader;
/*  44 */     this.idWriter = idWriter;
/*  45 */     this.nameReader = nameReader;
/*  46 */     this.nameWriter = nameWriter;
/*     */   }
/*     */   
/*     */   public NBT deserializeTag(IN from) throws IOException {
/*  50 */     return deserializeTag(from, true);
/*     */   }
/*     */   
/*     */   public NBT deserializeTag(IN from, boolean named) throws IOException {
/*  54 */     NBTType<?> type = readTagType(from);
/*  55 */     if (type == NBTType.END)
/*  56 */       return null; 
/*  58 */     if (named)
/*  59 */       readTagName(from); 
/*  61 */     return readTag(from, type);
/*     */   }
/*     */   
/*     */   public void serializeTag(OUT to, NBT tag) throws IOException {
/*  65 */     serializeTag(to, tag, true);
/*     */   }
/*     */   
/*     */   public void serializeTag(OUT to, NBT tag, boolean named) throws IOException {
/*  69 */     NBTType<?> type = tag.getType();
/*  70 */     writeTagType(to, type);
/*  71 */     if (tag.getType() == NBTType.END)
/*     */       return; 
/*  74 */     if (named)
/*  75 */       writeTagName(to, ""); 
/*  77 */     writeTag(to, tag);
/*     */   }
/*     */   
/*     */   protected <T extends NBT> void registerType(NBTType<T> type, int id, TagReader<IN, T> typeReader, TagWriter<OUT, T> typeWriter) {
/*  85 */     if (this.typeToId.containsKey(type))
/*  86 */       throw new IllegalArgumentException(MessageFormat.format("Nbt type {0} is already registered", new Object[] { type })); 
/*  88 */     if (this.idToType.containsKey(Integer.valueOf(id)))
/*  89 */       throw new IllegalArgumentException(MessageFormat.format("Nbt type id {0} is already registered", new Object[] { Integer.valueOf(id) })); 
/*  91 */     this.idToType.put(Integer.valueOf(id), type);
/*  92 */     this.typeToId.put(type, Integer.valueOf(id));
/*  93 */     this.typeReaders.put(type, typeReader);
/*  94 */     this.typeWriters.put(type, typeWriter);
/*     */   }
/*     */   
/*     */   protected NBTType<?> readTagType(IN from) throws IOException {
/*  98 */     int id = this.idReader.readId(from);
/*  99 */     NBTType<?> type = this.idToType.get(Integer.valueOf(id));
/* 100 */     if (type == null)
/* 101 */       throw new IOException(MessageFormat.format("Unknown nbt type id {0}", new Object[] { Integer.valueOf(id) })); 
/* 103 */     return type;
/*     */   }
/*     */   
/*     */   protected String readTagName(IN from) throws IOException {
/* 107 */     return this.nameReader.readName(from);
/*     */   }
/*     */   
/*     */   protected NBT readTag(IN from, NBTType<?> type) throws IOException {
/* 111 */     TagReader<IN, ? extends NBT> f = this.typeReaders.get(type);
/* 112 */     if (f == null)
/* 113 */       throw new IOException(MessageFormat.format("No reader registered for nbt type {0}", new Object[] { type })); 
/* 115 */     return f.readTag(from);
/*     */   }
/*     */   
/*     */   protected void writeTagType(OUT stream, NBTType<?> type) throws IOException {
/* 119 */     int id = ((Integer)this.typeToId.getOrDefault(type, Integer.valueOf(-1))).intValue();
/* 120 */     if (id == -1)
/* 121 */       throw new IOException(MessageFormat.format("Unknown nbt type {0}", new Object[] { type })); 
/* 123 */     this.idWriter.writeId(stream, id);
/*     */   }
/*     */   
/*     */   protected void writeTagName(OUT stream, String name) throws IOException {
/* 127 */     this.nameWriter.writeName(stream, name);
/*     */   }
/*     */   
/*     */   protected void writeTag(OUT stream, NBT tag) throws IOException {
/* 132 */     TagWriter<OUT, NBT> f = (TagWriter<OUT, NBT>)this.typeWriters.get(tag.getType());
/* 133 */     if (f == null)
/* 134 */       throw new IOException(MessageFormat.format("No writer registered for nbt type {0}", new Object[] { tag.getType() })); 
/* 136 */     f.writeTag(stream, tag);
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface IdReader<T> {
/*     */     int readId(T param1T) throws IOException;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface IdWriter<T> {
/*     */     void writeId(T param1T, int param1Int) throws IOException;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface NameReader<T> {
/*     */     String readName(T param1T) throws IOException;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface NameWriter<T> {
/*     */     void writeName(T param1T, String param1String) throws IOException;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface TagReader<IN, T extends NBT> {
/*     */     T readTag(IN param1IN) throws IOException;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface TagWriter<OUT, T extends NBT> {
/*     */     void writeTag(OUT param1OUT, T param1T) throws IOException;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\nbt\serializer\NBTSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */