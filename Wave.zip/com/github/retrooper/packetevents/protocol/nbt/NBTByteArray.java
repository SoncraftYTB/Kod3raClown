/*    */ package com.github.retrooper.packetevents.protocol.nbt;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class NBTByteArray extends NBT {
/*    */   protected final byte[] array;
/*    */   
/*    */   public NBTByteArray(byte[] array) {
/* 28 */     this.array = array;
/*    */   }
/*    */   
/*    */   public NBTType<NBTByteArray> getType() {
/* 33 */     return NBTType.BYTE_ARRAY;
/*    */   }
/*    */   
/*    */   public byte[] getValue() {
/* 37 */     return this.array;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 42 */     if (this == obj)
/* 43 */       return true; 
/* 45 */     if (obj == null)
/* 46 */       return false; 
/* 48 */     if (getClass() != obj.getClass())
/* 49 */       return false; 
/* 51 */     NBTByteArray other = (NBTByteArray)obj;
/* 52 */     return Arrays.equals(this.array, other.array);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 57 */     return Arrays.hashCode(this.array);
/*    */   }
/*    */   
/*    */   public NBTByteArray copy() {
/* 61 */     byte[] abyte = new byte[this.array.length];
/* 62 */     System.arraycopy(this.array, 0, abyte, 0, this.array.length);
/* 63 */     return new NBTByteArray(abyte);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\nbt\NBTByteArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */