package com.github.retrooper.packetevents.protocol.item.type;

import com.github.retrooper.packetevents.protocol.mapper.MappedEntity;
import com.github.retrooper.packetevents.protocol.world.states.type.StateType;
import java.util.Set;
import org.jetbrains.annotations.Nullable;

public interface ItemType extends MappedEntity {
  int getMaxAmount();
  
  int getMaxDurability();
  
  boolean isMusicDisc();
  
  ItemType getCraftRemainder();
  
  @Nullable
  StateType getPlacedType();
  
  Set<ItemTypes.ItemAttribute> getAttributes();
  
  boolean hasAttribute(ItemTypes.ItemAttribute paramItemAttribute);
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\item\type\ItemType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */