/*    */ package com.github.retrooper.packetevents.protocol.item.enchantment;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.item.enchantment.type.EnchantmentType;
/*    */ 
/*    */ public class Enchantment {
/*    */   private EnchantmentType type;
/*    */   
/*    */   private int level;
/*    */   
/*    */   private Enchantment(EnchantmentType type, int level) {
/* 29 */     this.type = type;
/* 30 */     this.level = level;
/*    */   }
/*    */   
/*    */   public EnchantmentType getType() {
/* 34 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(EnchantmentType type) {
/* 38 */     this.type = type;
/*    */   }
/*    */   
/*    */   public int getLevel() {
/* 42 */     return this.level;
/*    */   }
/*    */   
/*    */   public void setLevel(int level) {
/* 46 */     this.level = level;
/*    */   }
/*    */   
/*    */   public static Builder builder() {
/* 50 */     return new Builder();
/*    */   }
/*    */   
/*    */   public static class Builder {
/*    */     private EnchantmentType type;
/*    */     
/*    */     private int level;
/*    */     
/*    */     public Builder type(EnchantmentType type) {
/* 58 */       this.type = type;
/* 59 */       return this;
/*    */     }
/*    */     
/*    */     public Builder level(int level) {
/* 63 */       this.level = level;
/* 64 */       return this;
/*    */     }
/*    */     
/*    */     public Enchantment build() {
/* 68 */       return new Enchantment(this.type, this.level);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\item\enchantment\Enchantment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */