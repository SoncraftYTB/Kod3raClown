/*     */ package com.github.retrooper.packetevents.protocol.item.enchantment.type;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*     */ import com.github.retrooper.packetevents.util.TypesBuilder;
/*     */ import com.github.retrooper.packetevents.util.TypesBuilderData;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class EnchantmentTypes {
/*  31 */   private static final Map<String, EnchantmentType> ENCHANTMENT_TYPE_MAPPINGS = new HashMap<>();
/*     */   
/*  32 */   private static final Map<Byte, Map<Integer, EnchantmentType>> ENCHANTMENT_TYPE_ID_MAPPINGS = new HashMap<>();
/*     */   
/*  33 */   private static final TypesBuilder TYPES_BUILDER = new TypesBuilder("enchantment/enchantment_type_mappings", new ClientVersion[] { ClientVersion.V_1_12, ClientVersion.V_1_13, ClientVersion.V_1_14, ClientVersion.V_1_16, ClientVersion.V_1_19 });
/*     */   
/*     */   public static EnchantmentType define(String key) {
/*  41 */     final TypesBuilderData data = TYPES_BUILDER.define(key);
/*  42 */     EnchantmentType enchantmentType = new EnchantmentType() {
/*  43 */         private final int[] ids = data.getData();
/*     */         
/*     */         public ResourceLocation getName() {
/*  47 */           return data.getName();
/*     */         }
/*     */         
/*     */         public int getId(ClientVersion version) {
/*  52 */           int index = EnchantmentTypes.TYPES_BUILDER.getDataIndex(version);
/*  53 */           return this.ids[index];
/*     */         }
/*     */         
/*     */         public boolean equals(Object obj) {
/*  58 */           if (obj instanceof EnchantmentType)
/*  59 */             return (getName() == ((EnchantmentType)obj).getName()); 
/*  61 */           return false;
/*     */         }
/*     */       };
/*  65 */     ENCHANTMENT_TYPE_MAPPINGS.put(enchantmentType.getName().toString(), enchantmentType);
/*  66 */     for (ClientVersion version : TYPES_BUILDER.getVersions()) {
/*  67 */       int index = TYPES_BUILDER.getDataIndex(version);
/*  68 */       Map<Integer, EnchantmentType> typeIdMap = ENCHANTMENT_TYPE_ID_MAPPINGS.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/*  69 */       typeIdMap.put(Integer.valueOf(enchantmentType.getId(version)), enchantmentType);
/*     */     } 
/*  71 */     return enchantmentType;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static EnchantmentType getByName(String name) {
/*  76 */     return ENCHANTMENT_TYPE_MAPPINGS.get(name);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static EnchantmentType getById(ClientVersion version, int id) {
/*  81 */     int index = TYPES_BUILDER.getDataIndex(version);
/*  82 */     Map<Integer, EnchantmentType> typeIdMap = ENCHANTMENT_TYPE_ID_MAPPINGS.get(Byte.valueOf((byte)index));
/*  83 */     return typeIdMap.get(Integer.valueOf(id));
/*     */   }
/*     */   
/*  86 */   public static final EnchantmentType ALL_DAMAGE_PROTECTION = define("protection");
/*     */   
/*  87 */   public static final EnchantmentType FIRE_PROTECTION = define("fire_protection");
/*     */   
/*  88 */   public static final EnchantmentType FALL_PROTECTION = define("feather_falling");
/*     */   
/*  89 */   public static final EnchantmentType BLAST_PROTECTION = define("blast_protection");
/*     */   
/*  90 */   public static final EnchantmentType PROJECTILE_PROTECTION = define("projectile_protection");
/*     */   
/*  91 */   public static final EnchantmentType RESPIRATION = define("respiration");
/*     */   
/*  92 */   public static final EnchantmentType AQUA_AFFINITY = define("aqua_affinity");
/*     */   
/*  93 */   public static final EnchantmentType THORNS = define("thorns");
/*     */   
/*  94 */   public static final EnchantmentType DEPTH_STRIDER = define("depth_strider");
/*     */   
/*  95 */   public static final EnchantmentType FROST_WALKER = define("frost_walker");
/*     */   
/*  96 */   public static final EnchantmentType BINDING_CURSE = define("binding_curse");
/*     */   
/*  97 */   public static final EnchantmentType SOUL_SPEED = define("soul_speed");
/*     */   
/*  98 */   public static final EnchantmentType SWIFT_SNEAK = define("swift_sneak");
/*     */   
/*  99 */   public static final EnchantmentType SHARPNESS = define("sharpness");
/*     */   
/* 100 */   public static final EnchantmentType SMITE = define("smite");
/*     */   
/* 101 */   public static final EnchantmentType BANE_OF_ARTHROPODS = define("bane_of_arthropods");
/*     */   
/* 102 */   public static final EnchantmentType KNOCKBACK = define("knockback");
/*     */   
/* 103 */   public static final EnchantmentType FIRE_ASPECT = define("fire_aspect");
/*     */   
/* 104 */   public static final EnchantmentType MOB_LOOTING = define("looting");
/*     */   
/* 105 */   public static final EnchantmentType SWEEPING_EDGE = define("sweeping");
/*     */   
/* 106 */   public static final EnchantmentType BLOCK_EFFICIENCY = define("efficiency");
/*     */   
/* 107 */   public static final EnchantmentType SILK_TOUCH = define("silk_touch");
/*     */   
/* 108 */   public static final EnchantmentType UNBREAKING = define("unbreaking");
/*     */   
/* 109 */   public static final EnchantmentType BLOCK_FORTUNE = define("fortune");
/*     */   
/* 110 */   public static final EnchantmentType POWER_ARROWS = define("power");
/*     */   
/* 111 */   public static final EnchantmentType PUNCH_ARROWS = define("punch");
/*     */   
/* 112 */   public static final EnchantmentType FLAMING_ARROWS = define("flame");
/*     */   
/* 113 */   public static final EnchantmentType INFINITY_ARROWS = define("infinity");
/*     */   
/* 114 */   public static final EnchantmentType FISHING_LUCK = define("luck_of_the_sea");
/*     */   
/* 115 */   public static final EnchantmentType FISHING_SPEED = define("lure");
/*     */   
/* 116 */   public static final EnchantmentType LOYALTY = define("loyalty");
/*     */   
/* 117 */   public static final EnchantmentType IMPALING = define("impaling");
/*     */   
/* 118 */   public static final EnchantmentType RIPTIDE = define("riptide");
/*     */   
/* 119 */   public static final EnchantmentType CHANNELING = define("channeling");
/*     */   
/* 120 */   public static final EnchantmentType MULTISHOT = define("multishot");
/*     */   
/* 121 */   public static final EnchantmentType QUICK_CHARGE = define("quick_charge");
/*     */   
/* 122 */   public static final EnchantmentType PIERCING = define("piercing");
/*     */   
/* 123 */   public static final EnchantmentType MENDING = define("mending");
/*     */   
/* 124 */   public static final EnchantmentType VANISHING_CURSE = define("vanishing_curse");
/*     */   
/*     */   static {
/* 127 */     TYPES_BUILDER.unloadFileMappings();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\item\enchantment\type\EnchantmentTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */