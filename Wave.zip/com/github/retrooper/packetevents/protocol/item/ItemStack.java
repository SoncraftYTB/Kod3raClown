/*     */ package com.github.retrooper.packetevents.protocol.item;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.item.enchantment.Enchantment;
/*     */ import com.github.retrooper.packetevents.protocol.item.enchantment.type.EnchantmentType;
/*     */ import com.github.retrooper.packetevents.protocol.item.enchantment.type.EnchantmentTypes;
/*     */ import com.github.retrooper.packetevents.protocol.item.type.ItemType;
/*     */ import com.github.retrooper.packetevents.protocol.item.type.ItemTypes;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBT;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTInt;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTList;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTShort;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTString;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTType;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class ItemStack {
/*  35 */   public static final ItemStack EMPTY = new ItemStack(ItemTypes.AIR, 0, new NBTCompound(), 0);
/*     */   
/*     */   private final ItemType type;
/*     */   
/*     */   private int amount;
/*     */   
/*     */   @Nullable
/*     */   private NBTCompound nbt;
/*     */   
/*  40 */   private int legacyData = -1;
/*     */   
/*     */   private boolean cachedIsEmpty = false;
/*     */   
/*     */   private ItemStack(ItemType type, int amount, @Nullable NBTCompound nbt, int legacyData) {
/*  45 */     this.type = type;
/*  46 */     this.amount = amount;
/*  47 */     this.nbt = nbt;
/*  48 */     this.legacyData = legacyData;
/*  49 */     updateCachedEmptyStatus();
/*     */   }
/*     */   
/*     */   public int getMaxStackSize() {
/*  53 */     return getType().getMaxAmount();
/*     */   }
/*     */   
/*     */   public boolean isStackable() {
/*  57 */     return (getMaxStackSize() > 1 && (!isDamageableItem() || !isDamaged()));
/*     */   }
/*     */   
/*     */   public boolean isDamageableItem() {
/*  61 */     if (!this.cachedIsEmpty && getType().getMaxDurability() > 0) {
/*  62 */       NBTCompound tag = getNBT();
/*  63 */       return (tag == null || !tag.getBoolean("Unbreakable"));
/*     */     } 
/*  65 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDamaged() {
/*  69 */     return (isDamageableItem() && getDamageValue() > 0);
/*     */   }
/*     */   
/*     */   public int getDamageValue() {
/*  73 */     if (this.nbt == null)
/*  73 */       return 0; 
/*  74 */     NBTInt damage = (NBTInt)this.nbt.getTagOfTypeOrNull("Damage", NBTInt.class);
/*  75 */     return (damage == null) ? 0 : damage.getAsInt();
/*     */   }
/*     */   
/*     */   public void setDamageValue(int damage) {
/*  79 */     getOrCreateTag().setTag("Damage", (NBT)new NBTInt(Math.max(0, damage)));
/*     */   }
/*     */   
/*     */   public int getMaxDamage() {
/*  83 */     return getType().getMaxDurability();
/*     */   }
/*     */   
/*     */   public NBTCompound getOrCreateTag() {
/*  87 */     if (this.nbt == null)
/*  88 */       this.nbt = new NBTCompound(); 
/*  91 */     return this.nbt;
/*     */   }
/*     */   
/*     */   private void updateCachedEmptyStatus() {
/*  95 */     this.cachedIsEmpty = isEmpty();
/*     */   }
/*     */   
/*     */   public ItemType getType() {
/*  99 */     return this.cachedIsEmpty ? ItemTypes.AIR : this.type;
/*     */   }
/*     */   
/*     */   public int getAmount() {
/* 103 */     return this.cachedIsEmpty ? 0 : this.amount;
/*     */   }
/*     */   
/*     */   public void shrink(int amount) {
/* 107 */     setAmount(getAmount() - amount);
/*     */   }
/*     */   
/*     */   public void grow(int amount) {
/* 111 */     setAmount(getAmount() + amount);
/*     */   }
/*     */   
/*     */   public void setAmount(int amount) {
/* 115 */     this.amount = amount;
/* 116 */     updateCachedEmptyStatus();
/*     */   }
/*     */   
/*     */   public ItemStack split(int toTake) {
/* 120 */     int i = Math.min(toTake, getAmount());
/* 121 */     ItemStack itemstack = copy();
/* 122 */     itemstack.setAmount(i);
/* 123 */     shrink(i);
/* 124 */     return itemstack;
/*     */   }
/*     */   
/*     */   public ItemStack copy() {
/* 128 */     return this.cachedIsEmpty ? EMPTY : new ItemStack(this.type, this.amount, (this.nbt == null) ? null : this.nbt.copy(), this.legacyData);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public NBTCompound getNBT() {
/* 133 */     return this.nbt;
/*     */   }
/*     */   
/*     */   public void setNBT(NBTCompound nbt) {
/* 137 */     this.nbt = nbt;
/*     */   }
/*     */   
/*     */   public int getLegacyData() {
/* 141 */     return this.legacyData;
/*     */   }
/*     */   
/*     */   public void setLegacyData(int legacyData) {
/* 145 */     this.legacyData = legacyData;
/*     */   }
/*     */   
/*     */   public boolean isEnchantable(ClientVersion version) {
/* 149 */     if (getType() == ItemTypes.BOOK)
/* 149 */       return (getAmount() == 1); 
/* 150 */     if (getType() == ItemTypes.ENCHANTED_BOOK)
/* 150 */       return false; 
/* 151 */     return (getMaxStackSize() == 1 && canBeDepleted() && !isEnchanted(version));
/*     */   }
/*     */   
/*     */   public boolean isEnchanted(ClientVersion version) {
/* 155 */     String tagName = getEnchantmentsTagName(version);
/* 156 */     return (!isEmpty() && this.nbt != null && this.nbt.getCompoundListTagOrNull(tagName) != null && !this.nbt.getCompoundListTagOrNull(tagName).getTags().isEmpty());
/*     */   }
/*     */   
/*     */   private List<Enchantment> getEnchantments(@Nullable NBTCompound nbt, ClientVersion version) {
/* 160 */     String tagName = getEnchantmentsTagName(version);
/* 162 */     if (nbt == null || nbt.getCompoundListTagOrNull(tagName) == null)
/* 163 */       return new ArrayList<>(0); 
/* 165 */     NBTList<NBTCompound> nbtList = nbt.getCompoundListTagOrNull(tagName);
/* 166 */     List<NBTCompound> compounds = nbtList.getTags();
/* 167 */     List<Enchantment> enchantments = new ArrayList<>(compounds.size());
/* 169 */     for (NBTCompound compound : compounds) {
/* 170 */       EnchantmentType type = getEnchantmentTypeFromTag(compound, version);
/* 172 */       if (type != null) {
/* 173 */         NBTShort levelTag = (NBTShort)compound.getTagOfTypeOrNull("lvl", NBTShort.class);
/* 174 */         int level = levelTag.getAsInt();
/* 175 */         Enchantment enchantment = Enchantment.builder().type(type).level(level).build();
/* 176 */         enchantments.add(enchantment);
/*     */       } 
/*     */     } 
/* 180 */     return enchantments;
/*     */   }
/*     */   
/*     */   public List<Enchantment> getEnchantments(ClientVersion version) {
/* 184 */     return getEnchantments(this.nbt, version);
/*     */   }
/*     */   
/*     */   public int getEnchantmentLevel(EnchantmentType enchantment, ClientVersion version) {
/* 188 */     if (isEnchanted(version)) {
/* 190 */       assert this.nbt != null;
/* 191 */       String tagName = getEnchantmentsTagName(version);
/* 192 */       for (NBTCompound base : this.nbt.getCompoundListTagOrNull(tagName).getTags()) {
/* 193 */         EnchantmentType type = getEnchantmentTypeFromTag(base, version);
/* 194 */         if (enchantment == type) {
/* 195 */           NBTShort nbtShort = (NBTShort)base.getTagOfTypeOrNull("lvl", NBTShort.class);
/* 196 */           if (nbtShort == null)
/* 196 */             return 0; 
/* 197 */           return nbtShort.getAsInt();
/*     */         } 
/*     */       } 
/*     */     } 
/* 202 */     return 0;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static EnchantmentType getEnchantmentTypeFromTag(NBTCompound tag, ClientVersion version) {
/* 207 */     if (version.isNewerThanOrEquals(ClientVersion.V_1_13)) {
/* 208 */       String id = tag.getStringTagValueOrNull("id");
/* 209 */       return EnchantmentTypes.getByName(id);
/*     */     } 
/* 211 */     NBTShort idTag = (NBTShort)tag.getTagOfTypeOrNull("id", NBTShort.class);
/* 212 */     return EnchantmentTypes.getById(version, idTag.getAsInt());
/*     */   }
/*     */   
/*     */   public void setEnchantments(List<Enchantment> enchantments, ClientVersion version) {
/* 217 */     this.nbt = getOrCreateTag();
/* 218 */     String tagName = getEnchantmentsTagName(version);
/* 219 */     if (enchantments.isEmpty()) {
/* 221 */       if (this.nbt.getTagOrNull(tagName) != null)
/* 222 */         this.nbt.removeTag(tagName); 
/*     */     } else {
/* 225 */       List<NBTCompound> list = new ArrayList<>();
/* 226 */       for (Enchantment enchantment : enchantments) {
/* 227 */         NBTCompound compound = new NBTCompound();
/* 228 */         if (version.isNewerThanOrEquals(ClientVersion.V_1_13)) {
/* 229 */           compound.setTag("id", (NBT)new NBTString(enchantment.getType().getName().toString()));
/*     */         } else {
/* 231 */           compound.setTag("id", (NBT)new NBTShort((short)enchantment.getType().getId(version)));
/*     */         } 
/* 234 */         compound.setTag("lvl", (NBT)new NBTShort((short)enchantment.getLevel()));
/* 235 */         list.add(compound);
/*     */       } 
/* 237 */       assert this.nbt != null;
/* 238 */       this.nbt.setTag(tagName, (NBT)new NBTList(NBTType.COMPOUND, list));
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getEnchantmentsTagName(ClientVersion version) {
/* 243 */     String tagName = version.isNewerThanOrEquals(ClientVersion.V_1_13) ? "Enchantments" : "ench";
/* 244 */     if (this.type == ItemTypes.ENCHANTED_BOOK)
/* 245 */       tagName = "StoredEnchantments"; 
/* 247 */     return tagName;
/*     */   }
/*     */   
/*     */   public boolean canBeDepleted() {
/* 251 */     return (getType().getMaxDurability() > 0);
/*     */   }
/*     */   
/*     */   public boolean is(ItemType type) {
/* 255 */     return (getType() == type);
/*     */   }
/*     */   
/*     */   public static boolean isSameItemSameTags(ItemStack stack, ItemStack otherStack) {
/* 259 */     return (stack.is(otherStack.getType()) && tagMatches(stack, otherStack));
/*     */   }
/*     */   
/*     */   public static boolean tagMatches(ItemStack left, ItemStack right) {
/* 263 */     if (left == right)
/* 264 */       return true; 
/* 266 */     if (left == null)
/* 267 */       return right.isEmpty(); 
/* 269 */     if (right == null)
/* 270 */       return left.isEmpty(); 
/* 272 */     return Objects.equals(left.nbt, right.nbt);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 277 */     if (this == obj)
/* 278 */       return true; 
/* 279 */     if (obj instanceof ItemStack) {
/* 280 */       ItemStack itemStack = (ItemStack)obj;
/* 281 */       return (getType().equals(itemStack.getType()) && this.amount == itemStack.amount && 
/*     */         
/* 283 */         Objects.equals(this.nbt, itemStack.nbt) && this.legacyData == itemStack.legacyData);
/*     */     } 
/* 286 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 291 */     if (this.cachedIsEmpty)
/* 292 */       return "ItemStack[null]"; 
/* 294 */     String identifier = (this.type == null) ? "null" : this.type.getName().toString();
/* 295 */     int maxAmount = getType().getMaxAmount();
/* 296 */     return "ItemStack[type=" + identifier + ", amount=" + this.amount + "/" + maxAmount + ", nbt tag names: " + (
/* 297 */       (this.nbt != null) ? (String)this.nbt.getTagNames() : "[null]") + ", legacyData=" + this.legacyData + "]";
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 302 */     return (this.type == null || this.type == ItemTypes.AIR || this.amount <= 0);
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/* 306 */     return new Builder();
/*     */   }
/*     */   
/*     */   public static class Builder {
/*     */     private ItemType type;
/*     */     
/* 311 */     private int amount = 1;
/*     */     
/* 312 */     private NBTCompound nbt = null;
/*     */     
/* 313 */     private int legacyData = -1;
/*     */     
/*     */     public Builder type(ItemType type) {
/* 316 */       this.type = type;
/* 317 */       return this;
/*     */     }
/*     */     
/*     */     public Builder amount(int amount) {
/* 321 */       this.amount = amount;
/* 322 */       return this;
/*     */     }
/*     */     
/*     */     public Builder nbt(NBTCompound nbt) {
/* 326 */       this.nbt = nbt;
/* 327 */       return this;
/*     */     }
/*     */     
/*     */     public Builder legacyData(int legacyData) {
/* 331 */       this.legacyData = legacyData;
/* 332 */       return this;
/*     */     }
/*     */     
/*     */     public ItemStack build() {
/* 336 */       return new ItemStack(this.type, this.amount, this.nbt, this.legacyData);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\item\ItemStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */