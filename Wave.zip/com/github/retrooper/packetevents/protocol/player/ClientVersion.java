/*     */ package com.github.retrooper.packetevents.protocol.player;
/*     */ 
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.manager.server.VersionComparison;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public enum ClientVersion {
/*  42 */   V_1_7_10(5),
/*  44 */   V_1_8(47),
/*  46 */   V_1_9(107),
/*  46 */   V_1_9_1(108),
/*  46 */   V_1_9_2(109),
/*  50 */   V_1_9_3(110),
/*  51 */   V_1_10(210),
/*  52 */   V_1_11(315),
/*  56 */   V_1_11_1(316),
/*  57 */   V_1_12(335),
/*  57 */   V_1_12_1(338),
/*  57 */   V_1_12_2(340),
/*  59 */   V_1_13(393),
/*  59 */   V_1_13_1(401),
/*  59 */   V_1_13_2(404),
/*  61 */   V_1_14(477),
/*  61 */   V_1_14_1(480),
/*  61 */   V_1_14_2(485),
/*  62 */   V_1_14_3(490),
/*  62 */   V_1_14_4(498),
/*  64 */   V_1_15(573),
/*  64 */   V_1_15_1(575),
/*  64 */   V_1_15_2(578),
/*  66 */   V_1_16(735),
/*  66 */   V_1_16_1(736),
/*  66 */   V_1_16_2(751),
/*  67 */   V_1_16_3(753),
/*  71 */   V_1_16_4(754),
/*  73 */   V_1_17(755),
/*  73 */   V_1_17_1(756),
/*  78 */   V_1_18(757),
/*  79 */   V_1_18_2(758),
/*  81 */   V_1_19(759),
/*  82 */   V_1_19_1(760),
/*  83 */   V_1_19_3(761),
/*  84 */   V_1_19_4(762),
/*  85 */   V_1_20(763),
/*  86 */   V_1_20_2(764),
/*  90 */   V_1_20_3(765),
/*  93 */   LOWER_THAN_SUPPORTED_VERSIONS(V_1_7_10.protocolVersion - 1, true),
/*  95 */   HIGHER_THAN_SUPPORTED_VERSIONS(V_1_20_3.protocolVersion + 1, true),
/*  97 */   UNKNOWN(-1, true);
/*     */   
/*     */   private static final ClientVersion[] VALUES;
/*     */   
/*     */   private static final ClientVersion[] REVERSED_VALUES;
/*     */   
/*     */   private static final int LOWEST_SUPPORTED_PROTOCOL_VERSION;
/*     */   
/*     */   private static final int HIGHEST_SUPPORTED_PROTOCOL_VERSION;
/*     */   
/*     */   private final int protocolVersion;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private ServerVersion serverVersion;
/*     */   
/*     */   static {
/*  99 */     VALUES = values();
/* 103 */     List<ClientVersion> valuesAsList = Arrays.asList(values());
/* 104 */     Collections.reverse(valuesAsList);
/* 105 */     REVERSED_VALUES = valuesAsList.<ClientVersion>toArray(new ClientVersion[0]);
/* 108 */     LOWEST_SUPPORTED_PROTOCOL_VERSION = LOWER_THAN_SUPPORTED_VERSIONS.protocolVersion + 1;
/* 109 */     HIGHEST_SUPPORTED_PROTOCOL_VERSION = HIGHER_THAN_SUPPORTED_VERSIONS.protocolVersion - 1;
/*     */   }
/*     */   
/*     */   ClientVersion(int protocolVersion) {
/* 116 */     this.protocolVersion = protocolVersion;
/* 117 */     this.name = name().substring(2).replace("_", ".");
/*     */   }
/*     */   
/*     */   ClientVersion(int protocolVersion, boolean isNotRelease) {
/* 121 */     this.protocolVersion = protocolVersion;
/* 122 */     if (isNotRelease) {
/* 123 */       this.name = name();
/*     */     } else {
/* 125 */       this.name = name().substring(2).replace("_", ".");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isPreRelease(int protocolVersion) {
/* 130 */     return ((getLatest()).protocolVersion <= protocolVersion || 
/* 131 */       (getOldest()).protocolVersion >= protocolVersion);
/*     */   }
/*     */   
/*     */   public static boolean isRelease(int protocolVersion) {
/* 135 */     return (protocolVersion <= (getLatest()).protocolVersion && protocolVersion >= 
/* 136 */       (getOldest()).protocolVersion);
/*     */   }
/*     */   
/*     */   public boolean isPreRelease() {
/* 140 */     return isPreRelease(this.protocolVersion);
/*     */   }
/*     */   
/*     */   public boolean isRelease() {
/* 144 */     return isRelease(this.protocolVersion);
/*     */   }
/*     */   
/*     */   public String getReleaseName() {
/* 154 */     return this.name;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static ClientVersion getById(int protocolVersion) {
/* 165 */     if (protocolVersion < LOWEST_SUPPORTED_PROTOCOL_VERSION)
/* 166 */       return LOWER_THAN_SUPPORTED_VERSIONS; 
/* 167 */     if (protocolVersion > HIGHEST_SUPPORTED_PROTOCOL_VERSION)
/* 168 */       return HIGHER_THAN_SUPPORTED_VERSIONS; 
/* 170 */     for (ClientVersion version : VALUES) {
/* 171 */       if (version.protocolVersion > protocolVersion)
/*     */         break; 
/* 173 */       if (version.protocolVersion == protocolVersion)
/* 174 */         return version; 
/*     */     } 
/* 177 */     return UNKNOWN;
/*     */   }
/*     */   
/*     */   public static ClientVersion getLatest() {
/* 182 */     return REVERSED_VALUES[3];
/*     */   }
/*     */   
/*     */   public static ClientVersion getOldest() {
/* 186 */     return VALUES[0];
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ServerVersion toServerVersion() {
/* 191 */     if (this.serverVersion == null)
/* 192 */       this.serverVersion = ServerVersion.getById(this.protocolVersion); 
/* 194 */     return this.serverVersion;
/*     */   }
/*     */   
/*     */   public int getProtocolVersion() {
/* 203 */     return this.protocolVersion;
/*     */   }
/*     */   
/*     */   public boolean isNewerThan(ClientVersion target) {
/* 215 */     return (this.protocolVersion > target.protocolVersion);
/*     */   }
/*     */   
/*     */   public boolean isNewerThanOrEquals(ClientVersion target) {
/* 227 */     return (this.protocolVersion >= target.protocolVersion);
/*     */   }
/*     */   
/*     */   public boolean isOlderThan(ClientVersion target) {
/* 239 */     return (this.protocolVersion < target.protocolVersion);
/*     */   }
/*     */   
/*     */   public boolean isOlderThanOrEquals(ClientVersion target) {
/* 251 */     return (this.protocolVersion <= target.protocolVersion);
/*     */   }
/*     */   
/*     */   public boolean is(@NotNull VersionComparison comparison, @NotNull ClientVersion targetVersion) {
/* 268 */     switch (comparison) {
/*     */       case EQUALS:
/* 270 */         return (this.protocolVersion == targetVersion.protocolVersion);
/*     */       case NEWER_THAN:
/* 272 */         return isNewerThan(targetVersion);
/*     */       case NEWER_THAN_OR_EQUALS:
/* 274 */         return isNewerThanOrEquals(targetVersion);
/*     */       case OLDER_THAN:
/* 276 */         return isOlderThan(targetVersion);
/*     */       case OLDER_THAN_OR_EQUALS:
/* 278 */         return isOlderThanOrEquals(targetVersion);
/*     */     } 
/* 280 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\player\ClientVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */