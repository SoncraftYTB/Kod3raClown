/*    */ package com.github.retrooper.packetevents.protocol.player;
/*    */ 
/*    */ public enum InteractionHand {
/* 28 */   MAIN_HAND, OFF_HAND;
/*    */   
/*    */   private static final InteractionHand[] VALUES;
/*    */   
/*    */   static {
/* 31 */     VALUES = values();
/*    */   }
/*    */   
/*    */   public int getId() {
/* 34 */     return ordinal();
/*    */   }
/*    */   
/*    */   public static InteractionHand getById(int id) {
/* 38 */     return VALUES[id];
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\player\InteractionHand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */