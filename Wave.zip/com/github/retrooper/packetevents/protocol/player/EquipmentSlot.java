/*    */ package com.github.retrooper.packetevents.protocol.player;
/*    */ 
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public enum EquipmentSlot {
/* 25 */   MAIN_HAND(0),
/* 26 */   OFF_HAND(0),
/* 27 */   BOOTS(1),
/* 28 */   LEGGINGS(2),
/* 29 */   CHEST_PLATE(3),
/* 30 */   HELMET(4);
/*    */   
/*    */   private static final EquipmentSlot[] VALUES;
/*    */   
/*    */   private final byte legacyId;
/*    */   
/*    */   static {
/* 32 */     VALUES = values();
/*    */   }
/*    */   
/*    */   EquipmentSlot(int legacyId) {
/* 37 */     this.legacyId = (byte)legacyId;
/*    */   }
/*    */   
/*    */   public int getId(ServerVersion version) {
/* 41 */     if (version.isOlderThan(ServerVersion.V_1_9))
/* 42 */       return this.legacyId; 
/* 45 */     return ordinal();
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public static EquipmentSlot getById(ServerVersion version, int id) {
/* 52 */     for (EquipmentSlot slot : VALUES) {
/* 53 */       if (slot.getId(version) == id)
/* 54 */         return slot; 
/*    */     } 
/* 57 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\player\EquipmentSlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */