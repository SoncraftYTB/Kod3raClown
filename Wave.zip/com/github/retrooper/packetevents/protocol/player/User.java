/*     */ package com.github.retrooper.packetevents.protocol.player;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.netty.channel.ChannelHelper;
/*     */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*     */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*     */ import com.github.retrooper.packetevents.protocol.chat.ChatTypes;
/*     */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage;
/*     */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessageLegacy;
/*     */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage_v1_16;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTList;
/*     */ import com.github.retrooper.packetevents.protocol.world.Dimension;
/*     */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerChatMessage;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerCloseWindow;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetTitleSubtitle;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetTitleText;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetTitleTimes;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSystemChatMessage;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerTitle;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class User {
/*     */   private final Object channel;
/*     */   
/*     */   private ConnectionState decoderState;
/*     */   
/*     */   private ConnectionState encoderState;
/*     */   
/*     */   private ClientVersion clientVersion;
/*     */   
/*     */   private final UserProfile profile;
/*     */   
/*  49 */   private int entityId = -1;
/*     */   
/*  50 */   private int minWorldHeight = 0;
/*     */   
/*  51 */   private int totalWorldHeight = 256;
/*     */   
/*     */   private List<NBTCompound> worldNBT;
/*     */   
/*  53 */   private Dimension dimension = new Dimension(0);
/*     */   
/*     */   public User(Object channel, ConnectionState connectionState, ClientVersion clientVersion, UserProfile profile) {
/*  58 */     this.channel = channel;
/*  59 */     this.decoderState = connectionState;
/*  60 */     this.encoderState = connectionState;
/*  61 */     this.clientVersion = clientVersion;
/*  62 */     this.profile = profile;
/*     */   }
/*     */   
/*     */   public Object getChannel() {
/*  66 */     return this.channel;
/*     */   }
/*     */   
/*     */   public InetSocketAddress getAddress() {
/*  70 */     return (InetSocketAddress)ChannelHelper.remoteAddress(this.channel);
/*     */   }
/*     */   
/*     */   public ConnectionState getConnectionState() {
/*  74 */     ConnectionState decoderState = this.decoderState;
/*  75 */     ConnectionState encoderState = this.encoderState;
/*  76 */     if (decoderState != encoderState)
/*  77 */       throw new IllegalArgumentException("Can't get common connection state: " + decoderState + " != " + encoderState); 
/*  79 */     return decoderState;
/*     */   }
/*     */   
/*     */   public void setConnectionState(ConnectionState connectionState) {
/*  83 */     setDecoderState(connectionState);
/*  84 */     setEncoderState(connectionState);
/*     */   }
/*     */   
/*     */   public ConnectionState getDecoderState() {
/*  88 */     return this.decoderState;
/*     */   }
/*     */   
/*     */   public void setDecoderState(ConnectionState decoderState) {
/*  92 */     this.decoderState = decoderState;
/*  93 */     PacketEvents.getAPI().getLogManager().debug("Transitioned " + 
/*  94 */         getName() + "'s decoder into " + decoderState + " state!");
/*     */   }
/*     */   
/*     */   public ConnectionState getEncoderState() {
/*  98 */     return this.encoderState;
/*     */   }
/*     */   
/*     */   public void setEncoderState(ConnectionState encoderState) {
/* 102 */     this.encoderState = encoderState;
/* 103 */     PacketEvents.getAPI().getLogManager().debug("Transitioned " + 
/* 104 */         getName() + "'s encoder into " + encoderState + " state!");
/*     */   }
/*     */   
/*     */   public ClientVersion getClientVersion() {
/* 108 */     return this.clientVersion;
/*     */   }
/*     */   
/*     */   public void setClientVersion(ClientVersion clientVersion) {
/* 112 */     this.clientVersion = clientVersion;
/*     */   }
/*     */   
/*     */   public UserProfile getProfile() {
/* 116 */     return this.profile;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 120 */     return this.profile.getName();
/*     */   }
/*     */   
/*     */   public UUID getUUID() {
/* 124 */     return this.profile.getUUID();
/*     */   }
/*     */   
/*     */   public int getEntityId() {
/* 128 */     return this.entityId;
/*     */   }
/*     */   
/*     */   public void setEntityId(int entityId) {
/* 132 */     this.entityId = entityId;
/*     */   }
/*     */   
/*     */   public void sendPacket(Object buffer) {
/* 136 */     PacketEvents.getAPI().getProtocolManager().sendPacket(this.channel, buffer);
/*     */   }
/*     */   
/*     */   public void sendPacket(PacketWrapper<?> wrapper) {
/* 140 */     PacketEvents.getAPI().getProtocolManager().sendPacket(this.channel, wrapper);
/*     */   }
/*     */   
/*     */   public void sendPacketSilently(PacketWrapper<?> wrapper) {
/* 144 */     PacketEvents.getAPI().getProtocolManager().sendPacketSilently(this.channel, wrapper);
/*     */   }
/*     */   
/*     */   public void writePacket(PacketWrapper<?> wrapper) {
/* 148 */     PacketEvents.getAPI().getProtocolManager().writePacket(this.channel, wrapper);
/*     */   }
/*     */   
/*     */   public void flushPackets() {
/* 152 */     ChannelHelper.flush(this.channel);
/*     */   }
/*     */   
/*     */   public void closeConnection() {
/* 156 */     ChannelHelper.close(this.channel);
/*     */   }
/*     */   
/*     */   public void closeInventory() {
/* 167 */     WrapperPlayServerCloseWindow closeWindow = new WrapperPlayServerCloseWindow(0);
/* 168 */     PacketEvents.getAPI().getProtocolManager().sendPacket(this.channel, (PacketWrapper)closeWindow);
/*     */   }
/*     */   
/*     */   public void sendMessage(String legacyMessage) {
/* 172 */     Component component = AdventureSerializer.fromLegacyFormat(legacyMessage);
/* 173 */     sendMessage(component);
/*     */   }
/*     */   
/*     */   public void sendMessage(Component component) {
/* 177 */     sendMessage(component, ChatTypes.CHAT);
/*     */   }
/*     */   
/*     */   public void sendMessage(Component component, ChatType type) {
/*     */     WrapperPlayServerChatMessage wrapperPlayServerChatMessage;
/* 182 */     ServerVersion version = PacketEvents.getAPI().getInjector().isProxy() ? getClientVersion().toServerVersion() : PacketEvents.getAPI().getServerManager().getVersion();
/* 184 */     if (version.isNewerThanOrEquals(ServerVersion.V_1_19)) {
/* 185 */       WrapperPlayServerSystemChatMessage wrapperPlayServerSystemChatMessage = new WrapperPlayServerSystemChatMessage(false, component);
/*     */     } else {
/*     */       ChatMessageLegacy chatMessageLegacy;
/* 188 */       if (version.isNewerThanOrEquals(ServerVersion.V_1_16)) {
/* 189 */         ChatMessage_v1_16 chatMessage_v1_16 = new ChatMessage_v1_16(component, type, new UUID(0L, 0L));
/*     */       } else {
/* 191 */         chatMessageLegacy = new ChatMessageLegacy(component, type);
/*     */       } 
/* 193 */       wrapperPlayServerChatMessage = new WrapperPlayServerChatMessage((ChatMessage)chatMessageLegacy);
/*     */     } 
/* 195 */     PacketEvents.getAPI().getProtocolManager().sendPacket(this.channel, (PacketWrapper)wrapperPlayServerChatMessage);
/*     */   }
/*     */   
/*     */   public void sendTitle(String legacyTitle, String legacySubtitle, int fadeInTicks, int stayTicks, int fadeOutTicks) {
/* 200 */     Component title = AdventureSerializer.fromLegacyFormat(legacyTitle);
/* 201 */     Component subtitle = AdventureSerializer.fromLegacyFormat(legacySubtitle);
/* 202 */     sendTitle(title, subtitle, fadeInTicks, stayTicks, fadeOutTicks);
/*     */   }
/*     */   
/*     */   public void sendTitle(Component title, Component subtitle, int fadeInTicks, int stayTicks, int fadeOutTicks) {
/*     */     WrapperPlayServerTitle wrapperPlayServerTitle1, wrapperPlayServerTitle2, wrapperPlayServerTitle3;
/* 207 */     ServerVersion version = PacketEvents.getAPI().getInjector().isProxy() ? getClientVersion().toServerVersion() : PacketEvents.getAPI().getServerManager().getVersion();
/* 208 */     boolean modern = version.isNewerThanOrEquals(ServerVersion.V_1_17);
/* 210 */     PacketWrapper<?> setTitle = null;
/* 211 */     PacketWrapper<?> setSubtitle = null;
/* 212 */     if (modern) {
/* 213 */       WrapperPlayServerSetTitleTimes wrapperPlayServerSetTitleTimes = new WrapperPlayServerSetTitleTimes(fadeInTicks, stayTicks, fadeOutTicks);
/* 214 */       if (title != null)
/* 215 */         WrapperPlayServerSetTitleText wrapperPlayServerSetTitleText = new WrapperPlayServerSetTitleText(title); 
/* 217 */       if (subtitle != null)
/* 218 */         WrapperPlayServerSetTitleSubtitle wrapperPlayServerSetTitleSubtitle = new WrapperPlayServerSetTitleSubtitle(subtitle); 
/*     */     } else {
/* 221 */       wrapperPlayServerTitle1 = new WrapperPlayServerTitle(WrapperPlayServerTitle.TitleAction.SET_TIMES_AND_DISPLAY, (Component)null, null, null, fadeInTicks, stayTicks, fadeOutTicks);
/* 224 */       if (title != null)
/* 225 */         wrapperPlayServerTitle2 = new WrapperPlayServerTitle(WrapperPlayServerTitle.TitleAction.SET_TITLE, title, null, null, 0, 0, 0); 
/* 229 */       if (subtitle != null)
/* 230 */         wrapperPlayServerTitle3 = new WrapperPlayServerTitle(WrapperPlayServerTitle.TitleAction.SET_SUBTITLE, null, subtitle, null, 0, 0, 0); 
/*     */     } 
/* 235 */     sendPacket((PacketWrapper<?>)wrapperPlayServerTitle1);
/* 236 */     if (wrapperPlayServerTitle2 != null)
/* 237 */       sendPacket((PacketWrapper<?>)wrapperPlayServerTitle2); 
/* 239 */     if (wrapperPlayServerTitle3 != null)
/* 240 */       sendPacket((PacketWrapper<?>)wrapperPlayServerTitle3); 
/*     */   }
/*     */   
/*     */   public int getMinWorldHeight() {
/* 247 */     return this.minWorldHeight;
/*     */   }
/*     */   
/*     */   public void setMinWorldHeight(int minWorldHeight) {
/* 251 */     this.minWorldHeight = minWorldHeight;
/*     */   }
/*     */   
/*     */   public int getTotalWorldHeight() {
/* 255 */     return this.totalWorldHeight;
/*     */   }
/*     */   
/*     */   public void setTotalWorldHeight(int totalWorldHeight) {
/* 259 */     this.totalWorldHeight = totalWorldHeight;
/*     */   }
/*     */   
/*     */   public void setWorldNBT(NBTList<NBTCompound> worldNBT) {
/* 263 */     this.worldNBT = worldNBT.getTags();
/*     */   }
/*     */   
/*     */   public Dimension getDimension() {
/* 267 */     return this.dimension;
/*     */   }
/*     */   
/*     */   public void setDimension(Dimension dimension) {
/* 271 */     this.dimension = dimension;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public NBTCompound getWorldNBT(String worldName) {
/* 276 */     if (this.worldNBT == null)
/* 277 */       return null; 
/* 279 */     for (NBTCompound compound : this.worldNBT) {
/* 280 */       if (compound.getStringTagOrNull("name").getValue().equals(worldName))
/* 281 */         return compound; 
/*     */     } 
/* 284 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\player\User.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */