/*    */ package com.github.retrooper.packetevents.protocol.player;
/*    */ 
/*    */ public enum DiggingAction {
/* 22 */   START_DIGGING, CANCELLED_DIGGING, FINISHED_DIGGING, DROP_ITEM_STACK, DROP_ITEM, RELEASE_USE_ITEM, SWAP_ITEM_WITH_OFFHAND;
/*    */   
/*    */   private static final DiggingAction[] VALUES;
/*    */   
/*    */   static {
/* 30 */     VALUES = values();
/*    */   }
/*    */   
/*    */   public int getId() {
/* 33 */     return ordinal();
/*    */   }
/*    */   
/*    */   public static DiggingAction getById(int id) {
/* 37 */     return VALUES[id];
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\player\DiggingAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */