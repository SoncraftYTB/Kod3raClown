/*    */ package com.github.retrooper.packetevents.protocol.player;
/*    */ 
/*    */ public enum GameMode {
/* 28 */   SURVIVAL, CREATIVE, ADVENTURE, SPECTATOR;
/*    */   
/*    */   private static final GameMode[] VALUES;
/*    */   
/*    */   static {
/* 33 */     VALUES = values();
/*    */   }
/*    */   
/*    */   public int getId() {
/* 36 */     return ordinal();
/*    */   }
/*    */   
/*    */   public static GameMode getById(int id) {
/* 41 */     if (id < 0 || id >= VALUES.length)
/* 42 */       return SURVIVAL; 
/* 44 */     return VALUES[id];
/*    */   }
/*    */   
/*    */   public static GameMode defaultGameMode() {
/* 48 */     return SURVIVAL;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\player\GameMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */