package com.github.retrooper.packetevents.protocol.stats;

import net.kyori.adventure.text.Component;

public interface Statistic {
  String getId();
  
  Component display();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\stats\Statistic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */