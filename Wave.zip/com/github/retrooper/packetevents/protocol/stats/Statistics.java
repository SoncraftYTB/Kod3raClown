/*    */ package com.github.retrooper.packetevents.protocol.stats;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.util.MappingHelper;
/*    */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.kyori.adventure.text.Component;
/*    */ 
/*    */ public class Statistics {
/* 34 */   private static final Map<String, Statistic> STATISTIC_MAP = new HashMap<>();
/*    */   
/*    */   public static Statistic getById(String id) {
/* 37 */     return STATISTIC_MAP.get(id);
/*    */   }
/*    */   
/*    */   static {
/* 41 */     ServerVersion version = PacketEvents.getAPI().getServerManager().getVersion();
/* 43 */     if (version.isOlderThan(ServerVersion.V_1_12_2)) {
/* 45 */       JsonObject mapping = MappingHelper.getJSONObject("stats/statistics");
/* 47 */       if (version.isOlderThanOrEquals(ServerVersion.V_1_8_3)) {
/* 48 */         mapping = mapping.getAsJsonObject("V_1_8");
/*    */       } else {
/* 50 */         mapping = mapping.getAsJsonObject("V_1_12");
/*    */       } 
/* 53 */       for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)mapping.entrySet()) {
/* 54 */         final Component value = AdventureSerializer.parseComponent(((JsonElement)entry.getValue()).getAsString());
/* 56 */         Statistic statistic = new Statistic() {
/*    */             public String getId() {
/* 59 */               return (String)entry.getKey();
/*    */             }
/*    */             
/*    */             public Component display() {
/* 64 */               return value;
/*    */             }
/*    */             
/*    */             public boolean equals(Object obj) {
/* 69 */               if (obj instanceof Statistic)
/* 70 */                 return ((Statistic)obj).getId().equals(getId()); 
/* 72 */               return false;
/*    */             }
/*    */           };
/* 76 */         STATISTIC_MAP.put(entry.getKey(), statistic);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\stats\Statistics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */