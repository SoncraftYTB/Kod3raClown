/*    */ package com.github.retrooper.packetevents.protocol.world;
/*    */ 
/*    */ public enum MaterialType {
/* 22 */   AIR, STRUCTURAL_AIR, PORTAL, CLOTH_DECORATION, PLANT, WATER_PLANT, REPLACEABLE_PLANT, REPLACEABLE_FIREPROOF_PLANT, REPLACEABLE_WATER_PLANT, WATER, BUBBLE_COLUMN, LAVA, TOP_SNOW, FIRE, DECORATION, WEB, SCULK, BUILDABLE_GLASS, CLAY, DIRT, GRASS, ICE_SOLID, SAND, SPONGE, SHULKER_SHELL, WOOD, NETHER_WOOD, BAMBOO_SAPLING, BAMBOO, WOOL, EXPLOSIVE, LEAVES, GLASS, ICE, CACTUS, STONE, METAL, SNOW, HEAVY_METAL, BARRIER, PISTON, MOSS, VEGETABLE, EGG, CAKE, AMETHYST, POWDER_SNOW, FROGSPAWN, FROGLIGHT, DECORATED_POT;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\MaterialType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */