/*    */ package com.github.retrooper.packetevents.protocol.world;
/*    */ 
/*    */ import com.github.retrooper.packetevents.util.Vector3d;
/*    */ 
/*    */ public class Location {
/*    */   private Vector3d position;
/*    */   
/*    */   private float yaw;
/*    */   
/*    */   private float pitch;
/*    */   
/*    */   public Location(Vector3d position, float yaw, float pitch) {
/* 29 */     this.position = position;
/* 30 */     this.yaw = yaw;
/* 31 */     this.pitch = pitch;
/*    */   }
/*    */   
/*    */   public Location(double x, double y, double z, float yaw, float pitch) {
/* 35 */     this(new Vector3d(x, y, z), yaw, pitch);
/*    */   }
/*    */   
/*    */   public Vector3d getPosition() {
/* 39 */     return this.position;
/*    */   }
/*    */   
/*    */   public double getX() {
/* 43 */     return this.position.getX();
/*    */   }
/*    */   
/*    */   public double getY() {
/* 47 */     return this.position.getY();
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 51 */     return this.position.getZ();
/*    */   }
/*    */   
/*    */   public void setPosition(Vector3d position) {
/* 55 */     this.position = position;
/*    */   }
/*    */   
/*    */   public float getYaw() {
/* 59 */     return this.yaw;
/*    */   }
/*    */   
/*    */   public void setYaw(float yaw) {
/* 63 */     this.yaw = yaw;
/*    */   }
/*    */   
/*    */   public float getPitch() {
/* 67 */     return this.pitch;
/*    */   }
/*    */   
/*    */   public void setPitch(float pitch) {
/* 71 */     this.pitch = pitch;
/*    */   }
/*    */   
/*    */   public Location clone() {
/* 76 */     return new Location(this.position, this.yaw, this.pitch);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 81 */     return "Location {[" + this.position.toString() + "], yaw: " + this.yaw + ", pitch: " + this.pitch + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\Location.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */