/*     */ package com.github.retrooper.packetevents.protocol.world;
/*     */ 
/*     */ public enum BlockFace {
/*  32 */   DOWN(0, -1, 0),
/*  37 */   UP(0, 1, 0),
/*  42 */   NORTH(0, 0, -1),
/*  47 */   SOUTH(0, 0, 1),
/*  52 */   WEST(-1, 0, 0),
/*  57 */   EAST(1, 0, 0),
/*  62 */   OTHER((short)255, -1, -1, -1);
/*     */   
/*     */   private static final BlockFace[] VALUES;
/*     */   
/*     */   private static final BlockFace[] CARTESIAN_VALUES;
/*     */   
/*     */   final short faceValue;
/*     */   
/*     */   final int modX;
/*     */   
/*     */   final int modY;
/*     */   
/*     */   final int modZ;
/*     */   
/*     */   static {
/*  64 */     VALUES = values();
/*  65 */     CARTESIAN_VALUES = new BlockFace[] { DOWN, UP, NORTH, SOUTH, WEST, EAST };
/*     */   }
/*     */   
/*     */   BlockFace(short faceValue, int modX, int modY, int modZ) {
/*  73 */     this.faceValue = faceValue;
/*  74 */     this.modX = modX;
/*  75 */     this.modY = modY;
/*  76 */     this.modZ = modZ;
/*     */   }
/*     */   
/*     */   BlockFace(int modX, int modY, int modZ) {
/*  80 */     this.faceValue = (short)ordinal();
/*  81 */     this.modX = modX;
/*  82 */     this.modY = modY;
/*  83 */     this.modZ = modZ;
/*     */   }
/*     */   
/*     */   public static BlockFace getLegacyBlockFaceByValue(int face) {
/*  87 */     if (face == 255)
/*  87 */       return OTHER; 
/*  88 */     return VALUES[face % VALUES.length];
/*     */   }
/*     */   
/*     */   public static BlockFace getBlockFaceByValue(int face) {
/*  92 */     return VALUES[face % VALUES.length];
/*     */   }
/*     */   
/*     */   public int getModX() {
/*  96 */     return this.modX;
/*     */   }
/*     */   
/*     */   public int getModY() {
/* 100 */     return this.modY;
/*     */   }
/*     */   
/*     */   public int getModZ() {
/* 104 */     return this.modZ;
/*     */   }
/*     */   
/*     */   public BlockFace getOppositeFace() {
/* 108 */     switch (this) {
/*     */       case DOWN:
/* 110 */         return UP;
/*     */       case UP:
/* 112 */         return DOWN;
/*     */       case NORTH:
/* 114 */         return SOUTH;
/*     */       case SOUTH:
/* 116 */         return NORTH;
/*     */       case WEST:
/* 118 */         return EAST;
/*     */       case EAST:
/* 120 */         return WEST;
/*     */     } 
/* 122 */     return OTHER;
/*     */   }
/*     */   
/*     */   public BlockFace getCCW() {
/* 127 */     switch (this) {
/*     */       case NORTH:
/* 129 */         return WEST;
/*     */       case SOUTH:
/* 131 */         return EAST;
/*     */       case WEST:
/* 133 */         return SOUTH;
/*     */       case EAST:
/* 135 */         return NORTH;
/*     */     } 
/* 137 */     return OTHER;
/*     */   }
/*     */   
/*     */   public BlockFace getCW() {
/* 142 */     switch (this) {
/*     */       case NORTH:
/* 144 */         return EAST;
/*     */       case SOUTH:
/* 146 */         return WEST;
/*     */       case WEST:
/* 148 */         return NORTH;
/*     */       case EAST:
/* 150 */         return SOUTH;
/*     */     } 
/* 152 */     return OTHER;
/*     */   }
/*     */   
/*     */   public short getFaceValue() {
/* 157 */     return this.faceValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\BlockFace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */