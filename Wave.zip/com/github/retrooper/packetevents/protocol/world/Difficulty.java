/*    */ package com.github.retrooper.packetevents.protocol.world;
/*    */ 
/*    */ public enum Difficulty {
/* 22 */   PEACEFUL, EASY, NORMAL, HARD;
/*    */   
/*    */   private static final Difficulty[] VALUES;
/*    */   
/*    */   static {
/* 27 */     VALUES = values();
/*    */   }
/*    */   
/*    */   public int getId() {
/* 30 */     return ordinal();
/*    */   }
/*    */   
/*    */   public static Difficulty getById(int id) {
/* 34 */     return VALUES[id];
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\Difficulty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */