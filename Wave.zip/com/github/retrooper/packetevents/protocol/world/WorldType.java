/*    */ package com.github.retrooper.packetevents.protocol.world;
/*    */ 
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public enum WorldType {
/* 24 */   DEFAULT("default"),
/* 25 */   FLAT("flat"),
/* 26 */   LARGE_BIOMES("largeBiomes"),
/* 27 */   AMPLIFIED("amplified"),
/* 28 */   CUSTOMIZED("customized"),
/* 29 */   BUFFET("buffet"),
/* 30 */   DEBUG_ALL_BLOCK_STATES("debug_all_block_states"),
/* 31 */   DEFAULT_1_1("default_1_1");
/*    */   
/*    */   private static final WorldType[] VALUES;
/*    */   
/*    */   private final String name;
/*    */   
/*    */   static {
/* 33 */     VALUES = values();
/*    */   }
/*    */   
/*    */   WorldType(String name) {
/* 37 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 41 */     return this.name;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public static WorldType getByName(String name) {
/* 46 */     for (WorldType type : VALUES) {
/* 47 */       if (type.name.equals(name))
/* 48 */         return type; 
/*    */     } 
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\WorldType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */