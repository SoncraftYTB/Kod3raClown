/*    */ package com.github.retrooper.packetevents.protocol.world;
/*    */ 
/*    */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*    */ import com.github.retrooper.packetevents.util.Vector3i;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class WorldBlockPosition {
/*    */   private ResourceLocation world;
/*    */   
/*    */   private Vector3i blockPosition;
/*    */   
/*    */   public WorldBlockPosition(@NotNull ResourceLocation world, @NotNull Vector3i blockPosition) {
/* 30 */     this.world = world;
/* 31 */     this.blockPosition = blockPosition;
/*    */   }
/*    */   
/*    */   public WorldBlockPosition(@NotNull ResourceLocation world, int x, int y, int z) {
/* 35 */     this.world = world;
/* 36 */     this.blockPosition = new Vector3i(x, y, z);
/*    */   }
/*    */   
/*    */   public WorldBlockPosition(@NotNull Dimension dimension, @NotNull Vector3i blockPosition) {
/* 40 */     this.world = new ResourceLocation(dimension.getDimensionName());
/* 41 */     this.blockPosition = blockPosition;
/*    */   }
/*    */   
/*    */   public ResourceLocation getWorld() {
/* 45 */     return this.world;
/*    */   }
/*    */   
/*    */   public void setWorld(ResourceLocation world) {
/* 49 */     this.world = world;
/*    */   }
/*    */   
/*    */   public Vector3i getBlockPosition() {
/* 53 */     return this.blockPosition;
/*    */   }
/*    */   
/*    */   public void setBlockPosition(Vector3i blockPosition) {
/* 57 */     this.blockPosition = blockPosition;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\WorldBlockPosition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */