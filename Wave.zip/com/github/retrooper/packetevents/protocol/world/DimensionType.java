/*    */ package com.github.retrooper.packetevents.protocol.world;
/*    */ 
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ @Deprecated
/*    */ public enum DimensionType {
/* 25 */   NETHER(-1, "minecraft:the_nether"),
/* 26 */   OVERWORLD(0, "minecraft:overworld"),
/* 27 */   END(1, "minecraft:the_end"),
/* 28 */   CUSTOM(-999, "minecraft:custom");
/*    */   
/*    */   private static final DimensionType[] VALUES;
/*    */   
/*    */   private final int id;
/*    */   
/*    */   private final String name;
/*    */   
/*    */   static {
/* 30 */     VALUES = values();
/*    */   }
/*    */   
/*    */   DimensionType(int id, String name) {
/* 36 */     this.id = id;
/* 37 */     this.name = name;
/*    */   }
/*    */   
/*    */   public static DimensionType getById(int id) {
/* 41 */     return VALUES[id + 1];
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public static DimensionType getByName(String name) {
/* 46 */     for (DimensionType type : VALUES) {
/* 47 */       if (type.name.equals(name))
/* 48 */         return type; 
/*    */     } 
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 55 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 59 */     return this.name;
/*    */   }
/*    */   
/*    */   public static boolean isFlat(String levelType) {
/* 63 */     return WorldType.FLAT.getName().equals(levelType);
/*    */   }
/*    */   
/*    */   public static boolean isDebug(String levelType) {
/* 67 */     return WorldType.DEBUG_ALL_BLOCK_STATES.getName().equals(levelType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\DimensionType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */