/*    */ package com.github.retrooper.packetevents.protocol.world;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.nbt.NBT;
/*    */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*    */ import com.github.retrooper.packetevents.protocol.nbt.NBTString;
/*    */ 
/*    */ public class Dimension {
/*    */   private int id;
/*    */   
/*    */   private NBTCompound attributes;
/*    */   
/*    */   @Deprecated
/*    */   public Dimension(DimensionType type) {
/* 30 */     this.id = type.getId();
/* 31 */     this.attributes = new NBTCompound();
/*    */   }
/*    */   
/*    */   public Dimension(int id) {
/* 35 */     this.id = id;
/* 36 */     this.attributes = new NBTCompound();
/*    */   }
/*    */   
/*    */   public Dimension(NBTCompound attributes) {
/* 40 */     this.attributes = attributes;
/*    */   }
/*    */   
/*    */   public String getDimensionName() {
/* 44 */     return getAttributes().getStringTagValueOrDefault("effects", "");
/*    */   }
/*    */   
/*    */   public void setDimensionName(String name) {
/* 48 */     NBTCompound compound = getAttributes();
/* 49 */     compound.setTag("effects", (NBT)new NBTString(name));
/* 50 */     setAttributes(compound);
/*    */   }
/*    */   
/*    */   public int getId() {
/* 54 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(int id) {
/* 58 */     this.id = id;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public DimensionType getType() {
/* 63 */     return DimensionType.getById(this.id);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void setType(DimensionType type) {
/* 68 */     this.id = type.getId();
/*    */   }
/*    */   
/*    */   public NBTCompound getAttributes() {
/* 72 */     return this.attributes;
/*    */   }
/*    */   
/*    */   public void setAttributes(NBTCompound attributes) {
/* 76 */     this.attributes = attributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\Dimension.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */