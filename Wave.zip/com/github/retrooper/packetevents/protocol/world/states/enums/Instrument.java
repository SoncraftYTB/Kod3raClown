/*    */ package com.github.retrooper.packetevents.protocol.world.states.enums;
/*    */ 
/*    */ public enum Instrument {
/* 22 */   BANJO, BASEDRUM, BASS, BELL, BIT, CHIME, COW_BELL, DIDGERIDOO, FLUTE, GUITAR, HARP, HAT, IRON_XYLOPHONE, PLING, SNARE, XYLOPHONE, ZOMBIE, SKELETON, CREEPER, DRAGON, WITHER_SKELETON, PIGLIN, CUSTOM_HEAD;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\enums\Instrument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */