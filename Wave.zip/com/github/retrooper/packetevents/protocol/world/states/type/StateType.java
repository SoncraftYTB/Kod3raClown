/*     */ package com.github.retrooper.packetevents.protocol.world.states.type;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.protocol.world.MaterialType;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState;
/*     */ import java.util.Objects;
/*     */ 
/*     */ public class StateType {
/*     */   private final String name;
/*     */   
/*     */   private final float blastResistance;
/*     */   
/*     */   private final float hardness;
/*     */   
/*     */   private final boolean isSolid;
/*     */   
/*     */   private final boolean isBlocking;
/*     */   
/*     */   private final boolean isAir;
/*     */   
/*     */   private final boolean requiresCorrectTool;
/*     */   
/*     */   private final boolean exceedsCube;
/*     */   
/*     */   private final MaterialType materialType;
/*     */   
/*     */   public StateType(String name, float blastResistance, float hardness, boolean isSolid, boolean isBlocking, boolean isAir, boolean requiresCorrectTool, boolean isShapeExceedsCube, MaterialType materialType) {
/*  40 */     this.name = name;
/*  41 */     this.blastResistance = blastResistance;
/*  42 */     this.hardness = hardness;
/*  43 */     this.isSolid = isSolid;
/*  44 */     this.isBlocking = isBlocking;
/*  45 */     this.isAir = isAir;
/*  46 */     this.requiresCorrectTool = requiresCorrectTool;
/*  47 */     this.exceedsCube = isShapeExceedsCube;
/*  48 */     this.materialType = materialType;
/*     */   }
/*     */   
/*     */   public WrappedBlockState createBlockState() {
/*  52 */     return WrappedBlockState.getDefaultState(PacketEvents.getAPI().getServerManager().getVersion().toClientVersion(), this);
/*     */   }
/*     */   
/*     */   public WrappedBlockState createBlockState(ClientVersion version) {
/*  56 */     return WrappedBlockState.getDefaultState(version, this);
/*     */   }
/*     */   
/*     */   public String getName() {
/*  60 */     return this.name;
/*     */   }
/*     */   
/*     */   public float getBlastResistance() {
/*  64 */     return this.blastResistance;
/*     */   }
/*     */   
/*     */   public float getHardness() {
/*  68 */     return this.hardness;
/*     */   }
/*     */   
/*     */   public boolean isSolid() {
/*  72 */     return this.isSolid;
/*     */   }
/*     */   
/*     */   public boolean isBlocking() {
/*  76 */     return this.isBlocking;
/*     */   }
/*     */   
/*     */   public boolean isAir() {
/*  80 */     return this.isAir;
/*     */   }
/*     */   
/*     */   public boolean isRequiresCorrectTool() {
/*  84 */     return this.requiresCorrectTool;
/*     */   }
/*     */   
/*     */   public boolean isReplaceable() {
/*  88 */     switch (getMaterialType()) {
/*     */       case AIR:
/*     */       case STRUCTURAL_AIR:
/*     */       case REPLACEABLE_PLANT:
/*     */       case REPLACEABLE_FIREPROOF_PLANT:
/*     */       case REPLACEABLE_WATER_PLANT:
/*     */       case WATER:
/*     */       case BUBBLE_COLUMN:
/*     */       case LAVA:
/*     */       case TOP_SNOW:
/*     */       case FIRE:
/*  99 */         return true;
/*     */     } 
/* 101 */     return false;
/*     */   }
/*     */   
/*     */   public boolean exceedsCube() {
/* 106 */     return this.exceedsCube;
/*     */   }
/*     */   
/*     */   public MaterialType getMaterialType() {
/* 110 */     return this.materialType;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 115 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 120 */     if (this == o)
/* 120 */       return true; 
/* 121 */     if (o == null || getClass() != o.getClass())
/* 121 */       return false; 
/* 122 */     StateType stateType = (StateType)o;
/* 123 */     return (Float.compare(this.blastResistance, stateType.blastResistance) == 0 && 
/* 124 */       Float.compare(this.hardness, stateType.hardness) == 0 && this.isSolid == stateType.isSolid && this.isBlocking == stateType.isBlocking && this.isAir == stateType.isAir && this.requiresCorrectTool == stateType.requiresCorrectTool && this.exceedsCube == stateType.exceedsCube && 
/*     */       
/* 130 */       Objects.equals(this.name, stateType.name) && this.materialType == stateType.materialType);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 136 */     return Objects.hash(new Object[] { this.name, Float.valueOf(this.blastResistance), Float.valueOf(this.hardness), Boolean.valueOf(this.isSolid), Boolean.valueOf(this.isBlocking), Boolean.valueOf(this.isAir), Boolean.valueOf(this.requiresCorrectTool), Boolean.valueOf(this.exceedsCube), this.materialType });
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\type\StateType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */