/*     */ package com.github.retrooper.packetevents.protocol.world.states.type;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.world.BlockFace;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Attachment;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Axis;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.East;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Face;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Half;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Hinge;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Instrument;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Leaves;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Mode;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.North;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Orientation;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Part;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.SculkSensorPhase;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Shape;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.South;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Thickness;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Tilt;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.TrialSpawnerState;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.Type;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.VerticalDirection;
/*     */ import com.github.retrooper.packetevents.protocol.world.states.enums.West;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ public enum StateValue {
/*  28 */   AGE("age", Integer::parseInt),
/*  29 */   ATTACHED("attached", Boolean::parseBoolean),
/*  30 */   ATTACHMENT("attachment", Attachment::valueOf),
/*  31 */   AXIS("axis", Axis::valueOf),
/*  32 */   BERRIES("berries", Boolean::parseBoolean),
/*  33 */   BITES("bites", Integer::parseInt),
/*  34 */   BLOOM("bloom", Boolean::parseBoolean),
/*  35 */   BOTTOM("bottom", Boolean::parseBoolean),
/*  36 */   CANDLES("candles", Integer::parseInt),
/*  37 */   CAN_SUMMON("can_summon", Boolean::parseBoolean),
/*  38 */   CHARGES("charges", Integer::parseInt),
/*  39 */   CONDITIONAL("conditional", Boolean::parseBoolean),
/*  40 */   DELAY("delay", Integer::parseInt),
/*  41 */   DISARMED("disarmed", Boolean::parseBoolean),
/*  42 */   DISTANCE("distance", Integer::parseInt),
/*  43 */   DOWN("down", Boolean::parseBoolean),
/*  44 */   DRAG("drag", Boolean::parseBoolean),
/*  45 */   DUSTED("dusted", Integer::parseInt),
/*  46 */   EAST("east", East::valueOf),
/*  47 */   EGGS("eggs", Integer::parseInt),
/*  48 */   ENABLED("enabled", Boolean::parseBoolean),
/*  49 */   EXTENDED("extended", Boolean::parseBoolean),
/*  50 */   EYE("eye", Boolean::parseBoolean),
/*  51 */   FACE("face", Face::valueOf),
/*  52 */   FACING("facing", BlockFace::valueOf),
/*  53 */   FLOWER_AMOUNT("flower_amount", Integer::parseInt),
/*  54 */   HALF("half", Half::valueOf),
/*  55 */   HANGING("hanging", Boolean::parseBoolean),
/*  56 */   HAS_BOOK("has_book", Boolean::parseBoolean),
/*  57 */   HAS_BOTTLE_0("has_bottle_0", Boolean::parseBoolean),
/*  58 */   HAS_BOTTLE_1("has_bottle_1", Boolean::parseBoolean),
/*  59 */   HAS_BOTTLE_2("has_bottle_2", Boolean::parseBoolean),
/*  60 */   HAS_RECORD("has_record", Boolean::parseBoolean),
/*  61 */   HATCH("hatch", Integer::parseInt),
/*  62 */   HINGE("hinge", Hinge::valueOf),
/*  63 */   HONEY_LEVEL("honey_level", Integer::parseInt),
/*  64 */   IN_WALL("in_wall", Boolean::parseBoolean),
/*  65 */   INSTRUMENT("instrument", Instrument::valueOf),
/*  66 */   INVERTED("inverted", Boolean::parseBoolean),
/*  67 */   LAYERS("layers", Integer::parseInt),
/*  68 */   LEAVES("leaves", Leaves::valueOf),
/*  69 */   LEVEL("level", Integer::parseInt),
/*  70 */   LIT("lit", Boolean::parseBoolean),
/*  71 */   LOCKED("locked", Boolean::parseBoolean),
/*  72 */   MODE("mode", Mode::valueOf),
/*  73 */   MOISTURE("moisture", Integer::parseInt),
/*  74 */   NORTH("north", North::valueOf),
/*  75 */   NOTE("note", Integer::parseInt),
/*  76 */   OCCUPIED("occupied", Boolean::parseBoolean),
/*  77 */   OPEN("open", Boolean::parseBoolean),
/*  78 */   ORIENTATION("orientation", Orientation::valueOf),
/*  79 */   PART("part", Part::valueOf),
/*  80 */   PERSISTENT("persistent", Boolean::parseBoolean),
/*  81 */   PICKLES("pickles", Integer::parseInt),
/*  82 */   POWER("power", Integer::parseInt),
/*  83 */   POWERED("powered", Boolean::parseBoolean),
/*  84 */   ROTATION("rotation", Integer::parseInt),
/*  85 */   SCULK_SENSOR_PHASE("sculk_sensor_phase", SculkSensorPhase::valueOf),
/*  86 */   SHAPE("shape", Shape::valueOf),
/*  87 */   SHORT("short", Boolean::parseBoolean),
/*  88 */   SHRIEKING("shrieking", Boolean::parseBoolean),
/*  89 */   SIGNAL_FIRE("signal_fire", Boolean::parseBoolean),
/*  90 */   SLOT_0_OCCUPIED("slot_0_occupied", Boolean::parseBoolean),
/*  91 */   SLOT_1_OCCUPIED("slot_1_occupied", Boolean::parseBoolean),
/*  92 */   SLOT_2_OCCUPIED("slot_2_occupied", Boolean::parseBoolean),
/*  93 */   SLOT_3_OCCUPIED("slot_3_occupied", Boolean::parseBoolean),
/*  94 */   SLOT_4_OCCUPIED("slot_4_occupied", Boolean::parseBoolean),
/*  95 */   SLOT_5_OCCUPIED("slot_5_occupied", Boolean::parseBoolean),
/*  96 */   SNOWY("snowy", Boolean::parseBoolean),
/*  97 */   STAGE("stage", Integer::parseInt),
/*  98 */   SOUTH("south", South::valueOf),
/*  99 */   THICKNESS("thickness", Thickness::valueOf),
/* 100 */   TILT("tilt", Tilt::valueOf),
/* 101 */   TRIGGERED("triggered", Boolean::parseBoolean),
/* 102 */   TYPE("type", Type::valueOf),
/* 103 */   UNSTABLE("unstable", Boolean::parseBoolean),
/* 104 */   UP("up", Boolean::parseBoolean),
/* 105 */   VERTICAL_DIRECTION("vertical_direction", VerticalDirection::valueOf),
/* 106 */   WATERLOGGED("waterlogged", Boolean::parseBoolean),
/* 107 */   WEST("west", West::valueOf),
/* 108 */   CRACKED("cracked", Boolean::parseBoolean),
/* 109 */   CRAFTING("crafting", Boolean::parseBoolean),
/* 110 */   TRIAL_SPAWNER_STATE("trial_spawner_state", TrialSpawnerState::valueOf);
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final Function<String, Object> parser;
/*     */   
/*     */   private static final HashMap<String, StateValue> values;
/*     */   
/*     */   static {
/* 115 */     values = new HashMap<>();
/* 127 */     for (StateValue value : values())
/* 128 */       values.put(value.name, value); 
/*     */   }
/*     */   
/*     */   StateValue(String name, Function<String, Object> parser) {
/*     */     this.name = name;
/*     */     this.parser = parser;
/*     */   }
/*     */   
/*     */   public static StateValue byName(String name) {
/*     */     return values.get(name);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 133 */     return this.name;
/*     */   }
/*     */   
/*     */   public Function<String, Object> getParser() {
/* 137 */     return this.parser;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\type\StateValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */