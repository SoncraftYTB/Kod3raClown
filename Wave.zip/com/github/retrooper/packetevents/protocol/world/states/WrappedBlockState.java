/*      */ package com.github.retrooper.packetevents.protocol.world.states;
/*      */ 
/*      */ import com.github.retrooper.packetevents.PacketEvents;
/*      */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*      */ import com.github.retrooper.packetevents.protocol.world.BlockFace;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Attachment;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Axis;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Bloom;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.East;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Face;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Half;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Hinge;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Instrument;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Leaves;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Mode;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.North;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Orientation;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Part;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.SculkSensorPhase;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Shape;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.South;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Thickness;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Tilt;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.TrialSpawnerState;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.Type;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.VerticalDirection;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.enums.West;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.type.StateType;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.type.StateTypes;
/*      */ import com.github.retrooper.packetevents.protocol.world.states.type.StateValue;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.util.EnumMap;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ 
/*      */ public class WrappedBlockState {
/*   30 */   private static final WrappedBlockState AIR = new WrappedBlockState(StateTypes.AIR, new EnumMap<>(StateValue.class), 0, (byte)0);
/*      */   
/*   31 */   private static final Map<Byte, Map<String, WrappedBlockState>> BY_STRING = new HashMap<>();
/*      */   
/*   32 */   private static final Map<Byte, Map<Integer, WrappedBlockState>> BY_ID = new HashMap<>();
/*      */   
/*   33 */   private static final Map<Byte, Map<WrappedBlockState, String>> INTO_STRING = new HashMap<>();
/*      */   
/*   34 */   private static final Map<Byte, Map<WrappedBlockState, Integer>> INTO_ID = new HashMap<>();
/*      */   
/*   35 */   private static final Map<Byte, Map<StateType, WrappedBlockState>> DEFAULT_STATES = new HashMap<>();
/*      */   
/*   37 */   private static final Map<String, String> STRING_UPDATER = new HashMap<>();
/*      */   
/*   49 */   private static Map<Map<StateValue, Object>, Map<StateValue, Object>> cache = new HashMap<>(4845, 70.0F);
/*      */   
/*      */   int globalID;
/*      */   
/*      */   StateType type;
/*      */   
/*      */   static {
/*   52 */     STRING_UPDATER.put("grass_path", "dirt_path");
/*   54 */     loadLegacy();
/*   55 */     for (ClientVersion version : ClientVersion.values()) {
/*   56 */       if (version.isNewerThanOrEquals(ClientVersion.V_1_13) && version.isRelease())
/*   57 */         loadModern(version); 
/*      */     } 
/*   61 */     cache = null;
/*      */   }
/*      */   
/*   66 */   Map<StateValue, Object> data = new HashMap<>(0);
/*      */   
/*      */   boolean hasClonedData = false;
/*      */   
/*      */   byte mappingsIndex;
/*      */   
/*      */   public WrappedBlockState(StateType type, String[] data, int globalID, byte mappingsIndex) {
/*   71 */     this.type = type;
/*   72 */     this.globalID = globalID;
/*   74 */     if (data != null)
/*   75 */       for (String s : data) {
/*      */         try {
/*   77 */           String[] split = s.split("=");
/*   78 */           StateValue value = StateValue.byName(split[0]);
/*   79 */           this.data.put(value, value.getParser().apply(split[1].toUpperCase(Locale.ROOT)));
/*   80 */         } catch (Exception e) {
/*   81 */           e.printStackTrace();
/*   82 */           System.out.println("Failed to parse block state: " + s);
/*      */         } 
/*      */       }  
/*   88 */     this.data = cache.computeIfAbsent(this.data, key -> key);
/*   89 */     this.mappingsIndex = mappingsIndex;
/*      */   }
/*      */   
/*      */   public WrappedBlockState(StateType type, Map<StateValue, Object> data, int globalID, byte mappingsIndex) {
/*   93 */     this.globalID = globalID;
/*   94 */     this.type = type;
/*   95 */     this.data = data;
/*   96 */     this.mappingsIndex = mappingsIndex;
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public static WrappedBlockState getByGlobalId(int globalID) {
/*  101 */     return getByGlobalId(PacketEvents.getAPI().getServerManager().getVersion().toClientVersion(), globalID);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public static WrappedBlockState getByGlobalId(ClientVersion version, int globalID) {
/*  106 */     if (globalID == 0)
/*  106 */       return AIR; 
/*  107 */     byte mappingsIndex = getMappingsIndex(version);
/*  108 */     return ((WrappedBlockState)((Map)BY_ID.get(Byte.valueOf(mappingsIndex))).getOrDefault(Integer.valueOf(globalID), AIR)).clone();
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public static WrappedBlockState getByString(String string) {
/*  113 */     return getByString(PacketEvents.getAPI().getServerManager().getVersion().toClientVersion(), string);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public static WrappedBlockState getByString(ClientVersion version, String string) {
/*  118 */     byte mappingsIndex = getMappingsIndex(version);
/*  119 */     return ((WrappedBlockState)((Map)BY_STRING.get(Byte.valueOf(mappingsIndex))).getOrDefault(string.replace("minecraft:", ""), AIR)).clone();
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public static WrappedBlockState getDefaultState(StateType type) {
/*  124 */     return getDefaultState(PacketEvents.getAPI().getServerManager().getVersion().toClientVersion(), type);
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public static WrappedBlockState getDefaultState(ClientVersion version, StateType type) {
/*  129 */     if (type == StateTypes.AIR)
/*  129 */       return AIR; 
/*  130 */     byte mappingsIndex = getMappingsIndex(version);
/*  131 */     WrappedBlockState state = (WrappedBlockState)((Map)DEFAULT_STATES.get(Byte.valueOf(mappingsIndex))).get(type);
/*  132 */     if (state == null) {
/*  133 */       PacketEvents.getAPI().getLogger().config("Default state for " + type.getName() + " is null. Returning AIR");
/*  134 */       return AIR;
/*      */     } 
/*  136 */     return state.clone();
/*      */   }
/*      */   
/*      */   private static byte getMappingsIndex(ClientVersion version) {
/*  140 */     if (version.isOlderThan(ClientVersion.V_1_13))
/*  141 */       return 0; 
/*  142 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_13_1))
/*  143 */       return 1; 
/*  144 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_13_2))
/*  145 */       return 2; 
/*  146 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_14_4))
/*  147 */       return 3; 
/*  148 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_15_2))
/*  149 */       return 4; 
/*  150 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_16_1))
/*  151 */       return 5; 
/*  152 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_16_4))
/*  153 */       return 6; 
/*  154 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_18_2))
/*  155 */       return 7; 
/*  156 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_19_1))
/*  157 */       return 8; 
/*  158 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_19_3))
/*  159 */       return 9; 
/*  160 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_19_4))
/*  161 */       return 10; 
/*  162 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_20))
/*  163 */       return 11; 
/*  164 */     if (version.isOlderThanOrEquals(ClientVersion.V_1_20_2))
/*  165 */       return 12; 
/*  168 */     return 13;
/*      */   }
/*      */   
/*      */   private static void loadLegacy() {
/*  173 */     Map<Integer, WrappedBlockState> stateByIdMap = new HashMap<>();
/*  174 */     Map<WrappedBlockState, Integer> stateToIdMap = new HashMap<>();
/*  175 */     Map<String, WrappedBlockState> stateByStringMap = new HashMap<>();
/*  176 */     Map<WrappedBlockState, String> stateToStringMap = new HashMap<>();
/*  177 */     Map<StateType, WrappedBlockState> stateTypeToBlockStateMap = new HashMap<>();
/*      */     try {
/*  179 */       InputStream mappings = PacketEvents.getAPI().getSettings().getResourceProvider().apply("assets/mappings/block/legacy_block_mappings.txt");
/*  180 */       BufferedReader reader = new BufferedReader(new InputStreamReader(mappings));
/*      */       String line;
/*  182 */       while ((line = reader.readLine()) != null) {
/*  183 */         String[] split = line.split(",");
/*  184 */         int id = Integer.parseInt(split[0]);
/*  185 */         int data = Integer.parseInt(split[1]);
/*  186 */         int combinedID = id << 4 | data;
/*  188 */         String fullString = line.substring(split[0].length() + split[1].length() + 2);
/*  190 */         int endIndex = split[2].indexOf("[");
/*  192 */         String blockString = split[2].substring(0, (endIndex != -1) ? endIndex : split[2].length());
/*  194 */         StateType type = StateTypes.getByName(blockString);
/*  196 */         String[] dataStrings = null;
/*  197 */         if (endIndex != -1)
/*  198 */           dataStrings = line.substring(split[0].length() + split[1].length() + 2 + blockString.length() + 1, line.length() - 1).split(","); 
/*  201 */         if (type == null)
/*  202 */           PacketEvents.getAPI().getLogger().warning("Could not find type for " + blockString); 
/*  205 */         WrappedBlockState state = new WrappedBlockState(type, dataStrings, combinedID, (byte)0);
/*  207 */         stateByIdMap.put(Integer.valueOf(combinedID), state);
/*  208 */         stateToStringMap.put(state, fullString);
/*  209 */         stateToIdMap.put(state, Integer.valueOf(combinedID));
/*  214 */         stateByStringMap.putIfAbsent(fullString, state);
/*  217 */         stateTypeToBlockStateMap.putIfAbsent(type, state);
/*      */       } 
/*  219 */     } catch (IOException e) {
/*  220 */       PacketEvents.getAPI().getLogManager().debug("Palette reading failed! Unsupported version?");
/*  221 */       e.printStackTrace();
/*      */     } 
/*  223 */     BY_ID.put(Byte.valueOf((byte)0), stateByIdMap);
/*  224 */     INTO_ID.put(Byte.valueOf((byte)0), stateToIdMap);
/*  225 */     BY_STRING.put(Byte.valueOf((byte)0), stateByStringMap);
/*  226 */     INTO_STRING.put(Byte.valueOf((byte)0), stateToStringMap);
/*  227 */     DEFAULT_STATES.put(Byte.valueOf((byte)0), stateTypeToBlockStateMap);
/*      */   }
/*      */   
/*      */   private static void loadModern(ClientVersion version) {
/*  232 */     byte mappingsIndex = getMappingsIndex(version);
/*  233 */     if (BY_ID.containsKey(Byte.valueOf(mappingsIndex)))
/*      */       return; 
/*  237 */     InputStream mappings = PacketEvents.getAPI().getSettings().getResourceProvider().apply("assets/mappings/block/modern_block_mappings.txt");
/*  238 */     BufferedReader reader = new BufferedReader(new InputStreamReader(mappings));
/*  240 */     Map<Integer, WrappedBlockState> stateByIdMap = new HashMap<>();
/*  241 */     Map<WrappedBlockState, Integer> stateToIdMap = new HashMap<>();
/*  242 */     Map<String, WrappedBlockState> stateByStringMap = new HashMap<>();
/*  243 */     Map<WrappedBlockState, String> stateToStringMap = new HashMap<>();
/*  244 */     Map<StateType, WrappedBlockState> stateTypeToBlockStateMap = new HashMap<>();
/*  246 */     String versionString = version.getReleaseName();
/*  247 */     boolean found = false;
/*  248 */     int id = 0;
/*      */     try {
/*      */       String fullBlockString;
/*  252 */       while ((fullBlockString = reader.readLine()) != null) {
/*  253 */         if (!found) {
/*  254 */           if (fullBlockString.equals(versionString))
/*  255 */             found = true; 
/*      */           continue;
/*      */         } 
/*  259 */         if (fullBlockString.charAt(1) == '.')
/*      */           break; 
/*  264 */         boolean isDefault = fullBlockString.startsWith("*");
/*  265 */         fullBlockString = fullBlockString.replace("*", "");
/*  266 */         int index = fullBlockString.indexOf("[");
/*  268 */         String blockString = fullBlockString.substring(0, (index == -1) ? fullBlockString.length() : index);
/*  269 */         StateType type = StateTypes.getByName(blockString);
/*  271 */         if (type == null) {
/*  273 */           for (Map.Entry<String, String> stringEntry : STRING_UPDATER.entrySet())
/*  274 */             blockString = blockString.replace(stringEntry.getKey(), stringEntry.getValue()); 
/*  277 */           type = StateTypes.getByName(blockString);
/*  279 */           if (type == null)
/*  280 */             PacketEvents.getAPI().getLogger().warning("Unknown block type: " + fullBlockString); 
/*      */         } 
/*  284 */         String[] data = null;
/*  285 */         if (index != -1)
/*  286 */           data = fullBlockString.substring(index + 1, fullBlockString.length() - 1).split(","); 
/*  289 */         WrappedBlockState state = new WrappedBlockState(type, data, id, mappingsIndex);
/*  291 */         if (isDefault)
/*  292 */           stateTypeToBlockStateMap.put(state.getType(), state); 
/*  295 */         stateByStringMap.put(fullBlockString, state);
/*  296 */         stateByIdMap.put(Integer.valueOf(id), state);
/*  297 */         stateToStringMap.put(state, fullBlockString);
/*  298 */         stateToIdMap.put(state, Integer.valueOf(id));
/*  300 */         id++;
/*      */       } 
/*  302 */     } catch (Exception e) {
/*  303 */       e.printStackTrace();
/*      */     } 
/*  306 */     BY_ID.put(Byte.valueOf(mappingsIndex), stateByIdMap);
/*  307 */     INTO_ID.put(Byte.valueOf(mappingsIndex), stateToIdMap);
/*  308 */     BY_STRING.put(Byte.valueOf(mappingsIndex), stateByStringMap);
/*  309 */     INTO_STRING.put(Byte.valueOf(mappingsIndex), stateToStringMap);
/*  310 */     DEFAULT_STATES.put(Byte.valueOf(mappingsIndex), stateTypeToBlockStateMap);
/*      */   }
/*      */   
/*      */   public WrappedBlockState clone() {
/*  315 */     return new WrappedBlockState(this.type, this.data, this.globalID, this.mappingsIndex);
/*      */   }
/*      */   
/*      */   public boolean equals(Object o) {
/*  320 */     if (this == o)
/*  320 */       return true; 
/*  321 */     if (!(o instanceof WrappedBlockState))
/*  321 */       return false; 
/*  322 */     WrappedBlockState that = (WrappedBlockState)o;
/*  324 */     return (this.type == that.type && this.data.equals(that.data));
/*      */   }
/*      */   
/*      */   public int hashCode() {
/*  330 */     return Objects.hash(new Object[] { this.type, this.data });
/*      */   }
/*      */   
/*      */   public StateType getType() {
/*  334 */     return this.type;
/*      */   }
/*      */   
/*      */   public int getAge() {
/*  339 */     return ((Integer)this.data.get(StateValue.AGE)).intValue();
/*      */   }
/*      */   
/*      */   public void setAge(int age) {
/*  343 */     checkIfCloneNeeded();
/*  344 */     this.data.put(StateValue.AGE, Integer.valueOf(age));
/*  345 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isAttached() {
/*  349 */     return ((Boolean)this.data.get(StateValue.ATTACHED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setAttached(boolean attached) {
/*  353 */     checkIfCloneNeeded();
/*  354 */     this.data.put(StateValue.ATTACHED, Boolean.valueOf(attached));
/*  355 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Attachment getAttachment() {
/*  359 */     return (Attachment)this.data.get(StateValue.ATTACHMENT);
/*      */   }
/*      */   
/*      */   public void setAttachment(Attachment attachment) {
/*  363 */     checkIfCloneNeeded();
/*  364 */     this.data.put(StateValue.ATTACHMENT, attachment);
/*  365 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Axis getAxis() {
/*  369 */     return (Axis)this.data.get(StateValue.AXIS);
/*      */   }
/*      */   
/*      */   public void setAxis(Axis axis) {
/*  373 */     checkIfCloneNeeded();
/*  374 */     this.data.put(StateValue.AXIS, axis);
/*  375 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isBerries() {
/*  379 */     return ((Boolean)this.data.get(StateValue.BERRIES)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setBerries(boolean berries) {
/*  383 */     checkIfCloneNeeded();
/*  384 */     this.data.put(StateValue.BERRIES, Boolean.valueOf(berries));
/*  385 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getBites() {
/*  389 */     return ((Integer)this.data.get(StateValue.BITES)).intValue();
/*      */   }
/*      */   
/*      */   public void setBites(int bites) {
/*  393 */     checkIfCloneNeeded();
/*  394 */     this.data.put(StateValue.BITES, Integer.valueOf(bites));
/*  395 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isBottom() {
/*  399 */     return ((Boolean)this.data.get(StateValue.BOTTOM)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setBottom(boolean bottom) {
/*  403 */     checkIfCloneNeeded();
/*  404 */     this.data.put(StateValue.BOTTOM, Boolean.valueOf(bottom));
/*  405 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getCandles() {
/*  409 */     return ((Integer)this.data.get(StateValue.CANDLES)).intValue();
/*      */   }
/*      */   
/*      */   public void setCandles(int candles) {
/*  413 */     checkIfCloneNeeded();
/*  414 */     this.data.put(StateValue.CANDLES, Integer.valueOf(candles));
/*  415 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getCharges() {
/*  419 */     return ((Integer)this.data.get(StateValue.CHARGES)).intValue();
/*      */   }
/*      */   
/*      */   public void setCharges(int charges) {
/*  423 */     checkIfCloneNeeded();
/*  424 */     this.data.put(StateValue.CHARGES, Integer.valueOf(charges));
/*  425 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isConditional() {
/*  429 */     return ((Boolean)this.data.get(StateValue.CONDITIONAL)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setConditional(boolean conditional) {
/*  433 */     checkIfCloneNeeded();
/*  434 */     this.data.put(StateValue.CONDITIONAL, Boolean.valueOf(conditional));
/*  435 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getDelay() {
/*  439 */     return ((Integer)this.data.get(StateValue.DELAY)).intValue();
/*      */   }
/*      */   
/*      */   public void setDelay(int delay) {
/*  443 */     checkIfCloneNeeded();
/*  444 */     this.data.put(StateValue.DELAY, Integer.valueOf(delay));
/*  445 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isDisarmed() {
/*  449 */     return ((Boolean)this.data.get(StateValue.DISARMED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setDisarmed(boolean disarmed) {
/*  453 */     checkIfCloneNeeded();
/*  454 */     this.data.put(StateValue.DISARMED, Boolean.valueOf(disarmed));
/*  455 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getDistance() {
/*  459 */     return ((Integer)this.data.get(StateValue.DISTANCE)).intValue();
/*      */   }
/*      */   
/*      */   public void setDistance(int distance) {
/*  463 */     checkIfCloneNeeded();
/*  464 */     this.data.put(StateValue.DISTANCE, Integer.valueOf(distance));
/*  465 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isDown() {
/*  469 */     return ((Boolean)this.data.get(StateValue.DOWN)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setDown(boolean down) {
/*  473 */     checkIfCloneNeeded();
/*  474 */     this.data.put(StateValue.DOWN, Boolean.valueOf(down));
/*  475 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isDrag() {
/*  479 */     return ((Boolean)this.data.get(StateValue.DRAG)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setDrag(boolean drag) {
/*  483 */     checkIfCloneNeeded();
/*  484 */     this.data.put(StateValue.DRAG, Boolean.valueOf(drag));
/*  485 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getEggs() {
/*  489 */     return ((Integer)this.data.get(StateValue.EGGS)).intValue();
/*      */   }
/*      */   
/*      */   public void setEggs(int eggs) {
/*  493 */     checkIfCloneNeeded();
/*  494 */     this.data.put(StateValue.EGGS, Integer.valueOf(eggs));
/*  495 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isEnabled() {
/*  499 */     return ((Boolean)this.data.get(StateValue.ENABLED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setEnabled(boolean enabled) {
/*  503 */     checkIfCloneNeeded();
/*  504 */     this.data.put(StateValue.ENABLED, Boolean.valueOf(enabled));
/*  505 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isExtended() {
/*  509 */     return ((Boolean)this.data.get(StateValue.EXTENDED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setExtended(boolean extended) {
/*  513 */     checkIfCloneNeeded();
/*  514 */     this.data.put(StateValue.EXTENDED, Boolean.valueOf(extended));
/*  515 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isEye() {
/*  519 */     return ((Boolean)this.data.get(StateValue.EYE)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setEye(boolean eye) {
/*  523 */     checkIfCloneNeeded();
/*  524 */     this.data.put(StateValue.EYE, Boolean.valueOf(eye));
/*  525 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Face getFace() {
/*  529 */     return (Face)this.data.get(StateValue.FACE);
/*      */   }
/*      */   
/*      */   public void setFace(Face face) {
/*  533 */     checkIfCloneNeeded();
/*  534 */     this.data.put(StateValue.FACE, face);
/*  535 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public BlockFace getFacing() {
/*  539 */     return (BlockFace)this.data.get(StateValue.FACING);
/*      */   }
/*      */   
/*      */   public void setFacing(BlockFace facing) {
/*  543 */     checkIfCloneNeeded();
/*  544 */     this.data.put(StateValue.FACING, facing);
/*  545 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Half getHalf() {
/*  549 */     return (Half)this.data.get(StateValue.HALF);
/*      */   }
/*      */   
/*      */   public void setHalf(Half half) {
/*  553 */     checkIfCloneNeeded();
/*  554 */     this.data.put(StateValue.HALF, half);
/*  555 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isHanging() {
/*  559 */     return ((Boolean)this.data.get(StateValue.HANGING)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setHanging(boolean hanging) {
/*  563 */     checkIfCloneNeeded();
/*  564 */     this.data.put(StateValue.HANGING, Boolean.valueOf(hanging));
/*  565 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isHasBook() {
/*  569 */     return ((Boolean)this.data.get(StateValue.HAS_BOOK)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setHasBook(boolean hasBook) {
/*  573 */     checkIfCloneNeeded();
/*  574 */     this.data.put(StateValue.HAS_BOOK, Boolean.valueOf(hasBook));
/*  575 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isHasBottle0() {
/*  579 */     return ((Boolean)this.data.get(StateValue.HAS_BOTTLE_0)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setHasBottle0(boolean hasBottle0) {
/*  583 */     checkIfCloneNeeded();
/*  584 */     this.data.put(StateValue.HAS_BOTTLE_0, Boolean.valueOf(hasBottle0));
/*  585 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isHasBottle1() {
/*  589 */     return ((Boolean)this.data.get(StateValue.HAS_BOTTLE_1)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setHasBottle1(boolean hasBottle1) {
/*  593 */     checkIfCloneNeeded();
/*  594 */     this.data.put(StateValue.HAS_BOTTLE_1, Boolean.valueOf(hasBottle1));
/*  595 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isHasBottle2() {
/*  599 */     return ((Boolean)this.data.get(StateValue.HAS_BOTTLE_2)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setHasBottle2(boolean hasBottle2) {
/*  603 */     checkIfCloneNeeded();
/*  604 */     this.data.put(StateValue.HAS_BOTTLE_2, Boolean.valueOf(hasBottle2));
/*  605 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isHasRecord() {
/*  609 */     return ((Boolean)this.data.get(StateValue.HAS_RECORD)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setHasRecord(boolean hasRecord) {
/*  613 */     checkIfCloneNeeded();
/*  614 */     this.data.put(StateValue.HAS_RECORD, Boolean.valueOf(hasRecord));
/*  615 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getHatch() {
/*  619 */     return ((Integer)this.data.get(StateValue.HATCH)).intValue();
/*      */   }
/*      */   
/*      */   public void setHatch(int hatch) {
/*  623 */     checkIfCloneNeeded();
/*  624 */     this.data.put(StateValue.HATCH, Integer.valueOf(hatch));
/*  625 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Hinge getHinge() {
/*  629 */     return (Hinge)this.data.get(StateValue.HINGE);
/*      */   }
/*      */   
/*      */   public void setHinge(Hinge hinge) {
/*  633 */     checkIfCloneNeeded();
/*  634 */     this.data.put(StateValue.HINGE, hinge);
/*  635 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getHoneyLevel() {
/*  639 */     return ((Integer)this.data.get(StateValue.HONEY_LEVEL)).intValue();
/*      */   }
/*      */   
/*      */   public void setHoneyLevel(int honeyLevel) {
/*  643 */     checkIfCloneNeeded();
/*  644 */     this.data.put(StateValue.HONEY_LEVEL, Integer.valueOf(honeyLevel));
/*  645 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isInWall() {
/*  649 */     return ((Boolean)this.data.get(StateValue.IN_WALL)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setInWall(boolean inWall) {
/*  653 */     checkIfCloneNeeded();
/*  654 */     this.data.put(StateValue.IN_WALL, Boolean.valueOf(inWall));
/*  655 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Instrument getInstrument() {
/*  659 */     return (Instrument)this.data.get(StateValue.INSTRUMENT);
/*      */   }
/*      */   
/*      */   public void setInstrument(Instrument instrument) {
/*  663 */     checkIfCloneNeeded();
/*  664 */     this.data.put(StateValue.INSTRUMENT, instrument);
/*  665 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isInverted() {
/*  669 */     return ((Boolean)this.data.get(StateValue.INVERTED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setInverted(boolean inverted) {
/*  673 */     checkIfCloneNeeded();
/*  674 */     this.data.put(StateValue.INVERTED, Boolean.valueOf(inverted));
/*  675 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getLayers() {
/*  679 */     return ((Integer)this.data.get(StateValue.LAYERS)).intValue();
/*      */   }
/*      */   
/*      */   public void setLayers(int layers) {
/*  683 */     checkIfCloneNeeded();
/*  684 */     this.data.put(StateValue.LAYERS, Integer.valueOf(layers));
/*  685 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Leaves getLeaves() {
/*  689 */     return (Leaves)this.data.get(StateValue.LEAVES);
/*      */   }
/*      */   
/*      */   public void setLeaves(Leaves leaves) {
/*  693 */     checkIfCloneNeeded();
/*  694 */     this.data.put(StateValue.LEAVES, leaves);
/*  695 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getLevel() {
/*  699 */     return ((Integer)this.data.get(StateValue.LEVEL)).intValue();
/*      */   }
/*      */   
/*      */   public void setLevel(int level) {
/*  703 */     checkIfCloneNeeded();
/*  704 */     this.data.put(StateValue.LEVEL, Integer.valueOf(level));
/*  705 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isLit() {
/*  709 */     return ((Boolean)this.data.get(StateValue.LIT)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setLit(boolean lit) {
/*  713 */     checkIfCloneNeeded();
/*  714 */     this.data.put(StateValue.LIT, Boolean.valueOf(lit));
/*  715 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isLocked() {
/*  719 */     return ((Boolean)this.data.get(StateValue.LOCKED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setLocked(boolean locked) {
/*  723 */     checkIfCloneNeeded();
/*  724 */     this.data.put(StateValue.LOCKED, Boolean.valueOf(locked));
/*  725 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Mode getMode() {
/*  729 */     return (Mode)this.data.get(StateValue.MODE);
/*      */   }
/*      */   
/*      */   public void setMode(Mode mode) {
/*  733 */     checkIfCloneNeeded();
/*  734 */     this.data.put(StateValue.MODE, mode);
/*  735 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getMoisture() {
/*  739 */     return ((Integer)this.data.get(StateValue.MOISTURE)).intValue();
/*      */   }
/*      */   
/*      */   public void setMoisture(int moisture) {
/*  743 */     checkIfCloneNeeded();
/*  744 */     this.data.put(StateValue.MOISTURE, Integer.valueOf(moisture));
/*  745 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public North getNorth() {
/*  749 */     return (North)this.data.get(StateValue.NORTH);
/*      */   }
/*      */   
/*      */   public void setNorth(North north) {
/*  753 */     checkIfCloneNeeded();
/*  754 */     this.data.put(StateValue.NORTH, north);
/*  755 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getNote() {
/*  759 */     return ((Integer)this.data.get(StateValue.NOTE)).intValue();
/*      */   }
/*      */   
/*      */   public void setNote(int note) {
/*  763 */     checkIfCloneNeeded();
/*  764 */     this.data.put(StateValue.NOTE, Integer.valueOf(note));
/*  765 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isOccupied() {
/*  769 */     return ((Boolean)this.data.get(StateValue.OCCUPIED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setOccupied(boolean occupied) {
/*  773 */     checkIfCloneNeeded();
/*  774 */     this.data.put(StateValue.OCCUPIED, Boolean.valueOf(occupied));
/*  775 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isShrieking() {
/*  779 */     return ((Boolean)this.data.get(StateValue.SHRIEKING)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setShrieking(boolean shrieking) {
/*  783 */     checkIfCloneNeeded();
/*  784 */     this.data.put(StateValue.SHRIEKING, Boolean.valueOf(shrieking));
/*  785 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isCanSummon() {
/*  789 */     return ((Boolean)this.data.get(StateValue.CAN_SUMMON)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setCanSummon(boolean canSummon) {
/*  793 */     checkIfCloneNeeded();
/*  794 */     this.data.put(StateValue.CAN_SUMMON, Boolean.valueOf(canSummon));
/*  795 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isOpen() {
/*  799 */     return ((Boolean)this.data.get(StateValue.OPEN)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setOpen(boolean open) {
/*  803 */     checkIfCloneNeeded();
/*  804 */     this.data.put(StateValue.OPEN, Boolean.valueOf(open));
/*  805 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Orientation getOrientation() {
/*  809 */     return (Orientation)this.data.get(StateValue.ORIENTATION);
/*      */   }
/*      */   
/*      */   public void setOrientation(Orientation orientation) {
/*  813 */     checkIfCloneNeeded();
/*  814 */     this.data.put(StateValue.ORIENTATION, orientation);
/*  815 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Part getPart() {
/*  819 */     return (Part)this.data.get(StateValue.PART);
/*      */   }
/*      */   
/*      */   public void setPart(Part part) {
/*  823 */     checkIfCloneNeeded();
/*  824 */     this.data.put(StateValue.PART, part);
/*  825 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isPersistent() {
/*  829 */     return ((Boolean)this.data.get(StateValue.PERSISTENT)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setPersistent(boolean persistent) {
/*  833 */     checkIfCloneNeeded();
/*  834 */     this.data.put(StateValue.PERSISTENT, Boolean.valueOf(persistent));
/*  835 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getPickles() {
/*  839 */     return ((Integer)this.data.get(StateValue.PICKLES)).intValue();
/*      */   }
/*      */   
/*      */   public void setPickles(int pickles) {
/*  843 */     checkIfCloneNeeded();
/*  844 */     this.data.put(StateValue.PICKLES, Integer.valueOf(pickles));
/*  845 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getPower() {
/*  849 */     return ((Integer)this.data.get(StateValue.POWER)).intValue();
/*      */   }
/*      */   
/*      */   public void setPower(int power) {
/*  853 */     checkIfCloneNeeded();
/*  854 */     this.data.put(StateValue.POWER, Integer.valueOf(power));
/*  855 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isPowered() {
/*  859 */     return ((Boolean)this.data.get(StateValue.POWERED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setPowered(boolean powered) {
/*  863 */     checkIfCloneNeeded();
/*  864 */     this.data.put(StateValue.POWERED, Boolean.valueOf(powered));
/*  865 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getRotation() {
/*  869 */     return ((Integer)this.data.get(StateValue.ROTATION)).intValue();
/*      */   }
/*      */   
/*      */   public void setRotation(int rotation) {
/*  873 */     checkIfCloneNeeded();
/*  874 */     this.data.put(StateValue.ROTATION, Integer.valueOf(rotation));
/*  875 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public SculkSensorPhase getSculkSensorPhase() {
/*  879 */     return (SculkSensorPhase)this.data.get(StateValue.SCULK_SENSOR_PHASE);
/*      */   }
/*      */   
/*      */   public void setSculkSensorPhase(SculkSensorPhase sculkSensorPhase) {
/*  883 */     checkIfCloneNeeded();
/*  884 */     this.data.put(StateValue.SCULK_SENSOR_PHASE, sculkSensorPhase);
/*  885 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Shape getShape() {
/*  889 */     return (Shape)this.data.get(StateValue.SHAPE);
/*      */   }
/*      */   
/*      */   public void setShape(Shape shape) {
/*  893 */     checkIfCloneNeeded();
/*  894 */     this.data.put(StateValue.SHAPE, shape);
/*  895 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isShort() {
/*  899 */     return ((Boolean)this.data.get(StateValue.SHORT)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setShort(boolean short_) {
/*  903 */     checkIfCloneNeeded();
/*  904 */     this.data.put(StateValue.SHORT, Boolean.valueOf(short_));
/*  905 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isSignalFire() {
/*  909 */     return ((Boolean)this.data.get(StateValue.SIGNAL_FIRE)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setSignalFire(boolean signalFire) {
/*  913 */     checkIfCloneNeeded();
/*  914 */     this.data.put(StateValue.SIGNAL_FIRE, Boolean.valueOf(signalFire));
/*  915 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isSlotZeroOccupied() {
/*  919 */     return ((Boolean)this.data.get(StateValue.SLOT_0_OCCUPIED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setSlotZeroOccupied(boolean slotZeroOccupied) {
/*  923 */     checkIfCloneNeeded();
/*  924 */     this.data.put(StateValue.SLOT_0_OCCUPIED, Boolean.valueOf(slotZeroOccupied));
/*  925 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isSlotOneOccupied() {
/*  929 */     return ((Boolean)this.data.get(StateValue.SLOT_1_OCCUPIED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setSlotOneOccupied(boolean slotOneOccupied) {
/*  933 */     checkIfCloneNeeded();
/*  934 */     this.data.put(StateValue.SLOT_1_OCCUPIED, Boolean.valueOf(slotOneOccupied));
/*  935 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isSlotTwoOccupied() {
/*  939 */     return ((Boolean)this.data.get(StateValue.SLOT_2_OCCUPIED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setSlotTwoOccupied(boolean slotTwoOccupied) {
/*  943 */     checkIfCloneNeeded();
/*  944 */     this.data.put(StateValue.SLOT_2_OCCUPIED, Boolean.valueOf(slotTwoOccupied));
/*  945 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isSlotThreeOccupied() {
/*  949 */     return ((Boolean)this.data.get(StateValue.SLOT_3_OCCUPIED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setSlotThreeOccupied(boolean slotThreeOccupied) {
/*  953 */     checkIfCloneNeeded();
/*  954 */     this.data.put(StateValue.SLOT_3_OCCUPIED, Boolean.valueOf(slotThreeOccupied));
/*  955 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isSlotFourOccupied() {
/*  959 */     return ((Boolean)this.data.get(StateValue.SLOT_4_OCCUPIED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setSlotFourOccupied(boolean slotFourOccupied) {
/*  963 */     checkIfCloneNeeded();
/*  964 */     this.data.put(StateValue.SLOT_4_OCCUPIED, Boolean.valueOf(slotFourOccupied));
/*  965 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isSlotFiveOccupied() {
/*  969 */     return ((Boolean)this.data.get(StateValue.SLOT_5_OCCUPIED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setSlotFiveOccupied(boolean slotFiveOccupied) {
/*  973 */     checkIfCloneNeeded();
/*  974 */     this.data.put(StateValue.SLOT_5_OCCUPIED, Boolean.valueOf(slotFiveOccupied));
/*  975 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isSnowy() {
/*  979 */     return ((Boolean)this.data.get(StateValue.SNOWY)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setSnowy(boolean snowy) {
/*  983 */     checkIfCloneNeeded();
/*  984 */     this.data.put(StateValue.SNOWY, Boolean.valueOf(snowy));
/*  985 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public int getStage() {
/*  989 */     return ((Integer)this.data.get(StateValue.STAGE)).intValue();
/*      */   }
/*      */   
/*      */   public void setStage(int stage) {
/*  993 */     checkIfCloneNeeded();
/*  994 */     this.data.put(StateValue.STAGE, Integer.valueOf(stage));
/*  995 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public South getSouth() {
/*  999 */     return (South)this.data.get(StateValue.SOUTH);
/*      */   }
/*      */   
/*      */   public void setSouth(South south) {
/* 1003 */     checkIfCloneNeeded();
/* 1004 */     this.data.put(StateValue.SOUTH, south);
/* 1005 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Thickness getThickness() {
/* 1009 */     return (Thickness)this.data.get(StateValue.THICKNESS);
/*      */   }
/*      */   
/*      */   public void setThickness(Thickness thickness) {
/* 1013 */     checkIfCloneNeeded();
/* 1014 */     this.data.put(StateValue.THICKNESS, thickness);
/* 1015 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Tilt getTilt() {
/* 1019 */     return (Tilt)this.data.get(StateValue.TILT);
/*      */   }
/*      */   
/*      */   public void setTilt(Tilt tilt) {
/* 1023 */     checkIfCloneNeeded();
/* 1024 */     this.data.put(StateValue.TILT, tilt);
/* 1025 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isTriggered() {
/* 1029 */     return ((Boolean)this.data.get(StateValue.TRIGGERED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setTriggered(boolean triggered) {
/* 1033 */     checkIfCloneNeeded();
/* 1034 */     this.data.put(StateValue.TRIGGERED, Boolean.valueOf(triggered));
/* 1035 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Type getTypeData() {
/* 1039 */     return (Type)this.data.get(StateValue.TYPE);
/*      */   }
/*      */   
/*      */   public void setTypeData(Type type) {
/* 1043 */     checkIfCloneNeeded();
/* 1044 */     this.data.put(StateValue.TYPE, type);
/* 1045 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isUnstable() {
/* 1049 */     return ((Boolean)this.data.get(StateValue.UNSTABLE)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setUnstable(boolean unstable) {
/* 1053 */     checkIfCloneNeeded();
/* 1054 */     this.data.put(StateValue.UNSTABLE, Boolean.valueOf(unstable));
/* 1055 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isUp() {
/* 1059 */     return ((Boolean)this.data.get(StateValue.UP)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setUp(boolean up) {
/* 1063 */     checkIfCloneNeeded();
/* 1064 */     this.data.put(StateValue.UP, Boolean.valueOf(up));
/* 1065 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public VerticalDirection getVerticalDirection() {
/* 1069 */     return (VerticalDirection)this.data.get(StateValue.VERTICAL_DIRECTION);
/*      */   }
/*      */   
/*      */   public void setVerticalDirection(VerticalDirection verticalDirection) {
/* 1073 */     checkIfCloneNeeded();
/* 1074 */     this.data.put(StateValue.VERTICAL_DIRECTION, verticalDirection);
/* 1075 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isWaterlogged() {
/* 1079 */     return ((Boolean)this.data.get(StateValue.WATERLOGGED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setWaterlogged(boolean waterlogged) {
/* 1083 */     checkIfCloneNeeded();
/* 1084 */     this.data.put(StateValue.WATERLOGGED, Boolean.valueOf(waterlogged));
/* 1085 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public East getEast() {
/* 1089 */     return (East)this.data.get(StateValue.EAST);
/*      */   }
/*      */   
/*      */   public void setEast(East west) {
/* 1093 */     checkIfCloneNeeded();
/* 1094 */     this.data.put(StateValue.EAST, west);
/* 1095 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public West getWest() {
/* 1099 */     return (West)this.data.get(StateValue.WEST);
/*      */   }
/*      */   
/*      */   public void setWest(West west) {
/* 1103 */     checkIfCloneNeeded();
/* 1104 */     this.data.put(StateValue.WEST, west);
/* 1105 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public Bloom getBloom() {
/* 1109 */     return (Bloom)this.data.get(StateValue.BLOOM);
/*      */   }
/*      */   
/*      */   public void setBloom(Bloom bloom) {
/* 1113 */     checkIfCloneNeeded();
/* 1114 */     this.data.put(StateValue.BLOOM, bloom);
/* 1115 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isCracked() {
/* 1119 */     return ((Boolean)this.data.get(StateValue.CRACKED)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setCracked(boolean cracked) {
/* 1123 */     checkIfCloneNeeded();
/* 1124 */     this.data.put(StateValue.CRACKED, Boolean.valueOf(cracked));
/* 1125 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public boolean isCrafting() {
/* 1129 */     return ((Boolean)this.data.get(StateValue.CRAFTING)).booleanValue();
/*      */   }
/*      */   
/*      */   public void setCrafting(boolean crafting) {
/* 1133 */     checkIfCloneNeeded();
/* 1134 */     this.data.put(StateValue.CRAFTING, Boolean.valueOf(crafting));
/* 1135 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   public TrialSpawnerState getTrialSpawnerState() {
/* 1139 */     return (TrialSpawnerState)this.data.get(StateValue.TRIAL_SPAWNER_STATE);
/*      */   }
/*      */   
/*      */   public void setTrialSpawnerState(TrialSpawnerState trialSpawnerState) {
/* 1143 */     checkIfCloneNeeded();
/* 1144 */     this.data.put(StateValue.TRIAL_SPAWNER_STATE, trialSpawnerState);
/* 1145 */     checkIsStillValid();
/*      */   }
/*      */   
/*      */   private void checkIfCloneNeeded() {
/* 1155 */     if (!this.hasClonedData) {
/* 1156 */       this.data = new HashMap<>(this.data);
/* 1157 */       this.hasClonedData = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkIsStillValid() {
/* 1168 */     int oldGlobalID = this.globalID;
/* 1169 */     this.globalID = getGlobalIdNoCache();
/* 1170 */     if (this.globalID == -1) {
/* 1171 */       WrappedBlockState blockState = ((WrappedBlockState)((Map)BY_ID.get(Byte.valueOf(this.mappingsIndex))).getOrDefault(Integer.valueOf(oldGlobalID), AIR)).clone();
/* 1172 */       this.type = blockState.type;
/* 1173 */       this.globalID = blockState.globalID;
/* 1174 */       this.data = new HashMap<>(blockState.data);
/* 1177 */       if (PacketEvents.getAPI().getSettings().isDebugEnabled()) {
/* 1178 */         PacketEvents.getAPI().getLogManager().warn("Attempt to modify an unknown property for this game version and block!");
/* 1179 */         PacketEvents.getAPI().getLogManager().warn("Block: " + this.type.getName());
/* 1180 */         for (Map.Entry<StateValue, Object> entry : this.data.entrySet())
/* 1181 */           PacketEvents.getAPI().getLogManager().warn((new StringBuilder()).append(entry.getKey()).append(": ").append(entry.getValue()).toString()); 
/* 1183 */         (new IllegalStateException("An invalid modification was made to a block!")).printStackTrace();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Map<StateValue, Object> getInternalData() {
/* 1197 */     return this.data;
/*      */   }
/*      */   
/*      */   public int getGlobalId() {
/* 1208 */     return this.globalID;
/*      */   }
/*      */   
/*      */   private int getGlobalIdNoCache() {
/* 1215 */     return ((Integer)((Map)INTO_ID.get(Byte.valueOf(this.mappingsIndex))).getOrDefault(this, Integer.valueOf(-1))).intValue();
/*      */   }
/*      */   
/*      */   public String toString() {
/* 1220 */     return (String)((Map)INTO_STRING.get(Byte.valueOf(this.mappingsIndex))).get(this);
/*      */   }
/*      */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\WrappedBlockState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */