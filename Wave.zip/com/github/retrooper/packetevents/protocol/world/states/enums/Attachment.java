/*    */ package com.github.retrooper.packetevents.protocol.world.states.enums;
/*    */ 
/*    */ public enum Attachment {
/* 22 */   CEILING, DOUBLE_WALL, FLOOR, SINGLE_WALL;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\enums\Attachment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */