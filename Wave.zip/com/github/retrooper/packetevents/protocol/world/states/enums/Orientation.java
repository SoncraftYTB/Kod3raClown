/*    */ package com.github.retrooper.packetevents.protocol.world.states.enums;
/*    */ 
/*    */ public enum Orientation {
/* 22 */   DOWN_EAST, DOWN_NORTH, DOWN_SOUTH, DOWN_WEST, EAST_UP, NORTH_UP, SOUTH_UP, UP_EAST, UP_NORTH, UP_SOUTH, UP_WEST, WEST_UP;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\enums\Orientation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */