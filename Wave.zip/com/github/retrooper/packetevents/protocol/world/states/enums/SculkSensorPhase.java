/*    */ package com.github.retrooper.packetevents.protocol.world.states.enums;
/*    */ 
/*    */ public enum SculkSensorPhase {
/* 22 */   ACTIVE, COOLDOWN, INACTIVE;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\enums\SculkSensorPhase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */