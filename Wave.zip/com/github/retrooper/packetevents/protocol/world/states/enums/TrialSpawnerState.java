/*    */ package com.github.retrooper.packetevents.protocol.world.states.enums;
/*    */ 
/*    */ public enum TrialSpawnerState {
/* 23 */   INACTIVE, WAITING_FOR_PLAYERS, ACTIVE, WAITING_FOR_REWARD_EJECTION, EJECTING_REWARD, COOLDOWN;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\enums\TrialSpawnerState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */