/*    */ package com.github.retrooper.packetevents.protocol.world.states.enums;
/*    */ 
/*    */ public enum West {
/* 22 */   FALSE, LOW, NONE, SIDE, TALL, TRUE, UP;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\enums\West.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */