/*    */ package com.github.retrooper.packetevents.protocol.world.states.enums;
/*    */ 
/*    */ public enum Type {
/* 22 */   BOTTOM, DOUBLE, LEFT, NORMAL, RIGHT, SINGLE, STICKY, TOP;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\world\states\enums\Type.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */