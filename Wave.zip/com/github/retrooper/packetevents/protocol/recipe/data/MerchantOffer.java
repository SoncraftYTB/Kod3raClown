/*     */ package com.github.retrooper.packetevents.protocol.recipe.data;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.item.ItemStack;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class MerchantOffer implements RecipeData {
/*     */   private ItemStack firstInputItem;
/*     */   
/*     */   private ItemStack secondInputItem;
/*     */   
/*     */   private ItemStack outputItem;
/*     */   
/*     */   private int uses;
/*     */   
/*     */   private int maxUses;
/*     */   
/*     */   private int xp;
/*     */   
/*     */   private int specialPrice;
/*     */   
/*     */   private float priceMultiplier;
/*     */   
/*     */   private int demand;
/*     */   
/*     */   private MerchantOffer(ItemStack firstInputItem, ItemStack secondInputItem, ItemStack outputItem, int uses, int maxUses, int xp, int specialPrice, float priceMultiplier, int demand) {
/*  37 */     this.firstInputItem = firstInputItem;
/*  38 */     this.secondInputItem = secondInputItem;
/*  39 */     this.outputItem = outputItem;
/*  40 */     this.uses = uses;
/*  41 */     this.maxUses = maxUses;
/*  42 */     this.xp = xp;
/*  43 */     this.priceMultiplier = priceMultiplier;
/*  44 */     this.demand = demand;
/*  45 */     this.specialPrice = specialPrice;
/*     */   }
/*     */   
/*     */   public static MerchantOffer of(ItemStack buyItem1, @Nullable ItemStack buyItem2, ItemStack sellItem, int uses, int maxUses, int xp, int specialPrice, float priceMultiplier, int demand) {
/*  49 */     return new MerchantOffer(buyItem1, buyItem2, sellItem, uses, maxUses, xp, specialPrice, priceMultiplier, demand);
/*     */   }
/*     */   
/*     */   public static MerchantOffer of(ItemStack buyItem1, ItemStack sellItem, int uses, int maxUses, int xp, int specialPrice, float priceMultiplier, int demand) {
/*  53 */     return new MerchantOffer(buyItem1, null, sellItem, uses, maxUses, xp, specialPrice, priceMultiplier, demand);
/*     */   }
/*     */   
/*     */   public static MerchantOffer of(ItemStack buyItem1, ItemStack sellItem, int uses, int maxUses, int xp, float priceMultiplier, int demand) {
/*  57 */     return new MerchantOffer(buyItem1, null, sellItem, uses, maxUses, xp, 0, priceMultiplier, demand);
/*     */   }
/*     */   
/*     */   public ItemStack getFirstInputItem() {
/*  61 */     return this.firstInputItem;
/*     */   }
/*     */   
/*     */   public void setFirstInputItem(ItemStack firstInputItem) {
/*  65 */     this.firstInputItem = firstInputItem;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public ItemStack getSecondInputItem() {
/*  69 */     return this.secondInputItem;
/*     */   }
/*     */   
/*     */   public void setSecondInputItem(@Nullable ItemStack secondInputItem) {
/*  73 */     this.secondInputItem = secondInputItem;
/*     */   }
/*     */   
/*     */   public ItemStack getOutputItem() {
/*  77 */     return this.outputItem;
/*     */   }
/*     */   
/*     */   public void setOutputItem(ItemStack outputItem) {
/*  81 */     this.outputItem = outputItem;
/*     */   }
/*     */   
/*     */   public int getUses() {
/*  85 */     return this.uses;
/*     */   }
/*     */   
/*     */   public void setUses(int uses) {
/*  89 */     this.uses = uses;
/*     */   }
/*     */   
/*     */   public int getMaxUses() {
/*  93 */     return this.maxUses;
/*     */   }
/*     */   
/*     */   public void setMaxUses(int maxUses) {
/*  97 */     this.maxUses = maxUses;
/*     */   }
/*     */   
/*     */   public int getXp() {
/* 101 */     return this.xp;
/*     */   }
/*     */   
/*     */   public void setXp(int xp) {
/* 105 */     this.xp = xp;
/*     */   }
/*     */   
/*     */   public float getPriceMultiplier() {
/* 109 */     return this.priceMultiplier;
/*     */   }
/*     */   
/*     */   public void setPriceMultiplier(float priceMultiplier) {
/* 113 */     this.priceMultiplier = priceMultiplier;
/*     */   }
/*     */   
/*     */   public int getDemand() {
/* 117 */     return this.demand;
/*     */   }
/*     */   
/*     */   public void setDemand(int demand) {
/* 121 */     this.demand = demand;
/*     */   }
/*     */   
/*     */   public int getSpecialPrice() {
/* 125 */     return this.specialPrice;
/*     */   }
/*     */   
/*     */   public void setSpecialPrice(int specialPrice) {
/* 129 */     this.specialPrice = specialPrice;
/*     */   }
/*     */   
/*     */   public boolean isOutOfStock() {
/* 133 */     return (this.uses >= this.maxUses);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\recipe\data\MerchantOffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */