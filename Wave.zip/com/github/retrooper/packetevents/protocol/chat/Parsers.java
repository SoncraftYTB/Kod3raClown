/*     */ package com.github.retrooper.packetevents.protocol.chat;
/*     */ 
/*     */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class Parsers {
/*     */   private static final List<Parser> parsers;
/*     */   
/*     */   static {
/*  34 */     parsers = Arrays.asList(new Parser[] { 
/*  34 */           new Parser("brigadier:bool", null, null), new Parser("brigadier:float", packetWrapper -> {
/*     */               byte flags = packetWrapper.readByte();
/*     */               float min = ((flags & 0x1) != 0) ? packetWrapper.readFloat() : -3.4028235E38F;
/*     */               float max = ((flags & 0x2) != 0) ? packetWrapper.readFloat() : Float.MAX_VALUE;
/*     */               return Arrays.asList(new Object[] { Byte.valueOf(flags), Float.valueOf(min), Float.valueOf(max) }, );
/*     */             }(packetWrapper, properties) -> {
/*     */               byte flags = ((Byte)properties.get(0)).byteValue();
/*     */               packetWrapper.writeByte(flags);
/*     */               if ((flags & 0x1) != 0)
/*     */                 packetWrapper.writeFloat(((Float)properties.get(1)).floatValue()); 
/*     */               if ((flags & 0x2) != 0)
/*     */                 packetWrapper.writeFloat(((Float)properties.get(2)).floatValue()); 
/*  34 */             }), new Parser("brigadier:double", packetWrapper -> {
/*     */               byte flags = packetWrapper.readByte();
/*     */               double min = ((flags & 0x1) != 0) ? packetWrapper.readDouble() : -1.7976931348623157E308D;
/*     */               double max = ((flags & 0x2) != 0) ? packetWrapper.readDouble() : Double.MAX_VALUE;
/*     */               return Arrays.asList(new Object[] { Byte.valueOf(flags), Double.valueOf(min), Double.valueOf(max) }, );
/*     */             }(packetWrapper, properties) -> {
/*     */               byte flags = ((Byte)properties.get(0)).byteValue();
/*     */               packetWrapper.writeByte(flags);
/*     */               if ((flags & 0x1) != 0)
/*     */                 packetWrapper.writeDouble(((Double)properties.get(1)).doubleValue()); 
/*     */               if ((flags & 0x2) != 0)
/*     */                 packetWrapper.writeDouble(((Double)properties.get(2)).doubleValue()); 
/*  34 */             }), new Parser("brigadier:integer", packetWrapper -> {
/*     */               byte flags = packetWrapper.readByte();
/*     */               int min = ((flags & 0x1) != 0) ? packetWrapper.readInt() : Integer.MIN_VALUE;
/*     */               int max = ((flags & 0x2) != 0) ? packetWrapper.readInt() : Integer.MAX_VALUE;
/*     */               return Arrays.asList(new Object[] { Byte.valueOf(flags), Integer.valueOf(min), Integer.valueOf(max) }, );
/*     */             }(packetWrapper, properties) -> {
/*     */               byte flags = ((Byte)properties.get(0)).byteValue();
/*     */               packetWrapper.writeByte(flags);
/*     */               if ((flags & 0x1) != 0)
/*     */                 packetWrapper.writeInt(((Integer)properties.get(1)).intValue()); 
/*     */               if ((flags & 0x2) != 0)
/*     */                 packetWrapper.writeInt(((Integer)properties.get(2)).intValue()); 
/*  34 */             }), new Parser("brigadier:long", packetWrapper -> {
/*     */               byte flags = packetWrapper.readByte();
/*     */               long min = ((flags & 0x1) != 0) ? packetWrapper.readLong() : Long.MIN_VALUE;
/*     */               long max = ((flags & 0x2) != 0) ? packetWrapper.readLong() : Long.MAX_VALUE;
/*     */               return Arrays.asList(new Object[] { Byte.valueOf(flags), Long.valueOf(min), Long.valueOf(max) }, );
/*     */             }(packetWrapper, properties) -> {
/*     */               byte flags = ((Byte)properties.get(0)).byteValue();
/*     */               packetWrapper.writeByte(flags);
/*     */               if ((flags & 0x1) != 0)
/*     */                 packetWrapper.writeLong(((Long)properties.get(1)).longValue()); 
/*     */               if ((flags & 0x2) != 0)
/*     */                 packetWrapper.writeLong(((Long)properties.get(2)).longValue()); 
/*  34 */             }), new Parser("brigadier:string", packetWrapper -> Collections.singletonList(Integer.valueOf(packetWrapper.readVarInt())), (packetWrapper, properties) -> packetWrapper.writeVarInt(((Integer)properties.get(0)).intValue())), new Parser("minecraft:entity", packetWrapper -> Collections.singletonList(Byte.valueOf(packetWrapper.readByte())), (packetWrapper, properties) -> packetWrapper.writeByte(((Byte)properties.get(0)).intValue())), new Parser("minecraft:game_profile", null, null), new Parser("minecraft:block_pos", null, null), new Parser("minecraft:column_pos", null, null), 
/*  34 */           new Parser("minecraft:vec3", null, null), new Parser("minecraft:vec2", null, null), new Parser("minecraft:block_state", null, null), new Parser("minecraft:block_predicate", null, null), new Parser("minecraft:item_stack", null, null), new Parser("minecraft:item_predicate", null, null), new Parser("minecraft:color", null, null), new Parser("minecraft:component", null, null), new Parser("minecraft:style", null, null), new Parser("minecraft:message", null, null), 
/*  34 */           new Parser("minecraft:nbt", null, null), new Parser("minecraft:nbt_tag", null, null), new Parser("minecraft:nbt_path", null, null), new Parser("minecraft:objective", null, null), new Parser("minecraft:objective_criteria", null, null), new Parser("minecraft:operation", null, null), new Parser("minecraft:particle", null, null), new Parser("minecraft:angle", null, null), new Parser("minecraft:rotation", null, null), new Parser("minecraft:scoreboard_slot", null, null), 
/*  34 */           new Parser("minecraft:score_holder", packetWrapper -> Collections.singletonList(Byte.valueOf(packetWrapper.readByte())), (packetWrapper, properties) -> packetWrapper.writeByte(((Byte)properties.get(0)).intValue())), new Parser("minecraft:swizzle", null, null), new Parser("minecraft:team", null, null), new Parser("minecraft:item_slot", null, null), new Parser("minecraft:resource_location", null, null), new Parser("minecraft:function", null, null), new Parser("minecraft:entity_anchor", null, null), new Parser("minecraft:int_range", null, null), new Parser("minecraft:float_range", null, null), new Parser("minecraft:dimension", null, null), 
/*  34 */           new Parser("minecraft:gamemode", null, null), new Parser("minecraft:time", packetWrapper -> Collections.singletonList(Integer.valueOf(packetWrapper.readInt())), (packetWrapper, properties) -> packetWrapper.writeInt(((Integer)properties.get(0)).intValue())), new Parser("minecraft:resource_or_tag", packetWrapper -> Collections.singletonList(packetWrapper.readIdentifier()), (packetWrapper, properties) -> packetWrapper.writeIdentifier(properties.get(0))), new Parser("minecraft:resource_or_tag_key", packetWrapper -> Collections.singletonList(packetWrapper.readIdentifier()), (packetWrapper, properties) -> packetWrapper.writeIdentifier(properties.get(0))), new Parser("minecraft:resource", packetWrapper -> Collections.singletonList(packetWrapper.readIdentifier()), (packetWrapper, properties) -> packetWrapper.writeIdentifier(properties.get(0))), new Parser("minecraft:resource_key", packetWrapper -> Collections.singletonList(packetWrapper.readIdentifier()), (packetWrapper, properties) -> packetWrapper.writeIdentifier(properties.get(0))), new Parser("minecraft:template_mirror", null, null), new Parser("minecraft:template_rotation", null, null), new Parser("minecraft:heightmap", null, null), new Parser("minecraft:uuid", null, null) });
/*     */   }
/*     */   
/*     */   public static List<Parser> getParsers() {
/* 164 */     return parsers;
/*     */   }
/*     */   
/*     */   public static final class Parser {
/*     */     private final String name;
/*     */     
/*     */     private final Optional<Function<PacketWrapper<?>, List<Object>>> read;
/*     */     
/*     */     private final Optional<BiConsumer<PacketWrapper<?>, List<Object>>> write;
/*     */     
/*     */     public Parser(String name, @Nullable Function<PacketWrapper<?>, List<Object>> read, @Nullable BiConsumer<PacketWrapper<?>, List<Object>> write) {
/* 173 */       this.name = name;
/* 174 */       this.read = Optional.ofNullable(read);
/* 175 */       this.write = Optional.ofNullable(write);
/*     */     }
/*     */     
/*     */     public Optional<List<Object>> readProperties(PacketWrapper<?> packetWrapper) {
/* 179 */       return this.read.map(fn -> (List)fn.apply(packetWrapper));
/*     */     }
/*     */     
/*     */     public void writeProperties(PacketWrapper<?> packetWrapper, List<Object> properties) {
/* 183 */       this.write.ifPresent(fn -> fn.accept(packetWrapper, properties));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\Parsers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */