/*    */ package com.github.retrooper.packetevents.protocol.chat.message.reader.impl;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.chat.LastSeenMessages;
/*    */ import com.github.retrooper.packetevents.protocol.chat.filter.FilterMask;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage_v1_19_1;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.ChatMessageProcessor;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import java.time.Instant;
/*    */ import java.util.UUID;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.TextComponent;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ChatMessageProcessor_v1_19_1 implements ChatMessageProcessor {
/*    */   public ChatMessage readChatMessage(@NotNull PacketWrapper<?> wrapper) {
/*    */     TextComponent textComponent;
/* 38 */     byte[] previousSignature = (byte[])wrapper.readOptional(PacketWrapper::readByteArray);
/* 39 */     UUID senderUUID = wrapper.readUUID();
/* 40 */     byte[] signature = wrapper.readByteArray();
/* 41 */     String plainContent = wrapper.readString(256);
/* 42 */     Component chatContent = (Component)wrapper.readOptional(PacketWrapper::readComponent);
/* 43 */     if (chatContent == null && plainContent.isEmpty()) {
/* 44 */       textComponent = Component.empty();
/* 45 */     } else if (textComponent == null) {
/* 46 */       textComponent = Component.text(plainContent);
/*    */     } 
/* 48 */     Instant timestamp = wrapper.readTimestamp();
/* 49 */     long salt = wrapper.readLong();
/* 50 */     LastSeenMessages lastSeenMessages = wrapper.readLastSeenMessages();
/* 51 */     Component unsignedChatContent = (Component)wrapper.readOptional(PacketWrapper::readComponent);
/* 52 */     FilterMask filterMask = wrapper.readFilterMask();
/* 53 */     ChatMessage_v1_19_1.ChatTypeBoundNetwork chatType = wrapper.readChatTypeBoundNetwork();
/* 54 */     return (ChatMessage)new ChatMessage_v1_19_1(plainContent, (Component)textComponent, unsignedChatContent, senderUUID, chatType, previousSignature, signature, timestamp, salt, lastSeenMessages, filterMask);
/*    */   }
/*    */   
/*    */   public void writeChatMessage(@NotNull PacketWrapper<?> wrapper, @NotNull ChatMessage data) {
/* 60 */     ChatMessage_v1_19_1 newData = (ChatMessage_v1_19_1)data;
/* 61 */     wrapper.writeOptional(newData.getPreviousSignature(), PacketWrapper::writeByteArray);
/* 62 */     wrapper.writeUUID(newData.getSenderUUID());
/* 63 */     wrapper.writeByteArray(newData.getSignature());
/* 64 */     wrapper.writeString(newData.getPlainContent(), 256);
/* 65 */     wrapper.writeOptional(newData.getChatContent(), PacketWrapper::writeComponent);
/* 66 */     wrapper.writeTimestamp(newData.getTimestamp());
/* 67 */     wrapper.writeLong(newData.getSalt());
/* 68 */     wrapper.writeLastSeenMessages(newData.getLastSeenMessages());
/* 69 */     wrapper.writeOptional(newData.getUnsignedChatContent(), PacketWrapper::writeComponent);
/* 70 */     wrapper.writeFilterMask(newData.getFilterMask());
/* 71 */     wrapper.writeChatTypeBoundNetwork(newData.getChatType());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\reader\impl\ChatMessageProcessor_v1_19_1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */