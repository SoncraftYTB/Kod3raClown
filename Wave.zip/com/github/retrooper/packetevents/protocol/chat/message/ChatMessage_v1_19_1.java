/*     */ package com.github.retrooper.packetevents.protocol.chat.message;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*     */ import com.github.retrooper.packetevents.protocol.chat.LastSeenMessages;
/*     */ import com.github.retrooper.packetevents.protocol.chat.filter.FilterMask;
/*     */ import java.time.Instant;
/*     */ import java.util.UUID;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class ChatMessage_v1_19_1 extends ChatMessage_v1_16 {
/*     */   private String plainContent;
/*     */   
/*     */   @Nullable
/*     */   private Component unsignedChatContent;
/*     */   
/*     */   private ChatTypeBoundNetwork chatType;
/*     */   
/*     */   private byte[] previousSignature;
/*     */   
/*     */   private byte[] signature;
/*     */   
/*     */   private Instant timestamp;
/*     */   
/*     */   private long salt;
/*     */   
/*     */   private LastSeenMessages lastSeenMessages;
/*     */   
/*     */   private FilterMask filterMask;
/*     */   
/*     */   public ChatMessage_v1_19_1(String plainContent, Component decoratedChatContent, @Nullable Component unsignedChatContent, UUID senderUUID, ChatTypeBoundNetwork chatType, byte[] previousSignature, byte[] signature, Instant timestamp, long salt, LastSeenMessages lastSeenMessages, FilterMask filterMask) {
/*  48 */     super(decoratedChatContent, chatType.getType(), senderUUID);
/*  49 */     this.plainContent = plainContent;
/*  50 */     this.unsignedChatContent = unsignedChatContent;
/*  51 */     this.chatType = chatType;
/*  52 */     this.previousSignature = previousSignature;
/*  53 */     this.signature = signature;
/*  54 */     this.timestamp = timestamp;
/*  55 */     this.salt = salt;
/*  56 */     this.lastSeenMessages = lastSeenMessages;
/*  57 */     this.filterMask = filterMask;
/*     */   }
/*     */   
/*     */   public String getPlainContent() {
/*  61 */     return this.plainContent;
/*     */   }
/*     */   
/*     */   public void setPlainContent(String plainContent) {
/*  65 */     this.plainContent = plainContent;
/*     */   }
/*     */   
/*     */   public boolean isChatContentDecorated() {
/*  69 */     return !getChatContent().equals(Component.text(this.plainContent));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Component getUnsignedChatContent() {
/*  73 */     return this.unsignedChatContent;
/*     */   }
/*     */   
/*     */   public void setUnsignedChatContent(@Nullable Component unsignedChatContent) {
/*  77 */     this.unsignedChatContent = unsignedChatContent;
/*     */   }
/*     */   
/*     */   public ChatType getType() {
/*  82 */     return this.chatType.getType();
/*     */   }
/*     */   
/*     */   public void setType(ChatType type) {
/*  87 */     this.chatType.setType(type);
/*     */   }
/*     */   
/*     */   public ChatTypeBoundNetwork getChatType() {
/*  91 */     return this.chatType;
/*     */   }
/*     */   
/*     */   public void setChatType(ChatTypeBoundNetwork type) {
/*  95 */     this.chatType = type;
/*     */   }
/*     */   
/*     */   public byte[] getPreviousSignature() {
/*  99 */     return this.previousSignature;
/*     */   }
/*     */   
/*     */   public void setPreviousSignature(byte[] previousSignature) {
/* 103 */     this.previousSignature = previousSignature;
/*     */   }
/*     */   
/*     */   public byte[] getSignature() {
/* 107 */     return this.signature;
/*     */   }
/*     */   
/*     */   public void setSignature(byte[] signature) {
/* 111 */     this.signature = signature;
/*     */   }
/*     */   
/*     */   public Instant getTimestamp() {
/* 115 */     return this.timestamp;
/*     */   }
/*     */   
/*     */   public void setTimestamp(Instant timestamp) {
/* 119 */     this.timestamp = timestamp;
/*     */   }
/*     */   
/*     */   public long getSalt() {
/* 123 */     return this.salt;
/*     */   }
/*     */   
/*     */   public void setSalt(long salt) {
/* 127 */     this.salt = salt;
/*     */   }
/*     */   
/*     */   public LastSeenMessages getLastSeenMessages() {
/* 131 */     return this.lastSeenMessages;
/*     */   }
/*     */   
/*     */   public void setLastSeenMessages(LastSeenMessages lastSeenMessages) {
/* 135 */     this.lastSeenMessages = lastSeenMessages;
/*     */   }
/*     */   
/*     */   public FilterMask getFilterMask() {
/* 139 */     return this.filterMask;
/*     */   }
/*     */   
/*     */   public void setFilterMask(FilterMask filterMask) {
/* 143 */     this.filterMask = filterMask;
/*     */   }
/*     */   
/*     */   public static class ChatTypeBoundNetwork {
/*     */     private ChatType type;
/*     */     
/*     */     private Component name;
/*     */     
/*     */     @Nullable
/*     */     private Component targetName;
/*     */     
/*     */     public ChatTypeBoundNetwork(ChatType type, Component name, @Nullable Component targetName) {
/* 152 */       this.type = type;
/* 153 */       this.name = name;
/* 154 */       this.targetName = targetName;
/*     */     }
/*     */     
/*     */     public ChatType getType() {
/* 158 */       return this.type;
/*     */     }
/*     */     
/*     */     public void setType(ChatType type) {
/* 162 */       this.type = type;
/*     */     }
/*     */     
/*     */     public Component getName() {
/* 166 */       return this.name;
/*     */     }
/*     */     
/*     */     public void setName(Component name) {
/* 170 */       this.name = name;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Component getTargetName() {
/* 174 */       return this.targetName;
/*     */     }
/*     */     
/*     */     public void setTargetName(@Nullable Component targetName) {
/* 178 */       this.targetName = targetName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\ChatMessage_v1_19_1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */