/*    */ package com.github.retrooper.packetevents.protocol.chat.message;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*    */ import net.kyori.adventure.text.Component;
/*    */ 
/*    */ public class ChatMessageLegacy extends ChatMessage {
/*    */   public ChatMessageLegacy(Component chatContent, ChatType type) {
/* 26 */     super(chatContent, type);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\ChatMessageLegacy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */