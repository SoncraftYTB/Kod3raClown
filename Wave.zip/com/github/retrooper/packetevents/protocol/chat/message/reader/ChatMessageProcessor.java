package com.github.retrooper.packetevents.protocol.chat.message.reader;

import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import org.jetbrains.annotations.NotNull;

public interface ChatMessageProcessor {
  ChatMessage readChatMessage(@NotNull PacketWrapper<?> paramPacketWrapper);
  
  void writeChatMessage(@NotNull PacketWrapper<?> paramPacketWrapper, @NotNull ChatMessage paramChatMessage);
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\reader\ChatMessageProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */