/*    */ package com.github.retrooper.packetevents.protocol.chat.message.reader.impl;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatTypes;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessageLegacy;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.ChatMessageProcessor;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ChatMessageProcessorLegacy implements ChatMessageProcessor {
/*    */   public ChatMessage readChatMessage(@NotNull PacketWrapper<?> wrapper) {
/* 33 */     Component chatContent = wrapper.readComponent();
/* 34 */     int id = wrapper.readByte();
/* 35 */     ChatType type = ChatTypes.getById(wrapper.getServerVersion().toClientVersion(), id);
/* 36 */     return (ChatMessage)new ChatMessageLegacy(chatContent, type);
/*    */   }
/*    */   
/*    */   public void writeChatMessage(@NotNull PacketWrapper<?> wrapper, @NotNull ChatMessage data) {
/* 41 */     wrapper.writeComponent(data.getChatContent());
/* 42 */     wrapper.writeByte(data.getType().getId(wrapper.getServerVersion().toClientVersion()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\reader\impl\ChatMessageProcessorLegacy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */