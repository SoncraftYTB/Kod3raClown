/*    */ package com.github.retrooper.packetevents.protocol.chat.message;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*    */ import net.kyori.adventure.text.Component;
/*    */ 
/*    */ public class ChatMessage {
/*    */   private Component chatContent;
/*    */   
/*    */   private ChatType type;
/*    */   
/*    */   protected ChatMessage(Component chatContent, ChatType type) {
/* 29 */     this.chatContent = chatContent;
/* 30 */     this.type = type;
/*    */   }
/*    */   
/*    */   public Component getChatContent() {
/* 34 */     return this.chatContent;
/*    */   }
/*    */   
/*    */   public ChatType getType() {
/* 38 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setChatContent(Component chatContent) {
/* 42 */     this.chatContent = chatContent;
/*    */   }
/*    */   
/*    */   public void setType(ChatType type) {
/* 46 */     this.type = type;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\ChatMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */