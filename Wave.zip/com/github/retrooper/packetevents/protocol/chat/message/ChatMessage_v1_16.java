/*    */ package com.github.retrooper.packetevents.protocol.chat.message;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*    */ import java.util.UUID;
/*    */ import net.kyori.adventure.text.Component;
/*    */ 
/*    */ public class ChatMessage_v1_16 extends ChatMessage {
/*    */   private UUID senderUUID;
/*    */   
/*    */   public ChatMessage_v1_16(Component chatContent, ChatType type, UUID senderUUID) {
/* 30 */     super(chatContent, type);
/* 31 */     this.senderUUID = senderUUID;
/*    */   }
/*    */   
/*    */   public UUID getSenderUUID() {
/* 35 */     return this.senderUUID;
/*    */   }
/*    */   
/*    */   public void setSenderUUID(UUID senderUUID) {
/* 39 */     this.senderUUID = senderUUID;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\ChatMessage_v1_16.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */