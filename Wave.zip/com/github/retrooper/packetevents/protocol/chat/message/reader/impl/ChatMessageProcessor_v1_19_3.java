/*    */ package com.github.retrooper.packetevents.protocol.chat.message.reader.impl;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.chat.LastSeenMessages;
/*    */ import com.github.retrooper.packetevents.protocol.chat.filter.FilterMask;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage_v1_19_1;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage_v1_19_3;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.ChatMessageProcessor;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import java.time.Instant;
/*    */ import java.util.UUID;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ChatMessageProcessor_v1_19_3 implements ChatMessageProcessor {
/*    */   public ChatMessage readChatMessage(@NotNull PacketWrapper<?> wrapper) {
/* 19 */     UUID senderUUID = wrapper.readUUID();
/* 20 */     int index = wrapper.readVarInt();
/* 21 */     byte[] signature = (byte[])wrapper.readOptional(w -> w.readBytes(256));
/* 22 */     String plainContent = wrapper.readString(256);
/* 23 */     Instant timestamp = wrapper.readTimestamp();
/* 24 */     long salt = wrapper.readLong();
/* 25 */     LastSeenMessages.Packed lastSeenMessagesPacked = wrapper.readLastSeenMessagesPacked();
/* 26 */     Component unsignedChatContent = (Component)wrapper.readOptional(PacketWrapper::readComponent);
/* 27 */     FilterMask filterMask = wrapper.readFilterMask();
/* 28 */     ChatMessage_v1_19_1.ChatTypeBoundNetwork chatType = wrapper.readChatTypeBoundNetwork();
/* 30 */     return (ChatMessage)new ChatMessage_v1_19_3(senderUUID, index, signature, plainContent, timestamp, salt, lastSeenMessagesPacked, unsignedChatContent, filterMask, chatType);
/*    */   }
/*    */   
/*    */   public void writeChatMessage(@NotNull PacketWrapper<?> wrapper, @NotNull ChatMessage data) {
/* 35 */     ChatMessage_v1_19_3 newData = (ChatMessage_v1_19_3)data;
/* 36 */     wrapper.writeUUID(newData.getSenderUUID());
/* 37 */     wrapper.writeVarInt(newData.getIndex());
/* 38 */     wrapper.writeOptional(newData.getSignature(), PacketWrapper::writeBytes);
/* 39 */     wrapper.writeString(newData.getPlainContent());
/* 40 */     wrapper.writeTimestamp(newData.getTimestamp());
/* 41 */     wrapper.writeLong(newData.getSalt());
/* 42 */     wrapper.writeLastSeenMessagesPacked(newData.getLastSeenMessagesPacked());
/* 43 */     wrapper.writeOptional(newData.getUnsignedChatContent().orElse(null), PacketWrapper::writeComponent);
/* 44 */     wrapper.writeFilterMask(newData.getFilterMask());
/* 45 */     wrapper.writeChatTypeBoundNetwork(newData.getChatType());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\reader\impl\ChatMessageProcessor_v1_19_3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */