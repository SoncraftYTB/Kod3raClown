/*    */ package com.github.retrooper.packetevents.protocol.chat.message.reader.impl;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatTypes;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage_v1_19;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.ChatMessageProcessor;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import java.time.Instant;
/*    */ import java.util.UUID;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ChatMessageProcessor_v1_19 implements ChatMessageProcessor {
/*    */   public ChatMessage readChatMessage(@NotNull PacketWrapper<?> wrapper) {
/* 37 */     Component chatContent = wrapper.readComponent();
/* 38 */     Component unsignedChatContent = (Component)wrapper.readOptional(PacketWrapper::readComponent);
/* 39 */     int id = wrapper.readVarInt();
/* 40 */     ChatType type = ChatTypes.getById(wrapper.getServerVersion().toClientVersion(), id);
/* 41 */     UUID senderUUID = wrapper.readUUID();
/* 42 */     Component senderDisplayName = wrapper.readComponent();
/* 43 */     Component teamName = (Component)wrapper.readOptional(PacketWrapper::readComponent);
/* 44 */     Instant timestamp = wrapper.readTimestamp();
/* 45 */     long salt = wrapper.readLong();
/* 46 */     byte[] signature = wrapper.readByteArray();
/* 47 */     return (ChatMessage)new ChatMessage_v1_19(chatContent, unsignedChatContent, type, senderUUID, senderDisplayName, teamName, timestamp, salt, signature);
/*    */   }
/*    */   
/*    */   public void writeChatMessage(@NotNull PacketWrapper<?> wrapper, @NotNull ChatMessage data) {
/* 53 */     ChatMessage_v1_19 newData = (ChatMessage_v1_19)data;
/* 54 */     wrapper.writeComponent(newData.getChatContent());
/* 55 */     wrapper.writeOptional(newData.getUnsignedChatContent(), PacketWrapper::writeComponent);
/* 56 */     wrapper.writeVarInt(newData.getType().getId(wrapper.getServerVersion().toClientVersion()));
/* 57 */     wrapper.writeUUID(newData.getSenderUUID());
/* 58 */     wrapper.writeComponent(newData.getSenderDisplayName());
/* 59 */     wrapper.writeOptional(newData.getTeamName(), PacketWrapper::writeComponent);
/* 60 */     wrapper.writeTimestamp(newData.getTimestamp());
/* 61 */     wrapper.writeLong(newData.getSalt());
/* 62 */     wrapper.writeByteArray(newData.getSignature());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\reader\impl\ChatMessageProcessor_v1_19.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */