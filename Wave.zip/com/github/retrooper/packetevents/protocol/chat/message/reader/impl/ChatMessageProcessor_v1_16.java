/*    */ package com.github.retrooper.packetevents.protocol.chat.message.reader.impl;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*    */ import com.github.retrooper.packetevents.protocol.chat.ChatTypes;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage_v1_16;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.ChatMessageProcessor;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import java.util.UUID;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class ChatMessageProcessor_v1_16 implements ChatMessageProcessor {
/*    */   public ChatMessage readChatMessage(@NotNull PacketWrapper<?> wrapper) {
/* 35 */     Component chatContent = wrapper.readComponent();
/* 36 */     int id = wrapper.readByte();
/* 37 */     ChatType type = ChatTypes.getById(wrapper.getServerVersion().toClientVersion(), id);
/* 38 */     UUID senderUUID = wrapper.readUUID();
/* 39 */     return (ChatMessage)new ChatMessage_v1_16(chatContent, type, senderUUID);
/*    */   }
/*    */   
/*    */   public void writeChatMessage(@NotNull PacketWrapper<?> wrapper, @NotNull ChatMessage data) {
/* 44 */     wrapper.writeComponent(data.getChatContent());
/* 45 */     wrapper.writeByte(data.getType().getId(wrapper.getServerVersion().toClientVersion()));
/* 46 */     wrapper.writeUUID(((ChatMessage_v1_16)data).getSenderUUID());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\message\reader\impl\ChatMessageProcessor_v1_16.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */