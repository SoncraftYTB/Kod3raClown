/*    */ package com.github.retrooper.packetevents.protocol.chat;
/*    */ 
/*    */ public class SignedCommandArgument {
/*    */   private String argument;
/*    */   
/*    */   private byte[] signature;
/*    */   
/*    */   public SignedCommandArgument(String argument, byte[] signature) {
/*  8 */     this.argument = argument;
/*  9 */     this.signature = signature;
/*    */   }
/*    */   
/*    */   public String getArgument() {
/* 13 */     return this.argument;
/*    */   }
/*    */   
/*    */   public void setArgument(String argument) {
/* 17 */     this.argument = argument;
/*    */   }
/*    */   
/*    */   public byte[] getSignature() {
/* 21 */     return this.signature;
/*    */   }
/*    */   
/*    */   public void setSignature(byte[] signature) {
/* 25 */     this.signature = signature;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\SignedCommandArgument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */