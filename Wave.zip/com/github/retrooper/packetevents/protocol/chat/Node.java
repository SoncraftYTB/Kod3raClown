/*     */ package com.github.retrooper.packetevents.protocol.chat;
/*     */ 
/*     */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class Node {
/*     */   private byte flags;
/*     */   
/*     */   private List<Integer> children;
/*     */   
/*     */   private Optional<Integer> redirectNodeIndex;
/*     */   
/*     */   private Optional<String> name;
/*     */   
/*     */   private Optional<Integer> parserID;
/*     */   
/*     */   private Optional<List<Object>> properties;
/*     */   
/*     */   private Optional<ResourceLocation> suggestionsType;
/*     */   
/*     */   public Node(byte flags, List<Integer> children, @Nullable Integer redirectNodeIndex, @Nullable String name, @Nullable Integer parserID, @Nullable List<Object> properties, @Nullable ResourceLocation suggestionsType) {
/*  38 */     this.flags = flags;
/*  39 */     this.children = children;
/*  40 */     this.redirectNodeIndex = Optional.ofNullable(redirectNodeIndex);
/*  41 */     this.name = Optional.ofNullable(name);
/*  42 */     this.parserID = Optional.ofNullable(parserID);
/*  43 */     this.properties = Optional.ofNullable(properties);
/*  44 */     this.suggestionsType = Optional.ofNullable(suggestionsType);
/*     */   }
/*     */   
/*     */   public byte getFlags() {
/*  48 */     return this.flags;
/*     */   }
/*     */   
/*     */   public void setFlags(byte flags) {
/*  52 */     this.flags = flags;
/*     */   }
/*     */   
/*     */   public List<Integer> getChildren() {
/*  56 */     return this.children;
/*     */   }
/*     */   
/*     */   public void setChildren(List<Integer> children) {
/*  60 */     this.children = children;
/*     */   }
/*     */   
/*     */   public Optional<Integer> getRedirectNodeIndex() {
/*  64 */     return this.redirectNodeIndex;
/*     */   }
/*     */   
/*     */   public void setRedirectNodeIndex(Optional<Integer> redirectNodeIndex) {
/*  68 */     this.redirectNodeIndex = redirectNodeIndex;
/*     */   }
/*     */   
/*     */   public Optional<String> getName() {
/*  72 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(Optional<String> name) {
/*  76 */     this.name = name;
/*     */   }
/*     */   
/*     */   public Optional<Integer> getParserID() {
/*  80 */     return this.parserID;
/*     */   }
/*     */   
/*     */   public void setParserID(Optional<Integer> parserID) {
/*  84 */     this.parserID = parserID;
/*     */   }
/*     */   
/*     */   public Optional<List<Object>> getProperties() {
/*  88 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Optional<List<Object>> properties) {
/*  92 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   public Optional<ResourceLocation> getSuggestionsType() {
/*  96 */     return this.suggestionsType;
/*     */   }
/*     */   
/*     */   public void setSuggestionsType(Optional<ResourceLocation> suggestionsType) {
/* 100 */     this.suggestionsType = suggestionsType;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */