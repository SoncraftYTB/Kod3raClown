/*     */ package com.github.retrooper.packetevents.protocol.chat;
/*     */ 
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class LastSeenMessages {
/*  13 */   public static final LastSeenMessages EMPTY = new LastSeenMessages(new ArrayList<>());
/*     */   
/*     */   private final List<Entry> entries;
/*     */   
/*     */   public LastSeenMessages(List<Entry> entries) {
/*  18 */     this.entries = entries;
/*     */   }
/*     */   
/*     */   public void updateHash(DataOutput output) throws IOException {
/*  22 */     for (Entry entry : this.entries) {
/*  23 */       UUID uuid = entry.getUUID();
/*  24 */       byte[] lastVerifier = entry.getLastVerifier();
/*  25 */       output.writeByte(70);
/*  26 */       output.writeLong(uuid.getMostSignificantBits());
/*  27 */       output.writeLong(uuid.getLeastSignificantBits());
/*  28 */       output.write(lastVerifier);
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<Entry> getEntries() {
/*  33 */     return this.entries;
/*     */   }
/*     */   
/*     */   public static class Packed {
/*     */     private List<MessageSignature.Packed> packedMessageSignatures;
/*     */     
/*     */     public Packed(List<MessageSignature.Packed> packedMessageSignatures) {
/*  40 */       this.packedMessageSignatures = packedMessageSignatures;
/*     */     }
/*     */     
/*     */     public List<MessageSignature.Packed> getPackedMessageSignatures() {
/*  44 */       return this.packedMessageSignatures;
/*     */     }
/*     */     
/*     */     public void setPackedMessageSignatures(List<MessageSignature.Packed> packedMessageSignatures) {
/*  48 */       this.packedMessageSignatures = packedMessageSignatures;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Entry {
/*     */     private final UUID uuid;
/*     */     
/*     */     private final byte[] signature;
/*     */     
/*     */     public Entry(UUID uuid, byte[] lastVerifier) {
/*  57 */       this.uuid = uuid;
/*  58 */       this.signature = lastVerifier;
/*     */     }
/*     */     
/*     */     public UUID getUUID() {
/*  62 */       return this.uuid;
/*     */     }
/*     */     
/*     */     public byte[] getLastVerifier() {
/*  66 */       return this.signature;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LegacyUpdate {
/*     */     private final LastSeenMessages lastSeenMessages;
/*     */     
/*     */     @Nullable
/*     */     private final LastSeenMessages.Entry lastReceived;
/*     */     
/*     */     public LegacyUpdate(LastSeenMessages lastSeenMessages, @Nullable LastSeenMessages.Entry lastReceived) {
/*  75 */       this.lastSeenMessages = lastSeenMessages;
/*  76 */       this.lastReceived = lastReceived;
/*     */     }
/*     */     
/*     */     public LastSeenMessages getLastSeenMessages() {
/*  80 */       return this.lastSeenMessages;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public LastSeenMessages.Entry getLastReceived() {
/*  84 */       return this.lastReceived;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Update {
/*     */     private final int offset;
/*     */     
/*     */     private final BitSet acknowledged;
/*     */     
/*     */     public Update(int offset, BitSet acknowledged) {
/*  93 */       this.offset = offset;
/*  94 */       this.acknowledged = acknowledged;
/*     */     }
/*     */     
/*     */     public int getOffset() {
/*  98 */       return this.offset;
/*     */     }
/*     */     
/*     */     public BitSet getAcknowledged() {
/* 102 */       return this.acknowledged;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\LastSeenMessages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */