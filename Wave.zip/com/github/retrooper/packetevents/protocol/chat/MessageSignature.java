/*    */ package com.github.retrooper.packetevents.protocol.chat;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class MessageSignature {
/*    */   private byte[] bytes;
/*    */   
/*    */   public MessageSignature(byte[] bytes) {
/* 29 */     this.bytes = bytes;
/*    */   }
/*    */   
/*    */   public byte[] getBytes() {
/* 33 */     return this.bytes;
/*    */   }
/*    */   
/*    */   public void setBytes(byte[] bytes) {
/* 37 */     this.bytes = bytes;
/*    */   }
/*    */   
/*    */   public static class Packed {
/*    */     private int id;
/*    */     
/*    */     @Nullable
/*    */     private MessageSignature fullSignature;
/*    */     
/*    */     public Packed(@Nullable MessageSignature fullSignature) {
/* 45 */       this.id = -1;
/* 46 */       this.fullSignature = fullSignature;
/*    */     }
/*    */     
/*    */     public Packed(int id) {
/* 50 */       this.id = id;
/* 51 */       this.fullSignature = null;
/*    */     }
/*    */     
/*    */     public int getId() {
/* 55 */       return this.id;
/*    */     }
/*    */     
/*    */     public void setId(int id) {
/* 59 */       this.id = id;
/*    */     }
/*    */     
/*    */     public Optional<MessageSignature> getFullSignature() {
/* 63 */       return Optional.ofNullable(this.fullSignature);
/*    */     }
/*    */     
/*    */     public void setFullSignature(@Nullable MessageSignature fullSignature) {
/* 67 */       this.fullSignature = fullSignature;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\MessageSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */