/*    */ package com.github.retrooper.packetevents.protocol.chat;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*    */ import com.github.retrooper.packetevents.util.TypesBuilder;
/*    */ import com.github.retrooper.packetevents.util.TypesBuilderData;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ChatTypes {
/* 30 */   private static final Map<String, ChatType> CHAT_TYPE_MAP = new HashMap<>();
/*    */   
/* 32 */   private static final Map<Byte, Map<Integer, ChatType>> CHAT_TYPE_ID_MAP = new HashMap<>();
/*    */   
/* 33 */   private static final TypesBuilder TYPES_BUILDER = new TypesBuilder("chat/chat_type_mappings", new ClientVersion[] { ClientVersion.V_1_18_2, ClientVersion.V_1_19, ClientVersion.V_1_19_1 });
/*    */   
/*    */   static {
/* 39 */     TYPES_BUILDER.unloadFileMappings();
/*    */   }
/*    */   
/*    */   public static ChatType define(String key) {
/* 43 */     final TypesBuilderData data = TYPES_BUILDER.define(key);
/* 44 */     ChatType chatType = new ChatType() {
/* 45 */         private final int[] ids = data.getData();
/*    */         
/*    */         public ResourceLocation getName() {
/* 49 */           return data.getName();
/*    */         }
/*    */         
/*    */         public int getId(ClientVersion version) {
/* 54 */           int index = ChatTypes.TYPES_BUILDER.getDataIndex(version);
/* 55 */           return this.ids[index];
/*    */         }
/*    */       };
/* 58 */     CHAT_TYPE_MAP.put(chatType.getName().toString(), chatType);
/* 59 */     for (ClientVersion version : TYPES_BUILDER.getVersions()) {
/* 60 */       int index = TYPES_BUILDER.getDataIndex(version);
/* 61 */       Map<Integer, ChatType> typeIdMap = CHAT_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/* 62 */       typeIdMap.put(Integer.valueOf(chatType.getId(version)), chatType);
/*    */     } 
/* 64 */     return chatType;
/*    */   }
/*    */   
/*    */   public static ChatType getByName(String name) {
/* 69 */     return CHAT_TYPE_MAP.get(name);
/*    */   }
/*    */   
/*    */   public static ChatType getById(ClientVersion version, int id) {
/* 73 */     int index = TYPES_BUILDER.getDataIndex(version);
/* 74 */     return (ChatType)((Map)CHAT_TYPE_ID_MAP.get(Byte.valueOf((byte)index))).get(Integer.valueOf(id));
/*    */   }
/*    */   
/* 77 */   public static final ChatType CHAT = define("chat");
/*    */   
/* 78 */   public static final ChatType SAY_COMMAND = define("say_command");
/*    */   
/* 79 */   public static final ChatType MSG_COMMAND_INCOMING = define("msg_command_incoming");
/*    */   
/* 80 */   public static final ChatType MSG_COMMAND_OUTGOING = define("msg_command_outgoing");
/*    */   
/* 81 */   public static final ChatType TEAM_MSG_COMMAND_INCOMING = define("team_msg_command_incoming");
/*    */   
/* 82 */   public static final ChatType TEAM_MSG_COMMAND_OUTGOING = define("team_msg_command_outgoing");
/*    */   
/* 83 */   public static final ChatType EMOTE_COMMAND = define("emote_command");
/*    */   
/* 84 */   public static final ChatType RAW = define("raw");
/*    */   
/*    */   @Deprecated
/* 87 */   public static final ChatType SYSTEM = define("system");
/*    */   
/*    */   @Deprecated
/* 89 */   public static final ChatType GAME_INFO = define("game_info");
/*    */   
/*    */   @Deprecated
/* 91 */   public static final ChatType MSG_COMMAND = define("msg_command");
/*    */   
/*    */   @Deprecated
/* 93 */   public static final ChatType TEAM_MSG_COMMAND = define("team_msg_command");
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\chat\ChatTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */