/*    */ package com.github.retrooper.packetevents.protocol.particle.data;
/*    */ 
/*    */ import com.github.retrooper.packetevents.util.Vector3f;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class ParticleDustData extends ParticleData {
/*    */   private float scale;
/*    */   
/*    */   private float red;
/*    */   
/*    */   private float green;
/*    */   
/*    */   private float blue;
/*    */   
/*    */   public ParticleDustData(float scale, float red, float green, float blue) {
/* 34 */     this.scale = scale;
/* 35 */     this.red = red;
/* 36 */     this.green = green;
/* 37 */     this.blue = blue;
/*    */   }
/*    */   
/*    */   public ParticleDustData(float scale, Vector3f rgb) {
/* 41 */     this(scale, rgb.getX(), rgb.getY(), rgb.getZ());
/*    */   }
/*    */   
/*    */   public float getRed() {
/* 45 */     return this.red;
/*    */   }
/*    */   
/*    */   public void setRed(float red) {
/* 49 */     this.red = red;
/*    */   }
/*    */   
/*    */   public float getGreen() {
/* 53 */     return this.green;
/*    */   }
/*    */   
/*    */   public void setGreen(float green) {
/* 57 */     this.green = green;
/*    */   }
/*    */   
/*    */   public float getBlue() {
/* 61 */     return this.blue;
/*    */   }
/*    */   
/*    */   public void setBlue(float blue) {
/* 65 */     this.blue = blue;
/*    */   }
/*    */   
/*    */   public float getScale() {
/* 69 */     return this.scale;
/*    */   }
/*    */   
/*    */   public void setScale(float scale) {
/* 73 */     this.scale = scale;
/*    */   }
/*    */   
/*    */   public static ParticleDustData read(PacketWrapper<?> wrapper) {
/* 77 */     float red = wrapper.readFloat();
/* 78 */     float green = wrapper.readFloat();
/* 79 */     float blue = wrapper.readFloat();
/* 80 */     float scale = wrapper.readFloat();
/* 81 */     return new ParticleDustData(scale, red, green, blue);
/*    */   }
/*    */   
/*    */   public static void write(PacketWrapper<?> wrapper, ParticleDustData data) {
/* 85 */     wrapper.writeFloat(data.getRed());
/* 86 */     wrapper.writeFloat(data.getGreen());
/* 87 */     wrapper.writeFloat(data.getBlue());
/* 88 */     wrapper.writeFloat(data.getScale());
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 94 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\data\ParticleDustData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */