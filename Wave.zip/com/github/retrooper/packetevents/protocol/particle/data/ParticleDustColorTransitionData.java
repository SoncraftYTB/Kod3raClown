/*     */ package com.github.retrooper.packetevents.protocol.particle.data;
/*     */ 
/*     */ import com.github.retrooper.packetevents.util.Vector3f;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ 
/*     */ public class ParticleDustColorTransitionData extends ParticleData {
/*     */   private float scale;
/*     */   
/*     */   private float startRed;
/*     */   
/*     */   private float startGreen;
/*     */   
/*     */   private float startBlue;
/*     */   
/*     */   private float endRed;
/*     */   
/*     */   private float endGreen;
/*     */   
/*     */   private float endBlue;
/*     */   
/*     */   public ParticleDustColorTransitionData(float scale, float startRed, float startGreen, float startBlue, float endRed, float endGreen, float endBlue) {
/*  41 */     this.scale = scale;
/*  42 */     this.startRed = startRed;
/*  43 */     this.startGreen = startGreen;
/*  44 */     this.startBlue = startBlue;
/*  45 */     this.endRed = endRed;
/*  46 */     this.endGreen = endGreen;
/*  47 */     this.endBlue = endBlue;
/*     */   }
/*     */   
/*     */   public ParticleDustColorTransitionData(float scale, Vector3f startRGB, Vector3f endRGB) {
/*  51 */     this(scale, startRGB.getX(), startRGB.getY(), startRGB.getZ(), endRGB.getX(), endRGB.getY(), endRGB.getZ());
/*     */   }
/*     */   
/*     */   public float getScale() {
/*  55 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setScale(float scale) {
/*  59 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public float getStartRed() {
/*  63 */     return this.startRed;
/*     */   }
/*     */   
/*     */   public void setStartRed(float startRed) {
/*  67 */     this.startRed = startRed;
/*     */   }
/*     */   
/*     */   public float getStartGreen() {
/*  71 */     return this.startGreen;
/*     */   }
/*     */   
/*     */   public void setStartGreen(float startGreen) {
/*  75 */     this.startGreen = startGreen;
/*     */   }
/*     */   
/*     */   public float getStartBlue() {
/*  79 */     return this.startBlue;
/*     */   }
/*     */   
/*     */   public void setStartBlue(float startBlue) {
/*  83 */     this.startBlue = startBlue;
/*     */   }
/*     */   
/*     */   public float getEndRed() {
/*  87 */     return this.endRed;
/*     */   }
/*     */   
/*     */   public void setEndRed(float endRed) {
/*  91 */     this.endRed = endRed;
/*     */   }
/*     */   
/*     */   public float getEndGreen() {
/*  95 */     return this.endGreen;
/*     */   }
/*     */   
/*     */   public void setEndGreen(float endGreen) {
/*  99 */     this.endGreen = endGreen;
/*     */   }
/*     */   
/*     */   public float getEndBlue() {
/* 103 */     return this.endBlue;
/*     */   }
/*     */   
/*     */   public void setEndBlue(float endBlue) {
/* 107 */     this.endBlue = endBlue;
/*     */   }
/*     */   
/*     */   public static ParticleDustColorTransitionData read(PacketWrapper<?> wrapper) {
/* 111 */     float startRed = wrapper.readFloat();
/* 112 */     float startGreen = wrapper.readFloat();
/* 113 */     float startBlue = wrapper.readFloat();
/* 114 */     float scale = wrapper.readFloat();
/* 115 */     float endRed = wrapper.readFloat();
/* 116 */     float endGreen = wrapper.readFloat();
/* 117 */     float endBlue = wrapper.readFloat();
/* 118 */     return new ParticleDustColorTransitionData(scale, startRed, startGreen, startBlue, endRed, endGreen, endBlue);
/*     */   }
/*     */   
/*     */   public static void write(PacketWrapper<?> wrapper, ParticleDustColorTransitionData data) {
/* 122 */     wrapper.writeFloat(data.getStartRed());
/* 123 */     wrapper.writeFloat(data.getStartGreen());
/* 124 */     wrapper.writeFloat(data.getStartBlue());
/* 125 */     wrapper.writeFloat(data.getScale());
/* 126 */     wrapper.writeFloat(data.getEndRed());
/* 127 */     wrapper.writeFloat(data.getEndGreen());
/* 128 */     wrapper.writeFloat(data.getEndBlue());
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 133 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\data\ParticleDustColorTransitionData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */