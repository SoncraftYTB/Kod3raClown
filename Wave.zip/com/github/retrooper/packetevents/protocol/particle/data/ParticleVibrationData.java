/*     */ package com.github.retrooper.packetevents.protocol.particle.data;
/*     */ 
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.mapper.MappedEntity;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*     */ import com.github.retrooper.packetevents.util.Vector3i;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.Optional;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class ParticleVibrationData extends ParticleData {
/*     */   private Vector3i startingPosition;
/*     */   
/*     */   private PositionType type;
/*     */   
/*     */   @Nullable
/*     */   private Vector3i blockPosition;
/*     */   
/*     */   @Nullable
/*     */   private Integer entityId;
/*     */   
/*     */   private int ticks;
/*     */   
/*     */   public enum PositionType implements MappedEntity {
/*  35 */     BLOCK((String)new ResourceLocation("minecraft:block")),
/*  36 */     ENTITY((String)new ResourceLocation("minecraft:entity"));
/*     */     
/*     */     private final ResourceLocation name;
/*     */     
/*     */     PositionType(ResourceLocation name) {
/*  41 */       this.name = name;
/*     */     }
/*     */     
/*     */     public ResourceLocation getName() {
/*  46 */       return this.name;
/*     */     }
/*     */     
/*     */     public static PositionType getById(int id) {
/*  50 */       switch (id) {
/*     */         case 0:
/*  52 */           return BLOCK;
/*     */         case 1:
/*  54 */           return ENTITY;
/*     */       } 
/*  56 */       throw new IllegalArgumentException("Illegal position type id: " + id);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PositionType getByName(String name) {
/*  61 */       return getByName(new ResourceLocation(name));
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static PositionType getByName(ResourceLocation name) {
/*  65 */       for (PositionType type : values()) {
/*  66 */         if (type.getName().equals(name))
/*  67 */           return type; 
/*     */       } 
/*  70 */       return null;
/*     */     }
/*     */     
/*     */     public int getId(ClientVersion version) {
/*  75 */       return ordinal();
/*     */     }
/*     */   }
/*     */   
/*     */   public ParticleVibrationData(Vector3i startingPosition, @Nullable Vector3i blockPosition, int ticks) {
/*  86 */     this.startingPosition = startingPosition;
/*  87 */     this.type = PositionType.BLOCK;
/*  88 */     this.blockPosition = blockPosition;
/*  89 */     this.entityId = null;
/*  90 */     this.ticks = ticks;
/*     */   }
/*     */   
/*     */   public ParticleVibrationData(Vector3i startingPosition, int entityId, int ticks) {
/*  94 */     this.startingPosition = startingPosition;
/*  95 */     this.type = PositionType.ENTITY;
/*  96 */     this.blockPosition = null;
/*  97 */     this.entityId = Integer.valueOf(entityId);
/*  98 */     this.ticks = ticks;
/*     */   }
/*     */   
/*     */   public Vector3i getStartingPosition() {
/* 102 */     return this.startingPosition;
/*     */   }
/*     */   
/*     */   public void setStartingPosition(Vector3i startingPosition) {
/* 106 */     this.startingPosition = startingPosition;
/*     */   }
/*     */   
/*     */   public PositionType getType() {
/* 110 */     return this.type;
/*     */   }
/*     */   
/*     */   public Optional<Vector3i> getBlockPosition() {
/* 114 */     return Optional.ofNullable(this.blockPosition);
/*     */   }
/*     */   
/*     */   public void setBlockPosition(@Nullable Vector3i blockPosition) {
/* 118 */     this.blockPosition = blockPosition;
/*     */   }
/*     */   
/*     */   public Optional<Integer> getEntityId() {
/* 122 */     return Optional.ofNullable(this.entityId);
/*     */   }
/*     */   
/*     */   public void setEntityId(int entityId) {
/* 126 */     this.entityId = Integer.valueOf(entityId);
/*     */   }
/*     */   
/*     */   public int getTicks() {
/* 130 */     return this.ticks;
/*     */   }
/*     */   
/*     */   public void setTicks(int ticks) {
/* 134 */     this.ticks = ticks;
/*     */   }
/*     */   
/*     */   public static ParticleVibrationData read(PacketWrapper<?> wrapper) {
/*     */     PositionType positionType;
/* 139 */     Vector3i startingPos = wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_19_4) ? Vector3i.zero() : wrapper.readBlockPosition();
/* 142 */     if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_20_3)) {
/* 143 */       positionType = PositionType.getById(wrapper.readVarInt());
/*     */     } else {
/* 145 */       String positionTypeName = wrapper.readString();
/* 146 */       positionType = PositionType.getByName(positionTypeName);
/* 147 */       if (positionType == null)
/* 148 */         throw new IllegalArgumentException("Unknown position type: " + positionTypeName); 
/*     */     } 
/* 152 */     switch (positionType) {
/*     */       case BLOCK:
/* 154 */         return new ParticleVibrationData(startingPos, wrapper.readBlockPosition(), wrapper.readVarInt());
/*     */       case ENTITY:
/* 156 */         return new ParticleVibrationData(startingPos, wrapper.readVarInt(), wrapper.readVarInt());
/*     */     } 
/* 158 */     throw new IllegalArgumentException("Illegal position type: " + positionType);
/*     */   }
/*     */   
/*     */   public static void write(PacketWrapper<?> wrapper, ParticleVibrationData data) {
/* 163 */     if (wrapper.getServerVersion().isOlderThan(ServerVersion.V_1_19_4))
/* 164 */       wrapper.writeBlockPosition(data.getStartingPosition()); 
/* 167 */     if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_20_3)) {
/* 168 */       wrapper.writeVarInt(data.getType().getId(wrapper.getServerVersion().toClientVersion()));
/*     */     } else {
/* 170 */       wrapper.writeIdentifier(data.getType().getName());
/*     */     } 
/* 173 */     if (data.getType() == PositionType.BLOCK) {
/* 174 */       wrapper.writeBlockPosition(data.getBlockPosition().get());
/* 175 */     } else if (data.getType() == PositionType.ENTITY) {
/* 176 */       wrapper.writeVarInt(((Integer)data.getEntityId().get()).intValue());
/*     */     } 
/* 178 */     wrapper.writeVarInt(data.getTicks());
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 183 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\data\ParticleVibrationData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */