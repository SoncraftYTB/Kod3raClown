/*    */ package com.github.retrooper.packetevents.protocol.particle.data;
/*    */ 
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class ParticleBlockStateData extends ParticleData implements LegacyConvertible {
/*    */   private WrappedBlockState blockState;
/*    */   
/*    */   public ParticleBlockStateData(WrappedBlockState blockState) {
/* 30 */     this.blockState = blockState;
/*    */   }
/*    */   
/*    */   public WrappedBlockState getBlockState() {
/* 34 */     return this.blockState;
/*    */   }
/*    */   
/*    */   public void setBlockState(WrappedBlockState blockState) {
/* 38 */     this.blockState = blockState;
/*    */   }
/*    */   
/*    */   public static ParticleBlockStateData read(PacketWrapper<?> wrapper) {
/*    */     int blockID;
/* 43 */     if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_9)) {
/* 44 */       blockID = wrapper.readVarInt();
/* 46 */     } else if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_13)) {
/* 47 */       blockID = wrapper.readInt();
/*    */     } else {
/* 50 */       blockID = wrapper.readVarInt();
/*    */     } 
/* 52 */     return new ParticleBlockStateData(WrappedBlockState.getByGlobalId(wrapper.getServerVersion()
/* 53 */           .toClientVersion(), blockID));
/*    */   }
/*    */   
/*    */   public static void write(PacketWrapper<?> wrapper, ParticleBlockStateData data) {
/* 57 */     if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_9)) {
/* 58 */       wrapper.writeVarInt(data.getBlockState().getGlobalId());
/*    */     } else {
/* 61 */       wrapper.writeInt(data.getBlockState().getGlobalId());
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 67 */     return false;
/*    */   }
/*    */   
/*    */   public LegacyParticleData toLegacy(ClientVersion version) {
/* 72 */     return LegacyParticleData.ofOne(this.blockState.getGlobalId());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\data\ParticleBlockStateData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */