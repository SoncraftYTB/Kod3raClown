package com.github.retrooper.packetevents.protocol.particle.data;

import com.github.retrooper.packetevents.protocol.player.ClientVersion;

public interface LegacyConvertible {
  LegacyParticleData toLegacy(ClientVersion paramClientVersion);
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\data\LegacyConvertible.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */