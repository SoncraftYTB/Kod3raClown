/*    */ package com.github.retrooper.packetevents.protocol.particle.data;
/*    */ 
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class ParticleShriekData extends ParticleData {
/*    */   private int delay;
/*    */   
/*    */   public ParticleShriekData(int delay) {
/* 10 */     this.delay = delay;
/*    */   }
/*    */   
/*    */   public int getDelay() {
/* 14 */     return this.delay;
/*    */   }
/*    */   
/*    */   public void setDelay(int delay) {
/* 18 */     this.delay = delay;
/*    */   }
/*    */   
/*    */   public static ParticleShriekData read(PacketWrapper<?> wrapper) {
/* 22 */     return new ParticleShriekData(wrapper.readVarInt());
/*    */   }
/*    */   
/*    */   public static void write(PacketWrapper<?> wrapper, ParticleShriekData data) {
/* 26 */     wrapper.writeVarInt(data.getDelay());
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 31 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\data\ParticleShriekData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */