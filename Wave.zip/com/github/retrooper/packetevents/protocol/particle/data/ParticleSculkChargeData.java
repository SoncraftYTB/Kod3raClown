/*    */ package com.github.retrooper.packetevents.protocol.particle.data;
/*    */ 
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class ParticleSculkChargeData extends ParticleData {
/*    */   private float roll;
/*    */   
/*    */   public ParticleSculkChargeData(float roll) {
/* 10 */     this.roll = roll;
/*    */   }
/*    */   
/*    */   public float getRoll() {
/* 14 */     return this.roll;
/*    */   }
/*    */   
/*    */   public void setRoll(float roll) {
/* 18 */     this.roll = roll;
/*    */   }
/*    */   
/*    */   public static ParticleSculkChargeData read(PacketWrapper<?> wrapper) {
/* 22 */     return new ParticleSculkChargeData(wrapper.readFloat());
/*    */   }
/*    */   
/*    */   public static void write(PacketWrapper<?> wrapper, ParticleSculkChargeData data) {
/* 26 */     wrapper.writeFloat(data.getRoll());
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 31 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\data\ParticleSculkChargeData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */