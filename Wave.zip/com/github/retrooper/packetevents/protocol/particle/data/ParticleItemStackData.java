/*    */ package com.github.retrooper.packetevents.protocol.particle.data;
/*    */ 
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.protocol.item.ItemStack;
/*    */ import com.github.retrooper.packetevents.protocol.item.type.ItemTypes;
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class ParticleItemStackData extends ParticleData implements LegacyConvertible {
/*    */   private ItemStack itemStack;
/*    */   
/*    */   public ParticleItemStackData(ItemStack itemStack) {
/* 31 */     this.itemStack = itemStack;
/*    */   }
/*    */   
/*    */   public ItemStack getItemStack() {
/* 35 */     return this.itemStack;
/*    */   }
/*    */   
/*    */   public void setItemStack(ItemStack itemStack) {
/* 39 */     this.itemStack = itemStack;
/*    */   }
/*    */   
/*    */   public static ParticleItemStackData read(PacketWrapper<?> wrapper) {
/* 43 */     if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_13))
/* 44 */       return new ParticleItemStackData(wrapper.readItemStack()); 
/* 47 */     return new ParticleItemStackData(ItemStack.builder()
/* 48 */         .type(ItemTypes.getById(wrapper.getClientVersion(), wrapper.readVarInt()))
/* 49 */         .build());
/*    */   }
/*    */   
/*    */   public static void write(PacketWrapper<?> wrapper, ParticleItemStackData data) {
/* 54 */     wrapper.writeItemStack(data.getItemStack());
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 59 */     return false;
/*    */   }
/*    */   
/*    */   public LegacyParticleData toLegacy(ClientVersion version) {
/* 64 */     return LegacyParticleData.ofTwo(this.itemStack.getType().getId(version), this.itemStack.getLegacyData());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\data\ParticleItemStackData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */