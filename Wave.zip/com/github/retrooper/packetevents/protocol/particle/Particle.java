/*    */ package com.github.retrooper.packetevents.protocol.particle;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleData;
/*    */ import com.github.retrooper.packetevents.protocol.particle.type.ParticleType;
/*    */ 
/*    */ public class Particle {
/*    */   private ParticleType type;
/*    */   
/*    */   private ParticleData data;
/*    */   
/*    */   public Particle(ParticleType type, ParticleData data) {
/* 29 */     this.type = type;
/* 30 */     this.data = data;
/*    */   }
/*    */   
/*    */   public Particle(ParticleType type) {
/* 34 */     this(type, new ParticleData());
/*    */   }
/*    */   
/*    */   public ParticleType getType() {
/* 38 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(ParticleType type) {
/* 42 */     this.type = type;
/*    */   }
/*    */   
/*    */   public ParticleData getData() {
/* 46 */     return this.data;
/*    */   }
/*    */   
/*    */   public void setData(ParticleData data) {
/* 50 */     this.data = data;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\Particle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */