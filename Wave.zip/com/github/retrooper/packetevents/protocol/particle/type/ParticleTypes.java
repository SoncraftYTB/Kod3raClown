/*     */ package com.github.retrooper.packetevents.protocol.particle.type;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleBlockStateData;
/*     */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleData;
/*     */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleDustColorTransitionData;
/*     */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleDustData;
/*     */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleItemStackData;
/*     */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleSculkChargeData;
/*     */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleShriekData;
/*     */ import com.github.retrooper.packetevents.protocol.particle.data.ParticleVibrationData;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*     */ import com.github.retrooper.packetevents.util.TypesBuilder;
/*     */ import com.github.retrooper.packetevents.util.TypesBuilderData;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ public class ParticleTypes {
/*  34 */   private static final Map<String, ParticleType> PARTICLE_TYPE_MAP = new HashMap<>();
/*     */   
/*  35 */   private static final Map<Byte, Map<Integer, ParticleType>> PARTICLE_TYPE_ID_MAP = new HashMap<>();
/*     */   
/*  36 */   private static final TypesBuilder TYPES_BUILDER = new TypesBuilder("particle/particle_type_mappings", new ClientVersion[] { 
/*  36 */         ClientVersion.V_1_12_2, ClientVersion.V_1_13, ClientVersion.V_1_13_2, ClientVersion.V_1_14, ClientVersion.V_1_15, ClientVersion.V_1_16, ClientVersion.V_1_16_2, ClientVersion.V_1_17, ClientVersion.V_1_18, ClientVersion.V_1_19, 
/*  36 */         ClientVersion.V_1_19_4, ClientVersion.V_1_20, ClientVersion.V_1_20_3 });
/*     */   
/*     */   public static ParticleType define(String key, final Function<PacketWrapper<?>, ParticleData> readDataFunction, final BiConsumer<PacketWrapper<?>, ParticleData> writeDataFunction) {
/*  52 */     final TypesBuilderData data = TYPES_BUILDER.defineFromArray(key);
/*  53 */     ParticleType particleType = new ParticleType() {
/*  54 */         private final int[] ids = data.getData();
/*     */         
/*     */         public ResourceLocation getName() {
/*  57 */           return data.getName();
/*     */         }
/*     */         
/*     */         public int getId(ClientVersion version) {
/*  62 */           int index = ParticleTypes.TYPES_BUILDER.getDataIndex(version);
/*  63 */           return this.ids[index];
/*     */         }
/*     */         
/*     */         public Function<PacketWrapper<?>, ParticleData> readDataFunction() {
/*  68 */           return readDataFunction;
/*     */         }
/*     */         
/*     */         public BiConsumer<PacketWrapper<?>, ParticleData> writeDataFunction() {
/*  73 */           return writeDataFunction;
/*     */         }
/*     */         
/*     */         public boolean equals(Object obj) {
/*  78 */           if (obj instanceof ParticleType)
/*  79 */             return getName().equals(((ParticleType)obj).getName()); 
/*  81 */           return false;
/*     */         }
/*     */       };
/*  85 */     PARTICLE_TYPE_MAP.put(particleType.getName().toString(), particleType);
/*  86 */     for (ClientVersion version : TYPES_BUILDER.getVersions()) {
/*  87 */       int index = TYPES_BUILDER.getDataIndex(version);
/*  88 */       Map<Integer, ParticleType> typeIdMap = PARTICLE_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/*  89 */       typeIdMap.put(Integer.valueOf(particleType.getId(version)), particleType);
/*     */     } 
/*  91 */     return particleType;
/*     */   }
/*     */   
/*     */   public static ParticleType define(String key) {
/*  96 */     return define(key, wrapper -> new ParticleData(), (wrapper, data) -> {
/*     */         
/*     */         });
/*     */   }
/*     */   
/*     */   public static ParticleType getByName(String name) {
/* 106 */     return PARTICLE_TYPE_MAP.get(name);
/*     */   }
/*     */   
/*     */   public static ParticleType getById(ClientVersion version, int id) {
/* 110 */     int index = TYPES_BUILDER.getDataIndex(version);
/* 111 */     Map<Integer, ParticleType> typeIdMap = PARTICLE_TYPE_ID_MAP.get(Byte.valueOf((byte)index));
/* 112 */     return typeIdMap.get(Integer.valueOf(id));
/*     */   }
/*     */   
/* 115 */   public static final ParticleType AMBIENT_ENTITY_EFFECT = define("ambient_entity_effect");
/*     */   
/* 116 */   public static final ParticleType ANGRY_VILLAGER = define("angry_villager");
/*     */   
/*     */   public static final ParticleType BLOCK;
/*     */   
/*     */   public static final ParticleType BLOCK_MARKER;
/*     */   
/*     */   static {
/* 117 */     BLOCK = define("block", ParticleBlockStateData::read, (wrapper, data) -> ParticleBlockStateData.write(wrapper, (ParticleBlockStateData)data));
/* 118 */     BLOCK_MARKER = define("block_marker", ParticleBlockStateData::read, (wrapper, data) -> ParticleBlockStateData.write(wrapper, (ParticleBlockStateData)data));
/*     */   }
/*     */   
/* 119 */   public static final ParticleType BUBBLE = define("bubble");
/*     */   
/* 120 */   public static final ParticleType CLOUD = define("cloud");
/*     */   
/* 121 */   public static final ParticleType CRIT = define("crit");
/*     */   
/* 122 */   public static final ParticleType DAMAGE_INDICATOR = define("damage_indicator");
/*     */   
/* 123 */   public static final ParticleType DRAGON_BREATH = define("dragon_breath");
/*     */   
/* 124 */   public static final ParticleType DRIPPING_LAVA = define("dripping_lava");
/*     */   
/* 125 */   public static final ParticleType FALLING_LAVA = define("falling_lava");
/*     */   
/* 126 */   public static final ParticleType LANDING_LAVA = define("landing_lava");
/*     */   
/* 127 */   public static final ParticleType DRIPPING_WATER = define("dripping_water");
/*     */   
/* 128 */   public static final ParticleType FALLING_WATER = define("falling_water");
/*     */   
/*     */   public static final ParticleType DUST;
/*     */   
/*     */   public static final ParticleType DUST_COLOR_TRANSITION;
/*     */   
/*     */   static {
/* 129 */     DUST = define("dust", ParticleDustData::read, (wrapper, data) -> ParticleDustData.write(wrapper, (ParticleDustData)data));
/* 130 */     DUST_COLOR_TRANSITION = define("dust_color_transition", ParticleDustColorTransitionData::read, (wrapper, data) -> ParticleDustColorTransitionData.write(wrapper, (ParticleDustColorTransitionData)data));
/*     */   }
/*     */   
/* 131 */   public static final ParticleType EFFECT = define("effect");
/*     */   
/* 132 */   public static final ParticleType ELDER_GUARDIAN = define("elder_guardian");
/*     */   
/* 133 */   public static final ParticleType ENCHANTED_HIT = define("enchanted_hit");
/*     */   
/* 134 */   public static final ParticleType ENCHANT = define("enchant");
/*     */   
/* 135 */   public static final ParticleType END_ROD = define("end_rod");
/*     */   
/* 136 */   public static final ParticleType ENTITY_EFFECT = define("entity_effect");
/*     */   
/* 137 */   public static final ParticleType EXPLOSION_EMITTER = define("explosion_emitter");
/*     */   
/* 138 */   public static final ParticleType EXPLOSION = define("explosion");
/*     */   
/* 139 */   public static final ParticleType SONIC_BOOM = define("sonic_boom");
/*     */   
/*     */   public static final ParticleType FALLING_DUST;
/*     */   
/*     */   static {
/* 140 */     FALLING_DUST = define("falling_dust", ParticleBlockStateData::read, (wrapper, data) -> ParticleBlockStateData.write(wrapper, (ParticleBlockStateData)data));
/*     */   }
/*     */   
/* 141 */   public static final ParticleType FIREWORK = define("firework");
/*     */   
/* 142 */   public static final ParticleType FISHING = define("fishing");
/*     */   
/* 143 */   public static final ParticleType FLAME = define("flame");
/*     */   
/* 144 */   public static final ParticleType SCULK_SOUL = define("sculk_soul");
/*     */   
/*     */   public static final ParticleType SCULK_CHARGE;
/*     */   
/*     */   static {
/* 145 */     SCULK_CHARGE = define("sculk_charge", ParticleSculkChargeData::read, (wrapper, data) -> ParticleSculkChargeData.write(wrapper, (ParticleSculkChargeData)data));
/*     */   }
/*     */   
/* 146 */   public static final ParticleType SCULK_CHARGE_POP = define("sculk_charge_pop");
/*     */   
/* 147 */   public static final ParticleType SOUL_FIRE_FLAME = define("soul_fire_flame");
/*     */   
/* 148 */   public static final ParticleType SOUL = define("soul");
/*     */   
/* 149 */   public static final ParticleType FLASH = define("flash");
/*     */   
/* 150 */   public static final ParticleType HAPPY_VILLAGER = define("happy_villager");
/*     */   
/* 151 */   public static final ParticleType COMPOSTER = define("composter");
/*     */   
/* 152 */   public static final ParticleType HEART = define("heart");
/*     */   
/* 153 */   public static final ParticleType INSTANT_EFFECT = define("instant_effect");
/*     */   
/*     */   public static final ParticleType ITEM;
/*     */   
/*     */   public static final ParticleType VIBRATION;
/*     */   
/*     */   static {
/* 154 */     ITEM = define("item", ParticleItemStackData::read, (wrapper, data) -> ParticleItemStackData.write(wrapper, (ParticleItemStackData)data));
/* 155 */     VIBRATION = define("vibration", ParticleVibrationData::read, (wrapper, data) -> ParticleVibrationData.write(wrapper, (ParticleVibrationData)data));
/*     */   }
/*     */   
/* 156 */   public static final ParticleType ITEM_SLIME = define("item_slime");
/*     */   
/* 157 */   public static final ParticleType ITEM_SNOWBALL = define("item_snowball");
/*     */   
/* 158 */   public static final ParticleType LARGE_SMOKE = define("large_smoke");
/*     */   
/* 159 */   public static final ParticleType LAVA = define("lava");
/*     */   
/* 160 */   public static final ParticleType MYCELIUM = define("mycelium");
/*     */   
/* 161 */   public static final ParticleType NOTE = define("note");
/*     */   
/* 162 */   public static final ParticleType POOF = define("poof");
/*     */   
/* 163 */   public static final ParticleType PORTAL = define("portal");
/*     */   
/* 164 */   public static final ParticleType RAIN = define("rain");
/*     */   
/* 165 */   public static final ParticleType SMOKE = define("smoke");
/*     */   
/* 166 */   public static final ParticleType SNEEZE = define("sneeze");
/*     */   
/* 167 */   public static final ParticleType SPIT = define("spit");
/*     */   
/* 168 */   public static final ParticleType SQUID_INK = define("squid_ink");
/*     */   
/* 169 */   public static final ParticleType SWEEP_ATTACK = define("sweep_attack");
/*     */   
/* 170 */   public static final ParticleType TOTEM_OF_UNDYING = define("totem_of_undying");
/*     */   
/* 171 */   public static final ParticleType UNDERWATER = define("underwater");
/*     */   
/* 172 */   public static final ParticleType SPLASH = define("splash");
/*     */   
/* 173 */   public static final ParticleType WITCH = define("witch");
/*     */   
/* 174 */   public static final ParticleType BUBBLE_POP = define("bubble_pop");
/*     */   
/* 175 */   public static final ParticleType CURRENT_DOWN = define("current_down");
/*     */   
/* 176 */   public static final ParticleType BUBBLE_COLUMN_UP = define("bubble_column_up");
/*     */   
/* 177 */   public static final ParticleType NAUTILUS = define("nautilus");
/*     */   
/* 178 */   public static final ParticleType DOLPHIN = define("dolphin");
/*     */   
/* 179 */   public static final ParticleType CAMPFIRE_COSY_SMOKE = define("campfire_cosy_smoke");
/*     */   
/* 180 */   public static final ParticleType CAMPFIRE_SIGNAL_SMOKE = define("campfire_signal_smoke");
/*     */   
/* 181 */   public static final ParticleType DRIPPING_HONEY = define("dripping_honey");
/*     */   
/* 182 */   public static final ParticleType FALLING_HONEY = define("falling_honey");
/*     */   
/* 183 */   public static final ParticleType LANDING_HONEY = define("landing_honey");
/*     */   
/* 184 */   public static final ParticleType FALLING_NECTAR = define("falling_nectar");
/*     */   
/* 185 */   public static final ParticleType FALLING_SPORE_BLOSSOM = define("falling_spore_blossom");
/*     */   
/* 186 */   public static final ParticleType ASH = define("ash");
/*     */   
/* 187 */   public static final ParticleType CRIMSON_SPORE = define("crimson_spore");
/*     */   
/* 188 */   public static final ParticleType WARPED_SPORE = define("warped_spore");
/*     */   
/* 189 */   public static final ParticleType SPORE_BLOSSOM_AIR = define("spore_blossom_air");
/*     */   
/* 190 */   public static final ParticleType DRIPPING_OBSIDIAN_TEAR = define("dripping_obsidian_tear");
/*     */   
/* 191 */   public static final ParticleType FALLING_OBSIDIAN_TEAR = define("falling_obsidian_tear");
/*     */   
/* 192 */   public static final ParticleType LANDING_OBSIDIAN_TEAR = define("landing_obsidian_tear");
/*     */   
/* 193 */   public static final ParticleType REVERSE_PORTAL = define("reverse_portal");
/*     */   
/* 194 */   public static final ParticleType WHITE_ASH = define("white_ash");
/*     */   
/* 195 */   public static final ParticleType SMALL_FLAME = define("small_flame");
/*     */   
/* 196 */   public static final ParticleType SNOWFLAKE = define("snowflake");
/*     */   
/* 197 */   public static final ParticleType DRIPPING_DRIPSTONE_LAVA = define("dripping_dripstone_lava");
/*     */   
/* 198 */   public static final ParticleType FALLING_DRIPSTONE_LAVA = define("falling_dripstone_lava");
/*     */   
/* 199 */   public static final ParticleType DRIPPING_DRIPSTONE_WATER = define("dripping_dripstone_water");
/*     */   
/* 200 */   public static final ParticleType FALLING_DRIPSTONE_WATER = define("falling_dripstone_water");
/*     */   
/* 201 */   public static final ParticleType GLOW_SQUID_INK = define("glow_squid_ink");
/*     */   
/* 202 */   public static final ParticleType GLOW = define("glow");
/*     */   
/* 203 */   public static final ParticleType WAX_ON = define("wax_on");
/*     */   
/* 204 */   public static final ParticleType WAX_OFF = define("wax_off");
/*     */   
/* 205 */   public static final ParticleType ELECTRIC_SPARK = define("electric_spark");
/*     */   
/* 206 */   public static final ParticleType SCRAPE = define("scrape");
/*     */   
/*     */   public static final ParticleType SHRIEK;
/*     */   
/*     */   static {
/* 207 */     SHRIEK = define("shriek", ParticleShriekData::read, (wrapper, data) -> ParticleShriekData.write(wrapper, (ParticleShriekData)data));
/*     */   }
/*     */   
/* 209 */   public static final ParticleType DRIPPING_CHERRY_LEAVES = define("dripping_cherry_leaves");
/*     */   
/* 210 */   public static final ParticleType FALLING_CHERRY_LEAVES = define("falling_cherry_leaves");
/*     */   
/* 211 */   public static final ParticleType LANDING_CHERRY_LEAVES = define("landing_cherry_leaves");
/*     */   
/* 213 */   public static final ParticleType CHERRY_LEAVES = define("cherry_leaves");
/*     */   
/* 214 */   public static final ParticleType EGG_CRACK = define("egg_crack");
/*     */   
/* 216 */   public static final ParticleType GUST = define("gust");
/*     */   
/* 217 */   public static final ParticleType GUST_EMITTER = define("gust_emitter");
/*     */   
/* 218 */   public static final ParticleType WHITE_SMOKE = define("white_smoke");
/*     */   
/* 219 */   public static final ParticleType DUST_PLUME = define("dust_plume");
/*     */   
/* 220 */   public static final ParticleType GUST_DUST = define("gust_dust");
/*     */   
/* 221 */   public static final ParticleType TRIAL_SPAWNER_DETECTION = define("trial_spawner_detection");
/*     */   
/*     */   static {
/* 224 */     TYPES_BUILDER.unloadFileMappings();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\type\ParticleTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */