package com.github.retrooper.packetevents.protocol.particle.type;

import com.github.retrooper.packetevents.protocol.mapper.MappedEntity;
import com.github.retrooper.packetevents.protocol.particle.data.ParticleData;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import java.util.function.BiConsumer;
import java.util.function.Function;

public interface ParticleType extends MappedEntity {
  Function<PacketWrapper<?>, ParticleData> readDataFunction();
  
  BiConsumer<PacketWrapper<?>, ParticleData> writeDataFunction();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\particle\type\ParticleType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */