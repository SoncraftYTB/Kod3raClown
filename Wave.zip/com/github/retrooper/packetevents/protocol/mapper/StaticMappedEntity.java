/*    */ package com.github.retrooper.packetevents.protocol.mapper;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ 
/*    */ public interface StaticMappedEntity extends MappedEntity {
/*    */   int getId();
/*    */   
/*    */   default int getId(ClientVersion version) {
/* 27 */     return getId();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\mapper\StaticMappedEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */