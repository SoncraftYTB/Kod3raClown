/*    */ package com.github.retrooper.packetevents.protocol;
/*    */ 
/*    */ public enum PacketSide {
/* 22 */   CLIENT, SERVER;
/*    */   
/*    */   public PacketSide getOpposite() {
/* 25 */     if (this == CLIENT)
/* 26 */       return SERVER; 
/* 29 */     return CLIENT;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\PacketSide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */