/*    */ package com.github.retrooper.packetevents.protocol.entity.villager;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.entity.villager.profession.VillagerProfession;
/*    */ import com.github.retrooper.packetevents.protocol.entity.villager.profession.VillagerProfessions;
/*    */ import com.github.retrooper.packetevents.protocol.entity.villager.type.VillagerType;
/*    */ import com.github.retrooper.packetevents.protocol.entity.villager.type.VillagerTypes;
/*    */ 
/*    */ public class VillagerData {
/*    */   private VillagerType type;
/*    */   
/*    */   private VillagerProfession profession;
/*    */   
/*    */   private int level;
/*    */   
/*    */   public VillagerData(VillagerType type, VillagerProfession profession, int level) {
/* 32 */     this.type = type;
/* 33 */     this.profession = profession;
/* 34 */     this.level = level;
/*    */   }
/*    */   
/*    */   public VillagerData(int typeId, int professionId, int level) {
/* 38 */     this(VillagerTypes.getById(typeId), VillagerProfessions.getById(professionId), level);
/*    */   }
/*    */   
/*    */   public VillagerType getType() {
/* 42 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(VillagerType type) {
/* 46 */     this.type = type;
/*    */   }
/*    */   
/*    */   public VillagerProfession getProfession() {
/* 50 */     return this.profession;
/*    */   }
/*    */   
/*    */   public void setProfession(VillagerProfession profession) {
/* 54 */     this.profession = profession;
/*    */   }
/*    */   
/*    */   public int getLevel() {
/* 58 */     return this.level;
/*    */   }
/*    */   
/*    */   public void setLevel(int level) {
/* 62 */     this.level = level;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\entity\villager\VillagerData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */