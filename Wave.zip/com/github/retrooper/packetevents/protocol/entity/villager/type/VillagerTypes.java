/*    */ package com.github.retrooper.packetevents.protocol.entity.villager.type;
/*    */ 
/*    */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class VillagerTypes {
/* 27 */   private static final Map<String, VillagerType> VILLAGER_TYPE_MAP = new HashMap<>();
/*    */   
/* 28 */   private static final Map<Byte, VillagerType> VILLAGER_TYPE_ID_MAP = new HashMap<>();
/*    */   
/*    */   public static VillagerType define(final int id, String name) {
/* 32 */     final ResourceLocation location = new ResourceLocation(name);
/* 33 */     VillagerType type = new VillagerType() {
/*    */         public ResourceLocation getName() {
/* 36 */           return location;
/*    */         }
/*    */         
/*    */         public int getId() {
/* 41 */           return id;
/*    */         }
/*    */       };
/* 44 */     VILLAGER_TYPE_MAP.put(type.getName().toString(), type);
/* 45 */     VILLAGER_TYPE_ID_MAP.put(Byte.valueOf((byte)type.getId()), type);
/* 46 */     return type;
/*    */   }
/*    */   
/*    */   public static VillagerType getById(int id) {
/* 50 */     return VILLAGER_TYPE_ID_MAP.get(Byte.valueOf((byte)id));
/*    */   }
/*    */   
/*    */   public static VillagerType getByName(String name) {
/* 55 */     return VILLAGER_TYPE_MAP.get(name);
/*    */   }
/*    */   
/* 58 */   public static final VillagerType DESERT = define(0, "minecraft:desert");
/*    */   
/* 59 */   public static final VillagerType JUNGLE = define(1, "minecraft:jungle");
/*    */   
/* 60 */   public static final VillagerType PLAINS = define(2, "minecraft:plains");
/*    */   
/* 61 */   public static final VillagerType SAVANNA = define(3, "minecraft:savanna");
/*    */   
/* 62 */   public static final VillagerType SNOW = define(4, "minecraft:snow");
/*    */   
/* 63 */   public static final VillagerType SWAMP = define(5, "minecraft:swamp");
/*    */   
/* 64 */   public static final VillagerType TAIGA = define(6, "minecraft:taiga");
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\entity\villager\type\VillagerTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */