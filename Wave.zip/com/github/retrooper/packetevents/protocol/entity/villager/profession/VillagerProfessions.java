/*    */ package com.github.retrooper.packetevents.protocol.entity.villager.profession;
/*    */ 
/*    */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class VillagerProfessions {
/* 28 */   private static final Map<String, VillagerProfession> VILLAGER_PROFESSION_MAP = new HashMap<>();
/*    */   
/* 29 */   private static final Map<Byte, VillagerProfession> VILLAGER_PROFESSION_ID_MAP = new HashMap<>();
/*    */   
/*    */   public static VillagerProfession define(final int id, String name) {
/* 32 */     final ResourceLocation location = new ResourceLocation(name);
/* 33 */     VillagerProfession type = new VillagerProfession() {
/*    */         public ResourceLocation getName() {
/* 36 */           return location;
/*    */         }
/*    */         
/*    */         public int getId() {
/* 41 */           return id;
/*    */         }
/*    */       };
/* 44 */     VILLAGER_PROFESSION_MAP.put(type.getName().toString(), type);
/* 45 */     VILLAGER_PROFESSION_ID_MAP.put(Byte.valueOf((byte)type.getId()), type);
/* 46 */     return type;
/*    */   }
/*    */   
/*    */   public static VillagerProfession getById(int id) {
/* 50 */     return VILLAGER_PROFESSION_ID_MAP.get(Byte.valueOf((byte)id));
/*    */   }
/*    */   
/*    */   public static VillagerProfession getByName(String name) {
/* 55 */     return VILLAGER_PROFESSION_MAP.get(name);
/*    */   }
/*    */   
/* 58 */   public static final VillagerProfession NONE = define(0, "minecraft:none");
/*    */   
/* 59 */   public static final VillagerProfession ARMORER = define(1, "minecraft:armorer");
/*    */   
/* 60 */   public static final VillagerProfession BUTCHER = define(2, "minecraft:butcher");
/*    */   
/* 61 */   public static final VillagerProfession CARTOGRAPHER = define(3, "minecraft:cartographer");
/*    */   
/* 62 */   public static final VillagerProfession CLERIC = define(4, "minecraft:cleric");
/*    */   
/* 63 */   public static final VillagerProfession FARMER = define(5, "minecraft:farmer");
/*    */   
/* 64 */   public static final VillagerProfession FISHERMAN = define(6, "minecraft:fisherman");
/*    */   
/* 65 */   public static final VillagerProfession FLETCHER = define(7, "minecraft:fletcher");
/*    */   
/* 66 */   public static final VillagerProfession LEATHERWORKER = define(8, "minecraft:leatherworker");
/*    */   
/* 67 */   public static final VillagerProfession LIBRARIAN = define(9, "minecraft:librarian");
/*    */   
/* 68 */   public static final VillagerProfession MASON = define(10, "minecraft:mason");
/*    */   
/* 69 */   public static final VillagerProfession NITWIT = define(11, "minecraft:nitwit");
/*    */   
/* 70 */   public static final VillagerProfession SHEPHERD = define(12, "minecraft:shepherd");
/*    */   
/* 71 */   public static final VillagerProfession TOOLSMITH = define(13, "minecraft:toolsmith");
/*    */   
/* 72 */   public static final VillagerProfession WEAPONSMITH = define(14, "minecraft:weaponsmith");
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\entity\villager\profession\VillagerProfessions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */