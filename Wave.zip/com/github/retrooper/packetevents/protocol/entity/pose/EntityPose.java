/*    */ package com.github.retrooper.packetevents.protocol.entity.pose;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ 
/*    */ public enum EntityPose {
/* 24 */   STANDING, FALL_FLYING, SLEEPING, SWIMMING, SPIN_ATTACK, CROUCHING, LONG_JUMPING, DYING, CROAKING, USING_TONGUE, SITTING, ROARING, SNIFFING, EMERGING, DIGGING;
/*    */   
/*    */   public int getId(ClientVersion version) {
/* 41 */     if (this == DYING && version.isOlderThan(ClientVersion.V_1_17))
/* 42 */       return 6; 
/* 44 */     if (ordinal() >= 11 && version.isOlderThan(ClientVersion.V_1_19_3))
/* 45 */       return ordinal() - 1; 
/* 47 */     return ordinal();
/*    */   }
/*    */   
/*    */   public static EntityPose getById(ClientVersion version, int id) {
/* 52 */     if (id == 6 && version.isOlderThan(ClientVersion.V_1_17))
/* 53 */       return DYING; 
/* 56 */     if (id >= 10 && version.isOlderThan(ClientVersion.V_1_19_3))
/* 57 */       id++; 
/* 59 */     return values()[id];
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\entity\pose\EntityPose.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */