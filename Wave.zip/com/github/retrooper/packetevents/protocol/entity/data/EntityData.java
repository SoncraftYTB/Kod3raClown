/*    */ package com.github.retrooper.packetevents.protocol.entity.data;
/*    */ 
/*    */ public class EntityData {
/*    */   private int index;
/*    */   
/*    */   private EntityDataType<?> type;
/*    */   
/*    */   private Object value;
/*    */   
/*    */   public EntityData(int index, EntityDataType<?> type, Object value) {
/* 27 */     this.index = index;
/* 28 */     this.type = type;
/* 29 */     this.value = value;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 33 */     return this.index;
/*    */   }
/*    */   
/*    */   public void setIndex(int index) {
/* 37 */     this.index = index;
/*    */   }
/*    */   
/*    */   public EntityDataType<?> getType() {
/* 41 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(EntityDataType<?> type) {
/* 45 */     this.type = type;
/*    */   }
/*    */   
/*    */   public Object getValue() {
/* 49 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(Object value) {
/* 53 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\entity\data\EntityData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */