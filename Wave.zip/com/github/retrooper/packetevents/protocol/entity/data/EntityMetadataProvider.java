/*    */ package com.github.retrooper.packetevents.protocol.entity.data;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ import java.util.List;
/*    */ 
/*    */ public interface EntityMetadataProvider {
/*    */   List<EntityData> entityData(ClientVersion paramClientVersion);
/*    */   
/*    */   @Deprecated
/*    */   default List<EntityData> entityData() {
/* 33 */     return entityData(ClientVersion.getLatest());
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\entity\data\EntityMetadataProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */