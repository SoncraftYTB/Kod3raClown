/*     */ package com.github.retrooper.packetevents.protocol.entity.data;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.entity.pose.EntityPose;
/*     */ import com.github.retrooper.packetevents.protocol.entity.sniffer.SnifferState;
/*     */ import com.github.retrooper.packetevents.protocol.entity.villager.VillagerData;
/*     */ import com.github.retrooper.packetevents.protocol.item.ItemStack;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*     */ import com.github.retrooper.packetevents.protocol.particle.Particle;
/*     */ import com.github.retrooper.packetevents.protocol.particle.type.ParticleType;
/*     */ import com.github.retrooper.packetevents.protocol.particle.type.ParticleTypes;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.protocol.world.BlockFace;
/*     */ import com.github.retrooper.packetevents.protocol.world.WorldBlockPosition;
/*     */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*     */ import com.github.retrooper.packetevents.util.Quaternion4f;
/*     */ import com.github.retrooper.packetevents.util.TypesBuilder;
/*     */ import com.github.retrooper.packetevents.util.TypesBuilderData;
/*     */ import com.github.retrooper.packetevents.util.Vector3f;
/*     */ import com.github.retrooper.packetevents.util.Vector3i;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ import net.kyori.adventure.text.Component;
/*     */ 
/*     */ public class EntityDataTypes {
/*  56 */   private static final Map<String, EntityDataType<?>> ENTITY_DATA_TYPE_MAP = new HashMap<>();
/*     */   
/*  57 */   private static final Map<Byte, Map<Integer, EntityDataType<?>>> ENTITY_DATA_TYPE_ID_MAP = new HashMap<>();
/*     */   
/*  58 */   protected static final TypesBuilder TYPES_BUILDER = new TypesBuilder("entity/entity_data_type_mappings", new ClientVersion[] { ClientVersion.V_1_8, ClientVersion.V_1_9, ClientVersion.V_1_11, ClientVersion.V_1_13, ClientVersion.V_1_14, ClientVersion.V_1_19, ClientVersion.V_1_19_3, ClientVersion.V_1_19_4 });
/*     */   
/*  68 */   public static final EntityDataType<Byte> BYTE = define("byte", PacketWrapper::readByte, PacketWrapper::writeByte);
/*     */   
/*  70 */   public static final EntityDataType<Short> SHORT = define("short", PacketWrapper::readShort, PacketWrapper::writeShort);
/*     */   
/*     */   public static final EntityDataType<Integer> INT;
/*     */   
/*     */   static {
/*  72 */     INT = define("int", wrapper -> wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_9) ? Integer.valueOf(wrapper.readVarInt()) : Integer.valueOf(wrapper.readInt()), (wrapper, value) -> {
/*     */           if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_9)) {
/*     */             wrapper.writeVarInt(value.intValue());
/*     */           } else {
/*     */             wrapper.writeInt(value.intValue());
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*  86 */   public static final EntityDataType<Long> LONG = define("long", PacketWrapper::readVarLong, PacketWrapper::writeVarLong);
/*     */   
/*  88 */   public static final EntityDataType<Float> FLOAT = define("float", PacketWrapper::readFloat, PacketWrapper::writeFloat);
/*     */   
/*  90 */   public static final EntityDataType<String> STRING = define("string", PacketWrapper::readString, PacketWrapper::writeString);
/*     */   
/*     */   @Deprecated
/*  93 */   public static final EntityDataType<String> COMPONENT = define("component", PacketWrapper::readComponentJSON, PacketWrapper::writeComponentJSON);
/*     */   
/*  94 */   public static final EntityDataType<Component> ADV_COMPONENT = define("component", PacketWrapper::readComponent, PacketWrapper::writeComponent);
/*     */   
/*     */   @Deprecated
/*  97 */   public static final EntityDataType<Optional<String>> OPTIONAL_COMPONENT = define("optional_component", readOptionalComponentJSONDeserializer(), writeOptionalComponentJSONSerializer());
/*     */   
/*  98 */   public static final EntityDataType<Optional<Component>> OPTIONAL_ADV_COMPONENT = define("optional_component", readOptionalComponentDeserializer(), writeOptionalComponentSerializer());
/*     */   
/* 100 */   public static final EntityDataType<ItemStack> ITEMSTACK = define("itemstack", PacketWrapper::readItemStack, PacketWrapper::writeItemStack);
/*     */   
/*     */   public static final EntityDataType<Optional<ItemStack>> OPTIONAL_ITEMSTACK;
/*     */   
/*     */   static {
/* 102 */     OPTIONAL_ITEMSTACK = define("optional_itemstack", wrapper -> Optional.of(wrapper.readItemStack()), (wrapper, value) -> wrapper.writeItemStack(value.orElse(null)));
/*     */   }
/*     */   
/* 106 */   public static final EntityDataType<Boolean> BOOLEAN = define("boolean", PacketWrapper::readBoolean, PacketWrapper::writeBoolean);
/*     */   
/*     */   public static final EntityDataType<Vector3f> ROTATION;
/*     */   
/*     */   public static final EntityDataType<Vector3i> BLOCK_POSITION;
/*     */   
/*     */   static {
/* 108 */     ROTATION = define("rotation", wrapper -> new Vector3f(wrapper.readFloat(), wrapper.readFloat(), wrapper.readFloat()), (wrapper, value) -> {
/*     */           wrapper.writeFloat(value.x);
/*     */           wrapper.writeFloat(value.y);
/*     */           wrapper.writeFloat(value.z);
/*     */         });
/* 116 */     BLOCK_POSITION = define("block_position", wrapper -> {
/*     */           if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_9))
/*     */             return wrapper.readBlockPosition(); 
/*     */           int x = wrapper.readInt();
/*     */           int y = wrapper.readInt();
/*     */           int z = wrapper.readInt();
/*     */           return new Vector3i(x, y, z);
/*     */         }(wrapper, blockPosition) -> {
/*     */           if (wrapper.getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_9)) {
/*     */             wrapper.writeBlockPosition(blockPosition);
/*     */           } else {
/*     */             wrapper.writeInt(blockPosition.getX());
/*     */             wrapper.writeInt(blockPosition.getY());
/*     */             wrapper.writeInt(blockPosition.getZ());
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/* 135 */   public static final EntityDataType<Optional<Vector3i>> OPTIONAL_BLOCK_POSITION = define("optional_block_position", 
/* 136 */       readOptionalBlockPositionDeserializer(), writeOptionalBlockPositionSerializer());
/*     */   
/*     */   public static final EntityDataType<BlockFace> BLOCK_FACE;
/*     */   
/*     */   public static final EntityDataType<Optional<UUID>> OPTIONAL_UUID;
/*     */   
/*     */   static {
/* 138 */     BLOCK_FACE = define("block_face", wrapper -> {
/*     */           int id = wrapper.readVarInt();
/*     */           return BlockFace.getBlockFaceByValue(id);
/*     */         }(wrapper, value) -> wrapper.writeVarInt(value.getFaceValue()));
/* 144 */     OPTIONAL_UUID = define("optional_uuid", wrapper -> Optional.ofNullable((UUID)wrapper.readOptional(PacketWrapper::readUUID)), (wrapper, value) -> wrapper.writeOptional(value.orElse(null), PacketWrapper::writeUUID));
/*     */   }
/*     */   
/* 149 */   public static final EntityDataType<Integer> BLOCK_STATE = define("block_state", 
/* 150 */       readIntDeserializer(), writeIntSerializer());
/*     */   
/* 152 */   public static final EntityDataType<Integer> OPTIONAL_BLOCK_STATE = define("optional_block_state", readIntDeserializer(), writeIntSerializer());
/*     */   
/* 154 */   public static final EntityDataType<NBTCompound> NBT = define("nbt", PacketWrapper::readNBT, PacketWrapper::writeNBT);
/*     */   
/*     */   public static final EntityDataType<Particle> PARTICLE;
/*     */   
/*     */   static {
/* 156 */     PARTICLE = define("particle", wrapper -> {
/*     */           int id = wrapper.readVarInt();
/*     */           ParticleType type = ParticleTypes.getById(PacketEvents.getAPI().getServerManager().getVersion().toClientVersion(), id);
/*     */           return new Particle(type, type.readDataFunction().apply(wrapper));
/*     */         }(wrapper, particle) -> {
/*     */           wrapper.writeVarInt(particle.getType().getId(PacketEvents.getAPI().getServerManager().getVersion().toClientVersion()));
/*     */           particle.getType().writeDataFunction().accept(wrapper, particle.getData());
/*     */         });
/*     */   }
/*     */   
/* 165 */   public static final EntityDataType<VillagerData> VILLAGER_DATA = define("villager_data", PacketWrapper::readVillagerData, PacketWrapper::writeVillagerData);
/*     */   
/*     */   public static final EntityDataType<Optional<Integer>> OPTIONAL_INT;
/*     */   
/*     */   public static final EntityDataType<EntityPose> ENTITY_POSE;
/*     */   
/*     */   static {
/* 167 */     OPTIONAL_INT = define("optional_int", wrapper -> {
/*     */           int i = wrapper.readVarInt();
/*     */           return (i == 0) ? Optional.empty() : Optional.<Integer>of(Integer.valueOf(i - 1));
/*     */         }(wrapper, value) -> wrapper.writeVarInt(((Integer)value.orElse(Integer.valueOf(-1))).intValue() + 1));
/* 174 */     ENTITY_POSE = define("entity_pose", wrapper -> {
/*     */           int id = wrapper.readVarInt();
/*     */           return EntityPose.getById(wrapper.getServerVersion().toClientVersion(), id);
/*     */         }(wrapper, value) -> wrapper.writeVarInt(value.getId(wrapper.getServerVersion().toClientVersion())));
/*     */   }
/*     */   
/* 179 */   public static final EntityDataType<Integer> CAT_VARIANT = define("cat_variant_type", readIntDeserializer(), writeIntSerializer());
/*     */   
/* 181 */   public static final EntityDataType<Integer> FROG_VARIANT = define("frog_variant_type", readIntDeserializer(), writeIntSerializer());
/*     */   
/*     */   public static final EntityDataType<Optional<WorldBlockPosition>> OPTIONAL_GLOBAL_POSITION;
/*     */   
/*     */   static {
/* 183 */     OPTIONAL_GLOBAL_POSITION = define("optional_global_position", wrapper -> Optional.ofNullable((WorldBlockPosition)wrapper.readOptional(())), (wrapper, value) -> wrapper.writeOptional(value.orElse(null), ()));
/*     */   }
/*     */   
/* 190 */   public static final EntityDataType<Integer> PAINTING_VARIANT_TYPE = define("painting_variant_type", readIntDeserializer(), writeIntSerializer());
/*     */   
/*     */   public static final EntityDataType<SnifferState> SNIFFER_STATE;
/*     */   
/*     */   public static final EntityDataType<Vector3f> VECTOR3F;
/*     */   
/*     */   public static final EntityDataType<Quaternion4f> QUATERNION;
/*     */   
/*     */   static {
/* 192 */     SNIFFER_STATE = define("sniffer_state", wrapper -> {
/*     */           int id = wrapper.readVarInt();
/*     */           return SnifferState.values()[id];
/*     */         }(wrapper, value) -> wrapper.writeVarInt(value.ordinal()));
/* 198 */     VECTOR3F = define("vector3f", wrapper -> new Vector3f(wrapper.readFloat(), wrapper.readFloat(), wrapper.readFloat()), (wrapper, value) -> {
/*     */           wrapper.writeFloat(value.x);
/*     */           wrapper.writeFloat(value.y);
/*     */           wrapper.writeFloat(value.z);
/*     */         });
/* 206 */     QUATERNION = define("quaternion", wrapper -> new Quaternion4f(wrapper.readFloat(), wrapper.readFloat(), wrapper.readFloat(), wrapper.readFloat()), (wrapper, value) -> {
/*     */           wrapper.writeFloat(value.getX());
/*     */           wrapper.writeFloat(value.getY());
/*     */           wrapper.writeFloat(value.getZ());
/*     */           wrapper.writeFloat(value.getW());
/*     */         });
/*     */   }
/*     */   
/*     */   public static EntityDataType<?> getById(ClientVersion version, int id) {
/* 216 */     int index = TYPES_BUILDER.getDataIndex(version);
/* 217 */     Map<Integer, EntityDataType<?>> typeIdMap = ENTITY_DATA_TYPE_ID_MAP.get(Byte.valueOf((byte)index));
/* 218 */     return typeIdMap.get(Integer.valueOf(id));
/*     */   }
/*     */   
/*     */   public static EntityDataType<?> getByName(String name) {
/* 222 */     return ENTITY_DATA_TYPE_MAP.get(name);
/*     */   }
/*     */   
/*     */   public static <T> EntityDataType<T> define(String name, Function<PacketWrapper<?>, T> deserializer, BiConsumer<PacketWrapper<?>, T> serializer) {
/* 226 */     TypesBuilderData data = TYPES_BUILDER.define(name);
/* 227 */     EntityDataType<T> type = new EntityDataType<>(name, data.getData(), deserializer, (BiConsumer)serializer);
/* 229 */     ENTITY_DATA_TYPE_MAP.put(type.getName(), type);
/* 230 */     for (ClientVersion version : TYPES_BUILDER.getVersions()) {
/* 231 */       int index = TYPES_BUILDER.getDataIndex(version);
/* 232 */       if (index != -1) {
/* 234 */         Map<Integer, EntityDataType<?>> typeIdMap = ENTITY_DATA_TYPE_ID_MAP.computeIfAbsent(Byte.valueOf((byte)index), k -> new HashMap<>());
/* 235 */         typeIdMap.put(Integer.valueOf(type.getId(version)), type);
/*     */       } 
/*     */     } 
/* 237 */     return type;
/*     */   }
/*     */   
/*     */   private static <T> Function<PacketWrapper<?>, T> readIntDeserializer() {
/* 241 */     if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_9))
/* 242 */       return wrapper -> Integer.valueOf(wrapper.readVarInt()); 
/* 244 */     return wrapper -> Integer.valueOf(wrapper.readInt());
/*     */   }
/*     */   
/*     */   private static <T> BiConsumer<PacketWrapper<?>, T> writeIntSerializer() {
/* 249 */     return (wrapper, value) -> {
/*     */         int output = 0;
/*     */         if (value instanceof Byte) {
/*     */           output = ((Byte)value).intValue();
/*     */         } else if (value instanceof Short) {
/*     */           output = ((Short)value).intValue();
/*     */         } else if (value instanceof Integer) {
/*     */           output = ((Integer)value).intValue();
/*     */         } else if (value instanceof Long) {
/*     */           output = ((Long)value).intValue();
/*     */         } 
/*     */         if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_9)) {
/*     */           wrapper.writeVarInt(output);
/*     */         } else {
/*     */           wrapper.writeInt(output);
/*     */         } 
/*     */       };
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   private static Function<PacketWrapper<?>, Optional<String>> readOptionalComponentJSONDeserializer() {
/* 270 */     return wrapper -> wrapper.readBoolean() ? Optional.of(wrapper.readComponentJSON()) : Optional.empty();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   private static BiConsumer<PacketWrapper<?>, Optional<String>> writeOptionalComponentJSONSerializer() {
/* 281 */     return (wrapper, value) -> {
/*     */         if (value != null && value.isPresent()) {
/*     */           wrapper.writeBoolean(true);
/*     */           wrapper.writeComponentJSON(value.get());
/*     */         } else {
/*     */           wrapper.writeBoolean(false);
/*     */         } 
/*     */       };
/*     */   }
/*     */   
/*     */   private static Function<PacketWrapper<?>, Optional<Component>> readOptionalComponentDeserializer() {
/* 292 */     return wrapper -> wrapper.readBoolean() ? Optional.of(wrapper.readComponent()) : Optional.empty();
/*     */   }
/*     */   
/*     */   private static BiConsumer<PacketWrapper<?>, Optional<Component>> writeOptionalComponentSerializer() {
/* 302 */     return (wrapper, value) -> {
/*     */         if (value != null && value.isPresent()) {
/*     */           wrapper.writeBoolean(true);
/*     */           wrapper.writeComponent(value.get());
/*     */         } else {
/*     */           wrapper.writeBoolean(false);
/*     */         } 
/*     */       };
/*     */   }
/*     */   
/*     */   private static <T> Function<PacketWrapper<?>, T> readOptionalBlockPositionDeserializer() {
/* 313 */     if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_9))
/* 314 */       return wrapper -> wrapper.readBoolean() ? Optional.of(wrapper.readBlockPosition()) : Optional.empty(); 
/* 322 */     return wrapper -> {
/*     */         if (wrapper.readBoolean()) {
/*     */           int x = wrapper.readInt();
/*     */           int y = wrapper.readInt();
/*     */           int z = wrapper.readInt();
/*     */           return Optional.of(new Vector3i(x, y, z));
/*     */         } 
/*     */         return Optional.empty();
/*     */       };
/*     */   }
/*     */   
/*     */   private static <T> BiConsumer<PacketWrapper<?>, T> writeOptionalBlockPositionSerializer() {
/* 336 */     if (PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_9))
/* 337 */       return (wrapper, value) -> {
/*     */           if (value instanceof Optional) {
/*     */             Optional<?> optional = (Optional)value;
/*     */             if (optional.isPresent()) {
/*     */               wrapper.writeBoolean(true);
/*     */               wrapper.writeBlockPosition((Vector3i)optional.get());
/*     */             } else {
/*     */               wrapper.writeBoolean(false);
/*     */             } 
/*     */           } else {
/*     */             wrapper.writeBoolean(false);
/*     */           } 
/*     */         }; 
/* 351 */     return (wrapper, value) -> {
/*     */         if (value instanceof Optional) {
/*     */           Optional<?> optional = (Optional)value;
/*     */           if (optional.isPresent()) {
/*     */             wrapper.writeBoolean(true);
/*     */             Vector3i position = (Vector3i)optional.get();
/*     */             wrapper.writeInt(position.getX());
/*     */             wrapper.writeInt(position.getY());
/*     */             wrapper.writeInt(position.getZ());
/*     */           } else {
/*     */             wrapper.writeBoolean(false);
/*     */           } 
/*     */         } else {
/*     */           wrapper.writeBoolean(false);
/*     */         } 
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\entity\data\EntityDataTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */