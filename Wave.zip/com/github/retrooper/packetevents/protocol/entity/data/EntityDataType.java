/*    */ package com.github.retrooper.packetevents.protocol.entity.data;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import java.util.function.BiConsumer;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ public class EntityDataType<T> {
/*    */   private final String name;
/*    */   
/*    */   private final int[] ids;
/*    */   
/*    */   private final Function<PacketWrapper<?>, T> dataDeserializer;
/*    */   
/*    */   private final BiConsumer<PacketWrapper<?>, Object> dataSerializer;
/*    */   
/*    */   public EntityDataType(String name, int[] ids, Function<PacketWrapper<?>, T> dataDeserializer, BiConsumer<PacketWrapper<?>, Object> dataSerializer) {
/* 34 */     this.name = name;
/* 35 */     this.ids = ids;
/* 36 */     this.dataDeserializer = dataDeserializer;
/* 37 */     this.dataSerializer = dataSerializer;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 41 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getId(ClientVersion version) {
/* 45 */     int index = EntityDataTypes.TYPES_BUILDER.getDataIndex(version);
/* 46 */     return this.ids[index];
/*    */   }
/*    */   
/*    */   public Function<PacketWrapper<?>, T> getDataDeserializer() {
/* 50 */     return this.dataDeserializer;
/*    */   }
/*    */   
/*    */   public BiConsumer<PacketWrapper<?>, Object> getDataSerializer() {
/* 54 */     return this.dataSerializer;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\protocol\entity\data\EntityDataType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */