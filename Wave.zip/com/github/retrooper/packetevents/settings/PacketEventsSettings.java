/*     */ package com.github.retrooper.packetevents.settings;
/*     */ 
/*     */ import com.github.retrooper.packetevents.util.TimeStampMode;
/*     */ import java.io.InputStream;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ public class PacketEventsSettings {
/*     */   private TimeStampMode timestampMode;
/*     */   
/*     */   private boolean defaultReencode;
/*     */   
/*     */   private boolean checkForUpdates;
/*     */   
/*     */   private boolean downsampleColors;
/*     */   
/*     */   private boolean bStatsEnabled;
/*     */   
/*     */   private boolean debugEnabled;
/*     */   
/*     */   private Function<String, InputStream> resourceProvider;
/*     */   
/*     */   public PacketEventsSettings() {
/*  34 */     this.timestampMode = TimeStampMode.MILLIS;
/*  35 */     this.defaultReencode = true;
/*  36 */     this.checkForUpdates = true;
/*  37 */     this.downsampleColors = true;
/*  38 */     this.bStatsEnabled = true;
/*  39 */     this.debugEnabled = false;
/*  40 */     this.resourceProvider = (path -> PacketEventsSettings.class.getClassLoader().getResourceAsStream(path));
/*     */   }
/*     */   
/*     */   public PacketEventsSettings timeStampMode(TimeStampMode timeStampMode) {
/*  50 */     this.timestampMode = timeStampMode;
/*  51 */     return this;
/*     */   }
/*     */   
/*     */   public TimeStampMode getTimeStampMode() {
/*  59 */     return this.timestampMode;
/*     */   }
/*     */   
/*     */   public PacketEventsSettings reEncodeByDefault(boolean reEncodeByDefault) {
/*  68 */     this.defaultReencode = reEncodeByDefault;
/*  69 */     return this;
/*     */   }
/*     */   
/*     */   public PacketEventsSettings checkForUpdates(boolean checkForUpdates) {
/*  79 */     this.checkForUpdates = checkForUpdates;
/*  80 */     return this;
/*     */   }
/*     */   
/*     */   public PacketEventsSettings downsampleColors(boolean downsampleColors) {
/*  90 */     this.downsampleColors = downsampleColors;
/*  91 */     return this;
/*     */   }
/*     */   
/*     */   public PacketEventsSettings bStats(boolean bStatsEnabled) {
/* 101 */     this.bStatsEnabled = bStatsEnabled;
/* 102 */     return this;
/*     */   }
/*     */   
/*     */   public PacketEventsSettings debug(boolean debugEnabled) {
/* 112 */     this.debugEnabled = debugEnabled;
/* 113 */     return this;
/*     */   }
/*     */   
/*     */   public PacketEventsSettings customResourceProvider(Function<String, InputStream> resourceProvider) {
/* 124 */     this.resourceProvider = resourceProvider;
/* 125 */     return this;
/*     */   }
/*     */   
/*     */   public boolean reEncodeByDefault() {
/* 133 */     return this.defaultReencode;
/*     */   }
/*     */   
/*     */   public boolean shouldCheckForUpdates() {
/* 142 */     return this.checkForUpdates;
/*     */   }
/*     */   
/*     */   public boolean shouldDownsampleColors() {
/* 151 */     return this.downsampleColors;
/*     */   }
/*     */   
/*     */   public boolean isbStatsEnabled() {
/* 161 */     return this.bStatsEnabled;
/*     */   }
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 170 */     return this.debugEnabled;
/*     */   }
/*     */   
/*     */   public Function<String, InputStream> getResourceProvider() {
/* 179 */     return this.resourceProvider;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\settings\PacketEventsSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */