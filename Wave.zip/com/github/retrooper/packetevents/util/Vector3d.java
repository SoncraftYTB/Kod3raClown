/*     */ package com.github.retrooper.packetevents.util;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.world.BlockFace;
/*     */ import java.util.Objects;
/*     */ 
/*     */ public class Vector3d {
/*     */   public final double x;
/*     */   
/*     */   public final double y;
/*     */   
/*     */   public final double z;
/*     */   
/*     */   public Vector3d() {
/*  51 */     this.x = 0.0D;
/*  52 */     this.y = 0.0D;
/*  53 */     this.z = 0.0D;
/*     */   }
/*     */   
/*     */   public Vector3d(double x, double y, double z) {
/*  64 */     this.x = x;
/*  65 */     this.y = y;
/*  66 */     this.z = z;
/*     */   }
/*     */   
/*     */   public Vector3d(double[] array) {
/*  78 */     if (array.length > 0) {
/*  79 */       this.x = array[0];
/*     */     } else {
/*  81 */       this.x = 0.0D;
/*  82 */       this.y = 0.0D;
/*  83 */       this.z = 0.0D;
/*     */       return;
/*     */     } 
/*  87 */     if (array.length > 1) {
/*  88 */       this.y = array[1];
/*     */     } else {
/*  90 */       this.y = 0.0D;
/*  91 */       this.z = 0.0D;
/*     */       return;
/*     */     } 
/*  95 */     if (array.length > 2) {
/*  96 */       this.z = array[2];
/*     */     } else {
/*  98 */       this.z = 0.0D;
/*     */     } 
/*     */   }
/*     */   
/*     */   public double getX() {
/* 103 */     return this.x;
/*     */   }
/*     */   
/*     */   public double getY() {
/* 107 */     return this.y;
/*     */   }
/*     */   
/*     */   public double getZ() {
/* 111 */     return this.z;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 123 */     if (obj instanceof Vector3d) {
/* 124 */       Vector3d vec = (Vector3d)obj;
/* 125 */       return (this.x == vec.x && this.y == vec.y && this.z == vec.z);
/*     */     } 
/* 126 */     if (obj instanceof Vector3f) {
/* 127 */       Vector3f vec = (Vector3f)obj;
/* 128 */       return (this.x == vec.x && this.y == vec.y && this.z == vec.z);
/*     */     } 
/* 129 */     if (obj instanceof Vector3i) {
/* 130 */       Vector3i vec = (Vector3i)obj;
/* 131 */       return (this.x == vec.x && this.y == vec.y && this.z == vec.z);
/*     */     } 
/* 133 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 138 */     return Objects.hash(new Object[] { Double.valueOf(this.x), Double.valueOf(this.y), Double.valueOf(this.z) });
/*     */   }
/*     */   
/*     */   public Vector3d add(double x, double y, double z) {
/* 142 */     return new Vector3d(this.x + x, this.y + y, this.z + z);
/*     */   }
/*     */   
/*     */   public Vector3d add(Vector3d other) {
/* 146 */     return add(other.x, other.y, other.z);
/*     */   }
/*     */   
/*     */   public Vector3d offset(BlockFace face) {
/* 150 */     return add(face.getModX(), face.getModY(), face.getModZ());
/*     */   }
/*     */   
/*     */   public Vector3d subtract(double x, double y, double z) {
/* 154 */     return new Vector3d(this.x - x, this.y - y, this.z - z);
/*     */   }
/*     */   
/*     */   public Vector3d subtract(Vector3d other) {
/* 158 */     return subtract(other.x, other.y, other.z);
/*     */   }
/*     */   
/*     */   public Vector3d multiply(double x, double y, double z) {
/* 162 */     return new Vector3d(this.x * x, this.y * y, this.z * z);
/*     */   }
/*     */   
/*     */   public Vector3d multiply(Vector3d other) {
/* 166 */     return multiply(other.x, other.y, other.z);
/*     */   }
/*     */   
/*     */   public Vector3d multiply(double value) {
/* 170 */     return multiply(value, value, value);
/*     */   }
/*     */   
/*     */   public Vector3d crossProduct(Vector3d other) {
/* 174 */     double newX = this.y * other.z - other.y * this.z;
/* 175 */     double newY = this.z * other.x - other.z * this.x;
/* 176 */     double newZ = this.x * other.y - other.x * this.y;
/* 177 */     return new Vector3d(newX, newY, newZ);
/*     */   }
/*     */   
/*     */   public double dot(Vector3d other) {
/* 181 */     return this.x * other.x + this.y * other.y + this.z * other.z;
/*     */   }
/*     */   
/*     */   public Vector3d with(Double x, Double y, Double z) {
/* 185 */     return new Vector3d((x == null) ? this.x : x.doubleValue(), (y == null) ? this.y : y.doubleValue(), (z == null) ? this.z : z.doubleValue());
/*     */   }
/*     */   
/*     */   public Vector3d withX(double x) {
/* 189 */     return new Vector3d(x, this.y, this.z);
/*     */   }
/*     */   
/*     */   public Vector3d withY(double y) {
/* 193 */     return new Vector3d(this.x, y, this.z);
/*     */   }
/*     */   
/*     */   public Vector3d withZ(double z) {
/* 197 */     return new Vector3d(this.x, this.y, z);
/*     */   }
/*     */   
/*     */   public double distance(Vector3d other) {
/* 201 */     return Math.sqrt(distanceSquared(other));
/*     */   }
/*     */   
/*     */   public double length() {
/* 205 */     return Math.sqrt(lengthSquared());
/*     */   }
/*     */   
/*     */   public double lengthSquared() {
/* 209 */     return this.x * this.x + this.y * this.y + this.z * this.z;
/*     */   }
/*     */   
/*     */   public Vector3d normalize() {
/* 213 */     double length = length();
/* 215 */     return new Vector3d(this.x / length, this.y / length, this.z / length);
/*     */   }
/*     */   
/*     */   public double distanceSquared(Vector3d other) {
/* 219 */     double distX = (this.x - other.x) * (this.x - other.x);
/* 220 */     double distY = (this.y - other.y) * (this.y - other.y);
/* 221 */     double distZ = (this.z - other.z) * (this.z - other.z);
/* 222 */     return distX + distY + distZ;
/*     */   }
/*     */   
/*     */   public Vector3i toVector3i() {
/* 226 */     return new Vector3i((int)this.x, (int)this.y, (int)this.z);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 231 */     return "X: " + this.x + ", Y: " + this.y + ", Z: " + this.z;
/*     */   }
/*     */   
/*     */   public static Vector3d zero() {
/* 235 */     return new Vector3d();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\Vector3d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */