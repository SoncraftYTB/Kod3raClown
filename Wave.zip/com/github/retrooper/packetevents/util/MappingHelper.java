/*    */ package com.github.retrooper.packetevents.util;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*    */ import com.google.gson.JsonObject;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ 
/*    */ public class MappingHelper {
/*    */   public static JsonObject getJSONObject(String id) {
/* 33 */     StringBuilder sb = new StringBuilder();
/*    */     try {
/* 34 */       InputStream inputStream = PacketEvents.getAPI().getSettings().getResourceProvider().apply("assets/mappings/" + id + ".json");
/*    */       try {
/* 35 */         InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
/*    */         try {
/* 36 */           BufferedReader reader = new BufferedReader(streamReader);
/*    */           try {
/*    */             String line;
/* 39 */             while ((line = reader.readLine()) != null)
/* 40 */               sb.append(line); 
/* 43 */             reader.close();
/*    */           } catch (Throwable throwable) {
/*    */             try {
/*    */               reader.close();
/*    */             } catch (Throwable throwable1) {
/*    */               throwable.addSuppressed(throwable1);
/*    */             } 
/*    */             throw throwable;
/*    */           } 
/* 43 */           streamReader.close();
/*    */         } catch (Throwable throwable) {
/*    */           try {
/*    */             streamReader.close();
/*    */           } catch (Throwable throwable1) {
/*    */             throwable.addSuppressed(throwable1);
/*    */           } 
/*    */           throw throwable;
/*    */         } 
/* 43 */         if (inputStream != null)
/* 43 */           inputStream.close(); 
/*    */       } catch (Throwable throwable) {
/*    */         if (inputStream != null)
/*    */           try {
/*    */             inputStream.close();
/*    */           } catch (Throwable throwable1) {
/*    */             throwable.addSuppressed(throwable1);
/*    */           }  
/*    */         throw throwable;
/*    */       } 
/* 43 */     } catch (IOException e) {
/* 44 */       e.printStackTrace();
/*    */     } 
/* 46 */     return (JsonObject)AdventureSerializer.getGsonSerializer().serializer().fromJson(sb.toString(), JsonObject.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\MappingHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */