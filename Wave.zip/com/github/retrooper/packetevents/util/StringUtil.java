/*    */ package com.github.retrooper.packetevents.util;
/*    */ 
/*    */ public class StringUtil {
/*    */   public static String maximizeLength(String msg, int maxLength) {
/* 23 */     if (msg.length() > maxLength)
/* 24 */       return msg.substring(0, maxLength); 
/* 26 */     return msg;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\StringUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */