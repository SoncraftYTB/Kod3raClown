/*     */ package com.github.retrooper.packetevents.util.reflection;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ public class ReflectionObject implements ReflectionObjectReader, ReflectionObjectWriter {
/*  28 */   private static final Map<Class<?>, Map<Class<?>, Field[]>> FIELD_CACHE = new ConcurrentHashMap<>();
/*     */   
/*  29 */   private static final Field[] EMPTY_FIELD_ARRAY = new Field[0];
/*     */   
/*     */   protected final Object object;
/*     */   
/*     */   private final Class<?> clazz;
/*     */   
/*     */   public ReflectionObject() {
/*  34 */     this.object = null;
/*  35 */     this.clazz = null;
/*     */   }
/*     */   
/*     */   public ReflectionObject(Object object) {
/*  39 */     this.object = object;
/*  40 */     this.clazz = object.getClass();
/*     */   }
/*     */   
/*     */   public ReflectionObject(Object object, Class<?> clazz) {
/*  44 */     this.object = object;
/*  45 */     this.clazz = clazz;
/*     */   }
/*     */   
/*     */   public boolean readBoolean(int index) {
/*  50 */     return ((Boolean)read(index, (Class)boolean.class)).booleanValue();
/*     */   }
/*     */   
/*     */   public byte readByte(int index) {
/*  55 */     return ((Byte)read(index, (Class)byte.class)).byteValue();
/*     */   }
/*     */   
/*     */   public short readShort(int index) {
/*  60 */     return ((Short)read(index, (Class)short.class)).shortValue();
/*     */   }
/*     */   
/*     */   public int readInt(int index) {
/*  65 */     return ((Integer)read(index, (Class)int.class)).intValue();
/*     */   }
/*     */   
/*     */   public long readLong(int index) {
/*  70 */     return ((Long)read(index, (Class)long.class)).longValue();
/*     */   }
/*     */   
/*     */   public float readFloat(int index) {
/*  75 */     return ((Float)read(index, (Class)float.class)).floatValue();
/*     */   }
/*     */   
/*     */   public double readDouble(int index) {
/*  80 */     return ((Double)read(index, (Class)double.class)).doubleValue();
/*     */   }
/*     */   
/*     */   public boolean[] readBooleanArray(int index) {
/*  85 */     return read(index, (Class)boolean[].class);
/*     */   }
/*     */   
/*     */   public byte[] readByteArray(int index) {
/*  90 */     return read(index, (Class)byte[].class);
/*     */   }
/*     */   
/*     */   public short[] readShortArray(int index) {
/*  95 */     return read(index, (Class)short[].class);
/*     */   }
/*     */   
/*     */   public int[] readIntArray(int index) {
/* 100 */     return read(index, (Class)int[].class);
/*     */   }
/*     */   
/*     */   public long[] readLongArray(int index) {
/* 105 */     return read(index, (Class)long[].class);
/*     */   }
/*     */   
/*     */   public float[] readFloatArray(int index) {
/* 110 */     return read(index, (Class)float[].class);
/*     */   }
/*     */   
/*     */   public double[] readDoubleArray(int index) {
/* 115 */     return read(index, (Class)double[].class);
/*     */   }
/*     */   
/*     */   public String[] readStringArray(int index) {
/* 120 */     return read(index, (Class)String[].class);
/*     */   }
/*     */   
/*     */   public String readString(int index) {
/* 125 */     return read(index, String.class);
/*     */   }
/*     */   
/*     */   public Object readAnyObject(int index) {
/*     */     try {
/* 131 */       Field f = this.clazz.getDeclaredFields()[index];
/* 132 */       if (!f.isAccessible())
/* 133 */         f.setAccessible(true); 
/*     */       try {
/* 136 */         return f.get(this.object);
/* 137 */       } catch (IllegalAccessException|NullPointerException|ArrayIndexOutOfBoundsException e) {
/* 138 */         e.printStackTrace();
/*     */       } 
/* 140 */     } catch (ArrayIndexOutOfBoundsException e) {
/* 141 */       throw new IllegalStateException("PacketEvents failed to find any field indexed " + index + " in the " + this.clazz.getSimpleName() + " class!");
/*     */     } 
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   public <T> T readObject(int index, Class<? extends T> type) {
/* 148 */     return read(index, type);
/*     */   }
/*     */   
/*     */   public Enum<?> readEnumConstant(int index, Class<? extends Enum<?>> type) {
/* 153 */     return read(index, (Class)type);
/*     */   }
/*     */   
/*     */   public <T> T read(int index, Class<? extends T> type) {
/*     */     try {
/* 159 */       Field field = getField(type, index);
/* 160 */       return (T)field.get(this.object);
/* 161 */     } catch (IllegalAccessException|NullPointerException|ArrayIndexOutOfBoundsException e) {
/* 162 */       throw new IllegalStateException("PacketEvents failed to find a " + type.getSimpleName() + " indexed " + index + " by its type in the " + this.clazz.getName() + " class!");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeBoolean(int index, boolean value) {
/* 169 */     write(boolean.class, index, Boolean.valueOf(value));
/*     */   }
/*     */   
/*     */   public void writeByte(int index, byte value) {
/* 174 */     write(byte.class, index, Byte.valueOf(value));
/*     */   }
/*     */   
/*     */   public void writeShort(int index, short value) {
/* 179 */     write(short.class, index, Short.valueOf(value));
/*     */   }
/*     */   
/*     */   public void writeInt(int index, int value) {
/* 184 */     write(int.class, index, Integer.valueOf(value));
/*     */   }
/*     */   
/*     */   public void writeLong(int index, long value) {
/* 189 */     write(long.class, index, Long.valueOf(value));
/*     */   }
/*     */   
/*     */   public void writeFloat(int index, float value) {
/* 194 */     write(float.class, index, Float.valueOf(value));
/*     */   }
/*     */   
/*     */   public void writeDouble(int index, double value) {
/* 199 */     write(double.class, index, Double.valueOf(value));
/*     */   }
/*     */   
/*     */   public void writeString(int index, String value) {
/* 204 */     write(String.class, index, value);
/*     */   }
/*     */   
/*     */   public void writeObject(int index, Object value) {
/* 209 */     write(value.getClass(), index, value);
/*     */   }
/*     */   
/*     */   public void writeBooleanArray(int index, boolean[] array) {
/* 214 */     write(boolean[].class, index, array);
/*     */   }
/*     */   
/*     */   public void writeByteArray(int index, byte[] value) {
/* 219 */     write(byte[].class, index, value);
/*     */   }
/*     */   
/*     */   public void writeShortArray(int index, short[] value) {
/* 224 */     write(short[].class, index, value);
/*     */   }
/*     */   
/*     */   public void writeIntArray(int index, int[] value) {
/* 229 */     write(int[].class, index, value);
/*     */   }
/*     */   
/*     */   public void writeLongArray(int index, long[] value) {
/* 234 */     write(long[].class, index, value);
/*     */   }
/*     */   
/*     */   public void writeFloatArray(int index, float[] value) {
/* 239 */     write(float[].class, index, value);
/*     */   }
/*     */   
/*     */   public void writeDoubleArray(int index, double[] value) {
/* 244 */     write(double[].class, index, value);
/*     */   }
/*     */   
/*     */   public void writeStringArray(int index, String[] value) {
/* 249 */     write(String[].class, index, value);
/*     */   }
/*     */   
/*     */   public void writeAnyObject(int index, Object value) {
/*     */     try {
/* 255 */       Field f = this.clazz.getDeclaredFields()[index];
/* 256 */       f.set(this.object, value);
/* 257 */     } catch (Exception e) {
/* 258 */       throw new IllegalStateException("PacketEvents failed to find any field indexed " + index + " in the " + this.clazz.getSimpleName() + " class!");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeEnumConstant(int index, Enum<?> enumConstant) {
/*     */     try {
/* 265 */       write(enumConstant.getClass(), index, enumConstant);
/* 266 */     } catch (IllegalStateException ex) {
/* 267 */       write(enumConstant.getDeclaringClass(), index, enumConstant);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write(Class<?> type, int index, Object value) throws IllegalStateException {
/* 272 */     Field field = getField(type, index);
/* 273 */     if (field == null)
/* 274 */       throw new IllegalStateException("PacketEvents failed to find a " + type.getSimpleName() + " indexed " + index + " by its type in the " + this.clazz.getName() + " class!"); 
/*     */     try {
/* 277 */       field.set(this.object, value);
/* 278 */     } catch (IllegalAccessException|NullPointerException e) {
/* 279 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public <T> List<T> readList(int index) {
/* 284 */     return read(index, (Class)List.class);
/*     */   }
/*     */   
/*     */   public void writeList(int index, List<?> list) {
/* 288 */     write(List.class, index, list);
/*     */   }
/*     */   
/*     */   private Field getField(Class<?> type, int index) {
/* 292 */     Map<Class<?>, Field[]> cached = FIELD_CACHE.computeIfAbsent(this.clazz, k -> new ConcurrentHashMap<>());
/* 293 */     Field[] fields = cached.computeIfAbsent(type, typeClass -> getFields(typeClass, this.clazz.getDeclaredFields()));
/* 294 */     if (fields.length >= index + 1)
/* 295 */       return fields[index]; 
/* 297 */     throw new IllegalStateException("PacketEvents failed to find a " + type.getSimpleName() + " indexed " + index + " by its type in the " + this.clazz.getName() + " class!");
/*     */   }
/*     */   
/*     */   private Field[] getFields(Class<?> type, Field[] fields) {
/* 302 */     List<Field> ret = new ArrayList<>();
/* 303 */     for (Field field : fields) {
/* 304 */       if (field.getType().equals(type)) {
/* 305 */         if (!field.isAccessible())
/* 306 */           field.setAccessible(true); 
/* 308 */         ret.add(field);
/*     */       } 
/*     */     } 
/* 311 */     return ret.<Field>toArray(EMPTY_FIELD_ARRAY);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\reflection\ReflectionObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */