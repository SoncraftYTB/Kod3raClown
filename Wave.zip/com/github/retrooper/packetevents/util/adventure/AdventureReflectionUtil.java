/*     */ package com.github.retrooper.packetevents.util.adventure;
/*     */ 
/*     */ import com.github.retrooper.packetevents.util.reflection.Reflection;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.TypeAdapter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.function.Function;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.BlockNBTComponent;
/*     */ import net.kyori.adventure.text.event.ClickEvent;
/*     */ import net.kyori.adventure.text.event.HoverEvent;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import net.kyori.adventure.text.format.TextDecoration;
/*     */ import net.kyori.adventure.util.Index;
/*     */ 
/*     */ public class AdventureReflectionUtil {
/*     */   static TypeAdapter<Key> KEY_SERIALIZER_INSTANCE;
/*     */   
/*     */   static Function<Gson, Object> COMPONENT_SERIALIZER_CREATE;
/*     */   
/*     */   static TypeAdapter<ClickEvent.Action> CLICK_EVENT_ACTION_SERIALIZER_INSTANCE;
/*     */   
/*     */   static TypeAdapter<HoverEvent.Action<?>> HOVER_EVENT_ACTION_SERIALIZER_INSTANCE;
/*     */   
/*     */   static Function<Gson, Object> SHOW_ITEM_SERIALIZER_CREATE;
/*     */   
/*     */   static Function<Gson, Object> SHOW_ENTITY_SERIALIZER_CREATE;
/*     */   
/*     */   static TypeAdapter<TextColor> TEXT_COLOR_SERIALIZER_INSTANCE;
/*     */   
/*     */   static TypeAdapter<TextColor> TEXT_COLOR_SERIALIZER_DOWNSAMPLE_COLOR_INSTANCE;
/*     */   
/*     */   static TypeAdapter<TextDecoration> TEXT_DECORATION_SERIALIZER_INSTANCE;
/*     */   
/*     */   static TypeAdapter<BlockNBTComponent.Pos> BLOCK_NBT_POS_SERIALIZER_INSTANCE;
/*     */   
/*     */   static {
/*  33 */     Class<?> KEY_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.KeySerializer");
/*  34 */     Field KEY_SERIALIZER_INSTANCE_FIELD = Reflection.getField(KEY_SERIALIZER, "INSTANCE");
/*  35 */     KEY_SERIALIZER_INSTANCE = (TypeAdapter<Key>)getSafe(KEY_SERIALIZER_INSTANCE_FIELD);
/*  37 */     Class<?> COMPONENT_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.ComponentSerializerImpl");
/*  38 */     Class<?> SHOW_ITEM_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.ShowItemSerializer");
/*  39 */     Class<?> SHOW_ENTITY_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.ShowEntitySerializer");
/*  41 */     if (GsonComponentSerializerExtended.LEGACY_ADVENTURE) {
/*  42 */       Constructor<?> COMPONENT_SERIALIZER_CONSTRUCTOR = Reflection.getConstructor(COMPONENT_SERIALIZER, 0);
/*  43 */       COMPONENT_SERIALIZER_CREATE = (gson -> invokeSafe(COMPONENT_SERIALIZER_CONSTRUCTOR, new Object[0]));
/*  45 */       Class<?> INDEXED_SERIALIZER_CLASS = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.IndexedSerializer");
/*  46 */       Method INDEXED_SERIALIZER_CREATE_METHOD = Reflection.getMethod(INDEXED_SERIALIZER_CLASS, "of", new Class[] { String.class, Index.class });
/*  48 */       CLICK_EVENT_ACTION_SERIALIZER_INSTANCE = (TypeAdapter<ClickEvent.Action>)invokeSafe(INDEXED_SERIALIZER_CREATE_METHOD, new Object[] { "click action", ClickEvent.Action.NAMES });
/*  49 */       HOVER_EVENT_ACTION_SERIALIZER_INSTANCE = (TypeAdapter<HoverEvent.Action<?>>)invokeSafe(INDEXED_SERIALIZER_CREATE_METHOD, new Object[] { "hover action", HoverEvent.Action.NAMES });
/*  50 */       TEXT_DECORATION_SERIALIZER_INSTANCE = (TypeAdapter<TextDecoration>)invokeSafe(INDEXED_SERIALIZER_CREATE_METHOD, new Object[] { "text decoration", TextDecoration.NAMES });
/*  52 */       Constructor<?> SHOW_ITEM_SERIALIZER_CONSTRUCTOR = Reflection.getConstructor(SHOW_ITEM_SERIALIZER, 0);
/*  53 */       SHOW_ITEM_SERIALIZER_CREATE = (gson -> invokeSafe(SHOW_ITEM_SERIALIZER_CONSTRUCTOR, new Object[0]));
/*  55 */       Constructor<?> SHOW_ENTITY_SERIALIZER_CONSTRUCTOR = Reflection.getConstructor(SHOW_ENTITY_SERIALIZER, 0);
/*  56 */       SHOW_ENTITY_SERIALIZER_CREATE = (gson -> invokeSafe(SHOW_ENTITY_SERIALIZER_CONSTRUCTOR, new Object[0]));
/*     */     } else {
/*  58 */       Method COMPONENT_SERIALIZER_CREATE_METHOD = Reflection.getMethod(COMPONENT_SERIALIZER, "create", new Class[] { Gson.class });
/*  59 */       COMPONENT_SERIALIZER_CREATE = (gson -> invokeSafe(COMPONENT_SERIALIZER_CREATE_METHOD, new Object[] { gson }));
/*  61 */       Class<?> CLICK_EVENT_ACTION_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.ClickEventActionSerializer");
/*  62 */       Field CLICK_EVENT_ACTION_SERIALIZER_INSTANCE_FIELD = Reflection.getField(CLICK_EVENT_ACTION_SERIALIZER, "INSTANCE");
/*  63 */       CLICK_EVENT_ACTION_SERIALIZER_INSTANCE = (TypeAdapter<ClickEvent.Action>)getSafe(CLICK_EVENT_ACTION_SERIALIZER_INSTANCE_FIELD);
/*  65 */       Class<?> HOVER_EVENT_ACTION_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.HoverEventActionSerializer");
/*  66 */       Field HOVER_EVENT_ACTION_SERIALIZER_INSTANCE_FIELD = Reflection.getField(HOVER_EVENT_ACTION_SERIALIZER, "INSTANCE");
/*  67 */       HOVER_EVENT_ACTION_SERIALIZER_INSTANCE = (TypeAdapter<HoverEvent.Action<?>>)getSafe(HOVER_EVENT_ACTION_SERIALIZER_INSTANCE_FIELD);
/*  69 */       Class<?> TEXT_DECORATION_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.TextDecorationSerializer");
/*  70 */       Field TEXT_DECORATION_SERIALIZER_INSTANCE_FIELD = Reflection.getField(TEXT_DECORATION_SERIALIZER, "INSTANCE");
/*  71 */       TEXT_DECORATION_SERIALIZER_INSTANCE = (TypeAdapter<TextDecoration>)getSafe(TEXT_DECORATION_SERIALIZER_INSTANCE_FIELD);
/*  73 */       Method SHOW_ITEM_SERIALIZER_CREATE_METHOD = Reflection.getMethod(SHOW_ITEM_SERIALIZER, "create", new Class[] { Gson.class });
/*  74 */       SHOW_ITEM_SERIALIZER_CREATE = (gson -> invokeSafe(SHOW_ITEM_SERIALIZER_CREATE_METHOD, new Object[] { gson }));
/*  76 */       Method SHOW_ENTITY_SERIALIZER_CREATE_METHOD = Reflection.getMethod(SHOW_ENTITY_SERIALIZER, "create", new Class[] { Gson.class });
/*  77 */       SHOW_ENTITY_SERIALIZER_CREATE = (gson -> invokeSafe(SHOW_ENTITY_SERIALIZER_CREATE_METHOD, new Object[] { gson }));
/*     */     } 
/*  80 */     Class<?> TEXT_COLOR_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.TextColorSerializer");
/*  81 */     Field TEXT_COLOR_SERIALIZER_INSTANCE_FIELD = Reflection.getField(TEXT_COLOR_SERIALIZER, "INSTANCE");
/*  82 */     TEXT_COLOR_SERIALIZER_INSTANCE = (TypeAdapter<TextColor>)getSafe(TEXT_COLOR_SERIALIZER_INSTANCE_FIELD);
/*  84 */     Field TEXT_COLOR_SERIALIZER_DOWNSAMPLE_COLOR_INSTANCE_FIELD = Reflection.getField(TEXT_COLOR_SERIALIZER, "DOWNSAMPLE_COLOR");
/*  85 */     TEXT_COLOR_SERIALIZER_DOWNSAMPLE_COLOR_INSTANCE = (TypeAdapter<TextColor>)getSafe(TEXT_COLOR_SERIALIZER_DOWNSAMPLE_COLOR_INSTANCE_FIELD);
/*  87 */     Class<?> BLOCK_NBT_COMPONENT_POS_SERIALIZER = Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.BlockNBTComponentPosSerializer");
/*  88 */     Field BLOCK_NBT_COMPONENT_POS_SERIALIZER_INSTANCE_FIELD = Reflection.getField(BLOCK_NBT_COMPONENT_POS_SERIALIZER, "INSTANCE");
/*  89 */     BLOCK_NBT_POS_SERIALIZER_INSTANCE = (TypeAdapter<BlockNBTComponent.Pos>)getSafe(BLOCK_NBT_COMPONENT_POS_SERIALIZER_INSTANCE_FIELD);
/*     */   }
/*     */   
/*     */   static Object getSafe(Field field) {
/*  93 */     return getSafe(field, null);
/*     */   }
/*     */   
/*     */   static Object getSafe(Field field, Object instance) {
/*  97 */     if (field == null)
/*  97 */       return null; 
/*     */     try {
/* 100 */       return field.get(instance);
/* 101 */     } catch (Exception e) {
/* 102 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   static Object invokeSafe(Method method, Object... params) {
/* 107 */     return invokeSafe(null, method, params);
/*     */   }
/*     */   
/*     */   static Object invokeSafe(Object instance, Method method, Object... params) {
/* 111 */     if (method == null)
/* 111 */       return null; 
/*     */     try {
/* 113 */       return method.invoke(instance, params);
/* 114 */     } catch (Exception e) {
/* 115 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   static Object invokeSafe(Constructor<?> constructor, Object... params) {
/* 120 */     if (constructor == null)
/* 120 */       return null; 
/*     */     try {
/* 122 */       return constructor.newInstance(params);
/* 123 */     } catch (Exception e) {
/* 124 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\AdventureReflectionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */