/*     */ package com.github.retrooper.packetevents.util.adventure;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.stats.Statistics;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.StringJoiner;
/*     */ import java.util.UUID;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.nbt.BinaryTag;
/*     */ import net.kyori.adventure.nbt.CompoundBinaryTag;
/*     */ import net.kyori.adventure.nbt.TagStringIO;
/*     */ import net.kyori.adventure.nbt.api.BinaryTagHolder;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.TextComponent;
/*     */ import net.kyori.adventure.text.event.HoverEvent;
/*     */ import net.kyori.adventure.util.Codec;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class HoverSerializer {
/*  46 */   private static final TagStringIO SNBT_IO = TagStringIO.get();
/*     */   
/*  47 */   private static final Codec<CompoundBinaryTag, String, IOException, IOException> SNBT_CODEC = createCodec(SNBT_IO::asCompound, SNBT_IO::asString);
/*     */   
/*     */   static final String ITEM_TYPE = "id";
/*     */   
/*     */   static final String ITEM_COUNT = "Count";
/*     */   
/*     */   static final String ITEM_TAG = "tag";
/*     */   
/*     */   static final String ENTITY_NAME = "name";
/*     */   
/*     */   static final String ENTITY_TYPE = "type";
/*     */   
/*     */   static final String ENTITY_ID = "id";
/*     */   
/*     */   static {
/*  47 */     Objects.requireNonNull(SNBT_IO);
/*  47 */     Objects.requireNonNull(SNBT_IO);
/*     */   }
/*     */   
/*  56 */   static final Pattern LEGACY_NAME_PATTERN = Pattern.compile("([A-Z][a-z]+)([A-Z][a-z]+)?");
/*     */   
/*     */   public HoverEvent.ShowItem deserializeShowItem(GsonLike gson, JsonElement input, boolean legacy) throws IOException {
/*  59 */     if (legacy) {
/*  60 */       Component component = gson.<Component>fromJson(input, Component.class);
/*  61 */       assertTextComponent(component);
/*  62 */       CompoundBinaryTag contents = (CompoundBinaryTag)SNBT_CODEC.decode(((TextComponent)component).content());
/*  63 */       CompoundBinaryTag tag = contents.getCompound("tag");
/*  64 */       return createShowItem(
/*  65 */           Key.key(contents.getString("id")), contents
/*  66 */           .getByte("Count", (byte)1), 
/*  67 */           (tag == CompoundBinaryTag.empty()) ? null : BinaryTagHolder.encode(tag, SNBT_CODEC));
/*     */     } 
/*  70 */     return gson.<HoverEvent.ShowItem>fromJson(input, HoverEvent.ShowItem.class);
/*     */   }
/*     */   
/*     */   public HoverEvent.ShowEntity deserializeShowEntity(GsonLike gson, JsonElement input, Codec.Decoder<Component, String, ? extends RuntimeException> componentCodec, boolean legacy) throws IOException {
/*  75 */     if (legacy) {
/*  76 */       Component component = gson.<Component>fromJson(input, Component.class);
/*  77 */       assertTextComponent(component);
/*  78 */       CompoundBinaryTag contents = (CompoundBinaryTag)SNBT_CODEC.decode(((TextComponent)component).content());
/*  79 */       String type = contents.getString("type");
/*  80 */       Matcher matcher = LEGACY_NAME_PATTERN.matcher(type);
/*  81 */       if (matcher.matches()) {
/*  82 */         StringJoiner joiner = new StringJoiner("_");
/*  83 */         joiner.add(matcher.group(1));
/*  84 */         if (matcher.group(2) != null)
/*  85 */           joiner.add(matcher.group(2)); 
/*  87 */         type = joiner.toString().toLowerCase(Locale.ROOT);
/*     */       } 
/*  89 */       return createShowEntity(
/*  90 */           Key.key(type), 
/*  91 */           UUID.fromString(contents.getString("id")), (Component)componentCodec
/*  92 */           .decode(contents.getString("name")));
/*     */     } 
/*  95 */     return gson.<HoverEvent.ShowEntity>fromJson(input, HoverEvent.ShowEntity.class);
/*     */   }
/*     */   
/*     */   public Component deserializeShowAchievement(JsonElement input) {
/* 100 */     assertStringValue(input);
/* 101 */     return Statistics.getById(input.getAsString()).display();
/*     */   }
/*     */   
/*     */   private static void assertStringValue(JsonElement element) {
/* 105 */     if (!element.isJsonPrimitive() || !((JsonPrimitive)element).isString())
/* 106 */       throw new IllegalArgumentException("Legacy events must be single Component instances"); 
/*     */   }
/*     */   
/*     */   private static void assertTextComponent(Component component) {
/* 111 */     if (!(component instanceof TextComponent) || !component.children().isEmpty())
/* 112 */       throw new IllegalArgumentException("Legacy events must be single Component instances"); 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Component serializeShowItem(HoverEvent.ShowItem input) throws IOException {
/* 119 */     CompoundBinaryTag.Builder builder = (CompoundBinaryTag.Builder)((CompoundBinaryTag.Builder)CompoundBinaryTag.builder().putString("id", input.item().asString())).putByte("Count", (byte)input.count());
/* 120 */     BinaryTagHolder nbt = input.nbt();
/* 121 */     if (nbt != null)
/* 122 */       builder.put("tag", (BinaryTag)nbt.get(SNBT_CODEC)); 
/* 124 */     return (Component)Component.text((String)SNBT_CODEC.encode(builder.build()));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Component serializeShowEntity(HoverEvent.ShowEntity input, Codec.Encoder<Component, String, ? extends RuntimeException> componentCodec) throws IOException {
/* 130 */     CompoundBinaryTag.Builder builder = (CompoundBinaryTag.Builder)((CompoundBinaryTag.Builder)CompoundBinaryTag.builder().putString("id", input.id().toString())).putString("type", input.type().asString());
/* 131 */     Component name = input.name();
/* 132 */     if (name != null)
/* 133 */       builder.putString("name", (String)componentCodec.encode(name)); 
/* 135 */     return (Component)Component.text((String)SNBT_CODEC.encode(builder.build()));
/*     */   }
/*     */   
/*     */   public static interface GsonLike {
/*     */     static GsonLike fromGson(Gson gson) {
/* 141 */       Objects.requireNonNull(gson);
/* 141 */       return gson::fromJson;
/*     */     }
/*     */     
/*     */     <T> T fromJson(@Nullable JsonElement param1JsonElement, Class<T> param1Class);
/*     */   }
/*     */   
/*     */   private static HoverEvent.ShowItem createShowItem(@NotNull Key item, int count, @Nullable BinaryTagHolder nbt) {
/*     */     try {
/* 151 */       return HoverEvent.ShowItem.showItem(item, count, nbt);
/* 152 */     } catch (NoSuchMethodError ignored) {
/* 153 */       return HoverEvent.ShowItem.of(item, count, nbt);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static HoverEvent.ShowEntity createShowEntity(@NotNull Key type, @NotNull UUID id, @Nullable Component name) {
/*     */     try {
/* 159 */       return HoverEvent.ShowEntity.showEntity(type, id, name);
/* 160 */     } catch (NoSuchMethodError ignored) {
/* 161 */       return HoverEvent.ShowEntity.of(type, id, name);
/*     */     } 
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private static <D, E, DX extends Throwable, EX extends Throwable> Codec<D, E, DX, EX> createCodec(@NotNull Codec.Decoder<D, E, DX> decoder, @NotNull Codec.Encoder<D, E, EX> encoder) {
/*     */     try {
/* 167 */       return Codec.codec(decoder, encoder);
/* 168 */     } catch (NoSuchMethodError ignored) {
/* 169 */       return Codec.of(decoder, encoder);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\HoverSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */