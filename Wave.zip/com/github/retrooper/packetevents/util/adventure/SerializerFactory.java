/*    */ package com.github.retrooper.packetevents.util.adventure;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.TypeAdapter;
/*    */ import com.google.gson.TypeAdapterFactory;
/*    */ import com.google.gson.reflect.TypeToken;
/*    */ import net.kyori.adventure.key.Key;
/*    */ import net.kyori.adventure.text.BlockNBTComponent;
/*    */ import net.kyori.adventure.text.Component;
/*    */ import net.kyori.adventure.text.event.ClickEvent;
/*    */ import net.kyori.adventure.text.event.HoverEvent;
/*    */ import net.kyori.adventure.text.format.Style;
/*    */ import net.kyori.adventure.text.format.TextColor;
/*    */ import net.kyori.adventure.text.format.TextDecoration;
/*    */ 
/*    */ public class SerializerFactory implements TypeAdapterFactory {
/*    */   private final boolean downsampleColors;
/*    */   
/*    */   private final boolean emitLegacyHover;
/*    */   
/*    */   SerializerFactory(boolean downsampleColors, boolean emitLegacyHover) {
/* 40 */     this.downsampleColors = downsampleColors;
/* 41 */     this.emitLegacyHover = emitLegacyHover;
/*    */   }
/*    */   
/*    */   public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
/* 47 */     Class<? super T> rawType = type.getRawType();
/* 48 */     if (Component.class.isAssignableFrom(rawType))
/* 49 */       return (TypeAdapter<T>)AdventureReflectionUtil.COMPONENT_SERIALIZER_CREATE.apply(gson); 
/* 50 */     if (Key.class.isAssignableFrom(rawType))
/* 51 */       return (TypeAdapter)AdventureReflectionUtil.KEY_SERIALIZER_INSTANCE; 
/* 52 */     if (Style.class.isAssignableFrom(rawType))
/* 53 */       return (TypeAdapter)StyleSerializerExtended.create(this.emitLegacyHover, gson); 
/* 54 */     if (ClickEvent.Action.class.isAssignableFrom(rawType))
/* 55 */       return (TypeAdapter)AdventureReflectionUtil.CLICK_EVENT_ACTION_SERIALIZER_INSTANCE; 
/* 56 */     if (HoverEvent.Action.class.isAssignableFrom(rawType))
/* 57 */       return (TypeAdapter)AdventureReflectionUtil.HOVER_EVENT_ACTION_SERIALIZER_INSTANCE; 
/* 58 */     if (HoverEvent.ShowItem.class.isAssignableFrom(rawType))
/* 59 */       return (TypeAdapter<T>)AdventureReflectionUtil.SHOW_ITEM_SERIALIZER_CREATE.apply(gson); 
/* 60 */     if (HoverEvent.ShowEntity.class.isAssignableFrom(rawType))
/* 61 */       return (TypeAdapter<T>)AdventureReflectionUtil.SHOW_ENTITY_SERIALIZER_CREATE.apply(gson); 
/* 62 */     if (TextColorWrapper.class.isAssignableFrom(rawType))
/* 63 */       return TextColorWrapper.Serializer.INSTANCE; 
/* 64 */     if (TextColor.class.isAssignableFrom(rawType))
/* 65 */       return this.downsampleColors ? (TypeAdapter)AdventureReflectionUtil.TEXT_COLOR_SERIALIZER_DOWNSAMPLE_COLOR_INSTANCE : (TypeAdapter)AdventureReflectionUtil.TEXT_COLOR_SERIALIZER_INSTANCE; 
/* 66 */     if (TextDecoration.class.isAssignableFrom(rawType))
/* 67 */       return (TypeAdapter)AdventureReflectionUtil.TEXT_DECORATION_SERIALIZER_INSTANCE; 
/* 68 */     if (BlockNBTComponent.Pos.class.isAssignableFrom(rawType))
/* 69 */       return (TypeAdapter)AdventureReflectionUtil.BLOCK_NBT_POS_SERIALIZER_INSTANCE; 
/* 71 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\SerializerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */