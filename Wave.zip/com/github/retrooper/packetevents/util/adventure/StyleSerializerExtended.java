/*     */ package com.github.retrooper.packetevents.util.adventure;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import com.google.gson.TypeAdapter;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import com.google.gson.stream.JsonToken;
/*     */ import com.google.gson.stream.JsonWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Set;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.event.ClickEvent;
/*     */ import net.kyori.adventure.text.event.HoverEvent;
/*     */ import net.kyori.adventure.text.event.HoverEventSource;
/*     */ import net.kyori.adventure.text.format.Style;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import net.kyori.adventure.text.format.TextDecoration;
/*     */ import net.kyori.adventure.util.Codec;
/*     */ 
/*     */ public class StyleSerializerExtended extends TypeAdapter<Style> {
/*  41 */   private static final TextDecoration[] DECORATIONS = new TextDecoration[] { TextDecoration.BOLD, TextDecoration.ITALIC, TextDecoration.UNDERLINED, TextDecoration.STRIKETHROUGH, TextDecoration.OBFUSCATED };
/*     */   
/*     */   static final String FONT = "font";
/*     */   
/*     */   static final String COLOR = "color";
/*     */   
/*     */   static final String INSERTION = "insertion";
/*     */   
/*     */   static final String CLICK_EVENT = "clickEvent";
/*     */   
/*     */   static final String CLICK_EVENT_ACTION = "action";
/*     */   
/*     */   static final String CLICK_EVENT_VALUE = "value";
/*     */   
/*     */   static final String HOVER_EVENT = "hoverEvent";
/*     */   
/*     */   static final String HOVER_EVENT_ACTION = "action";
/*     */   
/*     */   static final String HOVER_EVENT_CONTENTS = "contents";
/*     */   
/*     */   @Deprecated
/*     */   static final String HOVER_EVENT_VALUE = "value";
/*     */   
/*     */   private final boolean emitLegacyHover;
/*     */   
/*     */   private final Gson gson;
/*     */   
/*     */   private final HoverSerializer hoverSerializer;
/*     */   
/*     */   static {
/*  51 */     Set<TextDecoration> knownDecorations = EnumSet.allOf(TextDecoration.class);
/*  52 */     for (TextDecoration decoration : DECORATIONS)
/*  53 */       knownDecorations.remove(decoration); 
/*  55 */     if (!knownDecorations.isEmpty())
/*  56 */       throw new IllegalStateException("Gson serializer is missing some text decorations: " + knownDecorations); 
/*     */   }
/*     */   
/*     */   static TypeAdapter<Style> create(boolean emitLegacyHover, Gson gson) {
/*  72 */     return (new StyleSerializerExtended(emitLegacyHover, gson)).nullSafe();
/*     */   }
/*     */   
/*     */   private StyleSerializerExtended(boolean emitLegacyHover, Gson gson) {
/*  80 */     this.emitLegacyHover = emitLegacyHover;
/*  81 */     this.gson = gson;
/*  82 */     this.hoverSerializer = new HoverSerializer();
/*     */   }
/*     */   
/*     */   public Style read(JsonReader in) throws IOException {
/*  87 */     in.beginObject();
/*  88 */     Style.Builder style = Style.style();
/*  90 */     while (in.hasNext()) {
/*  91 */       String fieldName = in.nextName();
/*  92 */       if (fieldName.equals("font")) {
/*  93 */         style.font((Key)this.gson.fromJson(in, Key.class));
/*     */         continue;
/*     */       } 
/*  94 */       if (fieldName.equals("color")) {
/*  95 */         TextColorWrapper color = (TextColorWrapper)this.gson.fromJson(in, TextColorWrapper.class);
/*  96 */         if (color.color != null) {
/*  97 */           style.color(color.color);
/*     */           continue;
/*     */         } 
/*  98 */         if (color.decoration != null)
/*  99 */           style.decoration(color.decoration, TextDecoration.State.TRUE); 
/*     */         continue;
/*     */       } 
/* 101 */       if (TextDecoration.NAMES.keys().contains(fieldName)) {
/* 102 */         style.decoration((TextDecoration)TextDecoration.NAMES.value(fieldName), readBoolean(in));
/*     */         continue;
/*     */       } 
/* 103 */       if (fieldName.equals("insertion")) {
/* 104 */         style.insertion(in.nextString());
/*     */         continue;
/*     */       } 
/* 105 */       if (fieldName.equals("clickEvent")) {
/* 106 */         in.beginObject();
/* 107 */         ClickEvent.Action action = null;
/* 108 */         String value = null;
/* 109 */         while (in.hasNext()) {
/* 110 */           String clickEventField = in.nextName();
/* 111 */           if (clickEventField.equals("action")) {
/* 112 */             action = (ClickEvent.Action)this.gson.fromJson(in, ClickEvent.Action.class);
/*     */             continue;
/*     */           } 
/* 113 */           if (clickEventField.equals("value")) {
/* 114 */             value = (in.peek() == JsonToken.NULL) ? null : in.nextString();
/*     */             continue;
/*     */           } 
/* 116 */           in.skipValue();
/*     */         } 
/* 119 */         if (action != null && action.readable() && value != null)
/* 120 */           style.clickEvent(ClickEvent.clickEvent(action, value)); 
/* 122 */         in.endObject();
/*     */         continue;
/*     */       } 
/* 123 */       if (fieldName.equals("hoverEvent")) {
/* 124 */         JsonObject hoverEventObject = (JsonObject)this.gson.fromJson(in, JsonObject.class);
/* 125 */         if (hoverEventObject != null) {
/*     */           JsonElement rawValue;
/* 126 */           JsonPrimitive serializedAction = hoverEventObject.getAsJsonPrimitive("action");
/* 127 */           if (serializedAction == null)
/*     */             continue; 
/* 133 */           boolean legacy = false;
/* 134 */           if (hoverEventObject.has("contents")) {
/* 135 */             rawValue = hoverEventObject.get("contents");
/* 136 */           } else if (hoverEventObject.has("value")) {
/* 137 */             rawValue = hoverEventObject.get("value");
/* 138 */             legacy = true;
/*     */           } else {
/* 140 */             rawValue = null;
/*     */           } 
/* 143 */           if (rawValue != null) {
/* 144 */             HoverEvent.Action action = null;
/* 145 */             Object value = null;
/* 146 */             switch (serializedAction.getAsString()) {
/*     */               case "show_text":
/* 148 */                 action = HoverEvent.Action.SHOW_TEXT;
/* 149 */                 value = this.gson.fromJson(rawValue, Component.class);
/*     */                 break;
/*     */               case "show_item":
/* 152 */                 action = HoverEvent.Action.SHOW_ITEM;
/* 153 */                 value = this.hoverSerializer.deserializeShowItem(HoverSerializer.GsonLike.fromGson(this.gson), rawValue, legacy);
/*     */                 break;
/*     */               case "show_entity":
/* 156 */                 action = HoverEvent.Action.SHOW_ENTITY;
/* 157 */                 value = this.hoverSerializer.deserializeShowEntity(HoverSerializer.GsonLike.fromGson(this.gson), rawValue, (Codec.Decoder)decoder(), legacy);
/*     */                 break;
/*     */               case "show_achievement":
/* 160 */                 action = HoverEvent.Action.SHOW_TEXT;
/* 161 */                 value = this.hoverSerializer.deserializeShowAchievement(rawValue);
/*     */                 break;
/*     */             } 
/* 165 */             if (value != null)
/* 166 */               style.hoverEvent((HoverEventSource)HoverEvent.hoverEvent(action, value)); 
/*     */           } 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 171 */       in.skipValue();
/*     */     } 
/* 175 */     in.endObject();
/* 176 */     return style.build();
/*     */   }
/*     */   
/*     */   private boolean readBoolean(JsonReader in) throws IOException {
/* 180 */     JsonToken peek = in.peek();
/* 181 */     if (peek == JsonToken.BOOLEAN)
/* 182 */       return in.nextBoolean(); 
/* 183 */     if (peek == JsonToken.STRING || peek == JsonToken.NUMBER)
/* 184 */       return Boolean.parseBoolean(in.nextString()); 
/* 186 */     throw new JsonParseException("Token of type " + peek + " cannot be interpreted as a boolean");
/*     */   }
/*     */   
/*     */   private Codec.Decoder<Component, String, JsonParseException> decoder() {
/* 191 */     return string -> (Component)this.gson.fromJson(string, Component.class);
/*     */   }
/*     */   
/*     */   private Codec.Encoder<Component, String, JsonParseException> encoder() {
/* 195 */     return component -> this.gson.toJson(component, Component.class);
/*     */   }
/*     */   
/*     */   public void write(JsonWriter out, Style value) throws IOException {
/* 200 */     out.beginObject();
/* 202 */     for (TextDecoration decoration : DECORATIONS) {
/* 203 */       TextDecoration.State state = value.decoration(decoration);
/* 204 */       if (state != TextDecoration.State.NOT_SET) {
/* 205 */         String name = (String)TextDecoration.NAMES.key(decoration);
/* 206 */         assert name != null;
/* 207 */         out.name(name);
/* 208 */         out.value((state == TextDecoration.State.TRUE));
/*     */       } 
/*     */     } 
/* 212 */     TextColor color = value.color();
/* 213 */     if (color != null) {
/* 214 */       out.name("color");
/* 215 */       this.gson.toJson(color, TextColor.class, out);
/*     */     } 
/* 218 */     String insertion = value.insertion();
/* 219 */     if (insertion != null) {
/* 220 */       out.name("insertion");
/* 221 */       out.value(insertion);
/*     */     } 
/* 224 */     ClickEvent clickEvent = value.clickEvent();
/* 225 */     if (clickEvent != null) {
/* 226 */       out.name("clickEvent");
/* 227 */       out.beginObject();
/* 228 */       out.name("action");
/* 229 */       this.gson.toJson(clickEvent.action(), ClickEvent.Action.class, out);
/* 230 */       out.name("value");
/* 231 */       out.value(clickEvent.value());
/* 232 */       out.endObject();
/*     */     } 
/* 235 */     HoverEvent<?> hoverEvent = value.hoverEvent();
/* 236 */     if (hoverEvent != null) {
/* 237 */       out.name("hoverEvent");
/* 238 */       out.beginObject();
/* 239 */       out.name("action");
/* 240 */       HoverEvent.Action<?> action = hoverEvent.action();
/* 241 */       this.gson.toJson(action, HoverEvent.Action.class, out);
/* 242 */       if (this.emitLegacyHover) {
/* 243 */         out.name("value");
/* 244 */         serializeLegacyHoverEvent(hoverEvent, out);
/*     */       } else {
/* 246 */         out.name("contents");
/* 247 */         if (action == HoverEvent.Action.SHOW_ITEM) {
/* 248 */           this.gson.toJson(hoverEvent.value(), HoverEvent.ShowItem.class, out);
/* 249 */         } else if (action == HoverEvent.Action.SHOW_ENTITY) {
/* 250 */           this.gson.toJson(hoverEvent.value(), HoverEvent.ShowEntity.class, out);
/* 251 */         } else if (action == HoverEvent.Action.SHOW_TEXT) {
/* 252 */           this.gson.toJson(hoverEvent.value(), Component.class, out);
/*     */         } else {
/* 254 */           throw new JsonParseException("Don't know how to serialize " + hoverEvent.value());
/*     */         } 
/*     */       } 
/* 258 */       out.endObject();
/*     */     } 
/* 261 */     Key font = value.font();
/* 262 */     if (font != null) {
/* 263 */       out.name("font");
/* 264 */       this.gson.toJson(font, Key.class, out);
/*     */     } 
/* 267 */     out.endObject();
/*     */   }
/*     */   
/*     */   private void serializeLegacyHoverEvent(HoverEvent<?> hoverEvent, JsonWriter out) throws IOException {
/* 271 */     if (hoverEvent.action() == HoverEvent.Action.SHOW_TEXT) {
/* 272 */       this.gson.toJson(hoverEvent.value(), Component.class, out);
/*     */       return;
/*     */     } 
/* 277 */     Component serialized = null;
/*     */     try {
/* 279 */       if (hoverEvent.action() == HoverEvent.Action.SHOW_ENTITY) {
/* 280 */         serialized = this.hoverSerializer.serializeShowEntity((HoverEvent.ShowEntity)hoverEvent.value(), (Codec.Encoder)encoder());
/* 281 */       } else if (hoverEvent.action() == HoverEvent.Action.SHOW_ITEM) {
/* 282 */         serialized = this.hoverSerializer.serializeShowItem((HoverEvent.ShowItem)hoverEvent.value());
/*     */       } 
/* 284 */     } catch (IOException ex) {
/* 285 */       throw new JsonSyntaxException(ex);
/*     */     } 
/* 287 */     if (serialized != null) {
/* 288 */       this.gson.toJson(serialized, Component.class, out);
/*     */     } else {
/* 290 */       out.nullValue();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\StyleSerializerExtended.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */