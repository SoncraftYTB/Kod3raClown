/*    */ package com.github.retrooper.packetevents.util.adventure;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.google.gson.JsonElement;
/*    */ import io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.GsonComponentSerializer;
/*    */ import io.github.retrooper.waveanticheat.packetevents.adventure.serializer.legacy.LegacyComponentSerializer;
/*    */ import net.kyori.adventure.text.Component;
/*    */ 
/*    */ public class AdventureSerializer {
/*    */   private static GsonComponentSerializer GSON;
/*    */   
/*    */   private static LegacyComponentSerializer LEGACY;
/*    */   
/*    */   public static GsonComponentSerializer getGsonSerializer() {
/* 34 */     if (GSON == null) {
/* 35 */       ServerVersion version = PacketEvents.getAPI().getServerManager().getVersion();
/* 38 */       GSON = new GsonComponentSerializerExtended((version.isOlderThan(ServerVersion.V_1_16) && PacketEvents.getAPI().getSettings().shouldDownsampleColors()), version.isOlderThanOrEquals(ServerVersion.V_1_12_2));
/*    */     } 
/* 41 */     return GSON;
/*    */   }
/*    */   
/*    */   public static LegacyComponentSerializer getLegacyGsonSerializer() {
/* 45 */     if (LEGACY == null) {
/* 46 */       LegacyComponentSerializer.Builder builder = LegacyComponentSerializer.builder();
/* 47 */       if (!PacketEvents.getAPI().getSettings().shouldDownsampleColors() || PacketEvents.getAPI().getServerManager().getVersion().isNewerThanOrEquals(ServerVersion.V_1_16))
/* 48 */         builder = builder.hexColors(); 
/* 49 */       LEGACY = builder.build();
/*    */     } 
/* 51 */     return LEGACY;
/*    */   }
/*    */   
/*    */   public static String asVanilla(Component component) {
/* 55 */     return getLegacyGsonSerializer().serialize(component);
/*    */   }
/*    */   
/*    */   public static Component fromLegacyFormat(String legacyMessage) {
/* 59 */     return getLegacyGsonSerializer().deserializeOrNull(legacyMessage);
/*    */   }
/*    */   
/*    */   public static String toLegacyFormat(Component component) {
/* 63 */     return (String)getLegacyGsonSerializer().serializeOrNull(component);
/*    */   }
/*    */   
/*    */   public static Component parseComponent(String json) {
/* 67 */     return getGsonSerializer().deserializeOrNull(json);
/*    */   }
/*    */   
/*    */   public static Component parseJsonTree(JsonElement json) {
/* 71 */     return getGsonSerializer().deserializeFromTree(json);
/*    */   }
/*    */   
/*    */   public static String toJson(Component component) {
/* 75 */     return (String)getGsonSerializer().serializeOrNull(component);
/*    */   }
/*    */   
/*    */   public static JsonElement toJsonTree(Component component) {
/* 79 */     return getGsonSerializer().serializeToTree(component);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\AdventureSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */