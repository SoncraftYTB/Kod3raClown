/*     */ package com.github.retrooper.packetevents.util.adventure;
/*     */ 
/*     */ import com.github.retrooper.packetevents.util.reflection.Reflection;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonParseException;
/*     */ import io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.GsonComponentSerializer;
/*     */ import java.util.function.UnaryOperator;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.BlockNBTComponent;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.event.ClickEvent;
/*     */ import net.kyori.adventure.text.event.HoverEvent;
/*     */ import net.kyori.adventure.text.format.Style;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import net.kyori.adventure.text.format.TextDecoration;
/*     */ import net.kyori.adventure.util.Buildable;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class GsonComponentSerializerExtended implements GsonComponentSerializer {
/*  45 */   static boolean LEGACY_ADVENTURE = (Reflection.getClassByNameWithoutException("io.github.retrooper.waveanticheat.packetevents.adventure.serializer.gson.SerializerFactory") == null);
/*     */   
/*     */   private final Gson serializer;
/*     */   
/*     */   private final UnaryOperator<GsonBuilder> populator;
/*     */   
/*     */   public GsonComponentSerializerExtended(boolean downsampleColor, boolean emitLegacyHover) {
/*  51 */     if (LEGACY_ADVENTURE) {
/*  52 */       this.populator = (builder -> {
/*     */           builder.registerTypeHierarchyAdapter(Key.class, AdventureReflectionUtil.KEY_SERIALIZER_INSTANCE);
/*     */           builder.registerTypeHierarchyAdapter(Component.class, AdventureReflectionUtil.COMPONENT_SERIALIZER_CREATE.apply(null));
/*     */           builder.registerTypeHierarchyAdapter(Style.class, new Legacy_StyleSerializerExtended(emitLegacyHover));
/*     */           builder.registerTypeAdapter(ClickEvent.Action.class, AdventureReflectionUtil.CLICK_EVENT_ACTION_SERIALIZER_INSTANCE);
/*     */           builder.registerTypeAdapter(HoverEvent.Action.class, AdventureReflectionUtil.HOVER_EVENT_ACTION_SERIALIZER_INSTANCE);
/*     */           builder.registerTypeAdapter(HoverEvent.ShowItem.class, AdventureReflectionUtil.SHOW_ITEM_SERIALIZER_CREATE.apply(null));
/*     */           builder.registerTypeAdapter(HoverEvent.ShowEntity.class, AdventureReflectionUtil.SHOW_ENTITY_SERIALIZER_CREATE.apply(null));
/*     */           builder.registerTypeAdapter(TextColorWrapper.class, TextColorWrapper.Serializer.INSTANCE);
/*     */           builder.registerTypeHierarchyAdapter(TextColor.class, downsampleColor ? AdventureReflectionUtil.TEXT_COLOR_SERIALIZER_DOWNSAMPLE_COLOR_INSTANCE : AdventureReflectionUtil.TEXT_COLOR_SERIALIZER_INSTANCE);
/*     */           builder.registerTypeAdapter(TextDecoration.class, AdventureReflectionUtil.TEXT_DECORATION_SERIALIZER_INSTANCE);
/*     */           builder.registerTypeHierarchyAdapter(BlockNBTComponent.Pos.class, AdventureReflectionUtil.BLOCK_NBT_POS_SERIALIZER_INSTANCE);
/*     */           return builder;
/*     */         });
/*     */     } else {
/*  67 */       this.populator = (builder -> {
/*     */           builder.registerTypeAdapterFactory(new SerializerFactory(downsampleColor, emitLegacyHover));
/*     */           return builder;
/*     */         });
/*     */     } 
/*  72 */     this.serializer = ((GsonBuilder)this.populator.apply(new GsonBuilder())).create();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Gson serializer() {
/*  77 */     return this.serializer;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public UnaryOperator<GsonBuilder> populator() {
/*  82 */     return this.populator;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Component deserialize(@NotNull String string) {
/*  87 */     Component component = (Component)serializer().fromJson(string, Component.class);
/*  88 */     if (component == null)
/*  88 */       throw new JsonParseException("Don't know how to turn " + string + " into a Component"); 
/*  89 */     return component;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Component deserializeOr(@Nullable String input, @Nullable Component fallback) {
/*  94 */     if (input == null)
/*  94 */       return fallback; 
/*  95 */     Component component = (Component)serializer().fromJson(input, Component.class);
/*  96 */     if (component == null)
/*  96 */       return fallback; 
/*  97 */     return component;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String serialize(@NotNull Component component) {
/* 102 */     return serializer().toJson(component);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Component deserializeFromTree(@NotNull JsonElement input) {
/* 107 */     Component component = (Component)serializer().fromJson(input, Component.class);
/* 108 */     if (component == null)
/* 108 */       throw new JsonParseException("Don't know how to turn " + input + " into a Component"); 
/* 109 */     return component;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public JsonElement serializeToTree(@NotNull Component component) {
/* 114 */     return serializer().toJsonTree(component);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public GsonComponentSerializer.Builder toBuilder() {
/* 119 */     throw new UnsupportedOperationException("Builder pattern is not supported.");
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\GsonComponentSerializerExtended.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */