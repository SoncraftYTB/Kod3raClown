/*    */ package com.github.retrooper.packetevents.util.adventure;
/*    */ 
/*    */ import com.google.gson.JsonParseException;
/*    */ import com.google.gson.JsonSyntaxException;
/*    */ import com.google.gson.TypeAdapter;
/*    */ import com.google.gson.stream.JsonReader;
/*    */ import com.google.gson.stream.JsonWriter;
/*    */ import java.io.IOException;
/*    */ import net.kyori.adventure.text.format.NamedTextColor;
/*    */ import net.kyori.adventure.text.format.TextColor;
/*    */ import net.kyori.adventure.text.format.TextDecoration;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class TextColorWrapper {
/*    */   @Nullable
/*    */   final TextColor color;
/*    */   
/*    */   @Nullable
/*    */   final TextDecoration decoration;
/*    */   
/*    */   final boolean reset;
/*    */   
/*    */   TextColorWrapper(@Nullable TextColor color, @Nullable TextDecoration decoration, boolean reset) {
/* 40 */     this.color = color;
/* 41 */     this.decoration = decoration;
/* 42 */     this.reset = reset;
/*    */   }
/*    */   
/*    */   static final class Serializer extends TypeAdapter<TextColorWrapper> {
/* 46 */     static final Serializer INSTANCE = new Serializer();
/*    */     
/*    */     public void write(JsonWriter out, TextColorWrapper value) {
/* 53 */       throw new JsonSyntaxException("Cannot write TextColorWrapper instances");
/*    */     }
/*    */     
/*    */     public TextColorWrapper read(JsonReader in) throws IOException {
/* 58 */       String input = in.nextString();
/* 59 */       TextColor color = colorFromString(input);
/* 60 */       TextDecoration decoration = (TextDecoration)TextDecoration.NAMES.value(input);
/* 61 */       boolean reset = (decoration == null && input.equals("reset"));
/* 62 */       if (color == null && decoration == null && !reset)
/* 63 */         throw new JsonParseException("Don't know how to parse " + input + " at " + in.getPath()); 
/* 65 */       return new TextColorWrapper(color, decoration, reset);
/*    */     }
/*    */     
/*    */     TextColor colorFromString(String value) {
/* 69 */       if (value.startsWith("#"))
/* 70 */         return TextColor.fromHexString(value); 
/* 72 */       return (TextColor)NamedTextColor.NAMES.value(value);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\TextColorWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */