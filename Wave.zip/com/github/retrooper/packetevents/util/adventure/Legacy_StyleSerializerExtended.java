/*     */ package com.github.retrooper.packetevents.util.adventure;
/*     */ 
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonDeserializer;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonNull;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import com.google.gson.JsonSerializer;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import com.google.gson.internal.Streams;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import net.kyori.adventure.key.Key;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import net.kyori.adventure.text.event.ClickEvent;
/*     */ import net.kyori.adventure.text.event.HoverEvent;
/*     */ import net.kyori.adventure.text.event.HoverEventSource;
/*     */ import net.kyori.adventure.text.format.Style;
/*     */ import net.kyori.adventure.text.format.TextColor;
/*     */ import net.kyori.adventure.text.format.TextDecoration;
/*     */ import net.kyori.adventure.util.Codec;
/*     */ 
/*     */ public class Legacy_StyleSerializerExtended implements JsonDeserializer<Style>, JsonSerializer<Style> {
/*  23 */   private static final TextDecoration[] DECORATIONS = new TextDecoration[] { TextDecoration.BOLD, TextDecoration.ITALIC, TextDecoration.UNDERLINED, TextDecoration.STRIKETHROUGH, TextDecoration.OBFUSCATED };
/*     */   
/*     */   static final String FONT = "font";
/*     */   
/*     */   static final String COLOR = "color";
/*     */   
/*     */   static final String INSERTION = "insertion";
/*     */   
/*     */   static final String CLICK_EVENT = "clickEvent";
/*     */   
/*     */   static final String CLICK_EVENT_ACTION = "action";
/*     */   
/*     */   static final String CLICK_EVENT_VALUE = "value";
/*     */   
/*     */   static final String HOVER_EVENT = "hoverEvent";
/*     */   
/*     */   static final String HOVER_EVENT_ACTION = "action";
/*     */   
/*     */   static final String HOVER_EVENT_CONTENTS = "contents";
/*     */   
/*     */   @Deprecated
/*     */   static final String HOVER_EVENT_VALUE = "value";
/*     */   
/*     */   private final boolean emitLegacyHover;
/*     */   
/*     */   private final HoverSerializer hoverSerializer;
/*     */   
/*     */   static {
/*  33 */     Set<TextDecoration> knownDecorations = EnumSet.allOf(TextDecoration.class);
/*  34 */     for (TextDecoration decoration : DECORATIONS)
/*  35 */       knownDecorations.remove(decoration); 
/*  37 */     if (!knownDecorations.isEmpty())
/*  38 */       throw new IllegalStateException("Gson serializer is missing some text decorations: " + knownDecorations); 
/*     */   }
/*     */   
/*     */   Legacy_StyleSerializerExtended(boolean emitLegacyHover) {
/*  56 */     this.emitLegacyHover = emitLegacyHover;
/*  57 */     this.hoverSerializer = new HoverSerializer();
/*     */   }
/*     */   
/*     */   public Style deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
/*  61 */     JsonObject object = json.getAsJsonObject();
/*  62 */     return deserialize(object, context);
/*     */   }
/*     */   
/*     */   private Style deserialize(JsonObject json, JsonDeserializationContext context) throws JsonParseException {
/*  66 */     Style.Builder style = Style.style();
/*  67 */     if (json.has("font"))
/*  68 */       style.font((Key)context.deserialize(json.get("font"), Key.class)); 
/*  71 */     if (json.has("color")) {
/*  72 */       TextColorWrapper color = (TextColorWrapper)context.deserialize(json.get("color"), TextColorWrapper.class);
/*  73 */       if (color.color != null) {
/*  74 */         style.color(color.color);
/*  75 */       } else if (color.decoration != null) {
/*  76 */         style.decoration(color.decoration, true);
/*     */       } 
/*     */     } 
/*  80 */     for (TextDecoration decoration : DECORATIONS) {
/*  81 */       String value = (String)TextDecoration.NAMES.key(decoration);
/*  82 */       if (json.has(value))
/*  83 */         style.decoration(decoration, json.get(value).getAsBoolean()); 
/*     */     } 
/*  87 */     if (json.has("insertion"))
/*  88 */       style.insertion(json.get("insertion").getAsString()); 
/*  91 */     if (json.has("clickEvent")) {
/*  92 */       JsonObject clickEvent = json.getAsJsonObject("clickEvent");
/*  93 */       if (clickEvent != null) {
/*  94 */         ClickEvent.Action action = optionallyDeserialize((JsonElement)clickEvent.getAsJsonPrimitive("action"), context, ClickEvent.Action.class);
/*  95 */         if (action != null && action.readable()) {
/*  96 */           JsonPrimitive rawValue = clickEvent.getAsJsonPrimitive("value");
/*  97 */           String value = (rawValue == null) ? null : rawValue.getAsString();
/*  98 */           if (value != null)
/*  99 */             style.clickEvent(ClickEvent.clickEvent(action, value)); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 105 */     if (json.has("hoverEvent")) {
/* 106 */       JsonObject hoverEventObject = json.getAsJsonObject("hoverEvent");
/* 107 */       if (hoverEventObject != null) {
/* 109 */         JsonPrimitive serializedAction = hoverEventObject.getAsJsonPrimitive("action");
/* 110 */         if (serializedAction != null) {
/*     */           JsonElement rawValue;
/*     */           boolean legacy;
/* 113 */           if (hoverEventObject.has("contents")) {
/* 114 */             legacy = false;
/* 115 */             rawValue = hoverEventObject.get("contents");
/* 116 */           } else if (hoverEventObject.has("value")) {
/* 117 */             rawValue = hoverEventObject.get("value");
/* 118 */             legacy = true;
/*     */           } else {
/* 120 */             legacy = false;
/* 121 */             rawValue = null;
/*     */           } 
/* 124 */           if (rawValue != null) {
/* 125 */             HoverEvent.Action action = null;
/* 126 */             Object value = null;
/* 127 */             switch (serializedAction.getAsString()) {
/*     */               case "show_text":
/* 129 */                 action = HoverEvent.Action.SHOW_TEXT;
/* 130 */                 value = context.deserialize(rawValue, Component.class);
/*     */                 break;
/*     */               case "show_item":
/* 133 */                 action = HoverEvent.Action.SHOW_ITEM;
/* 134 */                 value = tryIgnoring(() -> {
/*     */                       Objects.requireNonNull(context);
/*     */                       return this.hoverSerializer.deserializeShowItem(context::deserialize, rawValue, legacy);
/*     */                     });
/*     */                 break;
/*     */               case "show_entity":
/* 137 */                 action = HoverEvent.Action.SHOW_ENTITY;
/* 138 */                 value = tryIgnoring(() -> {
/*     */                       Objects.requireNonNull(context);
/*     */                       return this.hoverSerializer.deserializeShowEntity(context::deserialize, rawValue, (Codec.Decoder)decoder(context), legacy);
/*     */                     });
/*     */                 break;
/*     */               case "show_achievement":
/* 141 */                 action = HoverEvent.Action.SHOW_TEXT;
/* 142 */                 value = tryIgnoring(() -> this.hoverSerializer.deserializeShowAchievement(rawValue));
/*     */                 break;
/*     */             } 
/* 146 */             if (value != null)
/* 147 */               style.hoverEvent((HoverEventSource)HoverEvent.hoverEvent(action, value)); 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 154 */     if (json.has("font"))
/* 155 */       style.font((Key)context.deserialize(json.get("font"), Key.class)); 
/* 158 */     return style.build();
/*     */   }
/*     */   
/*     */   private <T> T tryIgnoring(ExceptionalFunction<T> function) {
/*     */     try {
/* 163 */       return function.invoke();
/* 164 */     } catch (IOException e) {
/* 165 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static <T> T optionallyDeserialize(JsonElement json, JsonDeserializationContext context, Class<T> type) {
/* 175 */     return (json == null) ? null : (T)context.deserialize(json, type);
/*     */   }
/*     */   
/*     */   private Codec.Decoder<Component, String, JsonParseException> decoder(JsonDeserializationContext ctx) {
/* 179 */     return string -> {
/*     */         JsonReader reader = new JsonReader(new StringReader(string));
/*     */         return (Component)ctx.deserialize(Streams.parse(reader), Component.class);
/*     */       };
/*     */   }
/*     */   
/*     */   public JsonElement serialize(Style src, Type typeOfSrc, JsonSerializationContext context) {
/* 186 */     JsonObject json = new JsonObject();
/* 188 */     for (TextDecoration decoration : DECORATIONS) {
/* 189 */       TextDecoration.State state = src.decoration(decoration);
/* 190 */       if (state != TextDecoration.State.NOT_SET) {
/* 191 */         String name = (String)TextDecoration.NAMES.key(decoration);
/* 192 */         assert name != null;
/* 193 */         json.addProperty(name, Boolean.valueOf((state == TextDecoration.State.TRUE)));
/*     */       } 
/*     */     } 
/* 197 */     TextColor color = src.color();
/* 198 */     if (color != null)
/* 199 */       json.add("color", context.serialize(color)); 
/* 202 */     String insertion = src.insertion();
/* 203 */     if (insertion != null)
/* 204 */       json.addProperty("insertion", insertion); 
/* 207 */     ClickEvent clickEvent = src.clickEvent();
/* 208 */     if (clickEvent != null) {
/* 209 */       JsonObject eventJson = new JsonObject();
/* 210 */       eventJson.add("action", context.serialize(clickEvent.action()));
/* 211 */       eventJson.addProperty("value", clickEvent.value());
/* 212 */       json.add("clickEvent", (JsonElement)eventJson);
/*     */     } 
/* 215 */     HoverEvent<?> hoverEvent = src.hoverEvent();
/* 216 */     if (hoverEvent != null) {
/* 217 */       JsonObject eventJson = new JsonObject();
/* 218 */       eventJson.add("action", context.serialize(hoverEvent.action()));
/* 219 */       JsonElement modernContents = context.serialize(hoverEvent.value());
/* 220 */       eventJson.add("contents", modernContents);
/* 221 */       if (this.emitLegacyHover)
/* 222 */         eventJson.add("value", serializeLegacyHoverEvent(hoverEvent, modernContents, context)); 
/* 225 */       json.add("hoverEvent", (JsonElement)eventJson);
/*     */     } 
/* 228 */     Key font = src.font();
/* 229 */     if (font != null)
/* 230 */       json.add("font", context.serialize(font)); 
/* 233 */     return (JsonElement)json;
/*     */   }
/*     */   
/*     */   private JsonElement serializeLegacyHoverEvent(HoverEvent<?> hoverEvent, JsonElement modernContents, JsonSerializationContext context) {
/* 237 */     if (hoverEvent.action() == HoverEvent.Action.SHOW_TEXT)
/* 238 */       return modernContents; 
/* 242 */     Component serialized = null;
/*     */     try {
/* 244 */       if (hoverEvent.action() == HoverEvent.Action.SHOW_ENTITY) {
/* 245 */         serialized = this.hoverSerializer.serializeShowEntity((HoverEvent.ShowEntity)hoverEvent.value(), encoder(context));
/* 246 */       } else if (hoverEvent.action() == HoverEvent.Action.SHOW_ITEM) {
/* 247 */         serialized = this.hoverSerializer.serializeShowItem((HoverEvent.ShowItem)hoverEvent.value());
/*     */       } 
/* 249 */     } catch (IOException var6) {
/* 250 */       throw new JsonSyntaxException(var6);
/*     */     } 
/* 253 */     return (serialized == null) ? (JsonElement)JsonNull.INSTANCE : context.serialize(serialized);
/*     */   }
/*     */   
/*     */   private Codec.Encoder<Component, String, RuntimeException> encoder(JsonSerializationContext ctx) {
/* 257 */     return component -> ctx.serialize(component).toString();
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   static interface ExceptionalFunction<T> {
/*     */     T invoke() throws IOException;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\Legacy_StyleSerializerExtended.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */