/*      */ package com.github.retrooper.packetevents.util.adventure;
/*      */ 
/*      */ import com.github.retrooper.packetevents.netty.buffer.ByteBufInputStream;
/*      */ import com.github.retrooper.packetevents.netty.buffer.ByteBufOutputStream;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.UUID;
/*      */ import net.kyori.adventure.key.Key;
/*      */ import net.kyori.adventure.nbt.api.BinaryTagHolder;
/*      */ import net.kyori.adventure.text.BlockNBTComponent;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.kyori.adventure.text.ComponentLike;
/*      */ import net.kyori.adventure.text.EntityNBTComponent;
/*      */ import net.kyori.adventure.text.KeybindComponent;
/*      */ import net.kyori.adventure.text.NBTComponent;
/*      */ import net.kyori.adventure.text.ScoreComponent;
/*      */ import net.kyori.adventure.text.SelectorComponent;
/*      */ import net.kyori.adventure.text.StorageNBTComponent;
/*      */ import net.kyori.adventure.text.TextComponent;
/*      */ import net.kyori.adventure.text.TranslatableComponent;
/*      */ import net.kyori.adventure.text.event.ClickEvent;
/*      */ import net.kyori.adventure.text.event.HoverEvent;
/*      */ import net.kyori.adventure.text.event.HoverEventSource;
/*      */ import net.kyori.adventure.text.format.NamedTextColor;
/*      */ import net.kyori.adventure.text.format.Style;
/*      */ import net.kyori.adventure.text.format.TextColor;
/*      */ import net.kyori.adventure.text.format.TextDecoration;
/*      */ 
/*      */ public final class AdventureNBTSerialization {
/*   94 */   private static final TagType[] NBT_TYPES = TagType.values();
/*      */   
/*      */   private static final int DEPTH_LIMIT = 12;
/*      */   
/*      */   private static final String OBFUSCATED = "obfuscated";
/*      */   
/*      */   private static final String BOLD = "bold";
/*      */   
/*      */   private static final String STRIKETHROUGH = "strikethrough";
/*      */   
/*      */   private static final String UNDERLINED = "underlined";
/*      */   
/*      */   private static final String ITALIC = "italic";
/*      */   
/*      */   private static final String OPEN_URL = "open_url";
/*      */   
/*      */   private static final String RUN_COMMAND = "run_command";
/*      */   
/*      */   private static final String SUGGEST_COMMAND = "suggest_command";
/*      */   
/*      */   private static final String CHANGE_PAGE = "change_page";
/*      */   
/*      */   private static final String COPY_TO_CLIPBOARD = "copy_to_clipboard";
/*      */   
/*      */   private static final String SHOW_TEXT = "show_text";
/*      */   
/*      */   private static final String SHOW_ITEM = "show_item";
/*      */   
/*      */   private static final String SHOW_ENTITY = "show_entity";
/*      */   
/*      */   private static final String ITEM_ID = "id";
/*      */   
/*      */   private static final String ITEM_COUNT = "count";
/*      */   
/*      */   private static final String ITEM_TAG = "tag";
/*      */   
/*      */   private static final String ENTITY_TYPE = "type";
/*      */   
/*      */   private static final String ENTITY_ID = "id";
/*      */   
/*      */   private static final String ENTITY_NAME = "name";
/*      */   
/*      */   private static TagType resolveNbtType(byte typeId) {
/*  127 */     if (typeId < 0 || typeId >= NBT_TYPES.length)
/*  128 */       throw new IllegalStateException("Invalid nbt type id read: " + typeId); 
/*  130 */     TagType nbtType = NBT_TYPES[typeId];
/*  131 */     if (nbtType == null)
/*  132 */       throw new IllegalStateException("Invalid nbt type id read: " + typeId); 
/*  134 */     return nbtType;
/*      */   }
/*      */   
/*      */   private static void requireType(TagType type, TagType wantedType) {
/*  138 */     if (type != wantedType)
/*  139 */       throw new IllegalStateException("Expected nbt type " + wantedType + ", read " + type); 
/*      */   }
/*      */   
/*      */   private static void requireComponentType(TagType type) {
/*  144 */     if (type != TagType.STRING && type != TagType.COMPOUND)
/*  145 */       throw new IllegalStateException("Expected nbt component type, read " + type); 
/*      */   }
/*      */   
/*      */   private static void requireState(boolean state) {
/*  150 */     if (!state)
/*  151 */       throw new IllegalStateException(); 
/*      */   }
/*      */   
/*      */   public static Style readStyle(Object byteBuf) throws IOException {
/*  156 */     return readStyle((DataInput)new ByteBufInputStream(byteBuf));
/*      */   }
/*      */   
/*      */   public static Style readStyle(DataInput input) throws IOException {
/*  160 */     TagType type = resolveNbtType(input.readByte());
/*  161 */     return readStyle(input, type);
/*      */   }
/*      */   
/*      */   private static Style readStyle(DataInput input, TagType rootType) throws IOException {
/*  165 */     return readStyle(input, rootType, 0);
/*      */   }
/*      */   
/*      */   private static Style readStyle(DataInput input, TagType rootType, int depth) throws IOException {
/*  169 */     if (depth > 12)
/*  170 */       throw new RuntimeException("Depth limit reached while decoding style: " + depth + " > " + '\f'); 
/*  172 */     if (rootType != TagType.COMPOUND)
/*  173 */       throw new RuntimeException("Unsupported nbt tag type for style: " + rootType); 
/*  176 */     Style.Builder style = null;
/*      */     TagType type;
/*  180 */     while ((type = resolveNbtType(input.readByte())) != TagType.END) {
/*  181 */       String key = input.readUTF();
/*  183 */       if (style == null)
/*  184 */         style = Style.style(); 
/*  186 */       readStyle(style, key, type, input, depth);
/*      */     } 
/*  189 */     return (style == null) ? Style.empty() : style.build();
/*      */   }
/*      */   
/*      */   private static void readStyle(Style.Builder style, String key, TagType type, DataInput input, int depth) throws IOException {
/*      */     ClickEvent.Action clickEventAction;
/*      */     String clickEventValue;
/*      */     TagType clickType;
/*      */     HoverEvent.Action<?> hoverEventAction;
/*      */     Object hoverEventContents;
/*      */     TagType hoverType;
/*      */     HoverEvent.Action<? super Object> unsafeAction;
/*  195 */     switch (key) {
/*      */       case "font":
/*  197 */         requireType(type, TagType.STRING);
/*  198 */         style.font(Key.key(input.readUTF()));
/*      */         return;
/*      */       case "color":
/*  201 */         requireType(type, TagType.STRING);
/*  202 */         style.color(parseColor(input.readUTF()));
/*      */         return;
/*      */       case "bold":
/*  205 */         requireType(type, TagType.BYTE);
/*  206 */         style.decoration(TextDecoration.BOLD, TextDecoration.State.byBoolean(input.readBoolean()));
/*      */         return;
/*      */       case "italic":
/*  209 */         requireType(type, TagType.BYTE);
/*  210 */         style.decoration(TextDecoration.ITALIC, TextDecoration.State.byBoolean(input.readBoolean()));
/*      */         return;
/*      */       case "underlined":
/*  213 */         requireType(type, TagType.BYTE);
/*  214 */         style.decoration(TextDecoration.UNDERLINED, TextDecoration.State.byBoolean(input.readBoolean()));
/*      */         return;
/*      */       case "strikethrough":
/*  217 */         requireType(type, TagType.BYTE);
/*  218 */         style.decoration(TextDecoration.STRIKETHROUGH, TextDecoration.State.byBoolean(input.readBoolean()));
/*      */         return;
/*      */       case "obfuscated":
/*  221 */         requireType(type, TagType.BYTE);
/*  222 */         style.decoration(TextDecoration.OBFUSCATED, TextDecoration.State.byBoolean(input.readBoolean()));
/*      */         return;
/*      */       case "insertion":
/*  225 */         requireType(type, TagType.STRING);
/*  226 */         style.insertion(input.readUTF());
/*      */         return;
/*      */       case "clickEvent":
/*  229 */         requireType(type, TagType.COMPOUND);
/*  231 */         clickEventAction = null;
/*  232 */         clickEventValue = null;
/*  235 */         while ((clickType = resolveNbtType(input.readByte())) != TagType.END) {
/*  236 */           String actionId, clickKey = input.readUTF();
/*  237 */           switch (clickKey) {
/*      */             case "action":
/*  239 */               requireType(clickType, TagType.STRING);
/*  240 */               requireState((clickEventAction == null));
/*  242 */               actionId = input.readUTF();
/*  243 */               switch (actionId) {
/*      */                 case "open_url":
/*  245 */                   clickEventAction = ClickEvent.Action.OPEN_URL;
/*      */                   continue;
/*      */                 case "run_command":
/*  248 */                   clickEventAction = ClickEvent.Action.RUN_COMMAND;
/*      */                   continue;
/*      */                 case "suggest_command":
/*  251 */                   clickEventAction = ClickEvent.Action.SUGGEST_COMMAND;
/*      */                   continue;
/*      */                 case "change_page":
/*  254 */                   clickEventAction = ClickEvent.Action.CHANGE_PAGE;
/*      */                   continue;
/*      */                 case "copy_to_clipboard":
/*  257 */                   clickEventAction = ClickEvent.Action.COPY_TO_CLIPBOARD;
/*      */                   continue;
/*      */               } 
/*  260 */               throw new IllegalStateException("Illegal click event action read: '" + actionId + "'");
/*      */             case "value":
/*  264 */               requireType(clickType, TagType.STRING);
/*  265 */               requireState((clickEventValue == null));
/*  266 */               clickEventValue = input.readUTF();
/*      */               continue;
/*      */           } 
/*  269 */           throw new IllegalStateException("Illegal click event nbt key read: '" + clickKey + "'");
/*      */         } 
/*  272 */         requireState((clickEventAction != null && clickEventValue != null));
/*  273 */         style.clickEvent(ClickEvent.clickEvent(clickEventAction, clickEventValue));
/*      */         return;
/*      */       case "hoverEvent":
/*  276 */         requireType(type, TagType.COMPOUND);
/*  278 */         hoverEventAction = null;
/*  279 */         hoverEventContents = null;
/*  282 */         while ((hoverType = resolveNbtType(input.readByte())) != TagType.END) {
/*      */           String actionId, itemId, entityType;
/*      */           int count;
/*      */           UUID entityId;
/*      */           String tag;
/*      */           Component entityName;
/*      */           TagType itemType;
/*  283 */           String hoverKey = input.readUTF();
/*  284 */           switch (hoverKey) {
/*      */             case "action":
/*  286 */               requireType(hoverType, TagType.STRING);
/*  287 */               requireState((hoverEventAction == null));
/*  289 */               actionId = input.readUTF();
/*  290 */               switch (actionId) {
/*      */                 case "show_text":
/*  292 */                   hoverEventAction = HoverEvent.Action.SHOW_TEXT;
/*      */                   continue;
/*      */                 case "show_item":
/*  295 */                   hoverEventAction = HoverEvent.Action.SHOW_ITEM;
/*      */                   continue;
/*      */                 case "show_entity":
/*  298 */                   hoverEventAction = HoverEvent.Action.SHOW_ENTITY;
/*      */                   continue;
/*      */               } 
/*  301 */               throw new IllegalStateException("Illegal hover event action read: '" + actionId + "'");
/*      */             case "contents":
/*  305 */               requireState((hoverEventContents == null));
/*  306 */               requireState((hoverEventAction != null));
/*  308 */               switch (hoverEventAction.toString()) {
/*      */                 case "show_text":
/*  310 */                   requireComponentType(hoverType);
/*  311 */                   hoverEventContents = readComponent(input, hoverType, depth + 1);
/*      */                   continue;
/*      */                 case "show_item":
/*  314 */                   if (hoverType == TagType.STRING) {
/*  315 */                     String str = input.readUTF();
/*  316 */                     hoverEventContents = HoverEvent.ShowItem.showItem(Key.key(str), 1);
/*      */                     continue;
/*      */                   } 
/*  318 */                   requireType(hoverType, TagType.COMPOUND);
/*  320 */                   itemId = null;
/*  321 */                   count = 1;
/*  322 */                   tag = null;
/*  325 */                   while ((itemType = resolveNbtType(input.readByte())) != TagType.END) {
/*  326 */                     String itemKey = input.readUTF();
/*  327 */                     switch (itemKey) {
/*      */                       case "id":
/*  329 */                         requireType(itemType, TagType.STRING);
/*  330 */                         requireState((itemId == null));
/*  331 */                         itemId = input.readUTF();
/*      */                       case "count":
/*  334 */                         requireType(itemType, TagType.INT);
/*  335 */                         count = input.readInt();
/*      */                       case "tag":
/*  338 */                         requireType(itemType, TagType.STRING);
/*  339 */                         tag = input.readUTF();
/*      */                     } 
/*      */                   } 
/*  344 */                   requireState((itemId != null));
/*  345 */                   hoverEventContents = HoverEvent.ShowItem.showItem(Key.key(itemId), count, 
/*  346 */                       (tag == null) ? null : BinaryTagHolder.binaryTagHolder(tag));
/*      */                   continue;
/*      */                 case "show_entity":
/*  350 */                   requireType(hoverType, TagType.COMPOUND);
/*  352 */                   entityType = null;
/*  353 */                   entityId = null;
/*  354 */                   entityName = null;
/*  357 */                   while ((itemType = resolveNbtType(input.readByte())) != TagType.END) {
/*  358 */                     String itemKey = input.readUTF();
/*  359 */                     switch (itemKey) {
/*      */                       case "type":
/*  361 */                         requireType(itemType, TagType.STRING);
/*  362 */                         requireState((entityType == null));
/*  363 */                         entityType = input.readUTF();
/*      */                       case "id":
/*  366 */                         requireType(itemType, TagType.INT_ARRAY);
/*  367 */                         requireState((entityId == null));
/*  368 */                         entityId = readUniqueId(input);
/*      */                       case "name":
/*  371 */                         requireComponentType(itemType);
/*  372 */                         requireState((entityName == null));
/*  373 */                         entityName = readComponent(input, itemType, depth + 1);
/*      */                     } 
/*      */                   } 
/*  378 */                   requireState((entityType != null && entityId != null));
/*  379 */                   hoverEventContents = HoverEvent.ShowEntity.showEntity(Key.key(entityType), entityId, entityName);
/*      */                   continue;
/*      */               } 
/*      */               continue;
/*      */           } 
/*  384 */           throw new IllegalStateException("Illegal hover event nbt key read: '" + hoverKey + "'");
/*      */         } 
/*  387 */         requireState((hoverEventContents != null));
/*  390 */         unsafeAction = (HoverEvent.Action)hoverEventAction;
/*  391 */         style.hoverEvent((HoverEventSource)HoverEvent.hoverEvent(unsafeAction, hoverEventContents));
/*      */         return;
/*      */     } 
/*  394 */     throw new IllegalStateException("Illegal component nbt key read: '" + key + "'");
/*      */   }
/*      */   
/*      */   public static void writeStyle(Object byteBuf, Style style) throws IOException {
/*  399 */     writeStyle((DataOutput)new ByteBufOutputStream(byteBuf), style);
/*      */   }
/*      */   
/*      */   public static void writeStyle(DataOutput output, Style style) throws IOException {
/*  403 */     TagType tagType = TagType.COMPOUND;
/*  404 */     output.writeByte(tagType.getId());
/*  405 */     writeStyle(output, style, tagType);
/*  406 */     output.writeByte(TagType.END.getId());
/*      */   }
/*      */   
/*      */   private static void writeStyle(DataOutput output, Style style, TagType rootType) throws IOException {
/*  410 */     if (rootType != TagType.COMPOUND)
/*  411 */       throw new UnsupportedEncodingException(); 
/*  413 */     if (style.isEmpty())
/*      */       return; 
/*  418 */     Key font = style.font();
/*  419 */     if (font != null) {
/*  420 */       output.writeByte(TagType.STRING.getId());
/*  421 */       output.writeUTF("font");
/*  422 */       output.writeUTF(font.asString());
/*      */     } 
/*  426 */     TextColor color = style.color();
/*  427 */     if (color != null) {
/*  428 */       output.writeByte(TagType.STRING.getId());
/*  429 */       output.writeUTF("color");
/*  430 */       output.writeUTF(stringifyColor(color));
/*      */     } 
/*  434 */     TextDecoration.State bold = style.decoration(TextDecoration.BOLD);
/*  435 */     if (bold != TextDecoration.State.NOT_SET) {
/*  436 */       output.writeByte(TagType.BYTE.getId());
/*  437 */       output.writeUTF("bold");
/*  438 */       output.writeBoolean((bold == TextDecoration.State.TRUE));
/*      */     } 
/*  441 */     TextDecoration.State italic = style.decoration(TextDecoration.ITALIC);
/*  442 */     if (italic != TextDecoration.State.NOT_SET) {
/*  443 */       output.writeByte(TagType.BYTE.getId());
/*  444 */       output.writeUTF("italic");
/*  445 */       output.writeBoolean((italic == TextDecoration.State.TRUE));
/*      */     } 
/*  448 */     TextDecoration.State underlined = style.decoration(TextDecoration.UNDERLINED);
/*  449 */     if (underlined != TextDecoration.State.NOT_SET) {
/*  450 */       output.writeByte(TagType.BYTE.getId());
/*  451 */       output.writeUTF("underlined");
/*  452 */       output.writeBoolean((underlined == TextDecoration.State.TRUE));
/*      */     } 
/*  455 */     TextDecoration.State strikethrough = style.decoration(TextDecoration.STRIKETHROUGH);
/*  456 */     if (strikethrough != TextDecoration.State.NOT_SET) {
/*  457 */       output.writeByte(TagType.BYTE.getId());
/*  458 */       output.writeUTF("strikethrough");
/*  459 */       output.writeBoolean((strikethrough == TextDecoration.State.TRUE));
/*      */     } 
/*  462 */     TextDecoration.State obfuscated = style.decoration(TextDecoration.OBFUSCATED);
/*  463 */     if (obfuscated != TextDecoration.State.NOT_SET) {
/*  464 */       output.writeByte(TagType.BYTE.getId());
/*  465 */       output.writeUTF("obfuscated");
/*  466 */       output.writeBoolean((obfuscated == TextDecoration.State.TRUE));
/*      */     } 
/*  470 */     String insertion = style.insertion();
/*  471 */     if (insertion != null) {
/*  472 */       output.writeByte(TagType.STRING.getId());
/*  473 */       output.writeUTF("insertion");
/*  474 */       output.writeUTF(insertion);
/*      */     } 
/*  478 */     ClickEvent clickEvent = style.clickEvent();
/*  479 */     if (clickEvent != null) {
/*  481 */       output.writeByte(TagType.COMPOUND.getId());
/*  482 */       output.writeUTF("clickEvent");
/*  485 */       ClickEvent.Action action = clickEvent.action();
/*  486 */       output.writeByte(TagType.STRING.getId());
/*  487 */       output.writeUTF("action");
/*  488 */       output.writeUTF(action.toString());
/*  491 */       String value = clickEvent.value();
/*  492 */       output.writeByte(TagType.STRING.getId());
/*  493 */       output.writeUTF("value");
/*  494 */       output.writeUTF(value);
/*  496 */       output.writeByte(TagType.END.getId());
/*      */     } 
/*  500 */     HoverEvent<?> hoverEvent = style.hoverEvent();
/*  501 */     if (hoverEvent != null) {
/*      */       Component text;
/*      */       TagType textTagType;
/*      */       HoverEvent.ShowItem item;
/*      */       Key itemId;
/*      */       int count;
/*      */       BinaryTagHolder nbt;
/*      */       HoverEvent.ShowEntity entity;
/*      */       Key entityType;
/*      */       UUID entityId;
/*      */       Component entityName;
/*  503 */       output.writeByte(TagType.COMPOUND.getId());
/*  504 */       output.writeUTF("hoverEvent");
/*  507 */       HoverEvent.Action<?> action = hoverEvent.action();
/*  508 */       output.writeByte(TagType.STRING.getId());
/*  509 */       output.writeUTF("action");
/*  510 */       output.writeUTF(action.toString());
/*  513 */       switch (action.toString()) {
/*      */         case "show_text":
/*  515 */           text = (Component)hoverEvent.value();
/*  516 */           textTagType = getComponentTagType(text);
/*  517 */           output.writeByte(textTagType.getId());
/*  518 */           output.writeUTF("contents");
/*  519 */           writeComponent(output, text, textTagType);
/*      */           break;
/*      */         case "show_item":
/*  522 */           item = (HoverEvent.ShowItem)hoverEvent.value();
/*  523 */           itemId = item.item();
/*  524 */           count = item.count();
/*  525 */           nbt = item.nbt();
/*  527 */           if (count == 1 && nbt == null) {
/*  528 */             output.writeByte(TagType.STRING.getId());
/*  529 */             output.writeUTF("contents");
/*  530 */             output.writeUTF(itemId.asString());
/*      */             break;
/*      */           } 
/*  533 */           output.writeByte(TagType.COMPOUND.getId());
/*  534 */           output.writeUTF("contents");
/*  537 */           output.writeByte(TagType.STRING.getId());
/*  538 */           output.writeUTF("id");
/*  539 */           output.writeUTF(itemId.asString());
/*  542 */           if (count != 1) {
/*  543 */             output.writeByte(TagType.INT.getId());
/*  544 */             output.writeUTF("count");
/*  545 */             output.writeInt(count);
/*      */           } 
/*  549 */           if (nbt != null) {
/*  550 */             output.writeByte(TagType.STRING.getId());
/*  551 */             output.writeUTF("tag");
/*  552 */             output.writeUTF(nbt.string());
/*      */           } 
/*  555 */           output.writeByte(TagType.END.getId());
/*      */           break;
/*      */         case "show_entity":
/*  559 */           entity = (HoverEvent.ShowEntity)hoverEvent.value();
/*  560 */           entityType = entity.type();
/*  561 */           entityId = entity.id();
/*  562 */           entityName = entity.name();
/*  565 */           output.writeByte(TagType.COMPOUND.getId());
/*  566 */           output.writeUTF("contents");
/*  569 */           output.writeByte(TagType.STRING.getId());
/*  570 */           output.writeUTF("type");
/*  571 */           output.writeUTF(entityType.asString());
/*  574 */           output.writeByte(TagType.INT_ARRAY.getId());
/*  575 */           output.writeUTF("id");
/*  576 */           writeUniqueId(output, entityId);
/*  579 */           if (entityName != null) {
/*  580 */             TagType nameTagType = getComponentTagType(entityName);
/*  581 */             output.writeByte(nameTagType.getId());
/*  582 */             output.writeUTF("name");
/*  583 */             writeComponent(output, entityName, nameTagType);
/*      */           } 
/*  586 */           output.writeByte(TagType.END.getId());
/*      */           break;
/*      */       } 
/*  590 */       output.writeByte(TagType.END.getId());
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Component readComponent(Object byteBuf) throws IOException {
/*  595 */     return readComponent((DataInput)new ByteBufInputStream(byteBuf));
/*      */   }
/*      */   
/*      */   public static Component readComponent(DataInput input) throws IOException {
/*  599 */     TagType type = resolveNbtType(input.readByte());
/*  600 */     return readComponent(input, type);
/*      */   }
/*      */   
/*      */   private static Component readComponent(DataInput input, TagType rootType) throws IOException {
/*  604 */     return readComponent(input, rootType, 0);
/*      */   }
/*      */   
/*      */   private static Component readComponent(DataInput input, TagType rootType, int depth) throws IOException {
/*      */     StorageNBTComponent.Builder builder;
/*  609 */     if (depth > 12)
/*  610 */       throw new RuntimeException("Depth limit reached while decoding component: " + depth + " > " + '\f'); 
/*  613 */     if (rootType == TagType.STRING)
/*  614 */       return (Component)Component.text(input.readUTF()); 
/*  616 */     if (rootType != TagType.COMPOUND)
/*  617 */       throw new RuntimeException("Unsupported nbt tag type for component: " + rootType); 
/*  621 */     List<Component> extra = null;
/*  622 */     String text = null;
/*  623 */     String translate = null;
/*  624 */     String translateFallback = null;
/*  625 */     List<Component> translateWith = null;
/*  626 */     String scoreName = null;
/*  627 */     String scoreObjective = null;
/*  628 */     String selector = null;
/*  629 */     String keybind = null;
/*  630 */     String nbt = null;
/*  631 */     boolean nbtInterpret = false;
/*  632 */     String nbtBlock = null;
/*  633 */     String nbtEntity = null;
/*  634 */     String nbtStorage = null;
/*  635 */     Component separator = null;
/*  637 */     Style.Builder style = null;
/*      */     TagType type;
/*  641 */     while ((type = resolveNbtType(input.readByte())) != TagType.END) {
/*      */       TagType scoreType;
/*  642 */       String key = input.readUTF();
/*  643 */       switch (key) {
/*      */         case "":
/*      */         case "text":
/*  648 */           requireType(type, TagType.STRING);
/*  649 */           requireState((text == null));
/*  650 */           text = input.readUTF();
/*      */           continue;
/*      */         case "translate":
/*  653 */           requireType(type, TagType.STRING);
/*  654 */           requireState((translate == null));
/*  655 */           translate = input.readUTF();
/*      */           continue;
/*      */         case "fallback":
/*  658 */           requireType(type, TagType.STRING);
/*  659 */           requireState((translateFallback == null));
/*  660 */           translateFallback = input.readUTF();
/*      */           continue;
/*      */         case "with":
/*  663 */           requireType(type, TagType.LIST);
/*  664 */           requireState((translateWith == null));
/*  665 */           translateWith = readComponentList(input, depth + 1);
/*      */           continue;
/*      */         case "score":
/*  668 */           requireType(type, TagType.COMPOUND);
/*  669 */           requireState((scoreName == null && scoreObjective == null));
/*  672 */           while ((scoreType = resolveNbtType(input.readByte())) != TagType.END) {
/*  673 */             String scoreKey = input.readUTF();
/*  674 */             switch (scoreKey) {
/*      */               case "name":
/*  676 */                 requireType(scoreType, TagType.STRING);
/*  677 */                 requireState((scoreName == null));
/*  678 */                 scoreName = input.readUTF();
/*      */                 continue;
/*      */               case "objective":
/*  681 */                 requireType(scoreType, TagType.STRING);
/*  682 */                 requireState((scoreObjective == null));
/*  683 */                 scoreObjective = input.readUTF();
/*      */                 continue;
/*      */             } 
/*  686 */             throw new IllegalStateException("Invalid nbt key read for score key: '" + scoreKey + "'");
/*      */           } 
/*  689 */           requireState((scoreName != null && scoreObjective != null));
/*      */           continue;
/*      */         case "selector":
/*  692 */           requireType(type, TagType.STRING);
/*  693 */           requireState((selector == null));
/*  694 */           selector = input.readUTF();
/*      */           continue;
/*      */         case "keybind":
/*  697 */           requireType(type, TagType.STRING);
/*  698 */           requireState((keybind == null));
/*  699 */           keybind = input.readUTF();
/*      */           continue;
/*      */         case "nbt":
/*  702 */           requireType(type, TagType.STRING);
/*  703 */           requireState((nbt == null));
/*  704 */           nbt = input.readUTF();
/*      */           continue;
/*      */         case "interpret":
/*  707 */           requireType(type, TagType.BYTE);
/*  708 */           nbtInterpret = input.readBoolean();
/*      */           continue;
/*      */         case "block":
/*  711 */           requireType(type, TagType.STRING);
/*  712 */           requireState((nbtBlock == null));
/*  713 */           nbtBlock = input.readUTF();
/*      */           continue;
/*      */         case "entity":
/*  716 */           requireType(type, TagType.STRING);
/*  717 */           requireState((nbtEntity == null));
/*  718 */           nbtEntity = input.readUTF();
/*      */           continue;
/*      */         case "storage":
/*  721 */           requireType(type, TagType.STRING);
/*  722 */           requireState((nbtStorage == null));
/*  723 */           nbtStorage = input.readUTF();
/*      */           continue;
/*      */         case "extra":
/*  726 */           requireType(type, TagType.LIST);
/*  727 */           requireState((extra == null));
/*  728 */           extra = readComponentList(input, depth + 1);
/*      */           continue;
/*      */         case "separator":
/*  731 */           requireComponentType(type);
/*  732 */           requireState((separator == null));
/*  733 */           separator = readComponent(input, type, depth + 1);
/*      */           continue;
/*      */       } 
/*  736 */       if (style == null)
/*  737 */         style = Style.style(); 
/*  739 */       readStyle(style, key, type, input, depth);
/*      */     } 
/*  746 */     if (text != null) {
/*  747 */       TextComponent.Builder builder1 = Component.text().content(text);
/*  748 */     } else if (translate != null) {
/*  749 */       if (translateWith != null) {
/*  750 */         TranslatableComponent.Builder builder1 = Component.translatable().key(translate).fallback(translateFallback).args(translateWith);
/*      */       } else {
/*  752 */         TranslatableComponent.Builder builder1 = Component.translatable().key(translate).fallback(translateFallback);
/*      */       } 
/*  754 */     } else if (scoreName != null && scoreObjective != null) {
/*  755 */       ScoreComponent.Builder builder1 = Component.score().name(scoreName).objective(scoreObjective);
/*  756 */     } else if (selector != null) {
/*  757 */       SelectorComponent.Builder builder1 = Component.selector().pattern(selector).separator((ComponentLike)separator);
/*  758 */     } else if (keybind != null) {
/*  759 */       KeybindComponent.Builder builder1 = Component.keybind().keybind(keybind);
/*  760 */     } else if (nbt != null) {
/*  761 */       if (nbtBlock != null) {
/*  764 */         BlockNBTComponent.Builder builder1 = ((BlockNBTComponent.Builder)((BlockNBTComponent.Builder)((BlockNBTComponent.Builder)Component.blockNBT().nbtPath(nbt)).interpret(nbtInterpret)).separator((ComponentLike)separator)).pos(BlockNBTComponent.Pos.fromString(nbtBlock));
/*  765 */       } else if (nbtEntity != null) {
/*  768 */         EntityNBTComponent.Builder builder1 = ((EntityNBTComponent.Builder)((EntityNBTComponent.Builder)((EntityNBTComponent.Builder)Component.entityNBT().nbtPath(nbt)).interpret(nbtInterpret)).separator((ComponentLike)separator)).selector(nbtEntity);
/*  769 */       } else if (nbtStorage != null) {
/*  772 */         builder = ((StorageNBTComponent.Builder)((StorageNBTComponent.Builder)((StorageNBTComponent.Builder)Component.storageNBT().nbtPath(nbt)).interpret(nbtInterpret)).separator((ComponentLike)separator)).storage(Key.key(nbtStorage));
/*      */       } else {
/*  774 */         throw new IllegalStateException("Illegal nbt component, block/entity/storage is missing");
/*      */       } 
/*      */     } else {
/*  777 */       throw new IllegalStateException("Illegal nbt component, component type could not be determined");
/*      */     } 
/*  780 */     if (style != null)
/*  781 */       builder.style(style.build()); 
/*  784 */     if (extra != null)
/*  785 */       builder.append(extra); 
/*  787 */     return (Component)builder.build();
/*      */   }
/*      */   
/*      */   public static void writeComponent(Object byteBuf, Component component) throws IOException {
/*  791 */     writeComponent((DataOutput)new ByteBufOutputStream(byteBuf), component);
/*      */   }
/*      */   
/*      */   public static void writeComponent(DataOutput output, Component component) throws IOException {
/*  795 */     TagType tagType = getComponentTagType(component);
/*  796 */     output.writeByte(tagType.getId());
/*  797 */     writeComponent(output, component, tagType);
/*      */   }
/*      */   
/*      */   private static void writeComponent(DataOutput output, Component component, TagType rootType) throws IOException {
/*  801 */     if (rootType == TagType.STRING) {
/*  802 */       output.writeUTF(((TextComponent)component).content());
/*      */       return;
/*      */     } 
/*  805 */     if (rootType != TagType.COMPOUND)
/*  806 */       throw new UnsupportedEncodingException(); 
/*  810 */     if (component instanceof TextComponent) {
/*  812 */       output.writeByte(TagType.STRING.getId());
/*  813 */       output.writeUTF("text");
/*  814 */       output.writeUTF(((TextComponent)component).content());
/*  815 */     } else if (component instanceof TranslatableComponent) {
/*  817 */       output.writeByte(TagType.STRING.getId());
/*  818 */       output.writeUTF("translate");
/*  819 */       output.writeUTF(((TranslatableComponent)component).key());
/*  822 */       String fallback = ((TranslatableComponent)component).fallback();
/*  823 */       if (fallback != null) {
/*  824 */         output.writeByte(TagType.STRING.getId());
/*  825 */         output.writeUTF("fallback");
/*  826 */         output.writeUTF(fallback);
/*      */       } 
/*  830 */       List<Component> args = ((TranslatableComponent)component).args();
/*  831 */       if (!args.isEmpty()) {
/*  832 */         output.writeByte(TagType.LIST.getId());
/*  833 */         output.writeUTF("with");
/*  834 */         writeComponentList(output, args);
/*      */       } 
/*  836 */     } else if (component instanceof ScoreComponent) {
/*  838 */       output.writeByte(TagType.COMPOUND.getId());
/*  839 */       output.writeUTF("score");
/*  842 */       String scoreName = ((ScoreComponent)component).name();
/*  843 */       output.writeByte(TagType.STRING.getId());
/*  844 */       output.writeUTF("name");
/*  845 */       output.writeUTF(scoreName);
/*  848 */       String scoreObjective = ((ScoreComponent)component).objective();
/*  849 */       output.writeByte(TagType.STRING.getId());
/*  850 */       output.writeUTF("objective");
/*  851 */       output.writeUTF(scoreObjective);
/*  853 */       output.writeByte(TagType.END.getId());
/*  854 */     } else if (component instanceof SelectorComponent) {
/*  856 */       output.writeByte(TagType.STRING.getId());
/*  857 */       output.writeUTF("selector");
/*  858 */       output.writeUTF(((SelectorComponent)component).pattern());
/*  861 */       Component separator = ((SelectorComponent)component).separator();
/*  862 */       if (separator != null) {
/*  863 */         TagType componentTagType = getComponentTagType(separator);
/*  864 */         output.writeByte(componentTagType.getId());
/*  865 */         output.writeUTF("separator");
/*  866 */         writeComponent(output, separator, componentTagType);
/*      */       } 
/*  868 */     } else if (component instanceof KeybindComponent) {
/*  870 */       output.writeByte(TagType.STRING.getId());
/*  871 */       output.writeUTF("keybind");
/*  872 */       output.writeUTF(((KeybindComponent)component).keybind());
/*  873 */     } else if (component instanceof NBTComponent) {
/*  875 */       String nbtPath = ((NBTComponent)component).nbtPath();
/*  876 */       output.writeByte(TagType.STRING.getId());
/*  877 */       output.writeUTF("nbt");
/*  878 */       output.writeUTF(nbtPath);
/*  881 */       boolean interpret = ((NBTComponent)component).interpret();
/*  882 */       if (interpret) {
/*  883 */         output.writeByte(TagType.BYTE.getId());
/*  884 */         output.writeUTF("interpret");
/*  885 */         output.writeBoolean(true);
/*      */       } 
/*  889 */       Component separator = ((NBTComponent)component).separator();
/*  890 */       if (separator != null) {
/*  891 */         TagType componentTagType = getComponentTagType(separator);
/*  892 */         output.writeByte(componentTagType.getId());
/*  893 */         output.writeUTF("separator");
/*  894 */         writeComponent(output, separator, componentTagType);
/*      */       } 
/*  897 */       if (component instanceof BlockNBTComponent) {
/*  899 */         BlockNBTComponent.Pos pos = ((BlockNBTComponent)component).pos();
/*  900 */         output.writeByte(TagType.STRING.getId());
/*  901 */         output.writeUTF("block");
/*  902 */         output.writeUTF(pos.asString());
/*  903 */       } else if (component instanceof EntityNBTComponent) {
/*  905 */         String selector = ((EntityNBTComponent)component).selector();
/*  906 */         output.writeByte(TagType.STRING.getId());
/*  907 */         output.writeUTF("entity");
/*  908 */         output.writeUTF(selector);
/*  909 */       } else if (component instanceof StorageNBTComponent) {
/*  911 */         Key storage = ((StorageNBTComponent)component).storage();
/*  912 */         output.writeByte(TagType.STRING.getId());
/*  913 */         output.writeUTF("storage");
/*  914 */         output.writeUTF(storage.asString());
/*      */       } else {
/*  916 */         throw new UnsupportedOperationException();
/*      */       } 
/*      */     } else {
/*  919 */       throw new UnsupportedOperationException();
/*      */     } 
/*  922 */     if (component.hasStyling())
/*  923 */       writeStyle(output, component.style(), TagType.COMPOUND); 
/*  927 */     List<Component> children = component.children();
/*  928 */     if (!children.isEmpty()) {
/*  929 */       output.writeByte(TagType.LIST.getId());
/*  930 */       output.writeUTF("extra");
/*  931 */       writeComponentList(output, children);
/*      */     } 
/*  934 */     output.writeByte(TagType.END.getId());
/*      */   }
/*      */   
/*      */   private static List<Component> readComponentList(DataInput input, int depth) throws IOException {
/*  938 */     byte typeId = input.readByte();
/*  939 */     int length = input.readInt();
/*  940 */     if (typeId == TagType.END.getId() && length > 0)
/*  941 */       throw new IllegalStateException("Non-empty list with no specified type read"); 
/*  944 */     TagType type = resolveNbtType(typeId);
/*  945 */     requireComponentType(type);
/*  946 */     if (length == 0)
/*  947 */       return Collections.emptyList(); 
/*  950 */     List<Component> components = new ArrayList<>(length);
/*  951 */     for (int i = 0; i < length; i++)
/*  952 */       components.add(readComponent(input, type, depth)); 
/*  954 */     return components;
/*      */   }
/*      */   
/*      */   private static void writeComponentList(DataOutput output, List<Component> components) throws IOException {
/*  958 */     if (components.isEmpty()) {
/*  959 */       output.writeByte(TagType.END.getId());
/*  960 */       output.writeInt(0);
/*      */       return;
/*      */     } 
/*  964 */     boolean simple = true;
/*  965 */     for (Component component : components) {
/*  966 */       if (!isSimpleComponent(component)) {
/*  967 */         simple = false;
/*      */         break;
/*      */       } 
/*      */     } 
/*  972 */     TagType tagType = getComponentTagType(simple);
/*  973 */     output.writeByte(tagType.getId());
/*  974 */     output.writeInt(components.size());
/*  975 */     for (Component component : components)
/*  976 */       writeComponent(output, component, tagType); 
/*      */   }
/*      */   
/*      */   private static UUID readUniqueId(DataInput input) throws IOException {
/*  983 */     int arrayLength = input.readInt();
/*  984 */     if (arrayLength != 4)
/*  985 */       throw new IllegalStateException("Invalid encoded uuid length: " + arrayLength + " != 4"); 
/*  987 */     return new UUID(input
/*  988 */         .readInt() << 32L | input.readInt() & 0xFFFFFFFFL, input
/*  989 */         .readInt() << 32L | input.readInt() & 0xFFFFFFFFL);
/*      */   }
/*      */   
/*      */   private static void writeUniqueId(DataOutput output, UUID uniqueId) throws IOException {
/*  996 */     long mostBits = uniqueId.getMostSignificantBits();
/*  997 */     long leastBits = uniqueId.getLeastSignificantBits();
/*  999 */     output.writeInt(4);
/* 1000 */     output.writeInt((int)(mostBits >> 32L));
/* 1001 */     output.writeInt((int)mostBits);
/* 1002 */     output.writeInt((int)(leastBits >> 32L));
/* 1003 */     output.writeInt((int)leastBits);
/*      */   }
/*      */   
/*      */   private static TagType getComponentTagType(Component component) {
/* 1007 */     return getComponentTagType(isSimpleComponent(component));
/*      */   }
/*      */   
/*      */   private static TagType getComponentTagType(boolean simple) {
/* 1011 */     return simple ? TagType.STRING : TagType.COMPOUND;
/*      */   }
/*      */   
/*      */   private static boolean isSimpleComponent(Component component) {
/* 1015 */     return (component instanceof TextComponent && 
/* 1016 */       !component.hasStyling() && component
/* 1017 */       .children().isEmpty());
/*      */   }
/*      */   
/*      */   private static TextColor parseColor(String colorStr) {
/*      */     TextColor color;
/* 1021 */     if (colorStr.isEmpty())
/* 1022 */       throw new IllegalStateException("Tried parsing empty color string"); 
/* 1026 */     if (colorStr.charAt(0) == '#') {
/* 1027 */       color = TextColor.fromHexString(colorStr);
/*      */     } else {
/* 1029 */       color = (TextColor)NamedTextColor.NAMES.value(colorStr);
/*      */     } 
/* 1032 */     if (color == null)
/* 1033 */       throw new IllegalStateException("Can't parse color from: " + colorStr); 
/* 1035 */     return color;
/*      */   }
/*      */   
/*      */   private static String stringifyColor(TextColor color) {
/* 1039 */     if (color instanceof NamedTextColor)
/* 1040 */       return color.toString(); 
/* 1042 */     return color.asHexString();
/*      */   }
/*      */   
/*      */   private enum TagType {
/* 1046 */     END, BYTE, SHORT, INT, LONG, FLOAT, DOUBLE, BYTE_ARRAY, STRING, LIST, COMPOUND, INT_ARRAY, LONG_ARRAY;
/*      */     
/*      */     public int getId() {
/* 1061 */       return ordinal();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\adventure\AdventureNBTSerialization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */