/*     */ package com.github.retrooper.packetevents.util;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.event.PacketEvent;
/*     */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.event.UserDisconnectEvent;
/*     */ import com.github.retrooper.packetevents.manager.protocol.ProtocolManager;
/*     */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class PacketEventsImplHelper {
/*     */   public static PacketSendEvent handleClientBoundPacket(Object channel, User user, Object player, Object buffer, boolean autoProtocolTranslation) throws Exception {
/*  39 */     if (!ByteBufHelper.isReadable(buffer))
/*  39 */       return null; 
/*  41 */     int preProcessIndex = ByteBufHelper.readerIndex(buffer);
/*  42 */     PacketSendEvent packetSendEvent = EventCreationUtil.createSendEvent(channel, user, player, buffer, autoProtocolTranslation);
/*  43 */     int processIndex = ByteBufHelper.readerIndex(buffer);
/*  44 */     PacketEvents.getAPI().getEventManager().callEvent((PacketEvent)packetSendEvent, () -> ByteBufHelper.readerIndex(buffer, processIndex));
/*  47 */     if (!packetSendEvent.isCancelled()) {
/*  49 */       if (packetSendEvent.getLastUsedWrapper() != null) {
/*  51 */         ByteBufHelper.clear(buffer);
/*  52 */         packetSendEvent.getLastUsedWrapper().writeVarInt(packetSendEvent.getPacketId());
/*  53 */         packetSendEvent.getLastUsedWrapper().write();
/*     */       } else {
/*  57 */         ByteBufHelper.readerIndex(buffer, preProcessIndex);
/*     */       } 
/*     */     } else {
/*  61 */       ByteBufHelper.clear(buffer);
/*     */     } 
/*  64 */     if (packetSendEvent.hasPostTasks())
/*  65 */       for (Runnable task : packetSendEvent.getPostTasks())
/*  66 */         task.run();  
/*  70 */     return packetSendEvent;
/*     */   }
/*     */   
/*     */   public static PacketReceiveEvent handleServerBoundPacket(Object channel, User user, Object player, Object buffer, boolean autoProtocolTranslation) throws Exception {
/*  77 */     if (!ByteBufHelper.isReadable(buffer))
/*  77 */       return null; 
/*  79 */     int preProcessIndex = ByteBufHelper.readerIndex(buffer);
/*  80 */     PacketReceiveEvent packetReceiveEvent = EventCreationUtil.createReceiveEvent(channel, user, player, buffer, autoProtocolTranslation);
/*  81 */     int processIndex = ByteBufHelper.readerIndex(buffer);
/*  82 */     PacketEvents.getAPI().getEventManager().callEvent((PacketEvent)packetReceiveEvent, () -> ByteBufHelper.readerIndex(buffer, processIndex));
/*  85 */     if (!packetReceiveEvent.isCancelled()) {
/*  87 */       if (packetReceiveEvent.getLastUsedWrapper() != null) {
/*  89 */         ByteBufHelper.clear(buffer);
/*  90 */         packetReceiveEvent.getLastUsedWrapper().writeVarInt(packetReceiveEvent.getPacketId());
/*  91 */         packetReceiveEvent.getLastUsedWrapper().write();
/*     */       } else {
/*  95 */         ByteBufHelper.readerIndex(buffer, preProcessIndex);
/*     */       } 
/*     */     } else {
/*  99 */       ByteBufHelper.clear(buffer);
/*     */     } 
/* 101 */     if (packetReceiveEvent.hasPostTasks())
/* 102 */       for (Runnable task : packetReceiveEvent.getPostTasks())
/* 103 */         task.run();  
/* 106 */     return packetReceiveEvent;
/*     */   }
/*     */   
/*     */   public static void handleDisconnection(Object channel, @Nullable UUID uuid) {
/* 110 */     synchronized (channel) {
/* 111 */       User user = PacketEvents.getAPI().getProtocolManager().getUser(channel);
/* 113 */       if (user != null) {
/* 114 */         UserDisconnectEvent disconnectEvent = new UserDisconnectEvent(user);
/* 115 */         PacketEvents.getAPI().getEventManager().callEvent((PacketEvent)disconnectEvent);
/* 116 */         PacketEvents.getAPI().getProtocolManager().removeUser(user.getChannel());
/*     */       } 
/* 119 */       if (uuid == null) {
/* 121 */         ProtocolManager.CHANNELS.entrySet().removeIf(pair -> (pair.getValue() == channel));
/*     */       } else {
/* 124 */         ProtocolManager.CHANNELS.remove(uuid);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\PacketEventsImplHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */