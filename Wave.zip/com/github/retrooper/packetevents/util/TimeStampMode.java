/*    */ package com.github.retrooper.packetevents.util;
/*    */ 
/*    */ public enum TimeStampMode {
/* 22 */   MILLIS, NANO, NONE;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\TimeStampMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */