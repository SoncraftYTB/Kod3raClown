/*     */ package com.github.retrooper.packetevents.util;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.world.BlockFace;
/*     */ import java.util.Objects;
/*     */ 
/*     */ public class Vector3i {
/*     */   public final int x;
/*     */   
/*     */   public final int y;
/*     */   
/*     */   public final int z;
/*     */   
/*     */   public Vector3i() {
/*  54 */     this.x = 0;
/*  55 */     this.y = 0;
/*  56 */     this.z = 0;
/*     */   }
/*     */   
/*     */   public Vector3i(long val) {
/*  60 */     this(val, PacketEvents.getAPI().getServerManager().getVersion());
/*     */   }
/*     */   
/*     */   public Vector3i(long val, ServerVersion serverVersion) {
/*  64 */     int y, z, x = (int)(val >> 38L);
/*  70 */     if (serverVersion.isNewerThanOrEquals(ServerVersion.V_1_14)) {
/*  71 */       y = (int)(val << 52L >> 52L);
/*  72 */       z = (int)(val << 26L >> 38L);
/*     */     } else {
/*  75 */       y = (int)(val >> 26L & 0xFFFL);
/*  76 */       z = (int)(val << 38L >> 38L);
/*     */     } 
/*  79 */     this.x = x;
/*  80 */     this.y = y;
/*  81 */     this.z = z;
/*     */   }
/*     */   
/*     */   public Vector3i(int x, int y, int z) {
/*  92 */     this.x = x;
/*  93 */     this.y = y;
/*  94 */     this.z = z;
/*     */   }
/*     */   
/*     */   public Vector3i(int[] array) {
/* 106 */     if (array.length > 0) {
/* 107 */       this.x = array[0];
/*     */     } else {
/* 109 */       this.x = 0;
/* 110 */       this.y = 0;
/* 111 */       this.z = 0;
/*     */       return;
/*     */     } 
/* 114 */     if (array.length > 1) {
/* 115 */       this.y = array[1];
/*     */     } else {
/* 117 */       this.y = 0;
/* 118 */       this.z = 0;
/*     */       return;
/*     */     } 
/* 121 */     if (array.length > 2) {
/* 122 */       this.z = array[2];
/*     */     } else {
/* 124 */       this.z = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long getSerializedPosition(ServerVersion serverVersion) {
/* 130 */     if (serverVersion.isNewerThanOrEquals(ServerVersion.V_1_17)) {
/* 131 */       long x = (getX() & 0x3FFFFFF);
/* 132 */       long y = (getY() & 0xFFF);
/* 133 */       long z = (getZ() & 0x3FFFFFF);
/* 135 */       return x << 38L | z << 12L | y;
/*     */     } 
/* 138 */     if (serverVersion.isNewerThanOrEquals(ServerVersion.V_1_14))
/* 139 */       return (getX() & 0x3FFFFFF) << 38L | (getZ() & 0x3FFFFFF) << 12L | (getY() & 0xFFF); 
/* 142 */     return (getX() & 0x3FFFFFF) << 38L | (getY() & 0xFFF) << 26L | (getZ() & 0x3FFFFFF);
/*     */   }
/*     */   
/*     */   public long getSerializedPosition() {
/* 146 */     return getSerializedPosition(PacketEvents.getAPI().getServerManager().getVersion());
/*     */   }
/*     */   
/*     */   public int getX() {
/* 150 */     return this.x;
/*     */   }
/*     */   
/*     */   public int getY() {
/* 154 */     return this.y;
/*     */   }
/*     */   
/*     */   public int getZ() {
/* 158 */     return this.z;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 170 */     if (obj instanceof Vector3i) {
/* 171 */       Vector3i vec = (Vector3i)obj;
/* 172 */       return (this.x == vec.x && this.y == vec.y && this.z == vec.z);
/*     */     } 
/* 173 */     if (obj instanceof Vector3d) {
/* 174 */       Vector3d vec = (Vector3d)obj;
/* 175 */       return (this.x == vec.x && this.y == vec.y && this.z == vec.z);
/*     */     } 
/* 176 */     if (obj instanceof Vector3f) {
/* 177 */       Vector3f vec = (Vector3f)obj;
/* 178 */       return (this.x == vec.x && this.y == vec.y && this.z == vec.z);
/*     */     } 
/* 180 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 185 */     return Objects.hash(new Object[] { Integer.valueOf(this.x), Integer.valueOf(this.y), Integer.valueOf(this.z) });
/*     */   }
/*     */   
/*     */   public Vector3d toVector3d() {
/* 189 */     return new Vector3d(this.x, this.y, this.z);
/*     */   }
/*     */   
/*     */   public Vector3i add(int x, int y, int z) {
/* 193 */     return new Vector3i(this.x + x, this.y + y, this.z + z);
/*     */   }
/*     */   
/*     */   public Vector3i add(Vector3i other) {
/* 197 */     return add(other.x, other.y, other.z);
/*     */   }
/*     */   
/*     */   public Vector3i offset(BlockFace face) {
/* 201 */     return add(face.getModX(), face.getModY(), face.getModZ());
/*     */   }
/*     */   
/*     */   public Vector3i subtract(int x, int y, int z) {
/* 205 */     return new Vector3i(this.x - x, this.y - y, this.z - z);
/*     */   }
/*     */   
/*     */   public Vector3i subtract(Vector3i other) {
/* 209 */     return subtract(other.x, other.y, other.z);
/*     */   }
/*     */   
/*     */   public Vector3i multiply(int x, int y, int z) {
/* 213 */     return new Vector3i(this.x * x, this.y * y, this.z * z);
/*     */   }
/*     */   
/*     */   public Vector3i multiply(Vector3i other) {
/* 217 */     return multiply(other.x, other.y, other.z);
/*     */   }
/*     */   
/*     */   public Vector3i multiply(int value) {
/* 221 */     return multiply(value, value, value);
/*     */   }
/*     */   
/*     */   public Vector3i crossProduct(Vector3i other) {
/* 225 */     int newX = this.y * other.z - other.y * this.z;
/* 226 */     int newY = this.z * other.x - other.z * this.x;
/* 227 */     int newZ = this.x * other.y - other.x * this.y;
/* 228 */     return new Vector3i(newX, newY, newZ);
/*     */   }
/*     */   
/*     */   public int dot(Vector3i other) {
/* 232 */     return this.x * other.x + this.y * other.y + this.z * other.z;
/*     */   }
/*     */   
/*     */   public Vector3i with(Integer x, Integer y, Integer z) {
/* 236 */     return new Vector3i((x == null) ? this.x : x.intValue(), (y == null) ? this.y : y.intValue(), (z == null) ? this.z : z.intValue());
/*     */   }
/*     */   
/*     */   public Vector3i withX(int x) {
/* 240 */     return new Vector3i(x, this.y, this.z);
/*     */   }
/*     */   
/*     */   public Vector3i withY(int y) {
/* 244 */     return new Vector3i(this.x, y, this.z);
/*     */   }
/*     */   
/*     */   public Vector3i withZ(int z) {
/* 248 */     return new Vector3i(this.x, this.y, z);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 253 */     return "X: " + this.x + ", Y: " + this.y + ", Z: " + this.z;
/*     */   }
/*     */   
/*     */   public static Vector3i zero() {
/* 257 */     return new Vector3i();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\Vector3i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */