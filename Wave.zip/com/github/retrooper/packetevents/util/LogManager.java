/*    */ package com.github.retrooper.packetevents.util;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import java.util.logging.Level;
/*    */ import java.util.regex.Pattern;
/*    */ import net.kyori.adventure.text.format.NamedTextColor;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class LogManager {
/* 11 */   private static final Pattern STRIP_COLOR_PATTERN = Pattern.compile("(?i)§[0-9A-FK-ORX]");
/*    */   
/*    */   protected void log(Level level, @Nullable NamedTextColor color, String message) {
/* 14 */     message = STRIP_COLOR_PATTERN.matcher(message).replaceAll("");
/* 15 */     PacketEvents.getAPI().getLogger().log(level, (color != null) ? color.toString() : ("" + message));
/*    */   }
/*    */   
/*    */   public void info(String message) {
/* 19 */     log(Level.INFO, null, message);
/*    */   }
/*    */   
/*    */   public void warn(String message) {
/* 23 */     log(Level.WARNING, null, message);
/*    */   }
/*    */   
/*    */   public void severe(String message) {
/* 27 */     log(Level.SEVERE, null, message);
/*    */   }
/*    */   
/*    */   public void debug(String message) {
/* 31 */     if (PacketEvents.getAPI().getSettings().isDebugEnabled())
/* 32 */       log(Level.FINE, null, message); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\LogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */