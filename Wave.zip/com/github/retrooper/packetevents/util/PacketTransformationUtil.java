/*    */ package com.github.retrooper.packetevents.util;
/*    */ 
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.protocol.player.Equipment;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDestroyEntities;
/*    */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityEquipment;
/*    */ import java.util.Collections;
/*    */ 
/*    */ public class PacketTransformationUtil {
/*    */   public static PacketWrapper<?>[] transform(PacketWrapper<?> wrapper) {
/* 32 */     if (wrapper instanceof WrapperPlayServerDestroyEntities) {
/* 33 */       WrapperPlayServerDestroyEntities destroyEntities = (WrapperPlayServerDestroyEntities)wrapper;
/* 34 */       int len = (destroyEntities.getEntityIds()).length;
/* 35 */       if (wrapper.getServerVersion() == ServerVersion.V_1_17 && len > 1) {
/* 37 */         PacketWrapper[] arrayOfPacketWrapper = new PacketWrapper[len];
/* 38 */         for (int i = 0; i < len; i++) {
/* 39 */           int entityId = destroyEntities.getEntityIds()[i];
/* 40 */           arrayOfPacketWrapper[i] = (PacketWrapper)new WrapperPlayServerDestroyEntities(entityId);
/*    */         } 
/* 42 */         return (PacketWrapper<?>[])arrayOfPacketWrapper;
/*    */       } 
/* 44 */     } else if (wrapper instanceof WrapperPlayServerEntityEquipment) {
/* 45 */       WrapperPlayServerEntityEquipment entityEquipment = (WrapperPlayServerEntityEquipment)wrapper;
/* 46 */       int len = entityEquipment.getEquipment().size();
/* 47 */       if (entityEquipment.getServerVersion().isOlderThan(ServerVersion.V_1_16) && len > 1) {
/* 49 */         PacketWrapper[] arrayOfPacketWrapper = new PacketWrapper[len];
/* 50 */         for (int i = 0; i < len; i++) {
/* 51 */           Equipment equipment = entityEquipment.getEquipment().get(i);
/* 52 */           arrayOfPacketWrapper[i] = (PacketWrapper)new WrapperPlayServerEntityEquipment(entityEquipment.getEntityId(), Collections.singletonList(equipment));
/*    */         } 
/* 54 */         return (PacketWrapper<?>[])arrayOfPacketWrapper;
/*    */       } 
/*    */     } 
/* 57 */     return (PacketWrapper<?>[])new PacketWrapper[] { wrapper };
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\PacketTransformationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */