/*    */ package com.github.retrooper.packetevents.util;
/*    */ 
/*    */ public class Quaternion4f {
/*    */   private float x;
/*    */   
/*    */   private float y;
/*    */   
/*    */   private float z;
/*    */   
/*    */   private float w;
/*    */   
/*    */   public Quaternion4f(float x, float y, float z, float w) {
/* 30 */     this.x = x;
/* 31 */     this.y = y;
/* 32 */     this.z = z;
/* 33 */     this.w = w;
/*    */   }
/*    */   
/*    */   public float getX() {
/* 37 */     return this.x;
/*    */   }
/*    */   
/*    */   public void setX(float x) {
/* 41 */     this.x = x;
/*    */   }
/*    */   
/*    */   public float getY() {
/* 45 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(float y) {
/* 49 */     this.y = y;
/*    */   }
/*    */   
/*    */   public float getZ() {
/* 53 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setZ(float z) {
/* 57 */     this.z = z;
/*    */   }
/*    */   
/*    */   public float getW() {
/* 61 */     return this.w;
/*    */   }
/*    */   
/*    */   public void setW(float w) {
/* 65 */     this.w = w;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\Quaternion4f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */