/*     */ package com.github.retrooper.packetevents.util.updatechecker;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.util.ColorUtil;
/*     */ import com.github.retrooper.packetevents.util.PEVersion;
/*     */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*     */ import com.google.gson.JsonObject;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import net.kyori.adventure.text.format.NamedTextColor;
/*     */ 
/*     */ public class UpdateChecker {
/*     */   public String checkLatestReleasedVersion() {
/*     */     try {
/*  43 */       URLConnection connection = (new URL("https://api.github.com/repos/retrooper/packetevents/releases/latest")).openConnection();
/*  44 */       connection.addRequestProperty("User-Agent", "Mozilla/4.0");
/*  45 */       BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*  46 */       String jsonResponse = reader.readLine();
/*  47 */       reader.close();
/*  48 */       JsonObject jsonObject = (JsonObject)AdventureSerializer.getGsonSerializer().serializer().fromJson(jsonResponse, JsonObject.class);
/*  49 */       return jsonObject.get("name").getAsString();
/*  50 */     } catch (IOException e) {
/*  51 */       throw new IllegalStateException("Failed to parse packetevents version!", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public UpdateCheckerStatus checkForUpdate() {
/*  59 */     PEVersion newVersion, localVersion = PacketEvents.getAPI().getVersion();
/*     */     try {
/*  62 */       newVersion = new PEVersion(checkLatestReleasedVersion());
/*  63 */     } catch (Exception ex) {
/*  64 */       ex.printStackTrace();
/*  65 */       newVersion = null;
/*     */     } 
/*  67 */     if (newVersion != null && localVersion.isOlderThan(newVersion)) {
/*  68 */       PacketEvents.getAPI().getLogManager().warn("There is an update available for packetevents! Your build: (" + 
/*  69 */           ColorUtil.toString(NamedTextColor.YELLOW) + localVersion + 
/*  70 */           ColorUtil.toString(NamedTextColor.WHITE) + ") | Latest released build: (" + 
/*  71 */           ColorUtil.toString(NamedTextColor.GREEN) + newVersion + 
/*  72 */           ColorUtil.toString(NamedTextColor.WHITE) + ")");
/*  73 */       return UpdateCheckerStatus.OUTDATED;
/*     */     } 
/*  74 */     if (newVersion != null && localVersion.isNewerThan(newVersion)) {
/*  75 */       PacketEvents.getAPI().getLogManager().info("You are on a dev or pre released build of packetevents. Your build: (" + 
/*  76 */           ColorUtil.toString(NamedTextColor.AQUA) + localVersion + 
/*  77 */           ColorUtil.toString(NamedTextColor.WHITE) + ") | Latest released build: (" + 
/*  78 */           ColorUtil.toString(NamedTextColor.DARK_AQUA) + newVersion + 
/*  79 */           ColorUtil.toString(NamedTextColor.WHITE) + ")");
/*  80 */       return UpdateCheckerStatus.PRE_RELEASE;
/*     */     } 
/*  81 */     if (localVersion.equals(newVersion)) {
/*  82 */       PacketEvents.getAPI().getLogManager().info("You are on the latest released version of packetevents. (" + 
/*  83 */           ColorUtil.toString(NamedTextColor.GREEN) + newVersion + ColorUtil.toString(NamedTextColor.WHITE) + ")");
/*  84 */       return UpdateCheckerStatus.UP_TO_DATE;
/*     */     } 
/*  86 */     PacketEvents.getAPI().getLogManager().warn("Something went wrong while checking for an update. Your build: (" + localVersion + ")");
/*  87 */     return UpdateCheckerStatus.FAILED;
/*     */   }
/*     */   
/*     */   public void handleUpdateCheck() {
/*  92 */     Thread thread = new Thread(() -> {
/*     */           PacketEvents.getAPI().getLogManager().info("Checking for an update, please wait...");
/*     */           UpdateCheckerStatus status = checkForUpdate();
/*     */           int waitTimeInSeconds = 5;
/*     */           int maxRetryCount = 5;
/*     */           int retries = 0;
/*     */           while (retries < maxRetryCount && status == UpdateCheckerStatus.FAILED) {
/*     */             PacketEvents.getAPI().getLogManager().warn("[Checking for an update again in " + waitTimeInSeconds + " seconds...");
/*     */             try {
/*     */               Thread.sleep(waitTimeInSeconds * 1000L);
/* 105 */             } catch (InterruptedException e) {
/*     */               e.printStackTrace();
/*     */             } 
/*     */             waitTimeInSeconds *= 2;
/*     */             status = checkForUpdate();
/*     */             if (retries == maxRetryCount - 1) {
/*     */               PacketEvents.getAPI().getLogManager().warn("packetevents failed to check for an update. No longer retrying.");
/*     */               break;
/*     */             } 
/*     */             retries++;
/*     */           } 
/*     */         }"packetevents-update-check-thread");
/* 122 */     thread.start();
/*     */   }
/*     */   
/*     */   public enum UpdateCheckerStatus {
/* 135 */     OUTDATED, PRE_RELEASE, UP_TO_DATE, FAILED;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\uti\\updatechecker\UpdateChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */