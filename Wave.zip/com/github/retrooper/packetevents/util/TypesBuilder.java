/*     */ package com.github.retrooper.packetevents.util;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ 
/*     */ public class TypesBuilder {
/*     */   private final String mapPath;
/*     */   
/*     */   private JsonObject fileMappings;
/*     */   
/*     */   private final VersionMapper versionMapper;
/*     */   
/*     */   public TypesBuilder(String mapPath, ClientVersion... versions) {
/*  34 */     this.mapPath = mapPath;
/*  35 */     this.versionMapper = new VersionMapper(versions);
/*     */   }
/*     */   
/*     */   public JsonObject getFileMappings() {
/*  39 */     return this.fileMappings;
/*     */   }
/*     */   
/*     */   public ClientVersion[] getVersions() {
/*  43 */     return this.versionMapper.getVersions();
/*     */   }
/*     */   
/*     */   public ClientVersion[] getReversedVersions() {
/*  47 */     return this.versionMapper.getReversedVersions();
/*     */   }
/*     */   
/*     */   public int getDataIndex(ClientVersion rawVersion) {
/*  51 */     return this.versionMapper.getIndex(rawVersion);
/*     */   }
/*     */   
/*     */   public void unloadFileMappings() {
/*  55 */     this.fileMappings = null;
/*     */   }
/*     */   
/*     */   public TypesBuilderData defineFromArray(String key) {
/*  59 */     if (this.fileMappings == null)
/*  60 */       this.fileMappings = MappingHelper.getJSONObject(this.mapPath); 
/*  62 */     ResourceLocation name = new ResourceLocation(key);
/*  63 */     int[] ids = new int[(getVersions()).length];
/*  64 */     int index = 0;
/*  65 */     for (ClientVersion v : getVersions()) {
/*  66 */       JsonArray array = this.fileMappings.getAsJsonArray(v.name());
/*  67 */       int tempId = 0;
/*  68 */       for (JsonElement element : array) {
/*  69 */         if (element.isJsonPrimitive()) {
/*  70 */           String elementString = element.getAsString();
/*  71 */           if (elementString.equals(key)) {
/*  72 */             ids[index] = tempId;
/*     */             break;
/*     */           } 
/*  75 */           tempId++;
/*     */         } 
/*     */       } 
/*  78 */       index++;
/*     */     } 
/*  80 */     return new TypesBuilderData(name, ids);
/*     */   }
/*     */   
/*     */   public TypesBuilderData define(String key) {
/*  84 */     if (this.fileMappings == null)
/*  85 */       this.fileMappings = MappingHelper.getJSONObject(this.mapPath); 
/*  87 */     ResourceLocation name = new ResourceLocation(key);
/*  88 */     int[] ids = new int[(getVersions()).length];
/*  89 */     int index = 0;
/*  90 */     for (ClientVersion v : getVersions()) {
/*  91 */       if (this.fileMappings.has(v.name())) {
/*  92 */         JsonObject jsonMap = this.fileMappings.getAsJsonObject(v.name());
/*  93 */         if (jsonMap.has(key)) {
/*  94 */           int id = jsonMap.get(key).getAsInt();
/*  95 */           ids[index] = id;
/*     */         } else {
/*  98 */           ids[index] = -1;
/*     */         } 
/*     */       } 
/* 101 */       index++;
/*     */     } 
/* 103 */     return new TypesBuilderData(name, ids);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\TypesBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */