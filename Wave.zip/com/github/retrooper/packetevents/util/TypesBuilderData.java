/*    */ package com.github.retrooper.packetevents.util;
/*    */ 
/*    */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*    */ 
/*    */ public class TypesBuilderData {
/*    */   private final int[] data;
/*    */   
/*    */   private final ResourceLocation name;
/*    */   
/*    */   public TypesBuilderData(ResourceLocation name, int[] data) {
/* 28 */     this.name = name;
/* 29 */     this.data = data;
/*    */   }
/*    */   
/*    */   public int[] getData() {
/* 33 */     return this.data;
/*    */   }
/*    */   
/*    */   public ResourceLocation getName() {
/* 37 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\TypesBuilderData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */