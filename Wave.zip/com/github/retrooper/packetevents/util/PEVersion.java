/*     */ package com.github.retrooper.packetevents.util;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class PEVersion {
/*     */   private final int[] versionIntArray;
/*     */   
/*     */   public PEVersion(int... version) {
/*  43 */     this.versionIntArray = version;
/*     */   }
/*     */   
/*     */   public PEVersion(String version) {
/*  52 */     String[] versionIntegers = version.split("\\.");
/*  53 */     int length = versionIntegers.length;
/*  54 */     this.versionIntArray = new int[length];
/*  55 */     for (int i = 0; i < length; i++)
/*  56 */       this.versionIntArray[i] = Integer.parseInt(versionIntegers[i]); 
/*     */   }
/*     */   
/*     */   public int compareTo(PEVersion version) {
/*  74 */     int localLength = this.versionIntArray.length;
/*  75 */     int oppositeLength = version.versionIntArray.length;
/*  76 */     int length = Math.max(localLength, oppositeLength);
/*  77 */     for (int i = 0; i < length; i++) {
/*  78 */       int localInteger = (i < localLength) ? this.versionIntArray[i] : 0;
/*  79 */       int oppositeInteger = (i < oppositeLength) ? version.versionIntArray[i] : 0;
/*  80 */       if (localInteger > oppositeInteger)
/*  81 */         return 1; 
/*  82 */       if (localInteger < oppositeInteger)
/*  83 */         return -1; 
/*     */     } 
/*  86 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean isNewerThan(PEVersion version) {
/*  96 */     return (compareTo(version) == 1);
/*     */   }
/*     */   
/*     */   public boolean isOlderThan(PEVersion version) {
/* 106 */     return (compareTo(version) == -1);
/*     */   }
/*     */   
/*     */   public int[] asArray() {
/* 115 */     return this.versionIntArray;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 127 */     if (obj == null)
/* 128 */       return false; 
/* 130 */     if (obj instanceof PEVersion)
/* 131 */       return Arrays.equals(this.versionIntArray, ((PEVersion)obj).versionIntArray); 
/* 133 */     return false;
/*     */   }
/*     */   
/*     */   public PEVersion clone() {
/* 143 */     return new PEVersion(this.versionIntArray);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 153 */     StringBuilder sb = (new StringBuilder(this.versionIntArray.length * 2 - 1)).append(this.versionIntArray[0]);
/* 154 */     for (int i = 1; i < this.versionIntArray.length; i++)
/* 155 */       sb.append(".").append(this.versionIntArray[i]); 
/* 157 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevent\\util\PEVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */