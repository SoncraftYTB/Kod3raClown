/*    */ package com.github.retrooper.packetevents.exception;
/*    */ 
/*    */ public class PacketProcessException extends RuntimeException {
/*    */   public PacketProcessException(String msg, Throwable cause) {
/* 23 */     super(msg, cause);
/*    */   }
/*    */   
/*    */   public PacketProcessException(Throwable cause) {
/* 27 */     super(cause);
/*    */   }
/*    */   
/*    */   public PacketProcessException(String msg) {
/* 31 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\exception\PacketProcessException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */