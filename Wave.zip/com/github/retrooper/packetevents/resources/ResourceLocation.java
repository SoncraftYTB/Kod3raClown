/*    */ package com.github.retrooper.packetevents.resources;
/*    */ 
/*    */ public class ResourceLocation {
/*    */   protected final String namespace;
/*    */   
/*    */   protected final String key;
/*    */   
/*    */   public ResourceLocation(String namespace, String key) {
/* 26 */     this.namespace = namespace;
/* 27 */     this.key = key;
/*    */   }
/*    */   
/*    */   public ResourceLocation(String location) {
/* 31 */     String[] array = { "minecraft", location };
/* 32 */     int index = location.indexOf(":");
/* 33 */     if (index != -1) {
/* 34 */       array[1] = location.substring(index + 1);
/* 35 */       if (index >= 1)
/* 36 */         array[0] = location.substring(0, index); 
/*    */     } 
/* 39 */     this.namespace = array[0];
/* 40 */     this.key = array[1];
/*    */   }
/*    */   
/*    */   public String getNamespace() {
/* 44 */     return this.namespace;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 48 */     return this.key;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 53 */     if (obj instanceof ResourceLocation) {
/* 54 */       ResourceLocation other = (ResourceLocation)obj;
/* 55 */       return (other.namespace.equals(this.namespace) && other.key.equals(this.key));
/*    */     } 
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 62 */     return this.namespace + ":" + this.key;
/*    */   }
/*    */   
/*    */   public static ResourceLocation minecraft(String key) {
/* 66 */     return new ResourceLocation("minecraft", key);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\resources\ResourceLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */