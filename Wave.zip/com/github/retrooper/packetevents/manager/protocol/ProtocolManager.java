/*     */ package com.github.retrooper.packetevents.manager.protocol;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.netty.channel.ChannelHelper;
/*     */ import com.github.retrooper.packetevents.protocol.ProtocolVersion;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import com.github.retrooper.packetevents.util.PacketTransformationUtil;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ 
/*     */ public interface ProtocolManager {
/*  36 */   public static final Map<UUID, Object> CHANNELS = new ConcurrentHashMap<>();
/*     */   
/*  38 */   public static final Map<Object, User> USERS = new ConcurrentHashMap<>();
/*     */   
/*     */   default Collection<User> getUsers() {
/*  41 */     return USERS.values();
/*     */   }
/*     */   
/*     */   default Collection<Object> getChannels() {
/*  45 */     return CHANNELS.values();
/*     */   }
/*     */   
/*     */   ProtocolVersion getPlatformVersion();
/*     */   
/*     */   void sendPacket(Object paramObject1, Object paramObject2);
/*     */   
/*     */   void sendPacketSilently(Object paramObject1, Object paramObject2);
/*     */   
/*     */   void writePacket(Object paramObject1, Object paramObject2);
/*     */   
/*     */   void writePacketSilently(Object paramObject1, Object paramObject2);
/*     */   
/*     */   void receivePacket(Object paramObject1, Object paramObject2);
/*     */   
/*     */   void receivePacketSilently(Object paramObject1, Object paramObject2);
/*     */   
/*     */   ClientVersion getClientVersion(Object paramObject);
/*     */   
/*     */   void sendPackets(Object channel, Object... byteBuf) {
/*  60 */     for (Object buf : byteBuf)
/*  61 */       sendPacket(channel, buf); 
/*     */   }
/*     */   
/*     */   void sendPacketsSilently(Object channel, Object... byteBuf) {
/*  66 */     for (Object buf : byteBuf)
/*  67 */       sendPacketSilently(channel, buf); 
/*     */   }
/*     */   
/*     */   void writePackets(Object channel, Object... byteBuf) {
/*  72 */     for (Object buf : byteBuf)
/*  73 */       writePacket(channel, buf); 
/*     */   }
/*     */   
/*     */   void writePacketsSilently(Object channel, Object... byteBuf) {
/*  78 */     for (Object buf : byteBuf)
/*  79 */       writePacketSilently(channel, buf); 
/*     */   }
/*     */   
/*     */   void receivePackets(Object channel, Object... byteBuf) {
/*  84 */     for (Object buf : byteBuf)
/*  85 */       receivePacket(channel, buf); 
/*     */   }
/*     */   
/*     */   void receivePacketsSilently(Object channel, Object... byteBuf) {
/*  90 */     for (Object buf : byteBuf)
/*  91 */       receivePacketSilently(channel, buf); 
/*     */   }
/*     */   
/*     */   default void setClientVersion(Object channel, ClientVersion version) {
/*  97 */     getUser(channel).setClientVersion(version);
/*     */   }
/*     */   
/*     */   @Internal
/*     */   default Object[] transformWrappers(PacketWrapper<?> wrapper, Object channel, boolean outgoing) {
/* 104 */     PacketWrapper[] arrayOfPacketWrapper = PacketTransformationUtil.transform(wrapper);
/* 105 */     Object[] buffers = new Object[arrayOfPacketWrapper.length];
/* 106 */     for (int i = 0; i < arrayOfPacketWrapper.length; i++) {
/* 107 */       arrayOfPacketWrapper[i].prepareForSend(channel, outgoing);
/* 108 */       buffers[i] = (arrayOfPacketWrapper[i]).buffer;
/* 110 */       (arrayOfPacketWrapper[i]).buffer = null;
/*     */     } 
/* 112 */     return buffers;
/*     */   }
/*     */   
/*     */   default void sendPacket(Object channel, PacketWrapper<?> wrapper) {
/* 116 */     Object[] transformed = transformWrappers(wrapper, channel, true);
/* 117 */     sendPackets(channel, transformed);
/*     */   }
/*     */   
/*     */   default void sendPacketSilently(Object channel, PacketWrapper<?> wrapper) {
/* 121 */     Object[] transformed = transformWrappers(wrapper, channel, true);
/* 122 */     sendPacketsSilently(channel, transformed);
/*     */   }
/*     */   
/*     */   default void writePacket(Object channel, PacketWrapper<?> wrapper) {
/* 126 */     Object[] transformed = transformWrappers(wrapper, channel, true);
/* 127 */     writePackets(channel, transformed);
/*     */   }
/*     */   
/*     */   default void writePacketSilently(Object channel, PacketWrapper<?> wrapper) {
/* 131 */     Object[] transformed = transformWrappers(wrapper, channel, true);
/* 132 */     writePacketsSilently(channel, transformed);
/*     */   }
/*     */   
/*     */   default void receivePacket(Object channel, PacketWrapper<?> wrapper) {
/* 136 */     Object[] transformed = transformWrappers(wrapper, channel, false);
/* 137 */     receivePackets(channel, transformed);
/*     */   }
/*     */   
/*     */   default void receivePacketSilently(Object channel, PacketWrapper<?> wrapper) {
/* 141 */     Object[] transformed = transformWrappers(wrapper, channel, false);
/* 142 */     receivePacketsSilently(channel, transformed);
/*     */   }
/*     */   
/*     */   default User getUser(Object channel) {
/* 146 */     Object pipeline = ChannelHelper.getPipeline(channel);
/* 147 */     return USERS.get(pipeline);
/*     */   }
/*     */   
/*     */   default User removeUser(Object channel) {
/* 151 */     Object pipeline = ChannelHelper.getPipeline(channel);
/* 152 */     return USERS.remove(pipeline);
/*     */   }
/*     */   
/*     */   default void setUser(Object channel, User user) {
/* 156 */     synchronized (channel) {
/* 157 */       Object pipeline = ChannelHelper.getPipeline(channel);
/* 158 */       USERS.put(pipeline, user);
/*     */     } 
/* 160 */     PacketEvents.getAPI().getInjector().updateUser(channel, user);
/*     */   }
/*     */   
/*     */   default Object getChannel(UUID uuid) {
/* 164 */     return CHANNELS.get(uuid);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\manager\protocol\ProtocolManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */