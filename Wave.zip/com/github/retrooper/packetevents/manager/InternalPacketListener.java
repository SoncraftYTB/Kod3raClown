/*     */ package com.github.retrooper.packetevents.manager;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.event.PacketListenerAbstract;
/*     */ import com.github.retrooper.packetevents.event.PacketListenerPriority;
/*     */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.manager.protocol.ProtocolManager;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTList;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import com.github.retrooper.packetevents.protocol.player.UserProfile;
/*     */ import com.github.retrooper.packetevents.wrapper.configuration.server.WrapperConfigServerRegistryData;
/*     */ import com.github.retrooper.packetevents.wrapper.handshaking.client.WrapperHandshakingClientHandshake;
/*     */ import com.github.retrooper.packetevents.wrapper.login.server.WrapperLoginServerLoginSuccess;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerJoinGame;
/*     */ import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerRespawn;
/*     */ import java.net.InetSocketAddress;
/*     */ 
/*     */ public class InternalPacketListener extends PacketListenerAbstract {
/*     */   public InternalPacketListener() {
/*  46 */     this(PacketListenerPriority.LOWEST);
/*     */   }
/*     */   
/*     */   public InternalPacketListener(PacketListenerPriority priority) {
/*  50 */     super(priority);
/*     */   }
/*     */   
/*     */   public void onPacketSend(PacketSendEvent event) {
/*  55 */     User user = event.getUser();
/*  56 */     if (event.getPacketType() == PacketType.Login.Server.LOGIN_SUCCESS) {
/*  57 */       Object channel = event.getChannel();
/*  59 */       WrapperLoginServerLoginSuccess loginSuccess = new WrapperLoginServerLoginSuccess(event);
/*  60 */       UserProfile profile = loginSuccess.getUserProfile();
/*  63 */       user.getProfile().setUUID(profile.getUUID());
/*  64 */       user.getProfile().setName(profile.getName());
/*  66 */       user.getProfile().setTextureProperties(profile.getTextureProperties());
/*  69 */       synchronized (channel) {
/*  70 */         ProtocolManager.CHANNELS.put(profile.getUUID(), channel);
/*     */       } 
/*  73 */       PacketEvents.getAPI().getLogManager().debug("Mapped player UUID with their channel.");
/*  77 */       boolean proxy = PacketEvents.getAPI().getInjector().isProxy();
/*  78 */       if (proxy ? event.getUser().getClientVersion().isNewerThanOrEquals(ClientVersion.V_1_20_2) : event
/*  79 */         .getServerVersion().isNewerThanOrEquals(ServerVersion.V_1_20_2)) {
/*  80 */         user.setEncoderState(ConnectionState.CONFIGURATION);
/*     */       } else {
/*  82 */         user.setConnectionState(ConnectionState.PLAY);
/*     */       } 
/*  87 */     } else if (event.getPacketType() == PacketType.Configuration.Server.REGISTRY_DATA) {
/*  88 */       WrapperConfigServerRegistryData registryData = new WrapperConfigServerRegistryData(event);
/*  91 */       NBTCompound registryDataTag = registryData.getRegistryData();
/*  92 */       if (registryDataTag != null) {
/*  95 */         NBTList<NBTCompound> list = registryDataTag.getCompoundTagOrNull("minecraft:dimension_type").getCompoundListTagOrNull("value");
/*  96 */         user.setWorldNBT(list);
/*     */       } 
/* 101 */     } else if (event.getPacketType() == PacketType.Play.Server.JOIN_GAME) {
/* 102 */       WrapperPlayServerJoinGame joinGame = new WrapperPlayServerJoinGame(event);
/* 103 */       user.setEntityId(joinGame.getEntityId());
/* 104 */       user.setDimension(joinGame.getDimension());
/* 105 */       if (event.getServerVersion().isOlderThanOrEquals(ServerVersion.V_1_16_5))
/*     */         return; 
/* 110 */       NBTCompound dimensionCodec = joinGame.getDimensionCodec();
/* 111 */       if (dimensionCodec != null) {
/* 114 */         NBTList<NBTCompound> list = dimensionCodec.getCompoundTagOrNull("minecraft:dimension_type").getCompoundListTagOrNull("value");
/* 115 */         user.setWorldNBT(list);
/*     */       } 
/* 119 */       NBTCompound dimension = user.getWorldNBT(joinGame.getDimension().getDimensionName());
/* 120 */       if (dimension != null) {
/* 121 */         NBTCompound worldNBT = dimension.getCompoundTagOrNull("element");
/* 122 */         user.setMinWorldHeight(worldNBT.getNumberTagOrNull("min_y").getAsInt());
/* 123 */         user.setTotalWorldHeight(worldNBT.getNumberTagOrNull("height").getAsInt());
/*     */       } 
/* 128 */     } else if (event.getPacketType() == PacketType.Play.Server.RESPAWN) {
/* 129 */       WrapperPlayServerRespawn respawn = new WrapperPlayServerRespawn(event);
/* 130 */       user.setDimension(respawn.getDimension());
/* 131 */       if (event.getServerVersion().isOlderThanOrEquals(ServerVersion.V_1_16_5))
/*     */         return; 
/* 135 */       NBTCompound dimension = user.getWorldNBT(respawn.getDimension().getDimensionName());
/* 136 */       if (dimension != null) {
/* 137 */         NBTCompound worldNBT = dimension.getCompoundTagOrNull("element");
/* 138 */         user.setMinWorldHeight(worldNBT.getNumberTagOrNull("min_y").getAsInt());
/* 139 */         user.setTotalWorldHeight(worldNBT.getNumberTagOrNull("height").getAsInt());
/*     */       } 
/* 141 */     } else if (event.getPacketType() == PacketType.Play.Server.CONFIGURATION_START) {
/* 142 */       user.setEncoderState(ConnectionState.CONFIGURATION);
/* 143 */     } else if (event.getPacketType() == PacketType.Configuration.Server.CONFIGURATION_END) {
/* 144 */       user.setEncoderState(ConnectionState.PLAY);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onPacketReceive(PacketReceiveEvent event) {
/* 150 */     User user = event.getUser();
/* 151 */     if (event.getPacketType() == PacketType.Handshaking.Client.HANDSHAKE) {
/* 152 */       Object channel = event.getChannel();
/* 153 */       InetSocketAddress address = event.getSocketAddress();
/* 154 */       WrapperHandshakingClientHandshake handshake = new WrapperHandshakingClientHandshake(event);
/* 155 */       ConnectionState nextState = handshake.getNextConnectionState();
/* 156 */       ClientVersion clientVersion = handshake.getClientVersion();
/* 158 */       user.setClientVersion(clientVersion);
/* 159 */       PacketEvents.getAPI().getLogManager().debug("Processed " + address.getHostString() + ":" + address.getPort() + "'s client version. Client Version: " + clientVersion.getReleaseName());
/* 161 */       user.setConnectionState(nextState);
/* 162 */     } else if (event.getPacketType() == PacketType.Login.Client.LOGIN_SUCCESS_ACK) {
/* 163 */       user.setDecoderState(ConnectionState.CONFIGURATION);
/* 164 */     } else if (event.getPacketType() == PacketType.Play.Client.CONFIGURATION_ACK) {
/* 165 */       user.setDecoderState(ConnectionState.CONFIGURATION);
/* 166 */     } else if (event.getPacketType() == PacketType.Configuration.Client.CONFIGURATION_END_ACK) {
/* 167 */       user.setDecoderState(ConnectionState.PLAY);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\manager\InternalPacketListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */