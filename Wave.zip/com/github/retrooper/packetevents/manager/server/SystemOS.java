/*    */ package com.github.retrooper.packetevents.manager.server;
/*    */ 
/*    */ public enum SystemOS {
/* 29 */   WINDOWS, MACOS, LINUX, OTHER;
/*    */   
/*    */   private static SystemOS CACHE;
/*    */   
/*    */   public static SystemOS getOSNoCache() {
/* 39 */     String os = System.getProperty("os.name").toLowerCase();
/* 40 */     for (SystemOS sysos : values()) {
/* 41 */       if (os.contains(sysos.name().toLowerCase()))
/* 42 */         return sysos; 
/*    */     } 
/* 45 */     return OTHER;
/*    */   }
/*    */   
/*    */   public static SystemOS getOS() {
/* 55 */     if (CACHE == null)
/* 56 */       CACHE = getOSNoCache(); 
/* 58 */     return CACHE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\manager\server\SystemOS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */