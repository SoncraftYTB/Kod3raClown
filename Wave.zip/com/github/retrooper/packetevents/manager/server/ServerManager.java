/*    */ package com.github.retrooper.packetevents.manager.server;
/*    */ 
/*    */ public interface ServerManager {
/*    */   ServerVersion getVersion();
/*    */   
/*    */   default SystemOS getOS() {
/* 35 */     return SystemOS.getOS();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\manager\server\ServerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */