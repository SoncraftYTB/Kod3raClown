/*    */ package com.github.retrooper.packetevents.manager.server;
/*    */ 
/*    */ public enum VersionComparison {
/* 28 */   EQUALS, NEWER_THAN, NEWER_THAN_OR_EQUALS, OLDER_THAN, OLDER_THAN_OR_EQUALS;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\manager\server\VersionComparison.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */