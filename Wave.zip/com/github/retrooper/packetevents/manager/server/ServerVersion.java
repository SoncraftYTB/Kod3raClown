/*     */ package com.github.retrooper.packetevents.manager.server;
/*     */ 
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public enum ServerVersion {
/*  35 */   V_1_7_10(5),
/*  36 */   V_1_8(47),
/*  36 */   V_1_8_3(47),
/*  36 */   V_1_8_8(47),
/*  37 */   V_1_9(107),
/*  37 */   V_1_9_2(109),
/*  37 */   V_1_9_4(110),
/*  39 */   V_1_10(210),
/*  39 */   V_1_10_1(210),
/*  39 */   V_1_10_2(210),
/*  40 */   V_1_11(315),
/*  40 */   V_1_11_2(316),
/*  41 */   V_1_12(335),
/*  41 */   V_1_12_1(338),
/*  41 */   V_1_12_2(340),
/*  42 */   V_1_13(393),
/*  42 */   V_1_13_1(401),
/*  42 */   V_1_13_2(404),
/*  43 */   V_1_14(477),
/*  43 */   V_1_14_1(480),
/*  43 */   V_1_14_2(485),
/*  43 */   V_1_14_3(490),
/*  43 */   V_1_14_4(498),
/*  44 */   V_1_15(573),
/*  44 */   V_1_15_1(575),
/*  44 */   V_1_15_2(578),
/*  45 */   V_1_16(735),
/*  45 */   V_1_16_1(736),
/*  45 */   V_1_16_2(751),
/*  45 */   V_1_16_3(753),
/*  45 */   V_1_16_4(754),
/*  45 */   V_1_16_5(754),
/*  46 */   V_1_17(755),
/*  46 */   V_1_17_1(756),
/*  47 */   V_1_18(757),
/*  47 */   V_1_18_1(757),
/*  47 */   V_1_18_2(758),
/*  49 */   V_1_19(759),
/*  49 */   V_1_19_1(760),
/*  49 */   V_1_19_2(760),
/*  49 */   V_1_19_3(761),
/*  49 */   V_1_19_4(762),
/*  51 */   V_1_20(763),
/*  51 */   V_1_20_1(763),
/*  51 */   V_1_20_2(764),
/*  51 */   V_1_20_3(765),
/*  51 */   V_1_20_4(765),
/*  53 */   ERROR(-1, true);
/*     */   
/*     */   private static final ServerVersion[] VALUES;
/*     */   
/*     */   private static final ServerVersion[] REVERSED_VALUES;
/*     */   
/*     */   private final int protocolVersion;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private ClientVersion toClientVersion;
/*     */   
/*     */   static {
/*  55 */     VALUES = values();
/*  59 */     REVERSED_VALUES = values();
/*  60 */     int i = 0;
/*  61 */     int j = REVERSED_VALUES.length - 1;
/*  63 */     while (j > i) {
/*  64 */       ServerVersion tmp = REVERSED_VALUES[j];
/*  65 */       REVERSED_VALUES[j--] = REVERSED_VALUES[i];
/*  66 */       REVERSED_VALUES[i++] = tmp;
/*     */     } 
/*     */   }
/*     */   
/*     */   ServerVersion(int protocolVersion) {
/*  75 */     this.protocolVersion = protocolVersion;
/*  76 */     this.name = name().substring(2).replace("_", ".");
/*     */   }
/*     */   
/*     */   ServerVersion(int protocolVersion, boolean isNotRelease) {
/*  80 */     this.protocolVersion = protocolVersion;
/*  81 */     if (isNotRelease) {
/*  82 */       this.name = name();
/*     */     } else {
/*  84 */       this.name = name().substring(2).replace("_", ".");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ServerVersion[] reversedValues() {
/*  89 */     return REVERSED_VALUES;
/*     */   }
/*     */   
/*     */   public static ServerVersion getLatest() {
/*  93 */     return REVERSED_VALUES[1];
/*     */   }
/*     */   
/*     */   public static ServerVersion getOldest() {
/*  97 */     return VALUES[0];
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static ServerVersion getById(int protocolVersion) {
/* 103 */     for (ServerVersion version : VALUES) {
/* 104 */       if (version.protocolVersion == protocolVersion)
/* 105 */         return version; 
/*     */     } 
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   public ClientVersion toClientVersion() {
/* 112 */     if (this.toClientVersion == null)
/* 113 */       this.toClientVersion = ClientVersion.getById(this.protocolVersion); 
/* 115 */     return this.toClientVersion;
/*     */   }
/*     */   
/*     */   public String getReleaseName() {
/* 125 */     return this.name;
/*     */   }
/*     */   
/*     */   public int getProtocolVersion() {
/* 134 */     return this.protocolVersion;
/*     */   }
/*     */   
/*     */   public boolean isNewerThan(ServerVersion target) {
/* 146 */     return (ordinal() > target.ordinal());
/*     */   }
/*     */   
/*     */   public boolean isOlderThan(ServerVersion target) {
/* 158 */     return (ordinal() < target.ordinal());
/*     */   }
/*     */   
/*     */   public boolean isNewerThanOrEquals(ServerVersion target) {
/* 170 */     return (ordinal() >= target.ordinal());
/*     */   }
/*     */   
/*     */   public boolean isOlderThanOrEquals(ServerVersion target) {
/* 182 */     return (ordinal() <= target.ordinal());
/*     */   }
/*     */   
/*     */   public boolean is(@NotNull VersionComparison comparison, @NotNull ServerVersion targetVersion) {
/* 199 */     switch (comparison) {
/*     */       case EQUALS:
/* 201 */         return (this.protocolVersion == targetVersion.protocolVersion);
/*     */       case NEWER_THAN:
/* 203 */         return isNewerThan(targetVersion);
/*     */       case NEWER_THAN_OR_EQUALS:
/* 205 */         return isNewerThanOrEquals(targetVersion);
/*     */       case OLDER_THAN:
/* 207 */         return isOlderThan(targetVersion);
/*     */       case OLDER_THAN_OR_EQUALS:
/* 209 */         return isOlderThanOrEquals(targetVersion);
/*     */     } 
/* 211 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\manager\server\ServerVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */