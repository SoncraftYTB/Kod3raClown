/*    */ package com.github.retrooper.packetevents.manager.player;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*    */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public interface PlayerManager {
/*    */   int getPing(@NotNull Object paramObject);
/*    */   
/*    */   @NotNull
/*    */   ClientVersion getClientVersion(@NotNull Object paramObject);
/*    */   
/*    */   Object getChannel(@NotNull Object paramObject);
/*    */   
/*    */   User getUser(@NotNull Object paramObject);
/*    */   
/*    */   default ConnectionState getConnectionState(@NotNull Object player) {
/* 38 */     return getUser(player).getConnectionState();
/*    */   }
/*    */   
/*    */   default void sendPacket(@NotNull Object player, @NotNull Object byteBuf) {
/* 42 */     PacketEvents.getAPI().getProtocolManager().sendPacket(getChannel(player), byteBuf);
/*    */   }
/*    */   
/*    */   default void sendPacket(@NotNull Object player, @NotNull PacketWrapper<?> wrapper) {
/* 45 */     PacketEvents.getAPI().getProtocolManager().sendPacket(getChannel(player), wrapper);
/*    */   }
/*    */   
/*    */   default void sendPacketSilently(@NotNull Object player, @NotNull Object byteBuf) {
/* 49 */     PacketEvents.getAPI().getProtocolManager().sendPacketSilently(getChannel(player), byteBuf);
/*    */   }
/*    */   
/*    */   default void sendPacketSilently(@NotNull Object player, @NotNull PacketWrapper<?> wrapper) {
/* 53 */     PacketEvents.getAPI().getProtocolManager().sendPacketSilently(getChannel(player), wrapper);
/*    */   }
/*    */   
/*    */   default void writePacket(@NotNull Object player, @NotNull Object byteBuf) {
/* 57 */     PacketEvents.getAPI().getProtocolManager().writePacket(getChannel(player), byteBuf);
/*    */   }
/*    */   
/*    */   default void writePacket(@NotNull Object player, @NotNull PacketWrapper<?> wrapper) {
/* 61 */     PacketEvents.getAPI().getProtocolManager().writePacket(getChannel(player), wrapper);
/*    */   }
/*    */   
/*    */   default void writePacketSilently(@NotNull Object player, @NotNull Object byteBuf) {
/* 65 */     PacketEvents.getAPI().getProtocolManager().writePacketSilently(getChannel(player), byteBuf);
/*    */   }
/*    */   
/*    */   default void writePacketSilently(@NotNull Object player, @NotNull PacketWrapper<?> wrapper) {
/* 69 */     PacketEvents.getAPI().getProtocolManager().writePacketSilently(getChannel(player), wrapper);
/*    */   }
/*    */   
/*    */   default void receivePacket(Object player, Object byteBuf) {
/* 73 */     PacketEvents.getAPI().getProtocolManager().receivePacket(getChannel(player), byteBuf);
/*    */   }
/*    */   
/*    */   default void receivePacket(Object player, PacketWrapper<?> wrapper) {
/* 77 */     PacketEvents.getAPI().getProtocolManager().receivePacket(getChannel(player), wrapper);
/*    */   }
/*    */   
/*    */   default void receivePacketSilently(Object player, Object byteBuf) {
/* 81 */     PacketEvents.getAPI().getProtocolManager().receivePacketSilently(getChannel(player), byteBuf);
/*    */   }
/*    */   
/*    */   default void receivePacketSilently(Object player, PacketWrapper<?> wrapper) {
/* 85 */     PacketEvents.getAPI().getProtocolManager().receivePacketSilently(getChannel(player), wrapper);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\manager\player\PlayerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */