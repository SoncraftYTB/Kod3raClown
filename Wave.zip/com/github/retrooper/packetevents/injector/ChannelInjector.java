/*    */ package com.github.retrooper.packetevents.injector;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ 
/*    */ public interface ChannelInjector {
/*    */   default boolean isServerBound() {
/* 25 */     return true;
/*    */   }
/*    */   
/*    */   void inject();
/*    */   
/*    */   void uninject();
/*    */   
/*    */   void updateUser(Object paramObject, User paramUser);
/*    */   
/*    */   void setPlayer(Object paramObject1, Object paramObject2);
/*    */   
/*    */   boolean isProxy();
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\injector\ChannelInjector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */