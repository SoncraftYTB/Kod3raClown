/*    */ package com.github.retrooper.packetevents.event.simple;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*    */ import com.github.retrooper.packetevents.event.ProtocolPacketEvent;
/*    */ import com.github.retrooper.packetevents.exception.PacketProcessException;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ 
/*    */ public class PacketPlaySendEvent extends PacketSendEvent {
/*    */   public PacketPlaySendEvent(Object channel, User user, Object player, Object rawByteBuf, boolean autoProtocolTranslation) throws PacketProcessException {
/* 33 */     super(channel, user, player, rawByteBuf, autoProtocolTranslation);
/*    */   }
/*    */   
/*    */   protected PacketPlaySendEvent(int packetId, PacketTypeCommon packetType, ServerVersion serverVersion, Object channel, User user, Object player, Object byteBuf) throws PacketProcessException {
/* 40 */     super(packetId, packetType, serverVersion, channel, user, player, byteBuf);
/*    */   }
/*    */   
/*    */   public PacketPlaySendEvent clone() {
/*    */     try {
/* 46 */       Object clonedBuffer = ByteBufHelper.retainedDuplicate(getByteBuf());
/* 47 */       return new PacketPlaySendEvent(getPacketId(), (PacketTypeCommon)getPacketType(), getServerVersion(), 
/* 48 */           getChannel(), getUser(), getPlayer(), clonedBuffer);
/* 49 */     } catch (PacketProcessException e) {
/* 50 */       e.printStackTrace();
/* 52 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public PacketType.Play.Server getPacketType() {
/* 56 */     return (PacketType.Play.Server)super.getPacketType();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\simple\PacketPlaySendEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */