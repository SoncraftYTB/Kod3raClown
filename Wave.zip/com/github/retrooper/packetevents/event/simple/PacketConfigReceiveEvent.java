/*    */ package com.github.retrooper.packetevents.event.simple;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*    */ import com.github.retrooper.packetevents.event.ProtocolPacketEvent;
/*    */ import com.github.retrooper.packetevents.exception.PacketProcessException;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ 
/*    */ public class PacketConfigReceiveEvent extends PacketReceiveEvent {
/*    */   public PacketConfigReceiveEvent(Object channel, User user, Object player, Object rawByteBuf, boolean autoProtocolTranslation) throws PacketProcessException {
/* 34 */     super(channel, user, player, rawByteBuf, autoProtocolTranslation);
/*    */   }
/*    */   
/*    */   protected PacketConfigReceiveEvent(int packetId, PacketTypeCommon packetType, ServerVersion serverVersion, Object channel, User user, Object player, Object byteBuf) throws PacketProcessException {
/* 41 */     super(packetId, packetType, serverVersion, channel, user, player, byteBuf);
/*    */   }
/*    */   
/*    */   public PacketConfigReceiveEvent clone() {
/*    */     try {
/* 47 */       Object clonedBuffer = ByteBufHelper.retainedDuplicate(getByteBuf());
/* 48 */       return new PacketConfigReceiveEvent(getPacketId(), (PacketTypeCommon)getPacketType(), getServerVersion(), 
/* 49 */           getChannel(), getUser(), getPlayer(), clonedBuffer);
/* 50 */     } catch (PacketProcessException e) {
/* 51 */       e.printStackTrace();
/* 53 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public PacketType.Configuration.Client getPacketType() {
/* 57 */     return (PacketType.Configuration.Client)super.getPacketType();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\simple\PacketConfigReceiveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */