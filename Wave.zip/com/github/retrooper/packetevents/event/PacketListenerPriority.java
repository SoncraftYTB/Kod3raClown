/*    */ package com.github.retrooper.packetevents.event;
/*    */ 
/*    */ public enum PacketListenerPriority {
/* 36 */   LOWEST, LOW, NORMAL, HIGH, HIGHEST, MONITOR;
/*    */   
/*    */   public static PacketListenerPriority getById(byte id) {
/* 66 */     return values()[id];
/*    */   }
/*    */   
/*    */   public byte getId() {
/* 70 */     return (byte)ordinal();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\PacketListenerPriority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */