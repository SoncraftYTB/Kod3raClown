package com.github.retrooper.packetevents.event;

public interface PlayerEvent<T> {
  T getPlayer();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\PlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */