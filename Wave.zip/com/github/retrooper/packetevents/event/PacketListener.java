/*    */ package com.github.retrooper.packetevents.event;
/*    */ 
/*    */ public interface PacketListener {
/*    */   default PacketListenerAbstract asAbstract(PacketListenerPriority priority) {
/* 23 */     return new PacketListenerAbstract(priority) {
/*    */         public void onUserConnect(UserConnectEvent event) {
/* 26 */           PacketListener.this.onUserConnect(event);
/*    */         }
/*    */         
/*    */         public void onUserLogin(UserLoginEvent event) {
/* 31 */           PacketListener.this.onUserLogin(event);
/*    */         }
/*    */         
/*    */         public void onUserDisconnect(UserDisconnectEvent event) {
/* 36 */           PacketListener.this.onUserDisconnect(event);
/*    */         }
/*    */         
/*    */         public void onPacketReceive(PacketReceiveEvent event) {
/* 41 */           PacketListener.this.onPacketReceive(event);
/*    */         }
/*    */         
/*    */         public void onPacketSend(PacketSendEvent event) {
/* 46 */           PacketListener.this.onPacketSend(event);
/*    */         }
/*    */         
/*    */         public void onPacketEventExternal(PacketEvent event) {
/* 51 */           PacketListener.this.onPacketEventExternal(event);
/*    */         }
/*    */       };
/*    */   }
/*    */   
/*    */   default void onUserConnect(UserConnectEvent event) {}
/*    */   
/*    */   default void onUserLogin(UserLoginEvent event) {}
/*    */   
/*    */   default void onUserDisconnect(UserDisconnectEvent event) {}
/*    */   
/*    */   default void onPacketReceive(PacketReceiveEvent event) {}
/*    */   
/*    */   default void onPacketSend(PacketSendEvent event) {}
/*    */   
/*    */   default void onPacketEventExternal(PacketEvent event) {}
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\PacketListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */