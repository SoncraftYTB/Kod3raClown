/*    */ package com.github.retrooper.packetevents.event;
/*    */ 
/*    */ public abstract class PacketListenerCommon {
/*    */   private final PacketListenerPriority priority;
/*    */   
/*    */   public PacketListenerCommon(PacketListenerPriority priority) {
/* 35 */     this.priority = priority;
/*    */   }
/*    */   
/*    */   public PacketListenerCommon() {
/* 39 */     this.priority = PacketListenerPriority.NORMAL;
/*    */   }
/*    */   
/*    */   public PacketListenerPriority getPriority() {
/* 43 */     return this.priority;
/*    */   }
/*    */   
/*    */   public void onUserConnect(UserConnectEvent event) {}
/*    */   
/*    */   public void onUserLogin(UserLoginEvent event) {}
/*    */   
/*    */   public void onUserDisconnect(UserDisconnectEvent event) {}
/*    */   
/*    */   void onPacketReceive(PacketReceiveEvent event) {}
/*    */   
/*    */   void onPacketSend(PacketSendEvent event) {}
/*    */   
/*    */   public void onPacketEventExternal(PacketEvent event) {}
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\PacketListenerCommon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */