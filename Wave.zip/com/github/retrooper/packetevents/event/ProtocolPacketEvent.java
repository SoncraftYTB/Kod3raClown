/*     */ package com.github.retrooper.packetevents.event;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.exception.InvalidDisconnectPacketSend;
/*     */ import com.github.retrooper.packetevents.exception.PacketProcessException;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*     */ import com.github.retrooper.packetevents.netty.buffer.UnpooledByteBufAllocationHelper;
/*     */ import com.github.retrooper.packetevents.netty.channel.ChannelHelper;
/*     */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*     */ import com.github.retrooper.packetevents.protocol.PacketSide;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.protocol.player.User;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public abstract class ProtocolPacketEvent<T> extends PacketEvent implements PlayerEvent<T>, CancellableEvent, UserEvent {
/*     */   private final Object channel;
/*     */   
/*     */   private final ConnectionState connectionState;
/*     */   
/*     */   private final User user;
/*     */   
/*     */   private final T player;
/*     */   
/*     */   private Object byteBuf;
/*     */   
/*     */   private final int packetID;
/*     */   
/*     */   private final PacketTypeCommon packetType;
/*     */   
/*     */   private ServerVersion serverVersion;
/*     */   
/*     */   private boolean cancel;
/*     */   
/*     */   private PacketWrapper<?> lastUsedWrapper;
/*     */   
/*  53 */   private List<Runnable> postTasks = null;
/*     */   
/*     */   private boolean cloned;
/*     */   
/*  55 */   private boolean needsReEncode = PacketEvents.getAPI().getSettings().reEncodeByDefault();
/*     */   
/*     */   public ProtocolPacketEvent(PacketSide packetSide, Object channel, User user, T player, Object byteBuf, boolean autoProtocolTranslation) throws PacketProcessException {
/*  60 */     this.channel = channel;
/*  61 */     this.user = user;
/*  62 */     this.player = player;
/*  63 */     if (autoProtocolTranslation || user.getClientVersion() == null) {
/*  64 */       this.serverVersion = PacketEvents.getAPI().getServerManager().getVersion();
/*     */     } else {
/*  67 */       this.serverVersion = user.getClientVersion().toServerVersion();
/*     */     } 
/*  70 */     this.byteBuf = byteBuf;
/*  71 */     int size = ByteBufHelper.readableBytes(byteBuf);
/*  72 */     if (size == 0)
/*  73 */       throw new PacketProcessException("Trying to process a packet, but it has no content. (Size=0)"); 
/*     */     try {
/*  76 */       this.packetID = ByteBufHelper.readVarInt(byteBuf);
/*  77 */     } catch (Exception e) {
/*  78 */       throw new PacketProcessException("Failed to read the Packet ID of a packet. (Size: " + size + ")");
/*     */     } 
/*  80 */     ClientVersion version = this.serverVersion.toClientVersion();
/*  81 */     ConnectionState state = (packetSide == PacketSide.CLIENT) ? user.getDecoderState() : user.getEncoderState();
/*  82 */     this.packetType = PacketType.getById(packetSide, state, version, this.packetID);
/*  84 */     if (this.packetType == null) {
/*  86 */       if (PacketType.getById(packetSide, ConnectionState.PLAY, version, this.packetID) == PacketType.Play.Server.DISCONNECT)
/*  87 */         throw new InvalidDisconnectPacketSend(); 
/*  89 */       throw new PacketProcessException("Failed to map the Packet ID " + this.packetID + " to a PacketType constant. Bound: " + packetSide.getOpposite() + ", Connection state: " + user.getDecoderState() + ", Server version: " + this.serverVersion.getReleaseName());
/*     */     } 
/*  91 */     this.connectionState = state;
/*     */   }
/*     */   
/*     */   public ProtocolPacketEvent(int packetID, PacketTypeCommon packetType, ServerVersion serverVersion, Object channel, User user, T player, Object byteBuf) {
/*  96 */     this.channel = channel;
/*  97 */     this.user = user;
/*  98 */     this.player = player;
/*  99 */     this.serverVersion = serverVersion;
/* 100 */     this.byteBuf = byteBuf;
/* 101 */     this.packetID = packetID;
/* 102 */     this.packetType = packetType;
/* 104 */     this
/* 105 */       .connectionState = (packetType != null && packetType.getSide() == PacketSide.SERVER) ? user.getEncoderState() : user.getDecoderState();
/* 106 */     this.cloned = true;
/*     */   }
/*     */   
/*     */   public void markForReEncode(boolean needsReEncode) {
/* 110 */     this.needsReEncode = needsReEncode;
/*     */   }
/*     */   
/*     */   public boolean needsReEncode() {
/* 114 */     return this.needsReEncode;
/*     */   }
/*     */   
/*     */   public boolean isClone() {
/* 119 */     return this.cloned;
/*     */   }
/*     */   
/*     */   public Object getChannel() {
/* 123 */     return this.channel;
/*     */   }
/*     */   
/*     */   public InetSocketAddress getSocketAddress() {
/* 127 */     return (InetSocketAddress)ChannelHelper.remoteAddress(this.channel);
/*     */   }
/*     */   
/*     */   public User getUser() {
/* 132 */     return this.user;
/*     */   }
/*     */   
/*     */   public T getPlayer() {
/* 137 */     return this.player;
/*     */   }
/*     */   
/*     */   public ConnectionState getConnectionState() {
/* 141 */     return this.connectionState;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ClientVersion getClientVersion() {
/* 147 */     return this.user.getClientVersion();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setClientVersion(@NotNull ClientVersion clientVersion) {
/* 152 */     PacketEvents.getAPI().getLogManager().debug("Setting client version with deprecated method " + clientVersion.getReleaseName());
/* 153 */     this.user.setClientVersion(clientVersion);
/*     */   }
/*     */   
/*     */   public ServerVersion getServerVersion() {
/* 157 */     return this.serverVersion;
/*     */   }
/*     */   
/*     */   public void setServerVersion(@NotNull ServerVersion serverVersion) {
/* 161 */     this.serverVersion = serverVersion;
/*     */   }
/*     */   
/*     */   public Object getByteBuf() {
/* 165 */     return this.byteBuf;
/*     */   }
/*     */   
/*     */   public void setByteBuf(Object byteBuf) {
/* 169 */     this.byteBuf = byteBuf;
/*     */   }
/*     */   
/*     */   public int getPacketId() {
/* 173 */     return this.packetID;
/*     */   }
/*     */   
/*     */   public PacketTypeCommon getPacketType() {
/* 177 */     return this.packetType;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public String getPacketName() {
/* 182 */     return ((Enum)this.packetType).name();
/*     */   }
/*     */   
/*     */   public boolean isCancelled() {
/* 187 */     return this.cancel;
/*     */   }
/*     */   
/*     */   public void setCancelled(boolean val) {
/* 192 */     this.cancel = val;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public PacketWrapper<?> getLastUsedWrapper() {
/* 197 */     return this.lastUsedWrapper;
/*     */   }
/*     */   
/*     */   public void setLastUsedWrapper(@Nullable PacketWrapper<?> lastUsedWrapper) {
/* 201 */     this.lastUsedWrapper = lastUsedWrapper;
/*     */   }
/*     */   
/*     */   public List<Runnable> getPostTasks() {
/* 205 */     if (this.postTasks == null)
/* 206 */       this.postTasks = new ArrayList<>(); 
/* 208 */     return this.postTasks;
/*     */   }
/*     */   
/*     */   public boolean hasPostTasks() {
/* 212 */     return (this.postTasks != null && !this.postTasks.isEmpty());
/*     */   }
/*     */   
/*     */   public ProtocolPacketEvent<?> clone() {
/* 217 */     return (this instanceof PacketReceiveEvent) ? ((PacketReceiveEvent)this).clone() : (
/* 218 */       (PacketSendEvent)this).clone();
/*     */   }
/*     */   
/*     */   public void cleanUp() {
/* 222 */     if (isClone())
/* 223 */       ByteBufHelper.release(this.byteBuf); 
/*     */   }
/*     */   
/*     */   public Object getFullBufferClone() {
/* 228 */     byte[] data = ByteBufHelper.copyBytes(getByteBuf());
/* 229 */     Object buffer = UnpooledByteBufAllocationHelper.buffer();
/* 230 */     ByteBufHelper.writeVarInt(buffer, getPacketId());
/* 231 */     ByteBufHelper.writeBytes(buffer, data);
/* 232 */     return buffer;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\ProtocolPacketEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */