/*    */ package com.github.retrooper.packetevents.event;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ 
/*    */ public class UserConnectEvent extends PacketEvent implements CancellableEvent, UserEvent {
/*    */   private final User user;
/*    */   
/*    */   private boolean cancelled;
/*    */   
/*    */   public UserConnectEvent(User user) {
/* 28 */     this.user = user;
/*    */   }
/*    */   
/*    */   public User getUser() {
/* 33 */     return this.user;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 38 */     return this.cancelled;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancelled) {
/* 43 */     this.cancelled = cancelled;
/*    */   }
/*    */   
/*    */   public void call(PacketListenerCommon listener) {
/* 48 */     listener.onUserConnect(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\UserConnectEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */