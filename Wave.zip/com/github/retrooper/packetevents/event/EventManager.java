/*     */ package com.github.retrooper.packetevents.event;
/*     */ 
/*     */ import com.github.retrooper.packetevents.PacketEvents;
/*     */ import com.github.retrooper.packetevents.exception.InvalidHandshakeException;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.logging.Level;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class EventManager {
/*  31 */   private final Map<Byte, Set<PacketListenerCommon>> listenersMap = new ConcurrentHashMap<>();
/*     */   
/*     */   public void callEvent(PacketEvent event) {
/*  43 */     callEvent(event, null);
/*     */   }
/*     */   
/*     */   public void callEvent(PacketEvent event, @Nullable Runnable postCallListenerAction) {
/*  47 */     for (byte priority = PacketListenerPriority.LOWEST.getId(); priority <= PacketListenerPriority.MONITOR.getId(); priority = (byte)(priority + 1)) {
/*  48 */       Set<PacketListenerCommon> listeners = this.listenersMap.get(Byte.valueOf(priority));
/*  49 */       if (listeners != null)
/*  50 */         for (PacketListenerCommon listener : listeners) {
/*     */           try {
/*  52 */             event.call(listener);
/*  53 */           } catch (Exception t) {
/*  55 */             if (t.getClass() != InvalidHandshakeException.class)
/*  56 */               PacketEvents.getAPI().getLogger().log(Level.WARNING, "PacketEvents caught an unhandled exception while calling your listener.", t); 
/*     */           } 
/*  59 */           if (postCallListenerAction != null)
/*  60 */             postCallListenerAction.run(); 
/*     */         }  
/*     */     } 
/*  66 */     if (event instanceof ProtocolPacketEvent && !((ProtocolPacketEvent)event).needsReEncode())
/*  67 */       ((ProtocolPacketEvent)event).setLastUsedWrapper(null); 
/*     */   }
/*     */   
/*     */   public PacketListenerCommon registerListener(PacketListener listener, PacketListenerPriority priority) {
/*  73 */     PacketListenerCommon packetListenerAbstract = listener.asAbstract(priority);
/*  74 */     return registerListener(packetListenerAbstract);
/*     */   }
/*     */   
/*     */   public PacketListenerCommon registerListener(PacketListenerCommon listener) {
/*  83 */     byte priority = listener.getPriority().getId();
/*  84 */     Set<PacketListenerCommon> listenerSet = this.listenersMap.get(Byte.valueOf(priority));
/*  85 */     if (listenerSet == null)
/*  86 */       listenerSet = ConcurrentHashMap.newKeySet(); 
/*  88 */     listenerSet.add(listener);
/*  89 */     this.listenersMap.put(Byte.valueOf(priority), listenerSet);
/*  90 */     return listener;
/*     */   }
/*     */   
/*     */   public PacketListenerCommon[] registerListeners(PacketListenerCommon... listeners) {
/*  99 */     for (PacketListenerCommon listener : listeners)
/* 100 */       registerListener(listener); 
/* 102 */     return listeners;
/*     */   }
/*     */   
/*     */   public void unregisterListener(PacketListenerCommon listener) {
/* 106 */     Set<PacketListenerCommon> listenerSet = this.listenersMap.get(Byte.valueOf(listener.getPriority().getId()));
/* 107 */     if (listenerSet == null)
/*     */       return; 
/* 108 */     listenerSet.remove(listener);
/*     */   }
/*     */   
/*     */   public void unregisterListeners(PacketListenerCommon... listeners) {
/* 112 */     for (PacketListenerCommon listener : listeners)
/* 113 */       unregisterListener(listener); 
/*     */   }
/*     */   
/*     */   public void unregisterAllListeners() {
/* 122 */     this.listenersMap.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\EventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */