/*    */ package com.github.retrooper.packetevents.event;
/*    */ 
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ 
/*    */ public class UserDisconnectEvent extends PacketEvent implements UserEvent {
/*    */   private final User user;
/*    */   
/*    */   public UserDisconnectEvent(User user) {
/* 27 */     this.user = user;
/*    */   }
/*    */   
/*    */   public User getUser() {
/* 32 */     return this.user;
/*    */   }
/*    */   
/*    */   public void call(PacketListenerCommon listener) {
/* 37 */     listener.onUserDisconnect(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\UserDisconnectEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */