/*    */ package com.github.retrooper.packetevents.event;
/*    */ 
/*    */ import com.github.retrooper.packetevents.exception.PacketProcessException;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*    */ import com.github.retrooper.packetevents.protocol.PacketSide;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.protocol.player.User;
/*    */ 
/*    */ public class PacketReceiveEvent extends ProtocolPacketEvent<Object> {
/*    */   protected PacketReceiveEvent(Object channel, User user, Object player, Object rawByteBuf, boolean autoProtocolTranslation) throws PacketProcessException {
/* 32 */     super(PacketSide.CLIENT, channel, user, player, rawByteBuf, autoProtocolTranslation);
/*    */   }
/*    */   
/*    */   protected PacketReceiveEvent(int packetID, PacketTypeCommon packetType, ServerVersion serverVersion, Object channel, User user, Object player, Object byteBuf) throws PacketProcessException {
/* 39 */     super(packetID, packetType, serverVersion, channel, user, player, byteBuf);
/*    */   }
/*    */   
/*    */   public void call(PacketListenerCommon listener) {
/* 45 */     listener.onPacketReceive(this);
/*    */   }
/*    */   
/*    */   public PacketReceiveEvent clone() {
/*    */     try {
/* 51 */       Object clonedBuffer = ByteBufHelper.retainedDuplicate(getByteBuf());
/* 52 */       return new PacketReceiveEvent(getPacketId(), getPacketType(), getServerVersion(), 
/* 53 */           getChannel(), getUser(), getPlayer(), clonedBuffer);
/* 54 */     } catch (PacketProcessException e) {
/* 55 */       e.printStackTrace();
/* 57 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\event\PacketReceiveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */