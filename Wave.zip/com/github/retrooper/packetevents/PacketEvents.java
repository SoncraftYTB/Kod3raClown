/*    */ package com.github.retrooper.packetevents;
/*    */ 
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ public final class PacketEvents {
/*    */   private static PacketEventsAPI<?> API;
/*    */   
/*    */   @Internal
/*    */   public static String IDENTIFIER;
/*    */   
/*    */   @Internal
/*    */   public static String ENCODER_NAME;
/*    */   
/*    */   @Internal
/*    */   public static String DECODER_NAME;
/*    */   
/*    */   @Internal
/*    */   public static String CONNECTION_HANDLER_NAME;
/*    */   
/*    */   @Internal
/*    */   public static String SERVER_CHANNEL_HANDLER_NAME;
/*    */   
/*    */   @Internal
/*    */   public static String TIMEOUT_HANDLER_NAME;
/*    */   
/*    */   public static PacketEventsAPI<?> getAPI() {
/* 32 */     return API;
/*    */   }
/*    */   
/*    */   public static void setAPI(PacketEventsAPI<?> api) {
/* 36 */     API = api;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\PacketEvents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */