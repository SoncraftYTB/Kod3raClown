package com.github.retrooper.packetevents.netty.buffer;

public interface ByteBufAllocationOperator {
  Object wrappedBuffer(byte[] paramArrayOfbyte);
  
  Object copiedBuffer(byte[] paramArrayOfbyte);
  
  Object buffer();
  
  Object directBuffer();
  
  Object compositeBuffer();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\netty\buffer\ByteBufAllocationOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */