/*    */ package com.github.retrooper.packetevents.netty.buffer;
/*    */ 
/*    */ import com.github.retrooper.packetevents.PacketEvents;
/*    */ 
/*    */ public class UnpooledByteBufAllocationHelper {
/*    */   public static Object wrappedBuffer(byte[] bytes) {
/* 25 */     return PacketEvents.getAPI().getNettyManager().getByteBufAllocationOperator().wrappedBuffer(bytes);
/*    */   }
/*    */   
/*    */   public static Object copiedBuffer(byte[] bytes) {
/* 29 */     return PacketEvents.getAPI().getNettyManager().getByteBufAllocationOperator().copiedBuffer(bytes);
/*    */   }
/*    */   
/*    */   public static Object buffer() {
/* 33 */     return PacketEvents.getAPI().getNettyManager().getByteBufAllocationOperator().buffer();
/*    */   }
/*    */   
/*    */   public static Object directBuffer() {
/* 37 */     return PacketEvents.getAPI().getNettyManager().getByteBufAllocationOperator().directBuffer();
/*    */   }
/*    */   
/*    */   public static Object compositeBuffer() {
/* 41 */     return PacketEvents.getAPI().getNettyManager().getByteBufAllocationOperator().compositeBuffer();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\netty\buffer\UnpooledByteBufAllocationHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */