/*     */ package com.github.retrooper.packetevents.netty.buffer;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class ByteBufInputStream extends InputStream implements DataInput {
/*     */   private final Object buffer;
/*     */   
/*     */   private final int startIndex;
/*     */   
/*     */   private final int endIndex;
/*     */   
/*     */   private final boolean releaseOnClose;
/*     */   
/*     */   public ByteBufInputStream(Object buffer) {
/*  32 */     this(buffer, ByteBufHelper.readableBytes(buffer));
/*     */   }
/*     */   
/*     */   public ByteBufInputStream(Object buffer, int length) {
/*  36 */     this(buffer, length, false);
/*     */   }
/*     */   
/*     */   public ByteBufInputStream(Object buffer, boolean releaseOnClose) {
/*  40 */     this(buffer, ByteBufHelper.readableBytes(buffer), releaseOnClose);
/*     */   }
/*     */   
/*  44 */   private final StringBuilder lineBuf = new StringBuilder();
/*     */   
/*     */   private boolean closed;
/*     */   
/*     */   public ByteBufInputStream(Object buffer, int length, boolean releaseOnClose) {
/*  45 */     if (buffer == null)
/*  46 */       throw new NullPointerException("buffer"); 
/*  47 */     if (length < 0) {
/*  48 */       if (releaseOnClose)
/*  49 */         ByteBufHelper.release(buffer); 
/*  52 */       throw new IllegalArgumentException("length: " + length);
/*     */     } 
/*  53 */     if (length > ByteBufHelper.readableBytes(buffer)) {
/*  54 */       if (releaseOnClose)
/*  55 */         ByteBufHelper.release(buffer); 
/*  58 */       throw new IndexOutOfBoundsException("Too many bytes to be read - Needs " + length + ", maximum is " + ByteBufHelper.readableBytes(buffer));
/*     */     } 
/*  60 */     this.releaseOnClose = releaseOnClose;
/*  61 */     this.buffer = buffer;
/*  62 */     this.startIndex = ByteBufHelper.readerIndex(buffer);
/*  63 */     this.endIndex = this.startIndex + length;
/*  64 */     ByteBufHelper.markReaderIndex(buffer);
/*     */   }
/*     */   
/*     */   public int readBytes() {
/*  69 */     return ByteBufHelper.readerIndex(this.buffer) - this.startIndex;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/*  74 */       super.close();
/*     */     } finally {
/*  76 */       if (this.releaseOnClose && !this.closed) {
/*  77 */         this.closed = true;
/*  78 */         ByteBufHelper.release(this.buffer);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int available() throws IOException {
/*  86 */     return this.endIndex - ByteBufHelper.readerIndex(this.buffer);
/*     */   }
/*     */   
/*     */   public void mark(int readlimit) {
/*  90 */     ByteBufHelper.markReaderIndex(this.buffer);
/*     */   }
/*     */   
/*     */   public boolean markSupported() {
/*  94 */     return true;
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/*  98 */     return !ByteBufHelper.isReadable(this.buffer) ? -1 : (ByteBufHelper.readByte(this.buffer) & 0xFF);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 103 */     int available = available();
/* 104 */     if (available == 0)
/* 105 */       return -1; 
/* 107 */     len = Math.min(available, len);
/* 108 */     ByteBufHelper.readBytes(this.buffer, b, off, len);
/* 109 */     return len;
/*     */   }
/*     */   
/*     */   public void reset() throws IOException {
/* 114 */     ByteBufHelper.resetReaderIndex(this.buffer);
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 118 */     return (n > 2147483647L) ? skipBytes(2147483647) : skipBytes((int)n);
/*     */   }
/*     */   
/*     */   public boolean readBoolean() throws IOException {
/* 122 */     checkAvailable(1);
/* 123 */     return (read() != 0);
/*     */   }
/*     */   
/*     */   public byte[] readBytes(int len) {
/* 127 */     byte[] bytes = new byte[len];
/* 128 */     ByteBufHelper.readBytes(this.buffer, bytes);
/* 129 */     return bytes;
/*     */   }
/*     */   
/*     */   public byte readByte() throws IOException {
/* 133 */     if (!ByteBufHelper.isReadable(this.buffer))
/* 134 */       throw new EOFException(); 
/* 136 */     return ByteBufHelper.readByte(this.buffer);
/*     */   }
/*     */   
/*     */   public char readChar() throws IOException {
/* 141 */     return (char)readShort();
/*     */   }
/*     */   
/*     */   public double readDouble() throws IOException {
/* 145 */     return Double.longBitsToDouble(readLong());
/*     */   }
/*     */   
/*     */   public float readFloat() throws IOException {
/* 149 */     return Float.intBitsToFloat(readInt());
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 153 */     readFully(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 157 */     checkAvailable(len);
/* 158 */     ByteBufHelper.readBytes(this.buffer, b, off, len);
/*     */   }
/*     */   
/*     */   public int readInt() throws IOException {
/* 162 */     checkAvailable(4);
/* 163 */     return ByteBufHelper.readInt(this.buffer);
/*     */   }
/*     */   
/*     */   public String readLine() throws IOException {
/* 167 */     this.lineBuf.setLength(0);
/* 169 */     while (ByteBufHelper.isReadable(this.buffer)) {
/* 170 */       int c = ByteBufHelper.readUnsignedByte(this.buffer);
/* 171 */       switch (c) {
/*     */         case 13:
/* 173 */           if (ByteBufHelper.isReadable(this.buffer) && 
/* 174 */             (char)ByteBufHelper.getUnsignedByte(this.buffer, ByteBufHelper.readerIndex(this.buffer)) == '\n')
/* 175 */             ByteBufHelper.skipBytes(this.buffer, 1); 
/*     */         case 10:
/* 178 */           return this.lineBuf.toString();
/*     */       } 
/* 180 */       this.lineBuf.append((char)c);
/*     */     } 
/* 184 */     return (this.lineBuf.length() > 0) ? this.lineBuf.toString() : null;
/*     */   }
/*     */   
/*     */   public long readLong() throws IOException {
/* 188 */     checkAvailable(8);
/* 189 */     return ByteBufHelper.readLong(this.buffer);
/*     */   }
/*     */   
/*     */   public long[] readLongs(int size) throws IOException {
/* 193 */     long[] array = new long[size];
/* 195 */     for (int i = 0; i < array.length; i++)
/* 196 */       array[i] = readLong(); 
/* 198 */     return array;
/*     */   }
/*     */   
/*     */   public short readShort() throws IOException {
/* 202 */     checkAvailable(2);
/* 203 */     return ByteBufHelper.readShort(this.buffer);
/*     */   }
/*     */   
/*     */   public String readUTF() throws IOException {
/* 207 */     return DataInputStream.readUTF(this);
/*     */   }
/*     */   
/*     */   public int readUnsignedByte() throws IOException {
/* 211 */     return readByte() & 0xFF;
/*     */   }
/*     */   
/*     */   public int readUnsignedShort() throws IOException {
/* 215 */     return readShort() & 0xFFFF;
/*     */   }
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 219 */     int nBytes = Math.min(available(), n);
/* 220 */     ByteBufHelper.skipBytes(this.buffer, nBytes);
/* 221 */     return nBytes;
/*     */   }
/*     */   
/*     */   private void checkAvailable(int fieldSize) throws IOException {
/* 225 */     if (fieldSize < 0)
/* 226 */       throw new IndexOutOfBoundsException("fieldSize cannot be a negative number"); 
/* 227 */     if (fieldSize > available())
/* 228 */       throw new EOFException("fieldSize is too long! Length is " + fieldSize + ", but maximum is " + available()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\netty\buffer\ByteBufInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */