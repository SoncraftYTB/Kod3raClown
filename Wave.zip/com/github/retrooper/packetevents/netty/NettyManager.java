package com.github.retrooper.packetevents.netty;

import com.github.retrooper.packetevents.netty.buffer.ByteBufAllocationOperator;
import com.github.retrooper.packetevents.netty.buffer.ByteBufOperator;
import com.github.retrooper.packetevents.netty.channel.ChannelOperator;

public interface NettyManager {
  ChannelOperator getChannelOperator();
  
  ByteBufOperator getByteBufOperator();
  
  ByteBufAllocationOperator getByteBufAllocationOperator();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\netty\NettyManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */