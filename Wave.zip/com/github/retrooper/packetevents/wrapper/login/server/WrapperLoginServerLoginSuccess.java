/*     */ package com.github.retrooper.packetevents.wrapper.login.server;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.player.TextureProperty;
/*     */ import com.github.retrooper.packetevents.protocol.player.UserProfile;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.UUID;
/*     */ 
/*     */ public class WrapperLoginServerLoginSuccess extends PacketWrapper<WrapperLoginServerLoginSuccess> {
/*     */   private UserProfile userProfile;
/*     */   
/*     */   public WrapperLoginServerLoginSuccess(PacketSendEvent event) {
/*  38 */     super(event);
/*     */   }
/*     */   
/*     */   public WrapperLoginServerLoginSuccess(UUID uuid, String username) {
/*  42 */     super((PacketTypeCommon)PacketType.Login.Server.LOGIN_SUCCESS);
/*  43 */     this.userProfile = new UserProfile(uuid, username);
/*     */   }
/*     */   
/*     */   public WrapperLoginServerLoginSuccess(UserProfile userProfile) {
/*  47 */     super((PacketTypeCommon)PacketType.Login.Server.LOGIN_SUCCESS);
/*  48 */     this.userProfile = userProfile;
/*     */   }
/*     */   
/*     */   public void read() {
/*     */     UUID uuid;
/*  54 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16)) {
/*  55 */       uuid = readUUID();
/*     */     } else {
/*  57 */       uuid = UUID.fromString(readString(36));
/*     */     } 
/*  59 */     String username = readString(16);
/*  60 */     this.userProfile = new UserProfile(uuid, username);
/*  62 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19)) {
/*  63 */       int propertyCount = readVarInt();
/*  64 */       for (int i = 0; i < propertyCount; i++) {
/*  65 */         String propertyName = readString();
/*  66 */         String propertyValue = readString();
/*  67 */         String propertySignature = (String)readOptional(PacketWrapper::readString);
/*  68 */         TextureProperty textureProperty = new TextureProperty(propertyName, propertyValue, propertySignature);
/*  69 */         this.userProfile.getTextureProperties().add(textureProperty);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write() {
/*  76 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16)) {
/*  77 */       writeUUID(this.userProfile.getUUID());
/*     */     } else {
/*  79 */       writeString(this.userProfile.getUUID().toString(), 36);
/*     */     } 
/*  81 */     writeString(this.userProfile.getName(), 16);
/*  83 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19)) {
/*  84 */       writeVarInt(this.userProfile.getTextureProperties().size());
/*  85 */       for (TextureProperty textureProperty : this.userProfile.getTextureProperties()) {
/*  86 */         writeString(textureProperty.getName());
/*  87 */         writeString(textureProperty.getValue());
/*  88 */         writeOptional(textureProperty.getSignature(), PacketWrapper::writeString);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void copy(WrapperLoginServerLoginSuccess wrapper) {
/*  95 */     this.userProfile = wrapper.userProfile;
/*     */   }
/*     */   
/*     */   public UserProfile getUserProfile() {
/*  99 */     return this.userProfile;
/*     */   }
/*     */   
/*     */   public void setUserProfile(UserProfile userProfile) {
/* 103 */     this.userProfile = userProfile;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\login\server\WrapperLoginServerLoginSuccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */