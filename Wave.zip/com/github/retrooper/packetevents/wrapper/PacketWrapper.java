/*      */ package com.github.retrooper.packetevents.wrapper;
/*      */ 
/*      */ import com.github.retrooper.packetevents.PacketEvents;
/*      */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*      */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*      */ import com.github.retrooper.packetevents.event.ProtocolPacketEvent;
/*      */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*      */ import com.github.retrooper.packetevents.manager.server.VersionComparison;
/*      */ import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
/*      */ import com.github.retrooper.packetevents.netty.channel.ChannelHelper;
/*      */ import com.github.retrooper.packetevents.protocol.PacketSide;
/*      */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*      */ import com.github.retrooper.packetevents.protocol.chat.ChatTypes;
/*      */ import com.github.retrooper.packetevents.protocol.chat.LastSeenMessages;
/*      */ import com.github.retrooper.packetevents.protocol.chat.MessageSignature;
/*      */ import com.github.retrooper.packetevents.protocol.chat.Node;
/*      */ import com.github.retrooper.packetevents.protocol.chat.Parsers;
/*      */ import com.github.retrooper.packetevents.protocol.chat.RemoteChatSession;
/*      */ import com.github.retrooper.packetevents.protocol.chat.SignedCommandArgument;
/*      */ import com.github.retrooper.packetevents.protocol.chat.filter.FilterMask;
/*      */ import com.github.retrooper.packetevents.protocol.chat.filter.FilterMaskType;
/*      */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage_v1_19_1;
/*      */ import com.github.retrooper.packetevents.protocol.entity.data.EntityData;
/*      */ import com.github.retrooper.packetevents.protocol.entity.data.EntityDataType;
/*      */ import com.github.retrooper.packetevents.protocol.entity.data.EntityDataTypes;
/*      */ import com.github.retrooper.packetevents.protocol.entity.data.EntityMetadataProvider;
/*      */ import com.github.retrooper.packetevents.protocol.entity.villager.VillagerData;
/*      */ import com.github.retrooper.packetevents.protocol.item.ItemStack;
/*      */ import com.github.retrooper.packetevents.protocol.item.type.ItemType;
/*      */ import com.github.retrooper.packetevents.protocol.item.type.ItemTypes;
/*      */ import com.github.retrooper.packetevents.protocol.nbt.NBT;
/*      */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*      */ import com.github.retrooper.packetevents.protocol.nbt.codec.NBTCodec;
/*      */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*      */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*      */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*      */ import com.github.retrooper.packetevents.protocol.player.GameMode;
/*      */ import com.github.retrooper.packetevents.protocol.player.PublicProfileKey;
/*      */ import com.github.retrooper.packetevents.protocol.player.User;
/*      */ import com.github.retrooper.packetevents.protocol.recipe.data.MerchantOffer;
/*      */ import com.github.retrooper.packetevents.protocol.world.Dimension;
/*      */ import com.github.retrooper.packetevents.protocol.world.WorldBlockPosition;
/*      */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*      */ import com.github.retrooper.packetevents.util.StringUtil;
/*      */ import com.github.retrooper.packetevents.util.Vector3i;
/*      */ import com.github.retrooper.packetevents.util.adventure.AdventureNBTSerialization;
/*      */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*      */ import com.github.retrooper.packetevents.util.crypto.MinecraftEncryptionUtil;
/*      */ import com.github.retrooper.packetevents.util.crypto.SaltSignature;
/*      */ import com.github.retrooper.packetevents.util.crypto.SignatureData;
/*      */ import java.io.IOException;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.PublicKey;
/*      */ import java.time.Instant;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.BitSet;
/*      */ import java.util.Collection;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.UUID;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.IntFunction;
/*      */ import net.kyori.adventure.text.Component;
/*      */ import net.kyori.adventure.text.format.Style;
/*      */ import org.jetbrains.annotations.ApiStatus.Experimental;
/*      */ import org.jetbrains.annotations.ApiStatus.Internal;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ 
/*      */ public class PacketWrapper<T extends PacketWrapper> {
/*      */   @Nullable
/*      */   public Object buffer;
/*      */   
/*      */   protected ClientVersion clientVersion;
/*      */   
/*      */   protected ServerVersion serverVersion;
/*      */   
/*      */   private PacketTypeData packetTypeData;
/*      */   
/*      */   @Nullable
/*      */   protected User user;
/*      */   
/*      */   private static final int MODERN_MESSAGE_LENGTH = 262144;
/*      */   
/*      */   private static final int LEGACY_MESSAGE_LENGTH = 32767;
/*      */   
/*      */   public PacketWrapper(ClientVersion clientVersion, ServerVersion serverVersion, int packetID) {
/*  108 */     if (packetID == -1)
/*  109 */       throw new IllegalArgumentException("Packet does not exist on this protocol version!"); 
/*  111 */     this.clientVersion = clientVersion;
/*  112 */     this.serverVersion = serverVersion;
/*  113 */     this.buffer = null;
/*  114 */     this.packetTypeData = new PacketTypeData(null, packetID);
/*      */   }
/*      */   
/*      */   public PacketWrapper(PacketReceiveEvent event) {
/*  118 */     this(event, true);
/*      */   }
/*      */   
/*      */   public PacketWrapper(PacketReceiveEvent event, boolean readData) {
/*  122 */     this.clientVersion = event.getUser().getClientVersion();
/*  123 */     this.serverVersion = event.getServerVersion();
/*  124 */     this.user = event.getUser();
/*  125 */     this.buffer = event.getByteBuf();
/*  126 */     this.packetTypeData = new PacketTypeData(event.getPacketType(), event.getPacketId());
/*  127 */     if (readData)
/*  128 */       readEvent((ProtocolPacketEvent<?>)event); 
/*      */   }
/*      */   
/*      */   public PacketWrapper(PacketSendEvent event) {
/*  133 */     this(event, true);
/*      */   }
/*      */   
/*      */   public PacketWrapper(PacketSendEvent event, boolean readData) {
/*  137 */     this.clientVersion = event.getUser().getClientVersion();
/*  138 */     this.serverVersion = event.getServerVersion();
/*  139 */     this.buffer = event.getByteBuf();
/*  140 */     this.packetTypeData = new PacketTypeData(event.getPacketType(), event.getPacketId());
/*  141 */     this.user = event.getUser();
/*  142 */     if (readData)
/*  143 */       readEvent((ProtocolPacketEvent<?>)event); 
/*      */   }
/*      */   
/*      */   public PacketWrapper(int packetID, ClientVersion clientVersion) {
/*  148 */     this(clientVersion, PacketEvents.getAPI().getServerManager().getVersion(), packetID);
/*      */   }
/*      */   
/*      */   public PacketWrapper(int packetID) {
/*  152 */     if (packetID == -1)
/*  153 */       throw new IllegalArgumentException("Packet does not exist on this protocol version!"); 
/*  155 */     this.clientVersion = ClientVersion.UNKNOWN;
/*  156 */     this.serverVersion = PacketEvents.getAPI().getServerManager().getVersion();
/*  157 */     this.buffer = null;
/*  158 */     this.packetTypeData = new PacketTypeData(null, packetID);
/*      */   }
/*      */   
/*      */   public PacketWrapper(PacketTypeCommon packetType) {
/*  162 */     this.clientVersion = ClientVersion.UNKNOWN;
/*  163 */     this.serverVersion = PacketEvents.getAPI().getServerManager().getVersion();
/*  164 */     this.buffer = null;
/*  165 */     int id = packetType.getId(PacketEvents.getAPI().getServerManager().getVersion().toClientVersion());
/*  166 */     this.packetTypeData = new PacketTypeData(packetType, id);
/*      */   }
/*      */   
/*      */   public static PacketWrapper<?> createUniversalPacketWrapper(Object byteBuf) {
/*  170 */     PacketWrapper<?> wrapper = new PacketWrapper(ClientVersion.UNKNOWN, PacketEvents.getAPI().getServerManager().getVersion(), -2);
/*  171 */     wrapper.buffer = byteBuf;
/*  172 */     return wrapper;
/*      */   }
/*      */   
/*      */   public static int getChunkX(long chunkKey) {
/*  176 */     return (int)(chunkKey & 0xFFFFFFFFL);
/*      */   }
/*      */   
/*      */   public static int getChunkZ(long chunkKey) {
/*  180 */     return (int)(chunkKey >>> 32L & 0xFFFFFFFFL);
/*      */   }
/*      */   
/*      */   public static long getChunkKey(int chunkX, int chunkZ) {
/*  184 */     return chunkX & 0xFFFFFFFFL | (chunkZ & 0xFFFFFFFFL) << 32L;
/*      */   }
/*      */   
/*      */   @Internal
/*      */   public final void prepareForSend(Object channel, boolean outgoing) {
/*  191 */     if (this.buffer == null || ByteBufHelper.refCnt(this.buffer) == 0)
/*  192 */       this.buffer = ChannelHelper.pooledByteBuf(channel); 
/*  196 */     if (PacketEvents.getAPI().getInjector().isProxy()) {
/*  197 */       User user = PacketEvents.getAPI().getProtocolManager().getUser(channel);
/*  198 */       if (this.packetTypeData.getPacketType() == null)
/*  200 */         this.packetTypeData.setPacketType(PacketType.getById(outgoing ? PacketSide.SERVER : PacketSide.CLIENT, user
/*  201 */               .getConnectionState(), this.serverVersion.toClientVersion(), this.packetTypeData.getNativePacketId())); 
/*  204 */       this.serverVersion = user.getClientVersion().toServerVersion();
/*  205 */       int id = this.packetTypeData.getPacketType().getId(user.getClientVersion());
/*  206 */       writeVarInt(id);
/*      */     } else {
/*  208 */       writeVarInt(this.packetTypeData.getNativePacketId());
/*      */     } 
/*  210 */     write();
/*      */   }
/*      */   
/*      */   public void read() {}
/*      */   
/*      */   public void write() {}
/*      */   
/*      */   public void copy(T wrapper) {}
/*      */   
/*      */   public final void readEvent(ProtocolPacketEvent<?> event) {
/*  229 */     PacketWrapper<?> last = event.getLastUsedWrapper();
/*  230 */     if (last != null) {
/*  231 */       copy((T)last);
/*      */     } else {
/*  233 */       read();
/*      */     } 
/*  235 */     event.setLastUsedWrapper(this);
/*      */   }
/*      */   
/*      */   public ClientVersion getClientVersion() {
/*  239 */     return this.clientVersion;
/*      */   }
/*      */   
/*      */   public void setClientVersion(ClientVersion clientVersion) {
/*  243 */     this.clientVersion = clientVersion;
/*      */   }
/*      */   
/*      */   public ServerVersion getServerVersion() {
/*  247 */     return this.serverVersion;
/*      */   }
/*      */   
/*      */   public void setServerVersion(ServerVersion serverVersion) {
/*  251 */     this.serverVersion = serverVersion;
/*      */   }
/*      */   
/*      */   public Object getBuffer() {
/*  255 */     return this.buffer;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public int getPacketId() {
/*  267 */     return getNativePacketId();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void setPacketId(int packetID) {
/*  277 */     setNativePacketId(packetID);
/*      */   }
/*      */   
/*      */   public int getNativePacketId() {
/*  281 */     return this.packetTypeData.getNativePacketId();
/*      */   }
/*      */   
/*      */   public void setNativePacketId(int nativePacketId) {
/*  285 */     this.packetTypeData.setNativePacketId(nativePacketId);
/*      */   }
/*      */   
/*      */   @Internal
/*      */   public PacketTypeData getPacketTypeData() {
/*  290 */     return this.packetTypeData;
/*      */   }
/*      */   
/*      */   public int getMaxMessageLength() {
/*  294 */     return this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_13) ? 262144 : 32767;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void resetByteBuf() {
/*  299 */     ByteBufHelper.clear(this.buffer);
/*      */   }
/*      */   
/*      */   public void resetBuffer() {
/*  303 */     ByteBufHelper.clear(this.buffer);
/*      */   }
/*      */   
/*      */   public byte readByte() {
/*  307 */     return ByteBufHelper.readByte(this.buffer);
/*      */   }
/*      */   
/*      */   public void writeByte(int value) {
/*  311 */     ByteBufHelper.writeByte(this.buffer, value);
/*      */   }
/*      */   
/*      */   public short readUnsignedByte() {
/*  315 */     return ByteBufHelper.readUnsignedByte(this.buffer);
/*      */   }
/*      */   
/*      */   public boolean readBoolean() {
/*  319 */     return (readByte() != 0);
/*      */   }
/*      */   
/*      */   public void writeBoolean(boolean value) {
/*  323 */     writeByte(value ? 1 : 0);
/*      */   }
/*      */   
/*      */   public int readInt() {
/*  327 */     return ByteBufHelper.readInt(this.buffer);
/*      */   }
/*      */   
/*      */   public void writeInt(int value) {
/*  331 */     ByteBufHelper.writeInt(this.buffer, value);
/*      */   }
/*      */   
/*      */   public int readVarInt() {
/*  335 */     int value = 0;
/*  336 */     int length = 0;
/*      */     while (true) {
/*  339 */       byte currentByte = readByte();
/*  340 */       value |= (currentByte & Byte.MAX_VALUE) << length * 7;
/*  341 */       length++;
/*  342 */       if (length > 5)
/*  343 */         throw new RuntimeException("VarInt is too large. Must be smaller than 5 bytes."); 
/*  345 */       if ((currentByte & 0x80) != 128)
/*  346 */         return value; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void writeVarInt(int value) {
/*      */     while (true) {
/*  351 */       if ((value & 0xFFFFFF80) == 0) {
/*  352 */         writeByte(value);
/*      */         break;
/*      */       } 
/*  355 */       writeByte(value & 0x7F | 0x80);
/*  356 */       value >>>= 7;
/*      */     } 
/*      */   }
/*      */   
/*      */   public <K, V> Map<K, V> readMap(Reader<K> keyFunction, Reader<V> valueFunction) {
/*  361 */     int size = readVarInt();
/*  362 */     Map<K, V> map = new HashMap<>(size);
/*  363 */     for (int i = 0; i < size; i++) {
/*  364 */       K key = keyFunction.apply(this);
/*  365 */       V value = valueFunction.apply(this);
/*  366 */       map.put(key, value);
/*      */     } 
/*  368 */     return map;
/*      */   }
/*      */   
/*      */   public <K, V> void writeMap(Map<K, V> map, Writer<K> keyConsumer, Writer<V> valueConsumer) {
/*  372 */     writeVarInt(map.size());
/*  373 */     for (Map.Entry<K, V> entry : map.entrySet()) {
/*  374 */       K key = entry.getKey();
/*  375 */       V value = entry.getValue();
/*  376 */       keyConsumer.accept(this, key);
/*  377 */       valueConsumer.accept(this, value);
/*      */     } 
/*      */   }
/*      */   
/*      */   public VillagerData readVillagerData() {
/*  382 */     int villagerTypeId = readVarInt();
/*  383 */     int villagerProfessionId = readVarInt();
/*  384 */     int level = readVarInt();
/*  385 */     return new VillagerData(villagerTypeId, villagerProfessionId, level);
/*      */   }
/*      */   
/*      */   public void writeVillagerData(VillagerData data) {
/*  389 */     writeVarInt(data.getType().getId());
/*  390 */     writeVarInt(data.getProfession().getId());
/*  391 */     writeVarInt(data.getLevel());
/*      */   }
/*      */   
/*      */   @NotNull
/*      */   public ItemStack readItemStack() {
/*  396 */     boolean v1_13_2 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_13_2);
/*  397 */     if (v1_13_2 && 
/*  398 */       !readBoolean())
/*  399 */       return ItemStack.EMPTY; 
/*  402 */     int typeID = v1_13_2 ? readVarInt() : readShort();
/*  403 */     if (typeID < 0 && !v1_13_2)
/*  404 */       return ItemStack.EMPTY; 
/*  406 */     ItemType type = ItemTypes.getById(this.serverVersion.toClientVersion(), typeID);
/*  407 */     int amount = readByte();
/*  408 */     int legacyData = v1_13_2 ? -1 : readShort();
/*  409 */     NBTCompound nbt = readNBT();
/*  410 */     return ItemStack.builder()
/*  411 */       .type(type)
/*  412 */       .amount(amount)
/*  413 */       .nbt(nbt)
/*  414 */       .legacyData(legacyData)
/*  415 */       .build();
/*      */   }
/*      */   
/*      */   public void writeItemStack(ItemStack itemStack) {
/*  419 */     if (itemStack == null)
/*  420 */       itemStack = ItemStack.EMPTY; 
/*  422 */     boolean v1_13_2 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_13_2);
/*  423 */     if (v1_13_2) {
/*  424 */       if (itemStack.isEmpty()) {
/*  425 */         writeBoolean(false);
/*      */       } else {
/*  427 */         writeBoolean(true);
/*  428 */         int typeID = itemStack.getType().getId(this.serverVersion.toClientVersion());
/*  429 */         writeVarInt(typeID);
/*  430 */         writeByte(itemStack.getAmount());
/*  431 */         writeNBT(itemStack.getNBT());
/*      */       } 
/*  434 */     } else if (itemStack.isEmpty()) {
/*  435 */       writeShort(-1);
/*      */     } else {
/*  437 */       int typeID = itemStack.getType().getId(this.serverVersion.toClientVersion());
/*  438 */       writeShort(typeID);
/*  439 */       writeByte(itemStack.getAmount());
/*  440 */       writeShort(itemStack.getLegacyData());
/*  441 */       writeNBT(itemStack.getNBT());
/*      */     } 
/*      */   }
/*      */   
/*      */   public NBTCompound readNBT() {
/*  447 */     return (NBTCompound)readDirectNBT();
/*      */   }
/*      */   
/*      */   public NBT readDirectNBT() {
/*  451 */     return (NBT)NBTCodec.readNBTFromBuffer(this.buffer, this.serverVersion);
/*      */   }
/*      */   
/*      */   public void writeNBT(NBTCompound nbt) {
/*  455 */     writeDirectNBT((NBT)nbt);
/*      */   }
/*      */   
/*      */   public void writeDirectNBT(NBT nbt) {
/*  459 */     NBTCodec.writeNBTToBuffer(this.buffer, this.serverVersion, nbt);
/*      */   }
/*      */   
/*      */   public String readString() {
/*  463 */     return readString(32767);
/*      */   }
/*      */   
/*      */   public String readString(int maxLen) {
/*  467 */     int j = readVarInt();
/*  469 */     if (j > maxLen * 4)
/*  470 */       throw new RuntimeException("The received encoded string buffer length is longer than maximum allowed (" + j + " > " + (maxLen * 4) + ")"); 
/*  471 */     if (j < 0)
/*  472 */       throw new RuntimeException("The received encoded string buffer length is less than zero! Weird string!"); 
/*  474 */     String s = ByteBufHelper.toString(this.buffer, ByteBufHelper.readerIndex(this.buffer), j, StandardCharsets.UTF_8);
/*  475 */     ByteBufHelper.readerIndex(this.buffer, ByteBufHelper.readerIndex(this.buffer) + j);
/*  476 */     if (s.length() > maxLen)
/*  477 */       throw new RuntimeException("The received string length is longer than maximum allowed (" + j + " > " + maxLen + ")"); 
/*  479 */     return s;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public String readComponentJSON() {
/*  487 */     return AdventureSerializer.asVanilla(readComponent());
/*      */   }
/*      */   
/*      */   public void writeString(String s) {
/*  491 */     writeString(s, 32767);
/*      */   }
/*      */   
/*      */   public void writeString(String s, int maxLen) {
/*  495 */     writeString(s, maxLen, true);
/*      */   }
/*      */   
/*      */   public void writeString(String s, int maxLen, boolean substr) {
/*  499 */     if (substr)
/*  500 */       s = StringUtil.maximizeLength(s, maxLen); 
/*  502 */     byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
/*  503 */     if (!substr && bytes.length > maxLen)
/*  504 */       throw new IllegalStateException("String too big (was " + bytes.length + " bytes encoded, max " + maxLen + ")"); 
/*  506 */     writeVarInt(bytes.length);
/*  507 */     ByteBufHelper.writeBytes(this.buffer, bytes);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void writeComponentJSON(String json) {
/*  514 */     writeComponent(AdventureSerializer.parseComponent(json));
/*      */   }
/*      */   
/*      */   public Component readComponent() {
/*  518 */     return this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20_3) ? 
/*  519 */       readComponentAsNBT() : readComponentAsJSON();
/*      */   }
/*      */   
/*      */   public Component readComponentAsNBT() {
/*      */     try {
/*  524 */       return AdventureNBTSerialization.readComponent(this.buffer);
/*  525 */     } catch (IOException exception) {
/*  526 */       throw new IllegalStateException(exception);
/*      */     } 
/*      */   }
/*      */   
/*      */   public Component readComponentAsJSON() {
/*  531 */     String jsonString = readString(getMaxMessageLength());
/*  532 */     return AdventureSerializer.parseComponent(jsonString);
/*      */   }
/*      */   
/*      */   public void writeComponent(Component component) {
/*  536 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20_3)) {
/*  537 */       writeComponentAsNBT(component);
/*      */     } else {
/*  539 */       writeComponentAsJSON(component);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void writeComponentAsNBT(Component component) {
/*      */     try {
/*  545 */       AdventureNBTSerialization.writeComponent(this.buffer, component);
/*  546 */     } catch (IOException exception) {
/*  547 */       throw new IllegalStateException(exception);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void writeComponentAsJSON(Component component) {
/*  552 */     String jsonString = AdventureSerializer.toJson(component);
/*  553 */     writeString(jsonString, getMaxMessageLength());
/*      */   }
/*      */   
/*      */   public Style readStyle() {
/*      */     try {
/*  558 */       return AdventureNBTSerialization.readStyle(this.buffer);
/*  559 */     } catch (IOException exception) {
/*  560 */       throw new IllegalStateException(exception);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void writeStyle(Style style) {
/*      */     try {
/*  566 */       AdventureNBTSerialization.writeStyle(this.buffer, style);
/*  567 */     } catch (IOException exception) {
/*  568 */       throw new IllegalStateException(exception);
/*      */     } 
/*      */   }
/*      */   
/*      */   public ResourceLocation readIdentifier(int maxLen) {
/*  573 */     return new ResourceLocation(readString(maxLen));
/*      */   }
/*      */   
/*      */   public ResourceLocation readIdentifier() {
/*  577 */     return readIdentifier(32767);
/*      */   }
/*      */   
/*      */   public void writeIdentifier(ResourceLocation identifier, int maxLen) {
/*  581 */     writeString(identifier.toString(), maxLen);
/*      */   }
/*      */   
/*      */   public void writeIdentifier(ResourceLocation identifier) {
/*  585 */     writeIdentifier(identifier, 32767);
/*      */   }
/*      */   
/*      */   public int readUnsignedShort() {
/*  589 */     return ByteBufHelper.readUnsignedShort(this.buffer);
/*      */   }
/*      */   
/*      */   public short readShort() {
/*  593 */     return ByteBufHelper.readShort(this.buffer);
/*      */   }
/*      */   
/*      */   public void writeShort(int value) {
/*  597 */     ByteBufHelper.writeShort(this.buffer, value);
/*      */   }
/*      */   
/*      */   public int readVarShort() {
/*  601 */     int low = readUnsignedShort();
/*  602 */     int high = 0;
/*  603 */     if ((low & 0x8000) != 0) {
/*  604 */       low &= 0x7FFF;
/*  605 */       high = readUnsignedByte();
/*      */     } 
/*  607 */     return (high & 0xFF) << 15 | low;
/*      */   }
/*      */   
/*      */   public void writeVarShort(int value) {
/*  611 */     int low = value & 0x7FFF;
/*  612 */     int high = (value & 0x7F8000) >> 15;
/*  613 */     if (high != 0)
/*  614 */       low |= 0x8000; 
/*  616 */     writeShort(low);
/*  617 */     if (high != 0)
/*  618 */       writeByte(high); 
/*      */   }
/*      */   
/*      */   public long readLong() {
/*  623 */     return ByteBufHelper.readLong(this.buffer);
/*      */   }
/*      */   
/*      */   public void writeLong(long value) {
/*  627 */     ByteBufHelper.writeLong(this.buffer, value);
/*      */   }
/*      */   
/*      */   public long readVarLong() {
/*  631 */     long value = 0L;
/*  632 */     int size = 0;
/*      */     int b;
/*  634 */     while (((b = readByte()) & 0x80) == 128)
/*  635 */       value |= (b & 0x7F) << size++ * 7; 
/*  637 */     return value | (b & 0x7F) << size * 7;
/*      */   }
/*      */   
/*      */   public void writeVarLong(long l) {
/*  641 */     while ((l & 0xFFFFFFFFFFFFFF80L) != 0L) {
/*  642 */       writeByte((int)(l & 0x7FL) | 0x80);
/*  643 */       l >>>= 7L;
/*      */     } 
/*  646 */     writeByte((int)l);
/*      */   }
/*      */   
/*      */   public float readFloat() {
/*  650 */     return ByteBufHelper.readFloat(this.buffer);
/*      */   }
/*      */   
/*      */   public void writeFloat(float value) {
/*  654 */     ByteBufHelper.writeFloat(this.buffer, value);
/*      */   }
/*      */   
/*      */   public double readDouble() {
/*  658 */     return ByteBufHelper.readDouble(this.buffer);
/*      */   }
/*      */   
/*      */   public void writeDouble(double value) {
/*  662 */     ByteBufHelper.writeDouble(this.buffer, value);
/*      */   }
/*      */   
/*      */   public byte[] readRemainingBytes() {
/*  666 */     return readBytes(ByteBufHelper.readableBytes(this.buffer));
/*      */   }
/*      */   
/*      */   public byte[] readBytes(int size) {
/*  670 */     byte[] bytes = new byte[size];
/*  671 */     ByteBufHelper.readBytes(this.buffer, bytes);
/*  672 */     return bytes;
/*      */   }
/*      */   
/*      */   public void writeBytes(byte[] array) {
/*  676 */     ByteBufHelper.writeBytes(this.buffer, array);
/*      */   }
/*      */   
/*      */   public byte[] readByteArray(int maxLength) {
/*  680 */     int len = readVarInt();
/*  681 */     if (len > maxLength)
/*  682 */       throw new RuntimeException("The received byte array length is longer than maximum allowed (" + len + " > " + maxLength + ")"); 
/*  684 */     return readBytes(len);
/*      */   }
/*      */   
/*      */   public byte[] readByteArray() {
/*  688 */     return readByteArray(ByteBufHelper.readableBytes(this.buffer));
/*      */   }
/*      */   
/*      */   public void writeByteArray(byte[] array) {
/*  692 */     writeVarInt(array.length);
/*  693 */     writeBytes(array);
/*      */   }
/*      */   
/*      */   public int[] readVarIntArray() {
/*  697 */     int readableBytes = ByteBufHelper.readableBytes(this.buffer);
/*  698 */     int size = readVarInt();
/*  699 */     if (size > readableBytes)
/*  700 */       throw new IllegalStateException("VarIntArray with size " + size + " is bigger than allowed " + readableBytes); 
/*  703 */     int[] array = new int[size];
/*  704 */     for (int i = 0; i < size; i++)
/*  705 */       array[i] = readVarInt(); 
/*  707 */     return array;
/*      */   }
/*      */   
/*      */   public void writeVarIntArray(int[] array) {
/*  711 */     writeVarInt(array.length);
/*  712 */     for (int i : array)
/*  713 */       writeVarInt(i); 
/*      */   }
/*      */   
/*      */   public long[] readLongArray(int size) {
/*  718 */     long[] array = new long[size];
/*  720 */     for (int i = 0; i < array.length; i++)
/*  721 */       array[i] = readLong(); 
/*  723 */     return array;
/*      */   }
/*      */   
/*      */   public byte[] readByteArrayOfSize(int size) {
/*  727 */     byte[] array = new byte[size];
/*  728 */     ByteBufHelper.readBytes(this.buffer, array);
/*  729 */     return array;
/*      */   }
/*      */   
/*      */   public void writeByteArrayOfSize(byte[] array) {
/*  733 */     ByteBufHelper.writeBytes(this.buffer, array);
/*      */   }
/*      */   
/*      */   public int[] readVarIntArrayOfSize(int size) {
/*  737 */     int[] array = new int[size];
/*  738 */     for (int i = 0; i < array.length; i++)
/*  739 */       array[i] = readVarInt(); 
/*  741 */     return array;
/*      */   }
/*      */   
/*      */   public void writeVarIntArrayOfSize(int[] array) {
/*  745 */     for (int i : array)
/*  746 */       writeVarInt(i); 
/*      */   }
/*      */   
/*      */   public long[] readLongArray() {
/*  751 */     int readableBytes = ByteBufHelper.readableBytes(this.buffer) / 8;
/*  752 */     int size = readVarInt();
/*  753 */     if (size > readableBytes)
/*  754 */       throw new IllegalStateException("LongArray with size " + size + " is bigger than allowed " + readableBytes); 
/*  756 */     long[] array = new long[size];
/*  758 */     for (int i = 0; i < array.length; i++)
/*  759 */       array[i] = readLong(); 
/*  761 */     return array;
/*      */   }
/*      */   
/*      */   public void writeLongArray(long[] array) {
/*  765 */     writeVarInt(array.length);
/*  766 */     for (long l : array)
/*  767 */       writeLong(l); 
/*      */   }
/*      */   
/*      */   public UUID readUUID() {
/*  772 */     long mostSigBits = readLong();
/*  773 */     long leastSigBits = readLong();
/*  774 */     return new UUID(mostSigBits, leastSigBits);
/*      */   }
/*      */   
/*      */   public void writeUUID(UUID uuid) {
/*  778 */     writeLong(uuid.getMostSignificantBits());
/*  779 */     writeLong(uuid.getLeastSignificantBits());
/*      */   }
/*      */   
/*      */   public Vector3i readBlockPosition() {
/*  783 */     long val = readLong();
/*  784 */     return new Vector3i(val, this.serverVersion);
/*      */   }
/*      */   
/*      */   public void writeBlockPosition(Vector3i pos) {
/*  788 */     long val = pos.getSerializedPosition(this.serverVersion);
/*  789 */     writeLong(val);
/*      */   }
/*      */   
/*      */   public GameMode readGameMode() {
/*  793 */     return GameMode.getById(readByte());
/*      */   }
/*      */   
/*      */   public void writeGameMode(@Nullable GameMode mode) {
/*  797 */     int id = (mode == null) ? -1 : mode.getId();
/*  798 */     writeByte(id);
/*      */   }
/*      */   
/*      */   public List<EntityData> readEntityMetadata() {
/*  802 */     List<EntityData> list = new ArrayList<>();
/*  803 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9)) {
/*  804 */       boolean v1_10 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_10);
/*      */       short index;
/*  806 */       while ((index = readUnsignedByte()) != 255) {
/*  807 */         int typeID = v1_10 ? readVarInt() : readUnsignedByte();
/*  808 */         EntityDataType<?> type = EntityDataTypes.getById(this.serverVersion.toClientVersion(), typeID);
/*  809 */         if (type == null)
/*  810 */           throw new IllegalStateException("Unknown entity metadata type id: " + typeID + " version " + this.serverVersion.toClientVersion()); 
/*  812 */         Object value = type.getDataDeserializer().apply(this);
/*  813 */         list.add(new EntityData(index, type, value));
/*      */       } 
/*      */     } else {
/*  816 */       for (byte data = readByte(); data != Byte.MAX_VALUE; data = readByte()) {
/*  817 */         int typeID = (data & 0xE0) >> 5;
/*  818 */         int index = data & 0x1F;
/*  819 */         EntityDataType<?> type = EntityDataTypes.getById(this.serverVersion.toClientVersion(), typeID);
/*  820 */         Object value = type.getDataDeserializer().apply(this);
/*  821 */         EntityData entityData = new EntityData(index, type, value);
/*  822 */         list.add(entityData);
/*      */       } 
/*      */     } 
/*  825 */     return list;
/*      */   }
/*      */   
/*      */   public void writeEntityMetadata(List<EntityData> list) {
/*  829 */     if (list == null)
/*  830 */       list = new ArrayList<>(); 
/*  832 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9)) {
/*  833 */       boolean v1_10 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_10);
/*  834 */       for (EntityData entityData : list) {
/*  835 */         writeByte(entityData.getIndex());
/*  836 */         if (v1_10) {
/*  837 */           writeVarInt(entityData.getType().getId(this.serverVersion.toClientVersion()));
/*      */         } else {
/*  839 */           writeByte(entityData.getType().getId(this.serverVersion.toClientVersion()));
/*      */         } 
/*  841 */         entityData.getType().getDataSerializer().accept(this, entityData.getValue());
/*      */       } 
/*  843 */       writeByte(255);
/*      */     } else {
/*  845 */       for (EntityData entityData : list) {
/*  846 */         int typeID = entityData.getType().getId(this.serverVersion.toClientVersion());
/*  847 */         int index = entityData.getIndex();
/*  848 */         int data = (typeID << 5 | index & 0x1F) & 0xFF;
/*  849 */         writeByte(data);
/*  850 */         entityData.getType().getDataSerializer().accept(this, entityData.getValue());
/*      */       } 
/*  852 */       writeByte(127);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void writeEntityMetadata(EntityMetadataProvider metadata) {
/*  857 */     writeEntityMetadata(metadata.entityData(this.serverVersion.toClientVersion()));
/*      */   }
/*      */   
/*      */   public Dimension readDimension() {
/*  861 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19)) {
/*  862 */       Dimension dimension = new Dimension(new NBTCompound());
/*  863 */       dimension.setDimensionName(readIdentifier().toString());
/*  864 */       return dimension;
/*      */     } 
/*  866 */     return new Dimension(readNBT());
/*      */   }
/*      */   
/*      */   public void writeDimension(Dimension dimension) {
/*  871 */     boolean v1_19 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19);
/*  872 */     boolean v1_16_2 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16_2);
/*  873 */     if (v1_19 || !v1_16_2) {
/*  874 */       writeString(dimension.getDimensionName(), 32767);
/*      */     } else {
/*  876 */       writeNBT(dimension.getAttributes());
/*      */     } 
/*      */   }
/*      */   
/*      */   public SaltSignature readSaltSignature() {
/*      */     byte[] signature;
/*  881 */     long salt = readLong();
/*  884 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19_3)) {
/*  886 */       if (readBoolean()) {
/*  887 */         signature = readBytes(256);
/*      */       } else {
/*  889 */         signature = new byte[0];
/*      */       } 
/*      */     } else {
/*  892 */       signature = readByteArray(256);
/*      */     } 
/*  894 */     return new SaltSignature(salt, signature);
/*      */   }
/*      */   
/*      */   public void writeSaltSignature(SaltSignature signature) {
/*  898 */     writeLong(signature.getSalt());
/*  899 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19_3)) {
/*  900 */       boolean present = ((signature.getSignature()).length != 0);
/*  901 */       writeBoolean(present);
/*  902 */       if (present)
/*  903 */         writeBytes(signature.getSignature()); 
/*      */     } else {
/*  907 */       writeByteArray(signature.getSignature());
/*      */     } 
/*      */   }
/*      */   
/*      */   public PublicKey readPublicKey() {
/*  912 */     return MinecraftEncryptionUtil.publicKey(readByteArray(512));
/*      */   }
/*      */   
/*      */   public void writePublicKey(PublicKey publicKey) {
/*  916 */     writeByteArray(publicKey.getEncoded());
/*      */   }
/*      */   
/*      */   public PublicProfileKey readPublicProfileKey() {
/*  920 */     Instant expiresAt = readTimestamp();
/*  921 */     PublicKey key = readPublicKey();
/*  922 */     byte[] keySignature = readByteArray(4096);
/*  923 */     return new PublicProfileKey(expiresAt, key, keySignature);
/*      */   }
/*      */   
/*      */   public void writePublicProfileKey(PublicProfileKey key) {
/*  927 */     writeTimestamp(key.getExpiresAt());
/*  928 */     writePublicKey(key.getKey());
/*  929 */     writeByteArray(key.getKeySignature());
/*      */   }
/*      */   
/*      */   public RemoteChatSession readRemoteChatSession() {
/*  933 */     return new RemoteChatSession(readUUID(), readPublicProfileKey());
/*      */   }
/*      */   
/*      */   public void writeRemoteChatSession(RemoteChatSession chatSession) {
/*  937 */     writeUUID(chatSession.getSessionId());
/*  938 */     writePublicProfileKey(chatSession.getPublicProfileKey());
/*      */   }
/*      */   
/*      */   public Instant readTimestamp() {
/*  942 */     return Instant.ofEpochMilli(readLong());
/*      */   }
/*      */   
/*      */   public void writeTimestamp(Instant timestamp) {
/*  946 */     writeLong(timestamp.toEpochMilli());
/*      */   }
/*      */   
/*      */   public SignatureData readSignatureData() {
/*  950 */     return new SignatureData(readTimestamp(), readPublicKey(), readByteArray(4096));
/*      */   }
/*      */   
/*      */   public void writeSignatureData(SignatureData signatureData) {
/*  954 */     writeTimestamp(signatureData.getTimestamp());
/*  955 */     writePublicKey(signatureData.getPublicKey());
/*  956 */     writeByteArray(signatureData.getSignature());
/*      */   }
/*      */   
/*      */   public static <K> IntFunction<K> limitValue(IntFunction<K> function, int limit) {
/*  960 */     return i -> {
/*      */         if (i > limit)
/*      */           throw new RuntimeException("Value " + i + " is larger than limit " + limit); 
/*      */         return function.apply(i);
/*      */       };
/*      */   }
/*      */   
/*      */   public WorldBlockPosition readWorldBlockPosition() {
/*  969 */     return new WorldBlockPosition(readIdentifier(), readBlockPosition());
/*      */   }
/*      */   
/*      */   public void writeWorldBlockPosition(WorldBlockPosition pos) {
/*  973 */     writeIdentifier(pos.getWorld());
/*  974 */     writeBlockPosition(pos.getBlockPosition());
/*      */   }
/*      */   
/*      */   public LastSeenMessages.Entry readLastSeenMessagesEntry() {
/*  978 */     return new LastSeenMessages.Entry(readUUID(), readByteArray());
/*      */   }
/*      */   
/*      */   public void writeLastMessagesEntry(LastSeenMessages.Entry entry) {
/*  982 */     writeUUID(entry.getUUID());
/*  983 */     writeByteArray(entry.getLastVerifier());
/*      */   }
/*      */   
/*      */   public LastSeenMessages.Update readLastSeenMessagesUpdate() {
/*  987 */     int signedMessages = readVarInt();
/*  988 */     BitSet seen = BitSet.valueOf(readBytes(3));
/*  989 */     return new LastSeenMessages.Update(signedMessages, seen);
/*      */   }
/*      */   
/*      */   public void writeLastSeenMessagesUpdate(LastSeenMessages.Update update) {
/*  993 */     writeVarInt(update.getOffset());
/*  994 */     byte[] lastSeen = Arrays.copyOf(update.getAcknowledged().toByteArray(), 3);
/*  995 */     writeBytes(lastSeen);
/*      */   }
/*      */   
/*      */   public LastSeenMessages.LegacyUpdate readLegacyLastSeenMessagesUpdate() {
/*  999 */     LastSeenMessages lastSeenMessages = readLastSeenMessages();
/* 1000 */     LastSeenMessages.Entry lastReceived = readOptional(PacketWrapper::readLastSeenMessagesEntry);
/* 1001 */     return new LastSeenMessages.LegacyUpdate(lastSeenMessages, lastReceived);
/*      */   }
/*      */   
/*      */   public void writeLegacyLastSeenMessagesUpdate(LastSeenMessages.LegacyUpdate legacyUpdate) {
/* 1005 */     writeLastSeenMessages(legacyUpdate.getLastSeenMessages());
/* 1006 */     writeOptional(legacyUpdate.getLastReceived(), PacketWrapper::writeLastMessagesEntry);
/*      */   }
/*      */   
/*      */   public MessageSignature.Packed readMessageSignaturePacked() {
/* 1010 */     int id = readVarInt() - 1;
/* 1011 */     if (id == -1)
/* 1012 */       return new MessageSignature.Packed(new MessageSignature(readBytes(256))); 
/* 1014 */     return new MessageSignature.Packed(id);
/*      */   }
/*      */   
/*      */   public void writeMessageSignaturePacked(MessageSignature.Packed messageSignaturePacked) {
/* 1018 */     writeVarInt(messageSignaturePacked.getId() + 1);
/* 1019 */     if (messageSignaturePacked.getFullSignature().isPresent())
/* 1020 */       writeBytes(((MessageSignature)messageSignaturePacked.getFullSignature().get()).getBytes()); 
/*      */   }
/*      */   
/*      */   public LastSeenMessages.Packed readLastSeenMessagesPacked() {
/* 1025 */     List<MessageSignature.Packed> packedMessageSignatures = readCollection(limitValue(ArrayList::new, 20), PacketWrapper::readMessageSignaturePacked);
/* 1026 */     return new LastSeenMessages.Packed(packedMessageSignatures);
/*      */   }
/*      */   
/*      */   public void writeLastSeenMessagesPacked(LastSeenMessages.Packed lastSeenMessagesPacked) {
/* 1030 */     writeCollection(lastSeenMessagesPacked.getPackedMessageSignatures(), PacketWrapper::writeMessageSignaturePacked);
/*      */   }
/*      */   
/*      */   public LastSeenMessages readLastSeenMessages() {
/* 1034 */     List<LastSeenMessages.Entry> entries = readCollection(limitValue(ArrayList::new, 5), PacketWrapper::readLastSeenMessagesEntry);
/* 1036 */     return new LastSeenMessages(entries);
/*      */   }
/*      */   
/*      */   public void writeLastSeenMessages(LastSeenMessages lastSeenMessages) {
/* 1040 */     writeCollection(lastSeenMessages.getEntries(), PacketWrapper::writeLastMessagesEntry);
/*      */   }
/*      */   
/*      */   public List<SignedCommandArgument> readSignedCommandArguments() {
/* 1044 */     return readCollection(ArrayList::new, _packet -> new SignedCommandArgument(readString(), readByteArray()));
/*      */   }
/*      */   
/*      */   public void writeSignedCommandArguments(List<SignedCommandArgument> signedArguments) {
/* 1048 */     writeCollection(signedArguments, (_packet, argument) -> {
/*      */           writeString(argument.getArgument());
/*      */           writeByteArray(argument.getSignature());
/*      */         });
/*      */   }
/*      */   
/*      */   public BitSet readBitSet() {
/* 1055 */     return BitSet.valueOf(readLongArray());
/*      */   }
/*      */   
/*      */   public void writeBitSet(BitSet bitSet) {
/* 1059 */     writeLongArray(bitSet.toLongArray());
/*      */   }
/*      */   
/*      */   public FilterMask readFilterMask() {
/* 1063 */     FilterMaskType type = FilterMaskType.getById(readVarInt());
/* 1064 */     switch (type) {
/*      */       case PARTIALLY_FILTERED:
/* 1066 */         return new FilterMask(readBitSet());
/*      */       case PASS_THROUGH:
/* 1068 */         return FilterMask.PASS_THROUGH;
/*      */       case FULLY_FILTERED:
/* 1070 */         return FilterMask.FULLY_FILTERED;
/*      */     } 
/* 1072 */     return null;
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface Reader<T> extends Function<PacketWrapper<?>, T> {}
/*      */   
/*      */   @FunctionalInterface
/*      */   public static interface Writer<T> extends BiConsumer<PacketWrapper<?>, T> {}
/*      */   
/*      */   public void writeFilterMask(FilterMask filterMask) {
/* 1077 */     writeVarInt(filterMask.getType().getId());
/* 1078 */     if (filterMask.getType() == FilterMaskType.PARTIALLY_FILTERED)
/* 1079 */       writeBitSet(filterMask.getMask()); 
/*      */   }
/*      */   
/*      */   public MerchantOffer readMerchantOffer() {
/* 1084 */     ItemStack buyItemPrimary = readItemStack();
/* 1085 */     ItemStack sellItem = readItemStack();
/* 1086 */     ItemStack buyItemSecondary = readOptional(PacketWrapper::readItemStack);
/* 1087 */     boolean tradeDisabled = readBoolean();
/* 1088 */     int uses = readInt();
/* 1089 */     int maxUses = readInt();
/* 1090 */     int xp = readInt();
/* 1091 */     int specialPrice = readInt();
/* 1092 */     float priceMultiplier = readFloat();
/* 1093 */     int demand = readInt();
/* 1094 */     MerchantOffer data = MerchantOffer.of(buyItemPrimary, buyItemSecondary, sellItem, uses, maxUses, xp, specialPrice, priceMultiplier, demand);
/* 1095 */     if (tradeDisabled)
/* 1096 */       data.setUses(data.getMaxUses()); 
/* 1098 */     return data;
/*      */   }
/*      */   
/*      */   public void writeMerchantOffer(MerchantOffer data) {
/* 1102 */     writeItemStack(data.getFirstInputItem());
/* 1103 */     writeItemStack(data.getOutputItem());
/* 1104 */     ItemStack buyItemSecondary = data.getSecondInputItem();
/* 1106 */     if (buyItemSecondary != null && buyItemSecondary.isEmpty())
/* 1107 */       buyItemSecondary = null; 
/* 1109 */     writeOptional(buyItemSecondary, PacketWrapper::writeItemStack);
/* 1110 */     writeBoolean((data.getUses() >= data.getMaxUses()));
/* 1111 */     writeInt(data.getUses());
/* 1112 */     writeInt(data.getMaxUses());
/* 1113 */     writeInt(data.getXp());
/* 1114 */     writeInt(data.getSpecialPrice());
/* 1115 */     writeFloat(data.getPriceMultiplier());
/* 1116 */     writeInt(data.getDemand());
/*      */   }
/*      */   
/*      */   public ChatMessage_v1_19_1.ChatTypeBoundNetwork readChatTypeBoundNetwork() {
/* 1120 */     int id = readVarInt();
/* 1121 */     ChatType type = ChatTypes.getById(getServerVersion().toClientVersion(), id);
/* 1122 */     Component name = readComponent();
/* 1123 */     Component targetName = readOptional(PacketWrapper::readComponent);
/* 1124 */     return new ChatMessage_v1_19_1.ChatTypeBoundNetwork(type, name, targetName);
/*      */   }
/*      */   
/*      */   public void writeChatTypeBoundNetwork(ChatMessage_v1_19_1.ChatTypeBoundNetwork chatType) {
/* 1128 */     writeVarInt(chatType.getType().getId(getServerVersion().toClientVersion()));
/* 1129 */     writeComponent(chatType.getName());
/* 1130 */     writeOptional(chatType.getTargetName(), PacketWrapper::writeComponent);
/*      */   }
/*      */   
/*      */   public Node readNode() {
/* 1134 */     byte flags = readByte();
/* 1135 */     int nodeType = flags & 0x3;
/* 1136 */     boolean hasRedirect = ((flags & 0x8) != 0);
/* 1137 */     boolean hasSuggestionsType = (nodeType == 2 && (flags & 0x10) != 0);
/* 1139 */     List<Integer> children = readList(PacketWrapper::readVarInt);
/* 1141 */     Integer redirectNodeIndex = hasRedirect ? Integer.valueOf(readVarInt()) : null;
/* 1142 */     String name = (nodeType == 1 || nodeType == 2) ? readString() : null;
/* 1143 */     Integer parserID = (nodeType == 2) ? Integer.valueOf(readVarInt()) : null;
/* 1144 */     List<Object> properties = (nodeType == 2) ? ((Parsers.Parser)Parsers.getParsers().get(parserID.intValue())).readProperties(this).orElse(null) : null;
/* 1145 */     ResourceLocation suggestionType = hasSuggestionsType ? readIdentifier() : null;
/* 1147 */     return new Node(flags, children, redirectNodeIndex, name, parserID, properties, suggestionType);
/*      */   }
/*      */   
/*      */   public void writeNode(Node node) {
/* 1151 */     writeByte(node.getFlags());
/* 1152 */     writeList(node.getChildren(), PacketWrapper::writeVarInt);
/* 1153 */     node.getRedirectNodeIndex().ifPresent(this::writeVarInt);
/* 1154 */     node.getName().ifPresent(this::writeString);
/* 1155 */     node.getParserID().ifPresent(this::writeVarInt);
/* 1156 */     if (node.getProperties().isPresent())
/* 1157 */       ((Parsers.Parser)Parsers.getParsers().get(((Integer)node.getParserID().get()).intValue())).writeProperties(this, node.getProperties().get()); 
/* 1158 */     node.getSuggestionsType().ifPresent(this::writeIdentifier);
/*      */   }
/*      */   
/*      */   public <T extends Enum<T>> EnumSet<T> readEnumSet(Class<T> enumClazz) {
/* 1162 */     Enum[] arrayOfEnum = (Enum[])enumClazz.getEnumConstants();
/* 1163 */     byte[] bytes = new byte[-Math.floorDiv(-arrayOfEnum.length, 8)];
/* 1164 */     ByteBufHelper.readBytes(getBuffer(), bytes);
/* 1165 */     BitSet bitSet = BitSet.valueOf(bytes);
/* 1166 */     EnumSet<T> set = EnumSet.noneOf(enumClazz);
/* 1167 */     for (int i = 0; i < arrayOfEnum.length; i++) {
/* 1168 */       if (bitSet.get(i))
/* 1169 */         set.add((T)arrayOfEnum[i]); 
/*      */     } 
/* 1172 */     return set;
/*      */   }
/*      */   
/*      */   public <T extends Enum<T>> void writeEnumSet(EnumSet<T> set, Class<T> enumClazz) {
/* 1176 */     Enum[] arrayOfEnum = (Enum[])enumClazz.getEnumConstants();
/* 1177 */     BitSet bitSet = new BitSet(arrayOfEnum.length);
/* 1178 */     for (int i = 0; i < arrayOfEnum.length; i++) {
/* 1179 */       if (set.contains(arrayOfEnum[i]))
/* 1180 */         bitSet.set(i); 
/*      */     } 
/* 1183 */     writeBytes(Arrays.copyOf(bitSet.toByteArray(), -Math.floorDiv(-arrayOfEnum.length, 8)));
/*      */   }
/*      */   
/*      */   @Experimental
/*      */   public <U, V, R> U readMultiVersional(VersionComparison version, ServerVersion target, Reader<V> first, Reader<R> second) {
/* 1188 */     if (this.serverVersion.is(version, target))
/* 1189 */       return (U)first.apply(this); 
/* 1191 */     return (U)second.apply(this);
/*      */   }
/*      */   
/*      */   @Experimental
/*      */   public <V> void writeMultiVersional(VersionComparison version, ServerVersion target, V value, Writer<V> first, Writer<V> second) {
/* 1197 */     if (this.serverVersion.is(version, target)) {
/* 1198 */       first.accept(this, value);
/*      */     } else {
/* 1200 */       second.accept(this, value);
/*      */     } 
/*      */   }
/*      */   
/*      */   public <R> R readOptional(Reader<R> reader) {
/* 1205 */     return readBoolean() ? reader.apply(this) : null;
/*      */   }
/*      */   
/*      */   public <V> void writeOptional(V value, Writer<V> writer) {
/* 1209 */     if (value != null) {
/* 1210 */       writeBoolean(true);
/* 1211 */       writer.accept(this, value);
/*      */     } else {
/* 1213 */       writeBoolean(false);
/*      */     } 
/*      */   }
/*      */   
/*      */   public <K, C extends Collection<K>> C readCollection(IntFunction<C> function, Reader<K> reader) {
/* 1219 */     int size = readVarInt();
/* 1220 */     Collection<K> collection = (Collection<K>)function.apply(size);
/* 1221 */     for (int i = 0; i < size; i++)
/* 1222 */       collection.add(reader.apply(this)); 
/* 1224 */     return (C)collection;
/*      */   }
/*      */   
/*      */   public <K> void writeCollection(Collection<K> collection, Writer<K> writer) {
/* 1228 */     writeVarInt(collection.size());
/* 1229 */     for (K key : collection)
/* 1230 */       writer.accept(this, key); 
/*      */   }
/*      */   
/*      */   public <K> List<K> readList(Reader<K> reader) {
/* 1235 */     return readCollection(ArrayList::new, reader);
/*      */   }
/*      */   
/*      */   public <K> void writeList(List<K> list, Writer<K> writer) {
/* 1239 */     writeVarInt(list.size());
/* 1240 */     for (K key : list)
/* 1241 */       writer.accept(this, key); 
/*      */   }
/*      */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\PacketWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */