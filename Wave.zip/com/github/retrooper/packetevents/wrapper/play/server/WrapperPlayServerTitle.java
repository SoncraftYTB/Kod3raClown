/*     */ package com.github.retrooper.packetevents.wrapper.play.server;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.Objects;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class WrapperPlayServerTitle extends PacketWrapper<WrapperPlayServerTitle> {
/*     */   @Deprecated
/*     */   public static boolean HANDLE_JSON = true;
/*     */   
/*     */   private TitleAction action;
/*     */   
/*     */   @Nullable
/*     */   private Component title;
/*     */   
/*     */   @Nullable
/*     */   private Component subtitle;
/*     */   
/*     */   @Nullable
/*     */   private Component actionBar;
/*     */   
/*     */   private int fadeInTicks;
/*     */   
/*     */   private int stayTicks;
/*     */   
/*     */   private int fadeOutTicks;
/*     */   
/*     */   public WrapperPlayServerTitle(PacketSendEvent event) {
/*  49 */     super(event);
/*     */   }
/*     */   
/*     */   public WrapperPlayServerTitle(TitleAction action, @Nullable Component title, @Nullable Component subtitle, @Nullable Component actionBar, int fadeInTicks, int stayTicks, int fadeOutTicks) {
/*  54 */     super((PacketTypeCommon)PacketType.Play.Server.TITLE);
/*  55 */     this.action = action;
/*  56 */     this.title = title;
/*  57 */     this.subtitle = subtitle;
/*  58 */     this.actionBar = actionBar;
/*  59 */     this.fadeInTicks = fadeInTicks;
/*  60 */     this.stayTicks = stayTicks;
/*  61 */     this.fadeOutTicks = fadeOutTicks;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WrapperPlayServerTitle(TitleAction action, @Nullable String titleJson, @Nullable String subtitleJson, @Nullable String actionBarJson, int fadeInTicks, int stayTicks, int fadeOutTicks) {
/*  67 */     this(action, AdventureSerializer.parseComponent(titleJson), AdventureSerializer.parseComponent(subtitleJson), 
/*  68 */         AdventureSerializer.parseComponent(actionBarJson), fadeInTicks, stayTicks, fadeOutTicks);
/*     */   }
/*     */   
/*     */   public void read() {
/*  73 */     boolean modern = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_11);
/*  74 */     int id = readVarInt();
/*  75 */     if (modern) {
/*  76 */       this.action = TitleAction.fromId(id);
/*     */     } else {
/*  78 */       this.action = TitleAction.fromLegacyId(id);
/*     */     } 
/*  80 */     switch ((TitleAction)Objects.requireNonNull((T)this.action)) {
/*     */       case SET_TITLE:
/*  82 */         this.title = readComponent();
/*     */         break;
/*     */       case SET_SUBTITLE:
/*  85 */         this.subtitle = readComponent();
/*     */         break;
/*     */       case SET_ACTION_BAR:
/*  88 */         this.actionBar = readComponent();
/*     */         break;
/*     */       case SET_TIMES_AND_DISPLAY:
/*  91 */         this.fadeInTicks = readInt();
/*  92 */         this.stayTicks = readInt();
/*  93 */         this.fadeOutTicks = readInt();
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void copy(WrapperPlayServerTitle wrapper) {
/* 100 */     this.action = wrapper.action;
/* 101 */     this.title = wrapper.title;
/* 102 */     this.subtitle = wrapper.subtitle;
/* 103 */     this.actionBar = wrapper.actionBar;
/* 104 */     this.fadeInTicks = wrapper.fadeInTicks;
/* 105 */     this.stayTicks = wrapper.stayTicks;
/* 106 */     this.fadeOutTicks = wrapper.fadeOutTicks;
/*     */   }
/*     */   
/*     */   public void write() {
/* 111 */     boolean modern = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_11);
/* 112 */     int id = modern ? this.action.getId() : this.action.getLegacyId();
/* 113 */     writeVarInt(id);
/* 114 */     switch (this.action) {
/*     */       case SET_TITLE:
/* 116 */         writeComponent(this.title);
/*     */         break;
/*     */       case SET_SUBTITLE:
/* 119 */         writeComponent(this.subtitle);
/*     */         break;
/*     */       case SET_ACTION_BAR:
/* 122 */         writeComponent(this.actionBar);
/*     */         break;
/*     */       case SET_TIMES_AND_DISPLAY:
/* 125 */         writeInt(this.fadeInTicks);
/* 126 */         writeInt(this.stayTicks);
/* 127 */         writeInt(this.fadeOutTicks);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public TitleAction getAction() {
/* 133 */     return this.action;
/*     */   }
/*     */   
/*     */   public void setAction(TitleAction action) {
/* 137 */     this.action = action;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Component getTitle() {
/* 141 */     return this.title;
/*     */   }
/*     */   
/*     */   public void setTitle(@Nullable Component title) {
/* 145 */     this.title = title;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   public String getTitleJson() {
/* 150 */     return AdventureSerializer.toJson(getTitle());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setTitleJson(@Nullable String titleJson) {
/* 155 */     setTitle(AdventureSerializer.parseComponent(titleJson));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Component getSubtitle() {
/* 159 */     return this.subtitle;
/*     */   }
/*     */   
/*     */   public void setSubtitle(@Nullable Component subtitle) {
/* 163 */     this.subtitle = subtitle;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   public String getSubtitleJson() {
/* 168 */     return AdventureSerializer.toJson(getSubtitle());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setSubtitleJson(@Nullable String subtitleJson) {
/* 173 */     setSubtitle(AdventureSerializer.parseComponent(subtitleJson));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Component getActionBar() {
/* 177 */     return this.actionBar;
/*     */   }
/*     */   
/*     */   public void setActionBar(@Nullable Component actionBar) {
/* 181 */     this.actionBar = actionBar;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   public String getActionBarJson() {
/* 186 */     return AdventureSerializer.toJson(getActionBar());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setActionBarJson(@Nullable String actionBarJson) {
/* 191 */     setActionBar(AdventureSerializer.parseComponent(actionBarJson));
/*     */   }
/*     */   
/*     */   public int getFadeInTicks() {
/* 195 */     return this.fadeInTicks;
/*     */   }
/*     */   
/*     */   public void setFadeInTicks(int fadeInTicks) {
/* 199 */     this.fadeInTicks = fadeInTicks;
/*     */   }
/*     */   
/*     */   public int getStayTicks() {
/* 203 */     return this.stayTicks;
/*     */   }
/*     */   
/*     */   public void setStayTicks(int stayTicks) {
/* 207 */     this.stayTicks = stayTicks;
/*     */   }
/*     */   
/*     */   public int getFadeOutTicks() {
/* 211 */     return this.fadeOutTicks;
/*     */   }
/*     */   
/*     */   public void setFadeOutTicks(int fadeOutTicks) {
/* 215 */     this.fadeOutTicks = fadeOutTicks;
/*     */   }
/*     */   
/*     */   public enum TitleAction {
/* 219 */     SET_TITLE(0),
/* 220 */     SET_SUBTITLE(1),
/* 221 */     SET_ACTION_BAR,
/* 222 */     SET_TIMES_AND_DISPLAY(2),
/* 223 */     HIDE(3),
/* 224 */     RESET(4);
/*     */     
/*     */     private final int legacyId;
/*     */     
/*     */     TitleAction(int legacyId) {
/* 232 */       this.legacyId = legacyId;
/*     */     }
/*     */     
/*     */     public static TitleAction fromId(int id) {
/* 236 */       return values()[id];
/*     */     }
/*     */     
/*     */     public static TitleAction fromLegacyId(int legacyId) {
/* 240 */       for (TitleAction action : values()) {
/* 241 */         if (action.legacyId == legacyId)
/* 242 */           return action; 
/*     */       } 
/* 245 */       return null;
/*     */     }
/*     */     
/*     */     public int getId() {
/* 249 */       return ordinal();
/*     */     }
/*     */     
/*     */     public int getLegacyId() {
/* 253 */       return this.legacyId;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerTitle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */