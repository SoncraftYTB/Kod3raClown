/*     */ package com.github.retrooper.packetevents.wrapper.play.server;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.player.GameMode;
/*     */ import com.github.retrooper.packetevents.protocol.world.Difficulty;
/*     */ import com.github.retrooper.packetevents.protocol.world.Dimension;
/*     */ import com.github.retrooper.packetevents.protocol.world.DimensionType;
/*     */ import com.github.retrooper.packetevents.protocol.world.WorldBlockPosition;
/*     */ import com.github.retrooper.packetevents.protocol.world.WorldType;
/*     */ import com.github.retrooper.packetevents.resources.ResourceLocation;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.Optional;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class WrapperPlayServerRespawn extends PacketWrapper<WrapperPlayServerRespawn> {
/*     */   public static final byte KEEP_NOTHING = 0;
/*     */   
/*     */   public static final byte KEEP_ATTRIBUTES = 1;
/*     */   
/*     */   public static final byte KEEP_ENTITY_DATA = 2;
/*     */   
/*     */   public static final byte KEEP_ALL_DATA = 3;
/*     */   
/*     */   private Dimension dimension;
/*     */   
/*     */   private Optional<String> worldName;
/*     */   
/*     */   private Difficulty difficulty;
/*     */   
/*     */   private long hashedSeed;
/*     */   
/*     */   private GameMode gameMode;
/*     */   
/*     */   @Nullable
/*     */   private GameMode previousGameMode;
/*     */   
/*     */   private boolean worldDebug;
/*     */   
/*     */   private boolean worldFlat;
/*     */   
/*     */   private byte keptData;
/*     */   
/*     */   private WorldBlockPosition lastDeathPosition;
/*     */   
/*     */   private Integer portalCooldown;
/*     */   
/*     */   private String levelType;
/*     */   
/*     */   public WrapperPlayServerRespawn(PacketSendEvent event) {
/*  55 */     super(event);
/*     */   }
/*     */   
/*     */   public WrapperPlayServerRespawn(Dimension dimension, @Nullable String worldName, Difficulty difficulty, long hashedSeed, GameMode gameMode, @Nullable GameMode previousGameMode, boolean worldDebug, boolean worldFlat, boolean keepingAllPlayerData, @Nullable ResourceLocation deathDimensionName, @Nullable WorldBlockPosition lastDeathPosition, @Nullable Integer portalCooldown) {
/*  62 */     this(dimension, worldName, difficulty, hashedSeed, gameMode, previousGameMode, worldDebug, worldFlat, 
/*  63 */         keepingAllPlayerData ? 3 : 0, lastDeathPosition, portalCooldown);
/*     */   }
/*     */   
/*     */   public WrapperPlayServerRespawn(Dimension dimension, @Nullable String worldName, Difficulty difficulty, long hashedSeed, GameMode gameMode, @Nullable GameMode previousGameMode, boolean worldDebug, boolean worldFlat, byte keptData, @Nullable WorldBlockPosition lastDeathPosition, @Nullable Integer portalCooldown) {
/*  69 */     super((PacketTypeCommon)PacketType.Play.Server.RESPAWN);
/*  70 */     this.dimension = dimension;
/*  71 */     setWorldName(worldName);
/*  72 */     this.difficulty = difficulty;
/*  73 */     this.hashedSeed = hashedSeed;
/*  74 */     this.gameMode = gameMode;
/*  75 */     this.previousGameMode = previousGameMode;
/*  76 */     this.worldDebug = worldDebug;
/*  77 */     this.worldFlat = worldFlat;
/*  78 */     this.keptData = keptData;
/*  79 */     this.lastDeathPosition = lastDeathPosition;
/*  80 */     this.portalCooldown = portalCooldown;
/*     */   }
/*     */   
/*     */   public void read() {
/*  85 */     boolean v1_14 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_14);
/*  86 */     boolean v1_15_0 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_15);
/*  87 */     boolean v1_16_0 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16);
/*  88 */     boolean v1_19 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19);
/*  89 */     boolean v1_19_3 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19_3);
/*  90 */     boolean v1_20_2 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20_2);
/*  92 */     if (v1_16_0) {
/*  93 */       this.dimension = readDimension();
/*  94 */       this.worldName = Optional.of(readString());
/*  95 */       this.hashedSeed = readLong();
/*  96 */       if (v1_20_2) {
/*  97 */         this.gameMode = readGameMode();
/*     */       } else {
/*  99 */         this.gameMode = GameMode.getById(readUnsignedByte());
/*     */       } 
/* 101 */       this.previousGameMode = readGameMode();
/* 102 */       this.worldDebug = readBoolean();
/* 103 */       this.worldFlat = readBoolean();
/* 104 */       if (v1_19_3) {
/* 105 */         if (!v1_20_2)
/* 106 */           this.keptData = readByte(); 
/*     */       } else {
/* 109 */         this.keptData = readBoolean() ? 3 : 2;
/*     */       } 
/* 111 */       if (v1_19)
/* 112 */         this.lastDeathPosition = (WorldBlockPosition)readOptional(PacketWrapper::readWorldBlockPosition); 
/* 114 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20))
/* 115 */         this.portalCooldown = Integer.valueOf(readVarInt()); 
/* 117 */       if (v1_20_2)
/* 118 */         this.keptData = readByte(); 
/*     */     } else {
/* 121 */       this.dimension = new Dimension(readInt());
/* 123 */       this.worldName = Optional.empty();
/* 124 */       this.hashedSeed = 0L;
/* 125 */       if (v1_15_0) {
/* 126 */         this.hashedSeed = readLong();
/* 127 */       } else if (!v1_14) {
/* 128 */         this.difficulty = Difficulty.getById(readByte());
/*     */       } 
/* 132 */       this.gameMode = GameMode.getById(readByte());
/* 133 */       this.levelType = readString(16);
/* 134 */       this.worldFlat = DimensionType.isFlat(this.levelType);
/* 135 */       this.worldDebug = DimensionType.isDebug(this.levelType);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write() {
/* 141 */     boolean v1_14 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_14);
/* 142 */     boolean v1_15_0 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_15);
/* 143 */     boolean v1_16_0 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16);
/* 144 */     boolean v1_19 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19);
/* 145 */     boolean v1_19_3 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19_3);
/* 146 */     boolean v1_20_2 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20_2);
/* 148 */     if (v1_16_0) {
/* 149 */       writeDimension(this.dimension);
/* 150 */       writeString(this.worldName.orElse(""));
/* 151 */       writeLong(this.hashedSeed);
/* 152 */       writeGameMode(this.gameMode);
/* 153 */       writeGameMode(this.previousGameMode);
/* 154 */       writeBoolean(this.worldDebug);
/* 155 */       writeBoolean(this.worldFlat);
/* 156 */       if (v1_19_3) {
/* 157 */         if (!v1_20_2)
/* 158 */           writeByte(this.keptData); 
/*     */       } else {
/* 161 */         writeBoolean(((this.keptData & 0x1) != 0));
/*     */       } 
/* 163 */       if (v1_19)
/* 164 */         writeOptional(this.lastDeathPosition, PacketWrapper::writeWorldBlockPosition); 
/* 166 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20)) {
/* 167 */         int pCooldown = (this.portalCooldown != null) ? this.portalCooldown.intValue() : 0;
/* 168 */         writeVarInt(pCooldown);
/*     */       } 
/* 170 */       if (v1_20_2)
/* 171 */         writeByte(this.keptData); 
/*     */     } else {
/* 174 */       writeInt(this.dimension.getId());
/* 175 */       if (v1_15_0) {
/* 176 */         writeLong(this.hashedSeed);
/* 177 */       } else if (!v1_14) {
/* 179 */         int id = (this.difficulty == null) ? Difficulty.NORMAL.getId() : this.difficulty.getId();
/* 180 */         writeByte(id);
/*     */       } 
/* 184 */       writeByte(this.gameMode.ordinal());
/* 186 */       if (this.worldFlat) {
/* 187 */         writeString(WorldType.FLAT.getName());
/* 188 */       } else if (this.worldDebug) {
/* 189 */         writeString(WorldType.DEBUG_ALL_BLOCK_STATES.getName());
/*     */       } else {
/* 191 */         writeString((this.levelType == null) ? WorldType.DEFAULT.getName() : this.levelType, 16);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void copy(WrapperPlayServerRespawn wrapper) {
/* 198 */     this.dimension = wrapper.dimension;
/* 199 */     this.worldName = wrapper.worldName;
/* 200 */     this.difficulty = wrapper.difficulty;
/* 201 */     this.hashedSeed = wrapper.hashedSeed;
/* 202 */     this.gameMode = wrapper.gameMode;
/* 203 */     this.previousGameMode = wrapper.previousGameMode;
/* 204 */     this.worldDebug = wrapper.worldDebug;
/* 205 */     this.worldFlat = wrapper.worldFlat;
/* 206 */     this.keptData = wrapper.keptData;
/* 207 */     this.lastDeathPosition = wrapper.lastDeathPosition;
/*     */   }
/*     */   
/*     */   public Dimension getDimension() {
/* 211 */     return this.dimension;
/*     */   }
/*     */   
/*     */   public void setDimension(Dimension dimension) {
/* 215 */     this.dimension = dimension;
/*     */   }
/*     */   
/*     */   public Optional<String> getWorldName() {
/* 219 */     return this.worldName;
/*     */   }
/*     */   
/*     */   public void setWorldName(@Nullable String worldName) {
/* 223 */     this.worldName = Optional.ofNullable(worldName);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Difficulty getDifficulty() {
/* 227 */     return this.difficulty;
/*     */   }
/*     */   
/*     */   public void setDifficulty(Difficulty difficulty) {
/* 231 */     this.difficulty = difficulty;
/*     */   }
/*     */   
/*     */   public long getHashedSeed() {
/* 235 */     return this.hashedSeed;
/*     */   }
/*     */   
/*     */   public void setHashedSeed(long hashedSeed) {
/* 239 */     this.hashedSeed = hashedSeed;
/*     */   }
/*     */   
/*     */   public GameMode getGameMode() {
/* 243 */     return this.gameMode;
/*     */   }
/*     */   
/*     */   public void setGameMode(GameMode gameMode) {
/* 247 */     this.gameMode = gameMode;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public GameMode getPreviousGameMode() {
/* 252 */     return this.previousGameMode;
/*     */   }
/*     */   
/*     */   public void setPreviousGameMode(@Nullable GameMode previousGameMode) {
/* 256 */     this.previousGameMode = previousGameMode;
/*     */   }
/*     */   
/*     */   public boolean isWorldDebug() {
/* 260 */     return this.worldDebug;
/*     */   }
/*     */   
/*     */   public void setWorldDebug(boolean worldDebug) {
/* 264 */     this.worldDebug = worldDebug;
/*     */   }
/*     */   
/*     */   public boolean isWorldFlat() {
/* 268 */     return this.worldFlat;
/*     */   }
/*     */   
/*     */   public void setWorldFlat(boolean worldFlat) {
/* 272 */     this.worldFlat = worldFlat;
/*     */   }
/*     */   
/*     */   public boolean isKeepingAllPlayerData() {
/* 276 */     return ((this.keptData & 0x1) != 0);
/*     */   }
/*     */   
/*     */   public void setKeepingAllPlayerData(boolean keepAllPlayerData) {
/* 280 */     this.keptData = keepAllPlayerData ? 3 : 2;
/*     */   }
/*     */   
/*     */   public byte getKeptData() {
/* 284 */     return this.keptData;
/*     */   }
/*     */   
/*     */   public void setKeptData(byte keptData) {
/* 288 */     this.keptData = keptData;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public WorldBlockPosition getLastDeathPosition() {
/* 292 */     return this.lastDeathPosition;
/*     */   }
/*     */   
/*     */   public void setLastDeathPosition(@Nullable WorldBlockPosition lastDeathPosition) {
/* 296 */     this.lastDeathPosition = lastDeathPosition;
/*     */   }
/*     */   
/*     */   public Optional<Integer> getPortalCooldown() {
/* 300 */     return Optional.ofNullable(this.portalCooldown);
/*     */   }
/*     */   
/*     */   public void setPortalCooldown(int portalCooldown) {
/* 304 */     this.portalCooldown = Integer.valueOf(portalCooldown);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerRespawn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */