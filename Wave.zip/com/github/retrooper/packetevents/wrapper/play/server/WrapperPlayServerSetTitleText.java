/*    */ package com.github.retrooper.packetevents.wrapper.play.server;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import net.kyori.adventure.text.Component;
/*    */ 
/*    */ public class WrapperPlayServerSetTitleText extends PacketWrapper<WrapperPlayServerSetTitleText> {
/*    */   @Deprecated
/*    */   public static boolean HANDLE_JSON = true;
/*    */   
/*    */   private Component title;
/*    */   
/*    */   public WrapperPlayServerSetTitleText(PacketSendEvent event) {
/* 35 */     super(event);
/*    */   }
/*    */   
/*    */   public WrapperPlayServerSetTitleText(String titleJson) {
/* 39 */     this(AdventureSerializer.parseComponent(titleJson));
/*    */   }
/*    */   
/*    */   public WrapperPlayServerSetTitleText(Component title) {
/* 43 */     super((PacketTypeCommon)PacketType.Play.Server.SET_TITLE_TEXT);
/* 44 */     this.title = title;
/*    */   }
/*    */   
/*    */   public void read() {
/* 49 */     this.title = readComponent();
/*    */   }
/*    */   
/*    */   public void write() {
/* 54 */     writeComponent(this.title);
/*    */   }
/*    */   
/*    */   public void copy(WrapperPlayServerSetTitleText wrapper) {
/* 59 */     this.title = wrapper.title;
/*    */   }
/*    */   
/*    */   public Component getTitle() {
/* 63 */     return this.title;
/*    */   }
/*    */   
/*    */   public void setTitle(Component title) {
/* 67 */     this.title = title;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public String getTitleJson() {
/* 72 */     return AdventureSerializer.toJson(getTitle());
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void setTitleJson(String titleJson) {
/* 77 */     setTitle(AdventureSerializer.parseComponent(titleJson));
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerSetTitleText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */