/*    */ package com.github.retrooper.packetevents.wrapper.play.server;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class WrapperPlayServerDestroyEntities extends PacketWrapper<WrapperPlayServerDestroyEntities> {
/*    */   private int[] entityIDs;
/*    */   
/*    */   public WrapperPlayServerDestroyEntities(PacketSendEvent event) {
/* 30 */     super(event);
/*    */   }
/*    */   
/*    */   public WrapperPlayServerDestroyEntities(int... entityIDs) {
/* 34 */     super((PacketTypeCommon)PacketType.Play.Server.DESTROY_ENTITIES);
/* 35 */     this.entityIDs = entityIDs;
/*    */   }
/*    */   
/*    */   public WrapperPlayServerDestroyEntities(int entityID) {
/* 39 */     super((PacketTypeCommon)PacketType.Play.Server.DESTROY_ENTITIES);
/* 40 */     this.entityIDs = new int[] { entityID };
/*    */   }
/*    */   
/*    */   public void read() {
/* 45 */     if (this.serverVersion == ServerVersion.V_1_17) {
/* 46 */       this.entityIDs = new int[] { readVarInt() };
/* 48 */     } else if (this.serverVersion == ServerVersion.V_1_7_10) {
/* 49 */       int entityIDCount = readUnsignedByte();
/* 50 */       this.entityIDs = new int[entityIDCount];
/* 51 */       for (int i = 0; i < entityIDCount; i++)
/* 52 */         this.entityIDs[i] = readInt(); 
/*    */     } else {
/* 55 */       int entityIDCount = readVarInt();
/* 56 */       this.entityIDs = new int[entityIDCount];
/* 57 */       for (int i = 0; i < entityIDCount; i++)
/* 58 */         this.entityIDs[i] = readVarInt(); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void write() {
/* 66 */     if (this.serverVersion == ServerVersion.V_1_17) {
/* 67 */       writeVarInt(this.entityIDs[0]);
/* 69 */     } else if (this.serverVersion == ServerVersion.V_1_7_10) {
/* 70 */       writeByte(this.entityIDs.length);
/* 71 */       for (int entityID : this.entityIDs)
/* 72 */         writeInt(entityID); 
/*    */     } else {
/* 75 */       writeVarInt(this.entityIDs.length);
/* 76 */       for (int entityID : this.entityIDs)
/* 77 */         writeVarInt(entityID); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void copy(WrapperPlayServerDestroyEntities wrapper) {
/* 85 */     this.entityIDs = wrapper.entityIDs;
/*    */   }
/*    */   
/*    */   public int[] getEntityIds() {
/* 89 */     return this.entityIDs;
/*    */   }
/*    */   
/*    */   public void setEntityIds(int[] entityIDs) {
/* 93 */     this.entityIDs = entityIDs;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerDestroyEntities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */