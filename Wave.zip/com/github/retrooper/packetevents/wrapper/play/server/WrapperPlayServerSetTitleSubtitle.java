/*    */ package com.github.retrooper.packetevents.wrapper.play.server;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import net.kyori.adventure.text.Component;
/*    */ 
/*    */ public class WrapperPlayServerSetTitleSubtitle extends PacketWrapper<WrapperPlayServerSetTitleSubtitle> {
/*    */   @Deprecated
/*    */   public static boolean HANDLE_JSON = true;
/*    */   
/*    */   private Component subtitle;
/*    */   
/*    */   public WrapperPlayServerSetTitleSubtitle(PacketSendEvent event) {
/* 35 */     super(event);
/*    */   }
/*    */   
/*    */   public WrapperPlayServerSetTitleSubtitle(String subtitleJson) {
/* 39 */     this(AdventureSerializer.parseComponent(subtitleJson));
/*    */   }
/*    */   
/*    */   public WrapperPlayServerSetTitleSubtitle(Component subtitle) {
/* 43 */     super((PacketTypeCommon)PacketType.Play.Server.SET_TITLE_SUBTITLE);
/* 44 */     this.subtitle = subtitle;
/*    */   }
/*    */   
/*    */   public void read() {
/* 49 */     this.subtitle = readComponent();
/*    */   }
/*    */   
/*    */   public void write() {
/* 54 */     writeComponent(this.subtitle);
/*    */   }
/*    */   
/*    */   public void copy(WrapperPlayServerSetTitleSubtitle wrapper) {
/* 59 */     this.subtitle = wrapper.subtitle;
/*    */   }
/*    */   
/*    */   public Component getSubtitle() {
/* 63 */     return this.subtitle;
/*    */   }
/*    */   
/*    */   public void setSubtitle(Component subtitle) {
/* 67 */     this.subtitle = subtitle;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public String getSubtitleJson() {
/* 72 */     return AdventureSerializer.toJson(getSubtitle());
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void setSubtitleJson(String subtitleJson) {
/* 77 */     setSubtitle(AdventureSerializer.parseComponent(subtitleJson));
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerSetTitleSubtitle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */