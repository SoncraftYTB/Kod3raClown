/*    */ package com.github.retrooper.packetevents.wrapper.play.server;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class WrapperPlayServerCloseWindow extends PacketWrapper<WrapperPlayServerCloseWindow> {
/*    */   private int windowId;
/*    */   
/*    */   public WrapperPlayServerCloseWindow(PacketSendEvent event) {
/* 29 */     super(event);
/*    */   }
/*    */   
/*    */   public WrapperPlayServerCloseWindow(int id) {
/* 33 */     super((PacketTypeCommon)PacketType.Play.Server.CLOSE_WINDOW);
/* 34 */     this.windowId = id;
/*    */   }
/*    */   
/*    */   public void read() {
/* 39 */     this.windowId = readUnsignedByte();
/*    */   }
/*    */   
/*    */   public void write() {
/* 44 */     writeByte(this.windowId);
/*    */   }
/*    */   
/*    */   public void copy(WrapperPlayServerCloseWindow wrapper) {
/* 49 */     this.windowId = wrapper.windowId;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public int getWindowId() {
/* 57 */     return this.windowId;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void setWindowId(int windowId) {
/* 65 */     this.windowId = windowId;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerCloseWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */