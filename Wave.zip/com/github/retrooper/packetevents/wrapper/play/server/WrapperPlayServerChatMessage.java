/*    */ package com.github.retrooper.packetevents.wrapper.play.server;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*    */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.ChatMessage;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.ChatMessageProcessor;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.impl.ChatMessageProcessorLegacy;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.impl.ChatMessageProcessor_v1_16;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.impl.ChatMessageProcessor_v1_19;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.impl.ChatMessageProcessor_v1_19_1;
/*    */ import com.github.retrooper.packetevents.protocol.chat.message.reader.impl.ChatMessageProcessor_v1_19_3;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ public class WrapperPlayServerChatMessage extends PacketWrapper<WrapperPlayServerChatMessage> {
/* 38 */   private static final ChatMessageProcessor CHAT_LEGACY_PROCESSOR = (ChatMessageProcessor)new ChatMessageProcessorLegacy();
/*    */   
/* 39 */   private static final ChatMessageProcessor CHAT_V1_16_PROCESSOR = (ChatMessageProcessor)new ChatMessageProcessor_v1_16();
/*    */   
/* 40 */   private static final ChatMessageProcessor CHAT_V1_19_PROCESSOR = (ChatMessageProcessor)new ChatMessageProcessor_v1_19();
/*    */   
/* 41 */   private static final ChatMessageProcessor CHAT_V1_19_1_PROCESSOR = (ChatMessageProcessor)new ChatMessageProcessor_v1_19_1();
/*    */   
/* 42 */   private static final ChatMessageProcessor CHAT_V1_19_3_PROCESSOR = (ChatMessageProcessor)new ChatMessageProcessor_v1_19_3();
/*    */   
/*    */   private ChatMessage message;
/*    */   
/*    */   public WrapperPlayServerChatMessage(PacketSendEvent event) {
/* 48 */     super(event);
/*    */   }
/*    */   
/*    */   public WrapperPlayServerChatMessage(ChatMessage message) {
/* 52 */     super((PacketTypeCommon)PacketType.Play.Server.CHAT_MESSAGE);
/* 53 */     this.message = message;
/*    */   }
/*    */   
/*    */   public void read() {
/* 58 */     this.message = getProcessor().readChatMessage(this);
/*    */   }
/*    */   
/*    */   public void write() {
/* 63 */     getProcessor().writeChatMessage(this, this.message);
/*    */   }
/*    */   
/*    */   public void copy(WrapperPlayServerChatMessage wrapper) {
/* 68 */     this.message = wrapper.message;
/*    */   }
/*    */   
/*    */   public ChatMessage getMessage() {
/* 72 */     return this.message;
/*    */   }
/*    */   
/*    */   public void setMessage(ChatMessage message) {
/* 76 */     this.message = message;
/*    */   }
/*    */   
/*    */   @Internal
/*    */   protected ChatMessageProcessor getProcessor() {
/* 81 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19_3))
/* 82 */       return CHAT_V1_19_3_PROCESSOR; 
/* 83 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19_1))
/* 84 */       return CHAT_V1_19_1_PROCESSOR; 
/* 85 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19))
/* 86 */       return CHAT_V1_19_PROCESSOR; 
/* 87 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16))
/* 88 */       return CHAT_V1_16_PROCESSOR; 
/* 90 */     return CHAT_LEGACY_PROCESSOR;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerChatMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */