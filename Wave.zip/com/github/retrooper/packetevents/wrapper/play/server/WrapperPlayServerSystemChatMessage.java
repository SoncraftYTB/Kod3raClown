/*     */ package com.github.retrooper.packetevents.wrapper.play.server;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.chat.ChatType;
/*     */ import com.github.retrooper.packetevents.protocol.chat.ChatTypes;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.util.adventure.AdventureSerializer;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import net.kyori.adventure.text.Component;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class WrapperPlayServerSystemChatMessage extends PacketWrapper<WrapperPlayServerSystemChatMessage> {
/*     */   @Deprecated
/*     */   public static boolean HANDLE_JSON = true;
/*     */   
/*     */   @Nullable
/*     */   private ChatType type;
/*     */   
/*     */   private boolean overlay;
/*     */   
/*     */   private Component message;
/*     */   
/*     */   public WrapperPlayServerSystemChatMessage(PacketSendEvent event) {
/*  50 */     super(event);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WrapperPlayServerSystemChatMessage(@NotNull ChatType type, Component message) {
/*  55 */     super((PacketTypeCommon)PacketType.Play.Server.SYSTEM_CHAT_MESSAGE);
/*  56 */     this.type = type;
/*  57 */     if (type == ChatTypes.GAME_INFO)
/*  58 */       this.overlay = true; 
/*  60 */     this.message = message;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WrapperPlayServerSystemChatMessage(@NotNull ChatType type, String messageJson) {
/*  65 */     super((PacketTypeCommon)PacketType.Play.Server.SYSTEM_CHAT_MESSAGE);
/*  66 */     this.message = AdventureSerializer.parseComponent(messageJson);
/*  67 */     this.type = type;
/*  68 */     if (type == ChatTypes.GAME_INFO)
/*  69 */       this.overlay = true; 
/*     */   }
/*     */   
/*     */   public WrapperPlayServerSystemChatMessage(boolean overlay, Component message) {
/*  74 */     super((PacketTypeCommon)PacketType.Play.Server.SYSTEM_CHAT_MESSAGE);
/*  75 */     this.message = message;
/*  76 */     this.overlay = overlay;
/*  77 */     this.type = overlay ? ChatTypes.GAME_INFO : ChatTypes.SYSTEM;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WrapperPlayServerSystemChatMessage(boolean overlay, String messageJson) {
/*  82 */     super((PacketTypeCommon)PacketType.Play.Server.SYSTEM_CHAT_MESSAGE);
/*  83 */     this.message = AdventureSerializer.parseComponent(messageJson);
/*  84 */     this.overlay = overlay;
/*  85 */     this.type = overlay ? ChatTypes.GAME_INFO : ChatTypes.SYSTEM;
/*     */   }
/*     */   
/*     */   public void read() {
/*  90 */     this.message = readComponent();
/*  91 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19_1)) {
/*  92 */       this.overlay = readBoolean();
/*     */     } else {
/*  94 */       this.type = ChatTypes.getById(this.serverVersion.toClientVersion(), readVarInt());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write() {
/* 100 */     writeComponent(this.message);
/* 101 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19_1)) {
/* 102 */       writeBoolean(this.overlay);
/* 104 */     } else if (this.type == null) {
/* 105 */       if (this.overlay) {
/* 106 */         writeVarInt(ChatTypes.GAME_INFO.getId(this.serverVersion.toClientVersion()));
/*     */       } else {
/* 108 */         writeVarInt(ChatTypes.SYSTEM.getId(this.serverVersion.toClientVersion()));
/*     */       } 
/*     */     } else {
/* 111 */       writeVarInt(this.type.getId(this.serverVersion.toClientVersion()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void copy(WrapperPlayServerSystemChatMessage wrapper) {
/* 118 */     this.type = wrapper.type;
/* 119 */     this.overlay = wrapper.overlay;
/* 120 */     this.message = wrapper.message;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Nullable
/*     */   public ChatType getType() {
/* 125 */     return this.type;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setType(@Nullable ChatType type) {
/* 130 */     this.type = type;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public String getMessageJson() {
/* 135 */     return AdventureSerializer.toJson(getMessage());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setMessageJson(String messageJson) {
/* 140 */     setMessage(AdventureSerializer.parseComponent(messageJson));
/*     */   }
/*     */   
/*     */   public Component getMessage() {
/* 144 */     return this.message;
/*     */   }
/*     */   
/*     */   public void setMessage(Component message) {
/* 148 */     this.message = message;
/*     */   }
/*     */   
/*     */   public boolean isOverlay() {
/* 152 */     return this.overlay;
/*     */   }
/*     */   
/*     */   public void setOverlay(boolean overlay) {
/* 156 */     this.overlay = overlay;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerSystemChatMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */