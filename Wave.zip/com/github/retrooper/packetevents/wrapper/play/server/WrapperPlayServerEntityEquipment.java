/*     */ package com.github.retrooper.packetevents.wrapper.play.server;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.item.ItemStack;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.player.Equipment;
/*     */ import com.github.retrooper.packetevents.protocol.player.EquipmentSlot;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class WrapperPlayServerEntityEquipment extends PacketWrapper<WrapperPlayServerEntityEquipment> {
/*     */   private int entityId;
/*     */   
/*     */   private List<Equipment> equipment;
/*     */   
/*     */   public WrapperPlayServerEntityEquipment(PacketSendEvent event) {
/*  37 */     super(event);
/*     */   }
/*     */   
/*     */   public WrapperPlayServerEntityEquipment(int entityId, List<Equipment> equipment) {
/*  41 */     super((PacketTypeCommon)PacketType.Play.Server.ENTITY_EQUIPMENT);
/*  42 */     this.entityId = entityId;
/*  43 */     this.equipment = equipment;
/*     */   }
/*     */   
/*     */   public void read() {
/*  48 */     if (this.serverVersion == ServerVersion.V_1_7_10) {
/*  49 */       this.entityId = readInt();
/*     */     } else {
/*  51 */       this.entityId = readVarInt();
/*     */     } 
/*  53 */     this.equipment = new ArrayList<>();
/*  54 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16)) {
/*     */       byte value;
/*     */       do {
/*  57 */         value = readByte();
/*  58 */         EquipmentSlot equipmentSlot = EquipmentSlot.getById(this.serverVersion, value & Byte.MAX_VALUE);
/*  59 */         ItemStack itemStack = readItemStack();
/*  60 */         this.equipment.add(new Equipment(equipmentSlot, itemStack));
/*  61 */       } while ((value & Byte.MIN_VALUE) != 0);
/*     */     } else {
/*     */       EquipmentSlot slot;
/*  64 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9)) {
/*  65 */         slot = EquipmentSlot.getById(this.serverVersion, readVarInt());
/*     */       } else {
/*  67 */         slot = EquipmentSlot.getById(this.serverVersion, readShort());
/*     */       } 
/*  69 */       this.equipment.add(new Equipment(slot, readItemStack()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write() {
/*  75 */     if (this.serverVersion == ServerVersion.V_1_7_10) {
/*  76 */       writeInt(this.entityId);
/*     */     } else {
/*  78 */       writeVarInt(this.entityId);
/*     */     } 
/*  80 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16)) {
/*  81 */       for (int i = 0; i < this.equipment.size(); i++) {
/*  82 */         Equipment equipment = this.equipment.get(i);
/*  83 */         boolean last = (i == this.equipment.size() - 1);
/*  84 */         writeByte(last ? equipment.getSlot().getId(this.serverVersion) : (equipment.getSlot().getId(this.serverVersion) | 0xFFFFFF80));
/*  85 */         writeItemStack(equipment.getItem());
/*     */       } 
/*     */     } else {
/*  88 */       Equipment equipment = this.equipment.get(0);
/*  89 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9)) {
/*  90 */         writeVarInt(equipment.getSlot().getId(this.serverVersion));
/*     */       } else {
/*  92 */         writeShort(equipment.getSlot().getId(this.serverVersion));
/*     */       } 
/*  94 */       writeItemStack(equipment.getItem());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void copy(WrapperPlayServerEntityEquipment wrapper) {
/* 100 */     this.entityId = wrapper.entityId;
/* 101 */     this.equipment = wrapper.equipment;
/*     */   }
/*     */   
/*     */   public int getEntityId() {
/* 105 */     return this.entityId;
/*     */   }
/*     */   
/*     */   public void setEntityId(int entityId) {
/* 109 */     this.entityId = entityId;
/*     */   }
/*     */   
/*     */   public List<Equipment> getEquipment() {
/* 113 */     return this.equipment;
/*     */   }
/*     */   
/*     */   public void setEquipment(List<Equipment> equipment) {
/* 117 */     this.equipment = equipment;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerEntityEquipment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */