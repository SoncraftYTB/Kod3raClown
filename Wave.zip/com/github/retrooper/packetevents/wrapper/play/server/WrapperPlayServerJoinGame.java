/*     */ package com.github.retrooper.packetevents.wrapper.play.server;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.player.GameMode;
/*     */ import com.github.retrooper.packetevents.protocol.world.Difficulty;
/*     */ import com.github.retrooper.packetevents.protocol.world.Dimension;
/*     */ import com.github.retrooper.packetevents.protocol.world.DimensionType;
/*     */ import com.github.retrooper.packetevents.protocol.world.WorldBlockPosition;
/*     */ import com.github.retrooper.packetevents.protocol.world.WorldType;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class WrapperPlayServerJoinGame extends PacketWrapper<WrapperPlayServerJoinGame> {
/*     */   private int entityID;
/*     */   
/*     */   private boolean hardcore;
/*     */   
/*     */   private GameMode gameMode;
/*     */   
/*     */   @Nullable
/*     */   private GameMode previousGameMode;
/*     */   
/*     */   private List<String> worldNames;
/*     */   
/*     */   private NBTCompound dimensionCodec;
/*     */   
/*     */   private Dimension dimension;
/*     */   
/*     */   private Difficulty difficulty;
/*     */   
/*     */   private String worldName;
/*     */   
/*     */   private long hashedSeed;
/*     */   
/*     */   private int maxPlayers;
/*     */   
/*     */   private int viewDistance;
/*     */   
/*     */   private int simulationDistance;
/*     */   
/*     */   private boolean reducedDebugInfo;
/*     */   
/*     */   private boolean enableRespawnScreen;
/*     */   
/*     */   private boolean limitedCrafting;
/*     */   
/*     */   private boolean isDebug;
/*     */   
/*     */   private boolean isFlat;
/*     */   
/*     */   private WorldBlockPosition lastDeathPosition;
/*     */   
/*     */   private Integer portalCooldown;
/*     */   
/*     */   public WrapperPlayServerJoinGame(PacketSendEvent event) {
/*  60 */     super(event);
/*     */   }
/*     */   
/*     */   public WrapperPlayServerJoinGame(int entityID, boolean hardcore, GameMode gameMode, @Nullable GameMode previousGameMode, List<String> worldNames, NBTCompound dimensionCodec, Dimension dimension, Difficulty difficulty, String worldName, long hashedSeed, int maxPlayers, int viewDistance, int simulationDistance, boolean reducedDebugInfo, boolean enableRespawnScreen, boolean isDebug, boolean isFlat, WorldBlockPosition lastDeathPosition, @Nullable Integer portalCooldown) {
/*  70 */     this(entityID, hardcore, gameMode, previousGameMode, worldNames, dimensionCodec, dimension, difficulty, worldName, hashedSeed, maxPlayers, viewDistance, simulationDistance, reducedDebugInfo, enableRespawnScreen, false, isDebug, isFlat, lastDeathPosition, portalCooldown);
/*     */   }
/*     */   
/*     */   public WrapperPlayServerJoinGame(int entityID, boolean hardcore, GameMode gameMode, @Nullable GameMode previousGameMode, List<String> worldNames, NBTCompound dimensionCodec, Dimension dimension, Difficulty difficulty, String worldName, long hashedSeed, int maxPlayers, int viewDistance, int simulationDistance, boolean reducedDebugInfo, boolean enableRespawnScreen, boolean limitedCrafting, boolean isDebug, boolean isFlat, WorldBlockPosition lastDeathPosition, @Nullable Integer portalCooldown) {
/*  82 */     super((PacketTypeCommon)PacketType.Play.Server.JOIN_GAME);
/*  83 */     this.entityID = entityID;
/*  84 */     this.hardcore = hardcore;
/*  85 */     this.gameMode = gameMode;
/*  86 */     this.previousGameMode = previousGameMode;
/*  87 */     this.worldNames = worldNames;
/*  88 */     this.dimensionCodec = dimensionCodec;
/*  89 */     this.dimension = dimension;
/*  90 */     this.difficulty = difficulty;
/*  91 */     this.worldName = worldName;
/*  92 */     this.hashedSeed = hashedSeed;
/*  93 */     this.maxPlayers = maxPlayers;
/*  94 */     this.viewDistance = viewDistance;
/*  95 */     this.simulationDistance = simulationDistance;
/*  96 */     this.reducedDebugInfo = reducedDebugInfo;
/*  97 */     this.enableRespawnScreen = enableRespawnScreen;
/*  98 */     this.limitedCrafting = limitedCrafting;
/*  99 */     this.isDebug = isDebug;
/* 100 */     this.isFlat = isFlat;
/* 101 */     this.lastDeathPosition = lastDeathPosition;
/* 102 */     this.portalCooldown = portalCooldown;
/*     */   }
/*     */   
/*     */   public void read() {
/* 107 */     this.entityID = readInt();
/* 108 */     boolean v1_20_2 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20_2);
/* 109 */     boolean v1_19 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19);
/* 110 */     boolean v1_18 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_18);
/* 111 */     boolean v1_16 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16);
/* 112 */     boolean v1_15 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_15);
/* 113 */     boolean v1_14 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_14);
/* 114 */     if (v1_16) {
/* 115 */       this.hardcore = readBoolean();
/* 116 */       if (!v1_20_2)
/* 117 */         this.gameMode = readGameMode(); 
/*     */     } else {
/* 120 */       int gameModeId = readUnsignedByte();
/* 121 */       this.hardcore = ((gameModeId & 0x8) == 8);
/* 122 */       this.gameMode = GameMode.getById(gameModeId & 0xFFFFFFF7);
/*     */     } 
/* 124 */     if (v1_16) {
/* 125 */       if (!v1_20_2)
/* 126 */         this.previousGameMode = readGameMode(); 
/* 128 */       int worldCount = readVarInt();
/* 129 */       this.worldNames = new ArrayList<>(worldCount);
/* 130 */       for (int i = 0; i < worldCount; i++)
/* 131 */         this.worldNames.add(readString()); 
/* 133 */       if (!v1_20_2) {
/* 134 */         this.dimensionCodec = readNBT();
/* 135 */         this.dimension = readDimension();
/* 136 */         this.worldName = readString();
/*     */       } 
/*     */     } else {
/* 139 */       this.previousGameMode = this.gameMode;
/* 140 */       this.dimensionCodec = new NBTCompound();
/* 141 */       this.dimension = new Dimension(this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9_2) ? readInt() : readByte());
/* 142 */       if (!v1_14)
/* 143 */         this.difficulty = Difficulty.getById(readByte()); 
/*     */     } 
/* 146 */     if (v1_15 && !v1_20_2)
/* 147 */       this.hashedSeed = readLong(); 
/* 149 */     if (v1_16) {
/* 150 */       this.maxPlayers = readVarInt();
/* 151 */       this.viewDistance = readVarInt();
/* 152 */       if (v1_18)
/* 152 */         this.simulationDistance = readVarInt(); 
/* 153 */       this.reducedDebugInfo = readBoolean();
/* 154 */       this.enableRespawnScreen = readBoolean();
/* 155 */       if (v1_20_2) {
/* 156 */         this.limitedCrafting = readBoolean();
/* 157 */         this.dimension = readDimension();
/* 158 */         this.worldName = readString();
/* 159 */         this.hashedSeed = readLong();
/* 160 */         this.gameMode = readGameMode();
/* 161 */         this.previousGameMode = readGameMode();
/*     */       } 
/* 163 */       this.isDebug = readBoolean();
/* 164 */       this.isFlat = readBoolean();
/*     */     } else {
/* 166 */       this.maxPlayers = readUnsignedByte();
/* 167 */       String levelType = readString(16);
/* 168 */       this.isFlat = DimensionType.isFlat(levelType);
/* 169 */       this.isDebug = DimensionType.isDebug(levelType);
/* 170 */       if (v1_14)
/* 171 */         this.viewDistance = readVarInt(); 
/* 173 */       this.reducedDebugInfo = readBoolean();
/* 174 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_15))
/* 175 */         this.enableRespawnScreen = readBoolean(); 
/*     */     } 
/* 178 */     if (v1_19)
/* 179 */       this.lastDeathPosition = (WorldBlockPosition)readOptional(PacketWrapper::readWorldBlockPosition); 
/* 181 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20))
/* 182 */       this.portalCooldown = Integer.valueOf(readVarInt()); 
/*     */   }
/*     */   
/*     */   public void write() {
/* 188 */     writeInt(this.entityID);
/* 189 */     boolean v1_20_2 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20_2);
/* 190 */     boolean v1_19 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19);
/* 191 */     boolean v1_18 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_18);
/* 192 */     boolean v1_16 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16);
/* 193 */     boolean v1_14 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_14);
/* 194 */     boolean v1_15 = this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_15);
/* 195 */     if (v1_16) {
/* 196 */       writeBoolean(this.hardcore);
/* 197 */       if (!v1_20_2)
/* 198 */         writeGameMode(this.gameMode); 
/*     */     } else {
/* 201 */       int gameModeId = this.gameMode.getId();
/* 202 */       if (this.hardcore)
/* 203 */         gameModeId |= 0x8; 
/* 205 */       writeByte(gameModeId);
/*     */     } 
/* 207 */     if (v1_16) {
/* 208 */       if (this.previousGameMode == null)
/* 209 */         this.previousGameMode = this.gameMode; 
/* 211 */       if (!v1_20_2)
/* 212 */         writeGameMode(this.previousGameMode); 
/* 214 */       writeVarInt(this.worldNames.size());
/* 215 */       for (String name : this.worldNames)
/* 216 */         writeString(name); 
/* 218 */       if (!v1_20_2) {
/* 219 */         writeNBT(this.dimensionCodec);
/* 220 */         writeDimension(this.dimension);
/* 221 */         writeString(this.worldName);
/*     */       } 
/*     */     } else {
/* 224 */       this.previousGameMode = this.gameMode;
/* 225 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9)) {
/* 226 */         writeInt(this.dimension.getId());
/*     */       } else {
/* 228 */         writeByte(this.dimension.getId());
/*     */       } 
/* 230 */       if (!v1_14)
/* 231 */         writeByte(this.difficulty.getId()); 
/*     */     } 
/* 234 */     if (v1_15 && !v1_20_2)
/* 235 */       writeLong(this.hashedSeed); 
/* 237 */     if (v1_16) {
/* 238 */       writeVarInt(this.maxPlayers);
/* 239 */       writeVarInt(this.viewDistance);
/* 240 */       if (v1_18)
/* 240 */         writeVarInt(this.simulationDistance); 
/* 241 */       writeBoolean(this.reducedDebugInfo);
/* 242 */       writeBoolean(this.enableRespawnScreen);
/* 243 */       if (v1_20_2) {
/* 244 */         writeBoolean(this.limitedCrafting);
/* 245 */         writeDimension(this.dimension);
/* 246 */         writeString(this.worldName);
/* 247 */         writeLong(this.hashedSeed);
/* 248 */         writeGameMode(this.gameMode);
/* 249 */         writeGameMode(this.previousGameMode);
/*     */       } 
/* 251 */       writeBoolean(this.isDebug);
/* 252 */       writeBoolean(this.isFlat);
/*     */     } else {
/*     */       String levelType;
/* 254 */       writeByte(this.maxPlayers);
/* 257 */       if (this.isFlat) {
/* 258 */         levelType = WorldType.FLAT.getName();
/* 259 */       } else if (this.isDebug) {
/* 260 */         levelType = WorldType.DEBUG_ALL_BLOCK_STATES.getName();
/*     */       } else {
/* 262 */         levelType = WorldType.DEFAULT.getName();
/*     */       } 
/* 264 */       writeString(levelType, 16);
/* 265 */       if (v1_14)
/* 266 */         writeVarInt(this.viewDistance); 
/* 268 */       writeBoolean(this.reducedDebugInfo);
/* 269 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_15))
/* 270 */         writeBoolean(this.enableRespawnScreen); 
/*     */     } 
/* 273 */     if (v1_19)
/* 274 */       writeOptional(this.lastDeathPosition, PacketWrapper::writeWorldBlockPosition); 
/* 276 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_20)) {
/* 277 */       int pCooldown = (this.portalCooldown != null) ? this.portalCooldown.intValue() : 0;
/* 278 */       writeVarInt(pCooldown);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void copy(WrapperPlayServerJoinGame wrapper) {
/* 284 */     this.entityID = wrapper.entityID;
/* 285 */     this.hardcore = wrapper.hardcore;
/* 286 */     this.gameMode = wrapper.gameMode;
/* 287 */     this.previousGameMode = wrapper.previousGameMode;
/* 288 */     this.worldNames = wrapper.worldNames;
/* 289 */     this.dimensionCodec = wrapper.dimensionCodec;
/* 290 */     this.dimension = wrapper.dimension;
/* 291 */     this.difficulty = wrapper.difficulty;
/* 292 */     this.worldName = wrapper.worldName;
/* 293 */     this.hashedSeed = wrapper.hashedSeed;
/* 294 */     this.maxPlayers = wrapper.maxPlayers;
/* 295 */     this.viewDistance = wrapper.viewDistance;
/* 296 */     this.simulationDistance = wrapper.simulationDistance;
/* 297 */     this.reducedDebugInfo = wrapper.reducedDebugInfo;
/* 298 */     this.enableRespawnScreen = wrapper.enableRespawnScreen;
/* 299 */     this.limitedCrafting = wrapper.limitedCrafting;
/* 300 */     this.isDebug = wrapper.isDebug;
/* 301 */     this.isFlat = wrapper.isFlat;
/* 302 */     this.lastDeathPosition = wrapper.lastDeathPosition;
/* 303 */     this.portalCooldown = wrapper.portalCooldown;
/*     */   }
/*     */   
/*     */   public int getEntityId() {
/* 307 */     return this.entityID;
/*     */   }
/*     */   
/*     */   public void setEntityId(int entityID) {
/* 311 */     this.entityID = entityID;
/*     */   }
/*     */   
/*     */   public boolean isHardcore() {
/* 315 */     return this.hardcore;
/*     */   }
/*     */   
/*     */   public void setHardcore(boolean hardcore) {
/* 319 */     this.hardcore = hardcore;
/*     */   }
/*     */   
/*     */   public GameMode getGameMode() {
/* 323 */     return this.gameMode;
/*     */   }
/*     */   
/*     */   public void setGameMode(GameMode gameMode) {
/* 327 */     this.gameMode = gameMode;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public GameMode getPreviousGameMode() {
/* 332 */     return this.previousGameMode;
/*     */   }
/*     */   
/*     */   public void setPreviousGameMode(@Nullable GameMode previousGameMode) {
/* 336 */     this.previousGameMode = previousGameMode;
/*     */   }
/*     */   
/*     */   public List<String> getWorldNames() {
/* 340 */     return this.worldNames;
/*     */   }
/*     */   
/*     */   public void setWorldNames(List<String> worldNames) {
/* 344 */     this.worldNames = worldNames;
/*     */   }
/*     */   
/*     */   public NBTCompound getDimensionCodec() {
/* 348 */     return this.dimensionCodec;
/*     */   }
/*     */   
/*     */   public void setDimensionCodec(NBTCompound dimensionCodec) {
/* 352 */     this.dimensionCodec = dimensionCodec;
/*     */   }
/*     */   
/*     */   public Dimension getDimension() {
/* 356 */     return this.dimension;
/*     */   }
/*     */   
/*     */   public void setDimension(Dimension dimension) {
/* 360 */     this.dimension = dimension;
/*     */   }
/*     */   
/*     */   public Difficulty getDifficulty() {
/* 364 */     return this.difficulty;
/*     */   }
/*     */   
/*     */   public void setDifficulty(Difficulty difficulty) {
/* 368 */     this.difficulty = difficulty;
/*     */   }
/*     */   
/*     */   public String getWorldName() {
/* 372 */     return this.worldName;
/*     */   }
/*     */   
/*     */   public void setWorldName(String worldName) {
/* 376 */     this.worldName = worldName;
/*     */   }
/*     */   
/*     */   public long getHashedSeed() {
/* 380 */     return this.hashedSeed;
/*     */   }
/*     */   
/*     */   public void setHashedSeed(long hashedSeed) {
/* 384 */     this.hashedSeed = hashedSeed;
/*     */   }
/*     */   
/*     */   public int getMaxPlayers() {
/* 388 */     return this.maxPlayers;
/*     */   }
/*     */   
/*     */   public void setMaxPlayers(int maxPlayers) {
/* 392 */     this.maxPlayers = maxPlayers;
/*     */   }
/*     */   
/*     */   public int getViewDistance() {
/* 396 */     return this.viewDistance;
/*     */   }
/*     */   
/*     */   public void setViewDistance(int viewDistance) {
/* 400 */     this.viewDistance = viewDistance;
/*     */   }
/*     */   
/*     */   public int getSimulationDistance() {
/* 404 */     return this.simulationDistance;
/*     */   }
/*     */   
/*     */   public void setSimulationDistance(int simulationDistance) {
/* 408 */     this.simulationDistance = simulationDistance;
/*     */   }
/*     */   
/*     */   public boolean isReducedDebugInfo() {
/* 412 */     return this.reducedDebugInfo;
/*     */   }
/*     */   
/*     */   public void setReducedDebugInfo(boolean reducedDebugInfo) {
/* 416 */     this.reducedDebugInfo = reducedDebugInfo;
/*     */   }
/*     */   
/*     */   public boolean isRespawnScreenEnabled() {
/* 420 */     return this.enableRespawnScreen;
/*     */   }
/*     */   
/*     */   public void setRespawnScreenEnabled(boolean enableRespawnScreen) {
/* 424 */     this.enableRespawnScreen = enableRespawnScreen;
/*     */   }
/*     */   
/*     */   public boolean isLimitedCrafting() {
/* 428 */     return this.limitedCrafting;
/*     */   }
/*     */   
/*     */   public void setLimitedCrafting(boolean limitedCrafting) {
/* 432 */     this.limitedCrafting = limitedCrafting;
/*     */   }
/*     */   
/*     */   public boolean isDebug() {
/* 436 */     return this.isDebug;
/*     */   }
/*     */   
/*     */   public void setDebug(boolean isDebug) {
/* 440 */     this.isDebug = isDebug;
/*     */   }
/*     */   
/*     */   public boolean isFlat() {
/* 444 */     return this.isFlat;
/*     */   }
/*     */   
/*     */   public void setFlat(boolean isFlat) {
/* 448 */     this.isFlat = isFlat;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public WorldBlockPosition getLastDeathPosition() {
/* 452 */     return this.lastDeathPosition;
/*     */   }
/*     */   
/*     */   public void setLastDeathPosition(@Nullable WorldBlockPosition lastDeathPosition) {
/* 456 */     this.lastDeathPosition = lastDeathPosition;
/*     */   }
/*     */   
/*     */   public Optional<Integer> getPortalCooldown() {
/* 460 */     return Optional.ofNullable(this.portalCooldown);
/*     */   }
/*     */   
/*     */   public void setPortalCooldown(int portalCooldown) {
/* 464 */     this.portalCooldown = Integer.valueOf(portalCooldown);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerJoinGame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */