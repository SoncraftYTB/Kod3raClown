/*    */ package com.github.retrooper.packetevents.wrapper.play.server;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class WrapperPlayServerSetTitleTimes extends PacketWrapper<WrapperPlayServerSetTitleTimes> {
/*    */   private int fadeInTicks;
/*    */   
/*    */   private int stayTicks;
/*    */   
/*    */   private int fadeOutTicks;
/*    */   
/*    */   public WrapperPlayServerSetTitleTimes(PacketSendEvent event) {
/* 31 */     super(event);
/*    */   }
/*    */   
/*    */   public WrapperPlayServerSetTitleTimes(int fadeInTicks, int stayTicks, int fadeOutTicks) {
/* 35 */     super((PacketTypeCommon)PacketType.Play.Server.SET_TITLE_TIMES);
/* 36 */     this.fadeInTicks = fadeInTicks;
/* 37 */     this.stayTicks = stayTicks;
/* 38 */     this.fadeOutTicks = fadeOutTicks;
/*    */   }
/*    */   
/*    */   public void read() {
/* 43 */     this.fadeInTicks = readInt();
/* 44 */     this.stayTicks = readInt();
/* 45 */     this.fadeOutTicks = readInt();
/*    */   }
/*    */   
/*    */   public void write() {
/* 50 */     writeInt(this.fadeInTicks);
/* 51 */     writeInt(this.stayTicks);
/* 52 */     writeInt(this.fadeOutTicks);
/*    */   }
/*    */   
/*    */   public void copy(WrapperPlayServerSetTitleTimes wrapper) {
/* 57 */     this.fadeInTicks = wrapper.fadeInTicks;
/* 58 */     this.stayTicks = wrapper.stayTicks;
/* 59 */     this.fadeOutTicks = wrapper.fadeOutTicks;
/*    */   }
/*    */   
/*    */   public int getFadeInTicks() {
/* 63 */     return this.fadeInTicks;
/*    */   }
/*    */   
/*    */   public void setFadeInTicks(int fadeInTicks) {
/* 67 */     this.fadeInTicks = fadeInTicks;
/*    */   }
/*    */   
/*    */   public int getStayTicks() {
/* 71 */     return this.stayTicks;
/*    */   }
/*    */   
/*    */   public void setStayTicks(int stayTicks) {
/* 75 */     this.stayTicks = stayTicks;
/*    */   }
/*    */   
/*    */   public int getFadeOutTicks() {
/* 79 */     return this.fadeOutTicks;
/*    */   }
/*    */   
/*    */   public void setFadeOutTicks(int fadeOutTicks) {
/* 83 */     this.fadeOutTicks = fadeOutTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\server\WrapperPlayServerSetTitleTimes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */