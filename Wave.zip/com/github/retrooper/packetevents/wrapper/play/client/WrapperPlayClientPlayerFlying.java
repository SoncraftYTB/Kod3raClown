/*     */ package com.github.retrooper.packetevents.wrapper.play.client;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*     */ import com.github.retrooper.packetevents.event.ProtocolPacketEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.world.Location;
/*     */ import com.github.retrooper.packetevents.util.Vector3d;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ 
/*     */ public class WrapperPlayClientPlayerFlying extends PacketWrapper<WrapperPlayClientPlayerFlying> {
/*     */   private boolean positionChanged;
/*     */   
/*     */   private boolean rotationChanged;
/*     */   
/*     */   private Location location;
/*     */   
/*     */   private boolean onGround;
/*     */   
/*     */   public WrapperPlayClientPlayerFlying(PacketReceiveEvent event) {
/*  36 */     super(event, false);
/*  37 */     this
/*  38 */       .positionChanged = (event.getPacketType() == PacketType.Play.Client.PLAYER_POSITION || event.getPacketType() == PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION);
/*  39 */     this
/*  40 */       .rotationChanged = (event.getPacketType() == PacketType.Play.Client.PLAYER_ROTATION || event.getPacketType() == PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION);
/*  41 */     readEvent((ProtocolPacketEvent)event);
/*     */   }
/*     */   
/*     */   public WrapperPlayClientPlayerFlying(boolean positionChanged, boolean rotationChanged, boolean onGround, Location location) {
/*  45 */     super((positionChanged && rotationChanged) ? (PacketTypeCommon)PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION : (
/*  46 */         positionChanged ? (PacketTypeCommon)PacketType.Play.Client.PLAYER_POSITION : (rotationChanged ? (PacketTypeCommon)PacketType.Play.Client.PLAYER_ROTATION : 
/*  47 */         (PacketTypeCommon)PacketType.Play.Client.PLAYER_FLYING)));
/*  48 */     this.positionChanged = positionChanged;
/*  49 */     this.rotationChanged = rotationChanged;
/*  50 */     this.onGround = onGround;
/*  51 */     this.location = location;
/*     */   }
/*     */   
/*     */   public static boolean isFlying(PacketTypeCommon type) {
/*  55 */     return (type == PacketType.Play.Client.PLAYER_FLYING || type == PacketType.Play.Client.PLAYER_POSITION || type == PacketType.Play.Client.PLAYER_ROTATION || type == PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION);
/*     */   }
/*     */   
/*     */   public void read() {
/*  63 */     Vector3d position = new Vector3d();
/*  64 */     float yaw = 0.0F;
/*  65 */     float pitch = 0.0F;
/*  66 */     if (this.positionChanged) {
/*  67 */       double x = readDouble();
/*  68 */       double y = readDouble();
/*  69 */       if (this.serverVersion == ServerVersion.V_1_7_10)
/*  71 */         double d = readDouble(); 
/*  73 */       double z = readDouble();
/*  74 */       position = new Vector3d(x, y, z);
/*     */     } 
/*  76 */     if (this.rotationChanged) {
/*  77 */       yaw = readFloat();
/*  78 */       pitch = readFloat();
/*     */     } 
/*  80 */     this.location = new Location(position, yaw, pitch);
/*  81 */     this.onGround = readBoolean();
/*     */   }
/*     */   
/*     */   public void write() {
/*  86 */     if (this.positionChanged) {
/*  87 */       writeDouble(this.location.getPosition().getX());
/*  88 */       if (this.serverVersion == ServerVersion.V_1_7_10)
/*  90 */         writeDouble(this.location.getPosition().getY() + 1.62D); 
/*  92 */       writeDouble(this.location.getPosition().getY());
/*  93 */       writeDouble(this.location.getPosition().getZ());
/*     */     } 
/*  95 */     if (this.rotationChanged) {
/*  96 */       writeFloat(this.location.getYaw());
/*  97 */       writeFloat(this.location.getPitch());
/*     */     } 
/*  99 */     writeBoolean(this.onGround);
/*     */   }
/*     */   
/*     */   public void copy(WrapperPlayClientPlayerFlying wrapper) {
/* 104 */     this.positionChanged = wrapper.positionChanged;
/* 105 */     this.rotationChanged = wrapper.rotationChanged;
/* 106 */     this.location = wrapper.location;
/* 107 */     this.onGround = wrapper.onGround;
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/* 111 */     return this.location;
/*     */   }
/*     */   
/*     */   public void setLocation(Location location) {
/* 115 */     this.location = location;
/*     */   }
/*     */   
/*     */   public boolean hasPositionChanged() {
/* 119 */     return this.positionChanged;
/*     */   }
/*     */   
/*     */   public void setPositionChanged(boolean positionChanged) {
/* 123 */     this.positionChanged = positionChanged;
/*     */   }
/*     */   
/*     */   public boolean hasRotationChanged() {
/* 127 */     return this.rotationChanged;
/*     */   }
/*     */   
/*     */   public void setRotationChanged(boolean rotationChanged) {
/* 131 */     this.rotationChanged = rotationChanged;
/*     */   }
/*     */   
/*     */   public boolean isOnGround() {
/* 135 */     return this.onGround;
/*     */   }
/*     */   
/*     */   public void setOnGround(boolean onGround) {
/* 139 */     this.onGround = onGround;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\client\WrapperPlayClientPlayerFlying.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */