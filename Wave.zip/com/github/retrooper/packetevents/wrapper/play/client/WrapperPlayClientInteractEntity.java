/*     */ package com.github.retrooper.packetevents.wrapper.play.client;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.player.InteractionHand;
/*     */ import com.github.retrooper.packetevents.util.Vector3f;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ import java.util.Optional;
/*     */ 
/*     */ public class WrapperPlayClientInteractEntity extends PacketWrapper<WrapperPlayClientInteractEntity> {
/*     */   private int entityID;
/*     */   
/*     */   private InteractAction interactAction;
/*     */   
/*     */   private Optional<Vector3f> target;
/*     */   
/*     */   private InteractionHand interactionHand;
/*     */   
/*     */   private Optional<Boolean> sneaking;
/*     */   
/*     */   public WrapperPlayClientInteractEntity(PacketReceiveEvent event) {
/*  43 */     super(event);
/*     */   }
/*     */   
/*     */   public WrapperPlayClientInteractEntity(int entityID, InteractAction interactAction, InteractionHand interactionHand, Optional<Vector3f> target, Optional<Boolean> sneaking) {
/*  47 */     super((PacketTypeCommon)PacketType.Play.Client.INTERACT_ENTITY);
/*  48 */     this.entityID = entityID;
/*  49 */     this.interactAction = interactAction;
/*  50 */     this.interactionHand = interactionHand;
/*  51 */     this.target = target;
/*  52 */     this.sneaking = sneaking;
/*     */   }
/*     */   
/*     */   public void read() {
/*  57 */     if (this.serverVersion == ServerVersion.V_1_7_10) {
/*  58 */       this.entityID = readInt();
/*  59 */       byte typeIndex = readByte();
/*  60 */       this.interactAction = InteractAction.VALUES[typeIndex];
/*  61 */       this.target = Optional.empty();
/*  62 */       this.interactionHand = InteractionHand.MAIN_HAND;
/*  63 */       this.sneaking = Optional.empty();
/*     */     } else {
/*  65 */       this.entityID = readVarInt();
/*  66 */       int typeIndex = readVarInt();
/*  67 */       this.interactAction = InteractAction.VALUES[typeIndex];
/*  68 */       if (this.interactAction == InteractAction.INTERACT_AT) {
/*  69 */         float x = readFloat();
/*  70 */         float y = readFloat();
/*  71 */         float z = readFloat();
/*  72 */         this.target = Optional.of(new Vector3f(x, y, z));
/*     */       } else {
/*  74 */         this.target = Optional.empty();
/*     */       } 
/*  77 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9) && (this.interactAction == InteractAction.INTERACT || this.interactAction == InteractAction.INTERACT_AT)) {
/*  78 */         int handID = readVarInt();
/*  79 */         this.interactionHand = InteractionHand.getById(handID);
/*     */       } else {
/*  81 */         this.interactionHand = InteractionHand.MAIN_HAND;
/*     */       } 
/*  84 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16)) {
/*  85 */         this.sneaking = Optional.of(Boolean.valueOf(readBoolean()));
/*     */       } else {
/*  87 */         this.sneaking = Optional.empty();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write() {
/*  94 */     if (this.serverVersion == ServerVersion.V_1_7_10) {
/*  95 */       writeInt(this.entityID);
/*  96 */       writeByte(this.interactAction.ordinal());
/*     */     } else {
/*  98 */       writeVarInt(this.entityID);
/*  99 */       writeVarInt(this.interactAction.ordinal());
/* 100 */       if (this.interactAction == InteractAction.INTERACT_AT) {
/* 101 */         Vector3f targetVec = this.target.orElse(new Vector3f(0.0F, 0.0F, 0.0F));
/* 102 */         writeFloat(targetVec.x);
/* 103 */         writeFloat(targetVec.y);
/* 104 */         writeFloat(targetVec.z);
/*     */       } 
/* 107 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9) && (this.interactAction == InteractAction.INTERACT || this.interactAction == InteractAction.INTERACT_AT))
/* 108 */         writeVarInt(this.interactionHand.getId()); 
/* 111 */       if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_16))
/* 112 */         writeBoolean(((Boolean)this.sneaking.orElse(Boolean.valueOf(false))).booleanValue()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void copy(WrapperPlayClientInteractEntity wrapper) {
/* 119 */     this.entityID = wrapper.entityID;
/* 120 */     this.interactAction = wrapper.interactAction;
/* 121 */     this.target = wrapper.target;
/* 122 */     this.interactionHand = wrapper.interactionHand;
/* 123 */     this.sneaking = wrapper.sneaking;
/*     */   }
/*     */   
/*     */   public int getEntityId() {
/* 127 */     return this.entityID;
/*     */   }
/*     */   
/*     */   public void setEntityId(int entityID) {
/* 131 */     this.entityID = entityID;
/*     */   }
/*     */   
/*     */   public InteractAction getAction() {
/* 135 */     return this.interactAction;
/*     */   }
/*     */   
/*     */   public void setAction(InteractAction interactAction) {
/* 139 */     this.interactAction = interactAction;
/*     */   }
/*     */   
/*     */   public InteractionHand getHand() {
/* 143 */     return this.interactionHand;
/*     */   }
/*     */   
/*     */   public void setHand(InteractionHand interactionHand) {
/* 147 */     this.interactionHand = interactionHand;
/*     */   }
/*     */   
/*     */   public Optional<Vector3f> getTarget() {
/* 151 */     return this.target;
/*     */   }
/*     */   
/*     */   public void setTarget(Optional<Vector3f> target) {
/* 155 */     this.target = target;
/*     */   }
/*     */   
/*     */   public Optional<Boolean> isSneaking() {
/* 159 */     return this.sneaking;
/*     */   }
/*     */   
/*     */   public void setSneaking(Optional<Boolean> sneaking) {
/* 163 */     this.sneaking = sneaking;
/*     */   }
/*     */   
/*     */   public enum InteractAction {
/* 167 */     INTERACT, ATTACK, INTERACT_AT;
/*     */     
/* 168 */     public static final InteractAction[] VALUES = values();
/*     */     
/*     */     static {
/*     */     
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\client\WrapperPlayClientInteractEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */