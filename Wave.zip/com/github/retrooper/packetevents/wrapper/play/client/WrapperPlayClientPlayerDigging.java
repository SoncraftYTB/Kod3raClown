/*     */ package com.github.retrooper.packetevents.wrapper.play.client;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*     */ import com.github.retrooper.packetevents.manager.server.ServerVersion;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.player.DiggingAction;
/*     */ import com.github.retrooper.packetevents.protocol.world.BlockFace;
/*     */ import com.github.retrooper.packetevents.util.Vector3i;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ 
/*     */ public class WrapperPlayClientPlayerDigging extends PacketWrapper<WrapperPlayClientPlayerDigging> {
/*     */   private DiggingAction action;
/*     */   
/*     */   private Vector3i blockPosition;
/*     */   
/*     */   private BlockFace blockFace;
/*     */   
/*     */   private int sequence;
/*     */   
/*     */   public WrapperPlayClientPlayerDigging(PacketReceiveEvent event) {
/*  36 */     super(event);
/*     */   }
/*     */   
/*     */   public WrapperPlayClientPlayerDigging(DiggingAction action, Vector3i blockPosition, BlockFace blockFace, int sequence) {
/*  40 */     super((PacketTypeCommon)PacketType.Play.Client.PLAYER_DIGGING);
/*  41 */     this.action = action;
/*  42 */     this.blockPosition = blockPosition;
/*  43 */     this.blockFace = blockFace;
/*  44 */     this.sequence = sequence;
/*     */   }
/*     */   
/*     */   public void read() {
/*  49 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_9)) {
/*  50 */       this.action = DiggingAction.getById(readVarInt());
/*     */     } else {
/*  52 */       this.action = DiggingAction.getById(readByte());
/*     */     } 
/*  55 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_8)) {
/*  56 */       this.blockPosition = readBlockPosition();
/*     */     } else {
/*  58 */       int x = readInt();
/*  59 */       int y = readUnsignedByte();
/*  60 */       int z = readInt();
/*  61 */       this.blockPosition = new Vector3i(x, y, z);
/*     */     } 
/*  63 */     short face = readUnsignedByte();
/*  65 */     this.blockFace = BlockFace.getBlockFaceByValue(face);
/*  67 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19))
/*  68 */       this.sequence = readVarInt(); 
/*     */   }
/*     */   
/*     */   public void write() {
/*  74 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_8)) {
/*  75 */       writeVarInt(this.action.getId());
/*  76 */       writeBlockPosition(this.blockPosition);
/*     */     } else {
/*  78 */       writeByte(this.action.getId());
/*  79 */       writeInt(this.blockPosition.x);
/*  80 */       writeByte(this.blockPosition.y);
/*  81 */       writeInt(this.blockPosition.z);
/*     */     } 
/*  83 */     writeByte(this.blockFace.getFaceValue());
/*  85 */     if (this.serverVersion.isNewerThanOrEquals(ServerVersion.V_1_19))
/*  86 */       writeVarInt(this.sequence); 
/*     */   }
/*     */   
/*     */   public void copy(WrapperPlayClientPlayerDigging wrapper) {
/*  92 */     this.action = wrapper.action;
/*  93 */     this.blockPosition = wrapper.blockPosition;
/*  94 */     this.blockFace = wrapper.blockFace;
/*  95 */     this.sequence = wrapper.sequence;
/*     */   }
/*     */   
/*     */   public DiggingAction getAction() {
/*  99 */     return this.action;
/*     */   }
/*     */   
/*     */   public void setAction(DiggingAction action) {
/* 103 */     this.action = action;
/*     */   }
/*     */   
/*     */   public Vector3i getBlockPosition() {
/* 107 */     return this.blockPosition;
/*     */   }
/*     */   
/*     */   public void setBlockPosition(Vector3i blockPosition) {
/* 111 */     this.blockPosition = blockPosition;
/*     */   }
/*     */   
/*     */   public BlockFace getBlockFace() {
/* 115 */     return this.blockFace;
/*     */   }
/*     */   
/*     */   public void setBlockFace(BlockFace blockFace) {
/* 119 */     this.blockFace = blockFace;
/*     */   }
/*     */   
/*     */   public int getSequence() {
/* 123 */     return this.sequence;
/*     */   }
/*     */   
/*     */   public void setSequence(int sequence) {
/* 127 */     this.sequence = sequence;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\play\client\WrapperPlayClientPlayerDigging.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */