/*     */ package com.github.retrooper.packetevents.wrapper.handshaking.client;
/*     */ 
/*     */ import com.github.retrooper.packetevents.event.PacketReceiveEvent;
/*     */ import com.github.retrooper.packetevents.exception.InvalidHandshakeException;
/*     */ import com.github.retrooper.packetevents.protocol.ConnectionState;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*     */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*     */ import com.github.retrooper.packetevents.protocol.player.ClientVersion;
/*     */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*     */ 
/*     */ public class WrapperHandshakingClientHandshake extends PacketWrapper<WrapperHandshakingClientHandshake> {
/*     */   private int protocolVersion;
/*     */   
/*     */   private ClientVersion clientVersion;
/*     */   
/*     */   private String serverAddress;
/*     */   
/*     */   private int serverPort;
/*     */   
/*     */   private ConnectionState nextConnectionState;
/*     */   
/*     */   public WrapperHandshakingClientHandshake(PacketReceiveEvent event) {
/*  41 */     super(event);
/*     */   }
/*     */   
/*     */   public WrapperHandshakingClientHandshake(int protocolVersion, String serverAddress, int serverPort, ConnectionState nextConnectionState) {
/*  45 */     super((PacketTypeCommon)PacketType.Handshaking.Client.HANDSHAKE);
/*  46 */     this.protocolVersion = protocolVersion;
/*  47 */     this.clientVersion = ClientVersion.getById(protocolVersion);
/*  48 */     this.serverAddress = serverAddress;
/*  49 */     this.serverPort = serverPort;
/*  50 */     this.nextConnectionState = nextConnectionState;
/*     */   }
/*     */   
/*     */   public void read() {
/*     */     try {
/*  58 */       this.protocolVersion = readVarInt();
/*  59 */       this.clientVersion = ClientVersion.getById(this.protocolVersion);
/*  60 */       this.serverAddress = readString(32767);
/*  61 */       this.serverPort = readUnsignedShort();
/*  62 */       int nextStateIndex = readVarInt();
/*  63 */       this.nextConnectionState = ConnectionState.getById(nextStateIndex);
/*  64 */     } catch (Exception e) {
/*  65 */       throw new InvalidHandshakeException();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write() {
/*  71 */     writeVarInt(this.protocolVersion);
/*  72 */     writeString(this.serverAddress, 32767);
/*  73 */     writeShort(this.serverPort);
/*  74 */     writeVarInt(this.nextConnectionState.ordinal());
/*     */   }
/*     */   
/*     */   public void copy(WrapperHandshakingClientHandshake wrapper) {
/*  79 */     this.protocolVersion = wrapper.protocolVersion;
/*  80 */     this.clientVersion = wrapper.clientVersion;
/*  81 */     this.serverAddress = wrapper.serverAddress;
/*  82 */     this.serverPort = wrapper.serverPort;
/*  83 */     this.nextConnectionState = wrapper.nextConnectionState;
/*     */   }
/*     */   
/*     */   public int getProtocolVersion() {
/*  93 */     return this.protocolVersion;
/*     */   }
/*     */   
/*     */   public void setProtocolVersion(int protocolVersion) {
/*  97 */     this.protocolVersion = protocolVersion;
/*  98 */     this.clientVersion = ClientVersion.getById(protocolVersion);
/*     */   }
/*     */   
/*     */   public ClientVersion getClientVersion() {
/* 108 */     return this.clientVersion;
/*     */   }
/*     */   
/*     */   public void setClientVersion(ClientVersion clientVersion) {
/* 112 */     this.clientVersion = clientVersion;
/* 113 */     this.protocolVersion = clientVersion.getProtocolVersion();
/*     */   }
/*     */   
/*     */   public String getServerAddress() {
/* 122 */     return this.serverAddress;
/*     */   }
/*     */   
/*     */   public void setServerAddress(String serverAddress) {
/* 126 */     this.serverAddress = serverAddress;
/*     */   }
/*     */   
/*     */   public int getServerPort() {
/* 135 */     return this.serverPort;
/*     */   }
/*     */   
/*     */   public void setServerPort(int serverPort) {
/* 139 */     this.serverPort = serverPort;
/*     */   }
/*     */   
/*     */   public ConnectionState getNextConnectionState() {
/* 149 */     return this.nextConnectionState;
/*     */   }
/*     */   
/*     */   public void setNextConnectionState(ConnectionState nextConnectionState) {
/* 153 */     this.nextConnectionState = nextConnectionState;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\handshaking\client\WrapperHandshakingClientHandshake.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */