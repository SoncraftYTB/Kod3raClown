/*    */ package com.github.retrooper.packetevents.wrapper.configuration.server;
/*    */ 
/*    */ import com.github.retrooper.packetevents.event.PacketSendEvent;
/*    */ import com.github.retrooper.packetevents.protocol.nbt.NBTCompound;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketType;
/*    */ import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
/*    */ import com.github.retrooper.packetevents.wrapper.PacketWrapper;
/*    */ 
/*    */ public class WrapperConfigServerRegistryData extends PacketWrapper<WrapperConfigServerRegistryData> {
/*    */   private NBTCompound registryData;
/*    */   
/*    */   public WrapperConfigServerRegistryData(PacketSendEvent event) {
/* 31 */     super(event);
/*    */   }
/*    */   
/*    */   public WrapperConfigServerRegistryData(NBTCompound registryData) {
/* 35 */     super((PacketTypeCommon)PacketType.Configuration.Server.REGISTRY_DATA);
/* 36 */     this.registryData = registryData;
/*    */   }
/*    */   
/*    */   public void read() {
/* 41 */     this.registryData = readNBT();
/*    */   }
/*    */   
/*    */   public void write() {
/* 46 */     writeNBT(this.registryData);
/*    */   }
/*    */   
/*    */   public void copy(WrapperConfigServerRegistryData wrapper) {
/* 51 */     this.registryData = wrapper.registryData;
/*    */   }
/*    */   
/*    */   public NBTCompound getRegistryData() {
/* 55 */     return this.registryData;
/*    */   }
/*    */   
/*    */   public void setRegistryData(NBTCompound registryData) {
/* 59 */     this.registryData = registryData;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\com\github\retrooper\packetevents\wrapper\configuration\server\WrapperConfigServerRegistryData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */