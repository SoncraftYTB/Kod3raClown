package net.kyori.adventure.audience;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import org.jetbrains.annotations.ApiStatus.Internal;

@Retention(RetentionPolicy.RUNTIME)
@Internal
@interface ForwardingAudienceOverrideNotRequired {}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\net\kyori\adventure\audience\ForwardingAudienceOverrideNotRequired.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */