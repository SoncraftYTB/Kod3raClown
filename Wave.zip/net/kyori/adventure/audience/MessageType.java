/*    */ package net.kyori.adventure.audience;
/*    */ 
/*    */ import org.jetbrains.annotations.ApiStatus.ScheduledForRemoval;
/*    */ 
/*    */ @Deprecated
/*    */ @ScheduledForRemoval(inVersion = "5.0.0")
/*    */ public enum MessageType {
/* 44 */   CHAT, SYSTEM;
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\net\kyori\adventure\audience\MessageType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */