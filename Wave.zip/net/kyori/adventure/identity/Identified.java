package net.kyori.adventure.identity;

import org.jetbrains.annotations.NotNull;

public interface Identified {
  @NotNull
  Identity identity();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\net\kyori\adventure\identity\Identified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */