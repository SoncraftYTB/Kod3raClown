package net.kyori.adventure.bossbar;

import org.jetbrains.annotations.NotNull;

public interface BossBarViewer {
  @NotNull
  Iterable<? extends BossBar> activeBossBars();
}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\net\kyori\adventure\bossbar\BossBarViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */