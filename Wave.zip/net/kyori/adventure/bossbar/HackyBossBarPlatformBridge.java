package net.kyori.adventure.bossbar;

import net.kyori.adventure.util.PlatformAPI;
import org.jetbrains.annotations.ApiStatus.Internal;

@Deprecated
@PlatformAPI
@Internal
abstract class HackyBossBarPlatformBridge {}


/* Location:              C:\Users\Soncraft\Downloads\Wave-0.2.0.jar!\net\kyori\adventure\bossbar\HackyBossBarPlatformBridge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */