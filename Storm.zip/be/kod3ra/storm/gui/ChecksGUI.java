/*     */ package be.kod3ra.storm.gui;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class ChecksGUI implements Listener, CommandExecutor {
/*     */   private Plugin plugin;
/*     */   
/*     */   private Inventory gui;
/*     */   
/*     */   private FileConfiguration config;
/*     */   
/*     */   private String guiTitle;
/*     */   
/*     */   private String backItemName;
/*     */   
/*     */   public ChecksGUI(Plugin plugin) {
/*  31 */     this.plugin = plugin;
/*  32 */     this.config = plugin.getConfig();
/*  35 */     this.guiTitle = this.config.getString("checksgui.gui-Title");
/*  36 */     this.backItemName = this.config.getString("maingui.back-Name");
/*  37 */     this.gui = Bukkit.createInventory(null, 54, this.guiTitle);
/*  39 */     addCheckItem("AirA");
/*  40 */     addCheckItem("FlightA");
/*  41 */     addCheckItem("FlightB");
/*  42 */     addCheckItem("SpeedA");
/*  43 */     addCheckItem("SpeedB");
/*  44 */     addCheckItem("MotionA");
/*  45 */     addCheckItem("WaterwalkA");
/*  46 */     addCheckItem("ReachA");
/*  47 */     addCheckItem("KillAuraA");
/*  48 */     addCheckItem("AutoclickerA");
/*  51 */     addBackItem();
/*     */   }
/*     */   
/*     */   private void addBackItem() {
/*  55 */     ItemStack item = createBackItem();
/*  56 */     this.gui.setItem(49, item);
/*     */   }
/*     */   
/*     */   private ItemStack createBackItem() {
/*  60 */     ItemStack item = new ItemStack(Material.BARRIER);
/*  61 */     ItemMeta meta = item.getItemMeta();
/*  62 */     meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', this.backItemName));
/*  63 */     item.setItemMeta(meta);
/*  65 */     return item;
/*     */   }
/*     */   
/*     */   private void addCheckItem(String checkName) {
/*  69 */     boolean isEnabled = this.config.getBoolean("checks." + checkName + ".enabled", true);
/*  71 */     ItemStack item = createCheckItem(checkName, isEnabled);
/*  72 */     this.gui.addItem(new ItemStack[] { item });
/*     */   }
/*     */   
/*     */   private ItemStack createCheckItem(String checkName, boolean isEnabled) {
/*  76 */     Material material = Material.getMaterial(isEnabled ? 339 : 395);
/*  77 */     String displayName = "Name: " + checkName;
/*  78 */     String loreText = isEnabled ? (
/*  79 */       ChatColor.RED + "Click to deactivate the check.\nYou will need to reload or restart the server!") : (
/*  80 */       ChatColor.GREEN + "Click to activate the check.\nYou will need to reload or restart the server!");
/*  82 */     ItemStack item = new ItemStack(material);
/*  83 */     ItemMeta meta = item.getItemMeta();
/*  84 */     meta.setDisplayName(displayName);
/*  85 */     meta.setLore(Arrays.asList(new String[] { loreText }));
/*  86 */     item.setItemMeta(meta);
/*  88 */     return item;
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  92 */     player.openInventory(this.gui);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  97 */     if (event.getInventory().equals(this.gui)) {
/*  98 */       event.setCancelled(true);
/*  99 */       ItemStack currentItem = event.getCurrentItem();
/* 100 */       if (currentItem != null && currentItem.hasItemMeta()) {
/* 101 */         if (currentItem.getType() == Material.BARRIER) {
/* 103 */           Player player = (Player)event.getWhoClicked();
/* 104 */           player.performCommand("stormmenu");
/*     */           return;
/*     */         } 
/* 108 */         String itemName = currentItem.getItemMeta().getDisplayName();
/* 109 */         String checkName = itemName.substring(6);
/* 111 */         boolean isEnabled = this.config.getBoolean("checks." + checkName + ".enabled", true);
/* 112 */         this.config.set("checks." + checkName + ".enabled", Boolean.valueOf(!isEnabled));
/* 113 */         this.plugin.saveConfig();
/* 115 */         ItemStack updatedItem = createCheckItem(checkName, !isEnabled);
/* 116 */         this.gui.setItem(event.getSlot(), updatedItem);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 123 */     if (sender instanceof Player) {
/* 124 */       Player player = (Player)sender;
/* 125 */       if (command.getName().equalsIgnoreCase("stormgui2")) {
/* 126 */         openGUI(player);
/* 127 */         return true;
/*     */       } 
/*     */     } 
/* 130 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\gui\ChecksGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */