/*     */ package be.kod3ra.storm.gui;
/*     */ 
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class PlayerGui implements Listener, CommandExecutor {
/*     */   private Plugin plugin;
/*     */   
/*     */   private Inventory gui;
/*     */   
/*     */   private String guiTitle;
/*     */   
/*     */   private String kickPlayersDisplayName;
/*     */   
/*     */   private String banPlayersDisplayName;
/*     */   
/*     */   private String infoPlayersDisplayName;
/*     */   
/*     */   private String backItemName;
/*     */   
/*     */   public PlayerGui(Plugin plugin) {
/*  29 */     this.plugin = plugin;
/*  32 */     loadConfigValues();
/*  34 */     this.gui = Bukkit.createInventory(null, 36, this.guiTitle);
/*  35 */     Bukkit.getPluginManager().registerEvents(this, plugin);
/*  36 */     createItems();
/*  37 */     addBackItem();
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  41 */     player.openInventory(this.gui);
/*     */   }
/*     */   
/*     */   private void createItems() {
/*  45 */     ItemStack kickItem = createItem(Material.IRON_AXE, this.kickPlayersDisplayName);
/*  46 */     ItemStack banItem = createItem(Material.DIAMOND_AXE, this.banPlayersDisplayName);
/*  47 */     ItemStack infoItem = createItem(Material.WATCH, this.infoPlayersDisplayName);
/*  49 */     this.gui.setItem(10, kickItem);
/*  50 */     this.gui.setItem(13, banItem);
/*  51 */     this.gui.setItem(16, infoItem);
/*     */   }
/*     */   
/*     */   private void addBackItem() {
/*  55 */     ItemStack item = createItem(Material.BARRIER, this.backItemName);
/*  56 */     this.gui.setItem(31, item);
/*     */   }
/*     */   
/*     */   private ItemStack createItem(Material material, String name) {
/*  60 */     ItemStack item = new ItemStack(material);
/*  61 */     ItemMeta meta = item.getItemMeta();
/*  62 */     meta.setDisplayName(name);
/*  63 */     item.setItemMeta(meta);
/*  64 */     return item;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  69 */     Inventory clickedInventory = event.getClickedInventory();
/*  70 */     if (clickedInventory != null && clickedInventory.equals(this.gui)) {
/*  71 */       event.setCancelled(true);
/*  72 */       ItemStack currentItem = event.getCurrentItem();
/*  73 */       if (currentItem != null && currentItem.getType() == Material.IRON_AXE) {
/*  74 */         Player player = (Player)event.getWhoClicked();
/*  75 */         player.performCommand("stormgui3");
/*  76 */       } else if (currentItem != null && currentItem.getType() == Material.DIAMOND_AXE) {
/*  77 */         Player player = (Player)event.getWhoClicked();
/*  78 */         player.performCommand("stormgui4");
/*  79 */       } else if (currentItem != null && currentItem.getType() == Material.WATCH) {
/*  80 */         Player player = (Player)event.getWhoClicked();
/*  81 */         player.performCommand("stormgui5");
/*  82 */       } else if (currentItem.getType() == Material.BARRIER) {
/*  83 */         Player player = (Player)event.getWhoClicked();
/*  84 */         player.performCommand("stormmenu");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/*  91 */     if (sender instanceof Player) {
/*  92 */       Player player = (Player)sender;
/*  93 */       if (command.getName().equalsIgnoreCase("stormgui6")) {
/*  94 */         openGUI(player);
/*  95 */         return true;
/*     */       } 
/*     */     } 
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   public void loadConfigValues() {
/* 103 */     FileConfiguration config = this.plugin.getConfig();
/* 104 */     config.options().copyDefaults(true);
/* 105 */     this.plugin.saveConfig();
/* 107 */     this.guiTitle = config.getString("playergui.gui-Title");
/* 108 */     this.kickPlayersDisplayName = config.getString("playergui.kick-Players");
/* 109 */     this.banPlayersDisplayName = config.getString("playergui.ban-Players");
/* 110 */     this.infoPlayersDisplayName = config.getString("playergui.info-Players");
/* 111 */     this.backItemName = config.getString("maingui.back-Name");
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\gui\PlayerGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */