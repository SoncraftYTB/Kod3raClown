/*     */ package be.kod3ra.storm.gui;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ public class LogsViolationsGUI implements CommandExecutor {
/*     */   private final FileConfiguration config;
/*     */   
/*     */   private final Main main;
/*     */   
/*     */   private String backItemName;
/*     */   
/*     */   private Inventory gui;
/*     */   
/*     */   public LogsViolationsGUI(Main main, FileConfiguration config) {
/*  30 */     this.main = main;
/*  31 */     this.config = config;
/*  32 */     this.backItemName = config.getString("maingui.back-Name");
/*  34 */     this.gui = Bukkit.createInventory(null, 54, config.getString("vllogsgui.gui-Title"));
/*  36 */     addBackItem();
/*     */   }
/*     */   
/*     */   private void addBackItem() {
/*  40 */     ItemStack item = createBackItem();
/*  41 */     this.gui.setItem(49, item);
/*     */   }
/*     */   
/*     */   private ItemStack createBackItem() {
/*  45 */     ItemStack item = new ItemStack(Material.BARRIER);
/*  46 */     ItemMeta meta = item.getItemMeta();
/*  47 */     meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', this.backItemName));
/*  48 */     item.setItemMeta(meta);
/*  50 */     return item;
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/*  56 */     if (sender instanceof Player) {
/*  57 */       Player player = (Player)sender;
/*  58 */       openLogsMenu(player);
/*  59 */       return true;
/*     */     } 
/*  61 */     sender.sendMessage("This command need to be executed by a player.");
/*  62 */     return false;
/*     */   }
/*     */   
/*     */   public void openLogsMenu(Player player) {
/*  67 */     String guiTitle = this.config.getString("vllogsgui.gui-Title");
/*  68 */     Inventory logsMenu = Bukkit.createInventory(null, 54, guiTitle);
/*  70 */     File logsFolder = new File("plugins/Storm/logs");
/*  71 */     File[] logFiles = logsFolder.listFiles();
/*  73 */     if (logFiles != null) {
/*     */       byte b;
/*     */       int i;
/*     */       File[] arrayOfFile;
/*  74 */       for (i = (arrayOfFile = logFiles).length, b = 0; b < i; ) {
/*  74 */         File logFile = arrayOfFile[b];
/*  75 */         if (logFile.isFile()) {
/*  76 */           ItemStack logItem = createLogItem(logFile.getName());
/*  77 */           logsMenu.addItem(new ItemStack[] { logItem });
/*     */         } 
/*     */         b++;
/*     */       } 
/*     */     } 
/*  82 */     player.openInventory(logsMenu);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  87 */     if (event.getInventory().getHolder() instanceof Player) {
/*  88 */       Player player = (Player)event.getInventory().getHolder();
/*  90 */       if (event.getClickedInventory() != null && event.getClickedInventory().equals(event.getView().getTopInventory())) {
/*  91 */         ItemStack clickedItem = event.getCurrentItem();
/*  92 */         if (clickedItem != null)
/*  93 */           if (clickedItem.getType() == Material.BARRIER) {
/*  95 */             player.performCommand("stormmenu");
/*  96 */             event.setCancelled(true);
/*  97 */           } else if (clickedItem.getType() == Material.PAPER) {
/*  99 */             event.setCancelled(true);
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private ItemStack createLogItem(String logFileName) {
/* 107 */     ItemStack item = new ItemStack(Material.PAPER);
/* 108 */     ItemMeta meta = item.getItemMeta();
/* 109 */     meta.setDisplayName(logFileName);
/* 112 */     String[] logInfo = logFileName.split("_");
/* 113 */     if (logInfo.length >= 3) {
/* 114 */       String playerName = logInfo[0];
/* 115 */       String date = logInfo[1];
/* 116 */       String check = logInfo[2];
/* 119 */       String playerFormat = this.config.getString("vllogsgui.lore-format.player");
/* 120 */       String dateFormat = this.config.getString("vllogsgui.lore-format.date");
/* 121 */       String checkFormat = this.config.getString("vllogsgui.lore-format.check");
/* 124 */       playerFormat = playerFormat.replace("%player%", playerName);
/* 125 */       dateFormat = dateFormat.replace("%date%", date);
/* 126 */       checkFormat = checkFormat.replace("%check%", check);
/* 129 */       meta.setLore(Arrays.asList(new String[] { playerFormat, dateFormat, checkFormat }));
/*     */     } else {
/* 132 */       meta.setLore(Arrays.asList(new String[] { "Log name is invalid." }));
/*     */     } 
/* 135 */     item.setItemMeta(meta);
/* 136 */     return item;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\gui\LogsViolationsGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */