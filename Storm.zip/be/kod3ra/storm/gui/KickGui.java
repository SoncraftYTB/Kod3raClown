/*     */ package be.kod3ra.storm.gui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class KickGui implements Listener, CommandExecutor {
/*     */   private Plugin plugin;
/*     */   
/*     */   private Inventory gui;
/*     */   
/*     */   private Map<Integer, UUID> playerSlots;
/*     */   
/*     */   private String guiTitle;
/*     */   
/*     */   private String backItemName;
/*     */   
/*     */   public KickGui(Plugin plugin) {
/*  33 */     this.plugin = plugin;
/*  36 */     loadConfigValues();
/*  38 */     this.gui = Bukkit.createInventory(null, 54, this.guiTitle);
/*  39 */     this.playerSlots = new HashMap<>();
/*  40 */     addBackItem();
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  44 */     updateGUI();
/*  45 */     player.openInventory(this.gui);
/*     */   }
/*     */   
/*     */   private void addBackItem() {
/*  49 */     ItemStack item = createBackItem();
/*  50 */     this.gui.setItem(49, item);
/*     */   }
/*     */   
/*     */   private ItemStack createBackItem() {
/*  54 */     ItemStack item = new ItemStack(Material.BARRIER);
/*  55 */     ItemMeta meta = item.getItemMeta();
/*  56 */     meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', this.backItemName));
/*  57 */     item.setItemMeta(meta);
/*  58 */     return item;
/*     */   }
/*     */   
/*     */   private void updateGUI() {
/*  62 */     this.gui.clear();
/*  63 */     int slot = 0;
/*  64 */     for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
/*  65 */       ItemStack skullItem = createPlayerSkullItem(onlinePlayer);
/*  66 */       this.gui.setItem(slot, skullItem);
/*  67 */       this.playerSlots.put(Integer.valueOf(slot), onlinePlayer.getUniqueId());
/*  68 */       slot++;
/*     */     } 
/*  70 */     addBackItem();
/*     */   }
/*     */   
/*     */   private ItemStack createPlayerSkullItem(Player player) {
/*  74 */     ItemStack skullItem = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
/*  75 */     ItemMeta skullMeta = skullItem.getItemMeta();
/*  76 */     skullMeta.setDisplayName(player.getName());
/*  77 */     skullItem.setItemMeta(skullMeta);
/*  78 */     return skullItem;
/*     */   }
/*     */   
/*     */   private ItemStack createItem(Material material, String name) {
/*  82 */     ItemStack item = new ItemStack(material);
/*  83 */     ItemMeta meta = item.getItemMeta();
/*  84 */     meta.setDisplayName(name);
/*  85 */     item.setItemMeta(meta);
/*  86 */     return item;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  91 */     if (event.getInventory().equals(this.gui)) {
/*  92 */       event.setCancelled(true);
/*  93 */       int slot = event.getRawSlot();
/*  94 */       if (this.playerSlots.containsKey(Integer.valueOf(slot))) {
/*  95 */         UUID playerId = this.playerSlots.get(Integer.valueOf(slot));
/*  96 */         Player player = Bukkit.getPlayer(playerId);
/*  97 */         if (player != null)
/*  98 */           Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "stormkick " + player.getName()); 
/* 100 */       } else if (slot == 49) {
/* 102 */         ItemStack currentItem = event.getCurrentItem();
/* 103 */         if (currentItem != null && currentItem.getType() == Material.BARRIER) {
/* 104 */           Player player = (Player)event.getWhoClicked();
/* 105 */           player.performCommand("stormmenu");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 113 */     if (sender instanceof Player) {
/* 114 */       Player player = (Player)sender;
/* 115 */       if (command.getName().equalsIgnoreCase("stormgui3")) {
/* 116 */         openGUI(player);
/* 117 */         return true;
/*     */       } 
/*     */     } 
/* 120 */     return false;
/*     */   }
/*     */   
/*     */   public void loadConfigValues() {
/* 125 */     FileConfiguration config = this.plugin.getConfig();
/* 126 */     config.options().copyDefaults(true);
/* 127 */     this.plugin.saveConfig();
/* 128 */     this.guiTitle = config.getString("kickgui.gui-Title");
/* 129 */     this.backItemName = config.getString("maingui.back-Name");
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\gui\KickGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */