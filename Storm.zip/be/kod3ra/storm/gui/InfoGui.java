/*     */ package be.kod3ra.storm.gui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class InfoGui implements Listener, CommandExecutor {
/*     */   private Plugin plugin;
/*     */   
/*     */   private Inventory gui;
/*     */   
/*     */   private Map<Integer, UUID> playerSlots;
/*     */   
/*     */   private String guiTitle;
/*     */   
/*     */   private String backItemName;
/*     */   
/*     */   public InfoGui(Plugin plugin) {
/*  32 */     this.plugin = plugin;
/*  33 */     this.playerSlots = new HashMap<>();
/*  36 */     loadConfigValues();
/*  38 */     this.gui = Bukkit.createInventory(null, 54, this.guiTitle);
/*  41 */     addBackItem();
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  45 */     updateGUI();
/*  46 */     player.openInventory(this.gui);
/*     */   }
/*     */   
/*     */   private void updateGUI() {
/*  50 */     this.gui.clear();
/*  51 */     int slot = 0;
/*  52 */     for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
/*  53 */       ItemStack skullItem = createPlayerSkullItem(onlinePlayer);
/*  54 */       this.gui.setItem(slot, skullItem);
/*  55 */       this.playerSlots.put(Integer.valueOf(slot), onlinePlayer.getUniqueId());
/*  56 */       slot++;
/*     */     } 
/*  58 */     addBackItem();
/*     */   }
/*     */   
/*     */   private void addBackItem() {
/*  62 */     ItemStack backItem = createBackItem();
/*  63 */     this.gui.setItem(49, backItem);
/*     */   }
/*     */   
/*     */   private ItemStack createBackItem() {
/*  67 */     ItemStack item = new ItemStack(Material.BARRIER);
/*  68 */     ItemMeta meta = item.getItemMeta();
/*  69 */     meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', this.backItemName));
/*  70 */     return item;
/*     */   }
/*     */   
/*     */   private ItemStack createPlayerSkullItem(Player player) {
/*  74 */     ItemStack skullItem = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
/*  75 */     ItemMeta skullMeta = skullItem.getItemMeta();
/*  76 */     skullMeta.setDisplayName(player.getName());
/*  77 */     skullItem.setItemMeta(skullMeta);
/*  78 */     return skullItem;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  83 */     if (event.getInventory().equals(this.gui)) {
/*  84 */       event.setCancelled(true);
/*  85 */       int slot = event.getRawSlot();
/*  86 */       if (slot == 49) {
/*  88 */         Player player = (Player)event.getWhoClicked();
/*  89 */         player.performCommand("stormmenu");
/*  90 */       } else if (this.playerSlots.containsKey(Integer.valueOf(slot))) {
/*  91 */         UUID playerId = this.playerSlots.get(Integer.valueOf(slot));
/*  92 */         Player clickedPlayer = Bukkit.getPlayer(playerId);
/*  93 */         Player executor = (Player)event.getWhoClicked();
/*  94 */         if (clickedPlayer != null)
/*  95 */           executor.performCommand("stormplayer " + clickedPlayer.getName()); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 103 */     if (sender instanceof Player) {
/* 104 */       Player player = (Player)sender;
/* 105 */       if (command.getName().equalsIgnoreCase("stormgui5")) {
/* 106 */         openGUI(player);
/* 107 */         return true;
/*     */       } 
/*     */     } 
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/* 115 */     FileConfiguration config = this.plugin.getConfig();
/* 116 */     config.options().copyDefaults(true);
/* 117 */     this.plugin.saveConfig();
/* 118 */     this.guiTitle = this.plugin.getConfig().getString("playerinfogui.gui-Title");
/* 119 */     this.backItemName = config.getString("maingui.back-Name");
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\gui\InfoGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */