/*     */ package be.kod3ra.storm.gui;
/*     */ 
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class MainGUI implements Listener, CommandExecutor {
/*     */   private Plugin plugin;
/*     */   
/*     */   private Inventory gui;
/*     */   
/*     */   private String guiTitle;
/*     */   
/*     */   private String detectionsDisplayName;
/*     */   
/*     */   private String playersDisplayName;
/*     */   
/*     */   private String vlLogsDisplayName;
/*     */   
/*     */   public MainGUI(Plugin plugin) {
/*  28 */     this.plugin = plugin;
/*  31 */     loadConfigValues();
/*  33 */     this.gui = Bukkit.createInventory(null, 27, this.guiTitle);
/*  35 */     ItemStack item = new ItemStack(Material.BOOK);
/*  36 */     ItemMeta itemMeta = item.getItemMeta();
/*  37 */     itemMeta.setDisplayName(this.detectionsDisplayName);
/*  38 */     item.setItemMeta(itemMeta);
/*  39 */     this.gui.setItem(10, item);
/*  41 */     ItemStack kickPlayersItem = new ItemStack(Material.STORAGE_MINECART);
/*  42 */     ItemMeta kickPlayersMeta = kickPlayersItem.getItemMeta();
/*  43 */     kickPlayersMeta.setDisplayName(this.playersDisplayName);
/*  44 */     kickPlayersItem.setItemMeta(kickPlayersMeta);
/*  45 */     this.gui.setItem(13, kickPlayersItem);
/*  47 */     ItemStack vlLogsItem = new ItemStack(Material.HOPPER);
/*  48 */     ItemMeta vlLogsMeta = vlLogsItem.getItemMeta();
/*  49 */     vlLogsMeta.setDisplayName(this.vlLogsDisplayName);
/*  50 */     vlLogsItem.setItemMeta(vlLogsMeta);
/*  51 */     this.gui.setItem(16, vlLogsItem);
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  55 */     player.openInventory(this.gui);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  60 */     Inventory clickedInventory = event.getClickedInventory();
/*  61 */     if (clickedInventory != null && clickedInventory.equals(this.gui)) {
/*  62 */       event.setCancelled(true);
/*  63 */       ItemStack currentItem = event.getCurrentItem();
/*  64 */       if (currentItem != null && currentItem.getType() == Material.BOOK) {
/*  65 */         Player player = (Player)event.getWhoClicked();
/*  66 */         player.performCommand("stormgui2");
/*     */       } 
/*     */     } 
/*  69 */     if (clickedInventory != null && clickedInventory.equals(this.gui)) {
/*  70 */       event.setCancelled(true);
/*  71 */       ItemStack currentItem = event.getCurrentItem();
/*  72 */       if (currentItem != null && currentItem.getType() == Material.STORAGE_MINECART) {
/*  73 */         Player player = (Player)event.getWhoClicked();
/*  74 */         player.performCommand("stormgui6");
/*     */       } 
/*     */     } 
/*  77 */     if (clickedInventory != null && clickedInventory.equals(this.gui)) {
/*  78 */       event.setCancelled(true);
/*  79 */       ItemStack currentItem = event.getCurrentItem();
/*  80 */       if (currentItem != null && currentItem.getType() == Material.HOPPER) {
/*  81 */         Player player = (Player)event.getWhoClicked();
/*  82 */         player.performCommand("stormgui7");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/*  89 */     if (sender instanceof Player) {
/*  90 */       Player player = (Player)sender;
/*  91 */       if (command.getName().equalsIgnoreCase("stormmenu")) {
/*  92 */         openGUI(player);
/*  93 */         return true;
/*     */       } 
/*     */     } 
/*  96 */     return false;
/*     */   }
/*     */   
/*     */   public void loadConfigValues() {
/* 101 */     FileConfiguration config = this.plugin.getConfig();
/* 102 */     config.options().copyDefaults(true);
/* 103 */     this.plugin.saveConfig();
/* 104 */     this.guiTitle = config.getString("maingui.gui-Title");
/* 105 */     this.detectionsDisplayName = config.getString("maingui.detections-DisplayName");
/* 106 */     this.playersDisplayName = config.getString("maingui.players-DisplayName");
/* 107 */     this.vlLogsDisplayName = config.getString("maingui.vllogs-DisplayName");
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\gui\MainGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */