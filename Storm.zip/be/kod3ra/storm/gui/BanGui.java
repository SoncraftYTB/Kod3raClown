/*     */ package be.kod3ra.storm.gui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class BanGui implements Listener, CommandExecutor {
/*     */   private Plugin plugin;
/*     */   
/*     */   private Inventory gui;
/*     */   
/*     */   private Map<Integer, UUID> playerSlots;
/*     */   
/*     */   private String guiTitle;
/*     */   
/*     */   private String backItemName;
/*     */   
/*     */   public BanGui(Plugin plugin) {
/*  32 */     this.plugin = plugin;
/*  35 */     loadConfigValues();
/*  37 */     this.gui = Bukkit.createInventory(null, 54, this.guiTitle);
/*  38 */     this.playerSlots = new HashMap<>();
/*  39 */     addBackItem();
/*     */   }
/*     */   
/*     */   public void openGUI(Player player) {
/*  43 */     updateGUI();
/*  44 */     player.openInventory(this.gui);
/*     */   }
/*     */   
/*     */   private void addBackItem() {
/*  48 */     ItemStack item = createBackItem();
/*  49 */     this.gui.setItem(49, item);
/*     */   }
/*     */   
/*     */   private void updateGUI() {
/*  53 */     this.gui.clear();
/*  54 */     int slot = 0;
/*  55 */     for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
/*  56 */       ItemStack skullItem = createPlayerSkullItem(onlinePlayer);
/*  57 */       this.gui.setItem(slot, skullItem);
/*  58 */       this.playerSlots.put(Integer.valueOf(slot), onlinePlayer.getUniqueId());
/*  59 */       slot++;
/*     */     } 
/*  61 */     addBackItem();
/*     */   }
/*     */   
/*     */   private ItemStack createPlayerSkullItem(Player player) {
/*  65 */     ItemStack skullItem = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
/*  66 */     ItemMeta skullMeta = skullItem.getItemMeta();
/*  67 */     skullMeta.setDisplayName(player.getName());
/*  68 */     skullItem.setItemMeta(skullMeta);
/*  69 */     return skullItem;
/*     */   }
/*     */   
/*     */   private ItemStack createItem(Material material, String name) {
/*  73 */     ItemStack item = new ItemStack(material);
/*  74 */     ItemMeta meta = item.getItemMeta();
/*  75 */     item.setItemMeta(meta);
/*  76 */     return item;
/*     */   }
/*     */   
/*     */   private ItemStack createBackItem() {
/*  80 */     FileConfiguration config = this.plugin.getConfig();
/*  81 */     ItemStack item = new ItemStack(Material.BARRIER);
/*  82 */     ItemMeta meta = item.getItemMeta();
/*  83 */     meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', this.backItemName));
/*  84 */     return item;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  89 */     if (event.getInventory().equals(this.gui)) {
/*  90 */       event.setCancelled(true);
/*  91 */       int slot = event.getRawSlot();
/*  92 */       if (this.playerSlots.containsKey(Integer.valueOf(slot))) {
/*  93 */         UUID playerId = this.playerSlots.get(Integer.valueOf(slot));
/*  94 */         Player player = Bukkit.getPlayer(playerId);
/*  95 */         if (player != null) {
/*  96 */           String command = "stormban " + player.getName() + " 720";
/*  97 */           Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), command);
/*     */         } 
/*  99 */       } else if (slot == 49) {
/* 101 */         ItemStack currentItem = event.getCurrentItem();
/* 102 */         if (currentItem != null && currentItem.getType() == Material.BARRIER) {
/* 103 */           Player player = (Player)event.getWhoClicked();
/* 104 */           player.performCommand("stormmenu");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 112 */     if (sender instanceof Player) {
/* 113 */       Player player = (Player)sender;
/* 114 */       if (command.getName().equalsIgnoreCase("stormgui4")) {
/* 115 */         openGUI(player);
/* 116 */         return true;
/*     */       } 
/*     */     } 
/* 119 */     return false;
/*     */   }
/*     */   
/*     */   public void loadConfigValues() {
/* 124 */     FileConfiguration config = this.plugin.getConfig();
/* 125 */     config.options().copyDefaults(true);
/* 126 */     this.plugin.saveConfig();
/* 127 */     this.guiTitle = config.getString("bangui.gui-Title");
/* 128 */     this.backItemName = this.plugin.getConfig().getString("maingui.back-Name");
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\gui\BanGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */