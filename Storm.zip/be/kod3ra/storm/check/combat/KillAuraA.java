/*     */ package be.kod3ra.storm.check.combat;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.MovementViolationEvent;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class KillAuraA implements Listener {
/*     */   private boolean isEnabled;
/*     */   
/*  26 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*  27 */   private final Map<UUID, Long> lastClickTime = new HashMap<>();
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private String violationMessage;
/*     */   
/*     */   public KillAuraA() {
/*  33 */     loadConfigValues();
/*  35 */     if (this.isEnabled)
/*  36 */       Bukkit.getPluginManager().registerEvents(this, (Plugin)Main.getInstance()); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/*  42 */     if (!this.isEnabled)
/*     */       return; 
/*  46 */     if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
/*  47 */       Player attacker = (Player)event.getDamager();
/*  48 */       Player victim = (Player)event.getEntity();
/*  51 */       if (!isFacing(attacker, victim)) {
/*  54 */         handleKillAuraAttack(attacker);
/*  56 */         if (isPlayerNear(attacker, victim))
/*     */           return; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPlayerNear(Player player, Player target) {
/*  68 */     Location playerLocation = player.getLocation();
/*  70 */     for (Player otherPlayer : Bukkit.getServer().getOnlinePlayers()) {
/*  71 */       if (otherPlayer != player && otherPlayer != target && otherPlayer.getWorld() == player.getWorld() && 
/*  72 */         otherPlayer.getLocation().distanceSquared(playerLocation) < 2.25D)
/*  74 */         return true; 
/*     */     } 
/*  78 */     return false;
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/*  82 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/*  86 */     UUID playerUUID = player.getUniqueId();
/*  87 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/*  92 */     if (!this.isEnabled)
/*     */       return; 
/*  96 */     Player player = event.getPlayer();
/*  97 */     UUID playerUUID = player.getUniqueId();
/* 100 */     this.lastClickTime.put(playerUUID, Long.valueOf(System.currentTimeMillis()));
/*     */   }
/*     */   
/*     */   private boolean isFacing(Player attacker, Player victim) {
/* 104 */     Vector toVictim = victim.getLocation().toVector().subtract(attacker.getLocation().toVector());
/* 105 */     Vector direction = attacker.getEyeLocation().getDirection();
/* 108 */     double angle = 120.0D;
/* 110 */     return (toVictim.angle(direction) < Math.toRadians(angle));
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/* 114 */     FileConfiguration config = Main.getInstance().getConfig();
/* 115 */     this.isEnabled = config.getBoolean("checks.KillAuraA.enabled", true);
/* 117 */     if (!this.isEnabled)
/*     */       return; 
/* 121 */     this.maxViolations = config.getInt("checks.KillAuraA.max-violations");
/* 122 */     this.kickCommand = config.getString("checks.KillAuraA.kick-command");
/* 123 */     this.violationMessage = config.getString("checks.KillAuraA.violation-message");
/*     */   }
/*     */   
/*     */   private void handleKillAuraAttack(Player player) {
/* 127 */     if (!this.isEnabled)
/*     */       return; 
/* 131 */     if (player.isOp() || player.hasPermission("storm.bypass.killaura"))
/*     */       return; 
/* 135 */     UUID playerUUID = player.getUniqueId();
/* 138 */     long currentTime = System.currentTimeMillis();
/* 139 */     long lastClick = ((Long)this.lastClickTime.getOrDefault(playerUUID, Long.valueOf(0L))).longValue();
/* 140 */     double clickRate = 1000.0D / (currentTime - lastClick);
/* 142 */     if (clickRate < 5.0D)
/*     */       return; 
/* 147 */     Bukkit.getServer().getPluginManager().callEvent((Event)new MovementViolationEvent(player));
/* 148 */     LagBack.updateLastKnownLocation(player);
/* 150 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 151 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 153 */     String message = this.violationMessage
/* 154 */       .replace("%PLAYER%", player.getName())
/* 155 */       .replace("%VL%", String.valueOf(violations))
/* 156 */       .replace("%MAX_VL%", String.valueOf(this.maxViolations));
/* 158 */     Logs.logViolation(player, "KillauraA", this.violationMessage);
/* 160 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 161 */       if (staff.hasPermission("storm.alerts"))
/* 162 */         staff.sendMessage(message); 
/*     */     } 
/* 167 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/* 169 */     if (violations >= this.maxViolations)
/* 170 */       handleAction(player); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player) {
/* 175 */     if (!this.isEnabled)
/*     */       return; 
/* 179 */     String commandToExecute = this.kickCommand.replace("%PLAYER%", player.getName());
/* 180 */     Main pluginInstance = Main.getInstance();
/* 181 */     if (pluginInstance == null)
/*     */       return; 
/* 187 */     Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */           if (paramString == null)
/*     */             return; 
/*     */           paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */         });
/* 197 */     violationCount.remove(player.getUniqueId());
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\combat\KillAuraA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */