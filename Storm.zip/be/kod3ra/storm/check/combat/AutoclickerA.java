/*     */ package be.kod3ra.storm.check.combat;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class AutoclickerA implements Listener {
/*     */   private boolean isEnabled;
/*     */   
/*  21 */   private final HashMap<Player, Long> clickCounts = new HashMap<>();
/*     */   
/*  22 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*     */   private final Plugin plugin;
/*     */   
/*     */   private int maxClicksPerSecond;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private String violationMessage;
/*     */   
/*     */   public AutoclickerA(Plugin plugin) {
/*  30 */     this.plugin = plugin;
/*  33 */     loadConfigValues();
/*  36 */     if (this.isEnabled)
/*  37 */       Bukkit.getPluginManager().registerEvents(this, plugin); 
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/*  42 */     FileConfiguration config = this.plugin.getConfig();
/*  43 */     this.isEnabled = config.getBoolean("checks.AutoclickerA.enabled", true);
/*  45 */     if (!this.isEnabled)
/*     */       return; 
/*  49 */     this.maxClicksPerSecond = config.getInt("checks.AutoclickerA.max-clicks-per-second");
/*  50 */     this.maxViolations = config.getInt("checks.AutoclickerA.max-violations");
/*  51 */     this.kickCommand = config.getString("checks.AutoclickerA.kick-command");
/*  52 */     this.violationMessage = config.getString("checks.AutoclickerA.violation-message");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/*  57 */     if (!this.isEnabled)
/*     */       return; 
/*  61 */     Player player = event.getPlayer();
/*  64 */     long clickCount = ((Long)this.clickCounts.getOrDefault(player, Long.valueOf(0L))).longValue();
/*  67 */     this.clickCounts.put(player, Long.valueOf(clickCount + 1L));
/*  70 */     Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
/*     */           if (this.clickCounts.containsKey(paramPlayer) && ((Long)this.clickCounts.get(paramPlayer)).longValue() > this.maxClicksPerSecond)
/*     */             handleViolation(paramPlayer); 
/*     */           this.clickCounts.remove(paramPlayer);
/*  77 */         }20L);
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/*  81 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/*  85 */     UUID playerUUID = player.getUniqueId();
/*  86 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   private void handleViolation(Player player) {
/*  90 */     if (!this.isEnabled)
/*     */       return; 
/*  94 */     UUID playerUUID = player.getUniqueId();
/*  96 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/*  97 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/*  99 */     String message = this.violationMessage
/* 100 */       .replace("%PLAYER%", player.getName())
/* 101 */       .replace("%VL%", String.valueOf(violations))
/* 102 */       .replace("%MAX_VL%", String.valueOf(this.maxViolations));
/* 104 */     Logs.logViolation(player, "AutoclickerA", this.violationMessage);
/* 106 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 107 */       if (staff.hasPermission("storm.alerts"))
/* 108 */         staff.sendMessage(message); 
/*     */     } 
/* 113 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/* 115 */     if (violations >= this.maxViolations)
/* 116 */       handleAction(player); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player) {
/* 121 */     if (!this.isEnabled)
/*     */       return; 
/* 125 */     String commandToExecute = this.kickCommand.replace("%PLAYER%", player.getName());
/* 126 */     Main pluginInstance = Main.getInstance();
/* 127 */     if (pluginInstance == null)
/*     */       return; 
/* 133 */     Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */           if (paramString == null)
/*     */             return; 
/*     */           paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */         });
/* 143 */     violationCount.remove(player.getUniqueId());
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\combat\AutoclickerA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */