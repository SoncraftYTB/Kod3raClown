/*     */ package be.kod3ra.storm.check.combat;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class ReachA implements Listener {
/*     */   private boolean isEnabled;
/*     */   
/*  26 */   private Map<Player, Long> lastAttackTime = new HashMap<>();
/*     */   
/*  27 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private String violationMessage;
/*     */   
/*     */   public ReachA() {
/*  33 */     loadConfigValues();
/*  35 */     if (this.isEnabled)
/*  36 */       ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(
/*  37 */             (Plugin)Main.getInstance(), 
/*  38 */             ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.USE_ENTITY }) {
/*     */             public void onPacketReceiving(PacketEvent event) {
/*  43 */               if (event.getPacketType() == PacketType.Play.Client.USE_ENTITY) {
/*  44 */                 Player player = event.getPlayer();
/*  47 */                 if (player.isOp() || player.hasPermission("storm.bypass.reach"))
/*     */                   return; 
/*  51 */                 int targetEntityId = ((Integer)event.getPacket().getIntegers().read(0)).intValue();
/*  53 */                 Entity targetEntity = ReachA.this.getEntityById(targetEntityId);
/*  54 */                 if (targetEntity instanceof Player) {
/*  55 */                   Player target = (Player)targetEntity;
/*  57 */                   long currentTime = System.currentTimeMillis();
/*  60 */                   if (currentTime - ((Long)ReachA.this.lastAttackTime.getOrDefault(player, Long.valueOf(0L))).longValue() < 1500L)
/*     */                     return; 
/*  64 */                   double reachDistance = 3.95D;
/*  65 */                   double playerReach = player.getLocation().distance(target.getLocation());
/*  67 */                   if (playerReach > reachDistance)
/*  68 */                     ReachA.this.handleViolation(player); 
/*  72 */                   ReachA.this.lastAttackTime.put(player, Long.valueOf(currentTime));
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           }); 
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/*  81 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/*  85 */     UUID playerUUID = player.getUniqueId();
/*  86 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/*  90 */     FileConfiguration config = Main.getInstance().getConfig();
/*  92 */     this.isEnabled = config.getBoolean("checks.ReachA.enabled", true);
/*  94 */     if (!this.isEnabled)
/*     */       return; 
/*  98 */     this.maxViolations = config.getInt("checks.ReachA.max-violations");
/*  99 */     this.kickCommand = config.getString("checks.ReachA.kick-command");
/* 100 */     this.violationMessage = config.getString("checks.ReachA.violation-message");
/*     */   }
/*     */   
/*     */   private Entity getEntityById(int entityId) {
/* 104 */     for (World world : Bukkit.getWorlds()) {
/* 105 */       for (Entity entity : world.getEntities()) {
/* 106 */         if (entity.getEntityId() == entityId)
/* 107 */           return entity; 
/*     */       } 
/*     */     } 
/* 111 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isWithinMaxReach(Player attacker, Player victim) {
/* 115 */     double reach = attacker.getLocation().distance(victim.getLocation());
/* 118 */     return victim.isOnGround();
/*     */   }
/*     */   
/*     */   private void handleViolation(Player player) {
/* 122 */     if (!this.isEnabled)
/*     */       return; 
/* 126 */     UUID playerUUID = player.getUniqueId();
/* 128 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 129 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 131 */     String message = this.violationMessage
/* 132 */       .replace("%PLAYER%", player.getName())
/* 133 */       .replace("%VL%", String.valueOf(violations))
/* 134 */       .replace("%MAX_VL%", String.valueOf(this.maxViolations));
/* 136 */     Logs.logViolation(player, "ReachA", this.violationMessage);
/* 138 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 139 */       if (staff.hasPermission("storm.alerts"))
/* 140 */         staff.sendMessage(message); 
/*     */     } 
/* 145 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/* 147 */     if (violations >= this.maxViolations)
/* 148 */       handleAction(player); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player) {
/* 153 */     if (!this.isEnabled)
/*     */       return; 
/* 157 */     String commandToExecute = this.kickCommand.replace("%PLAYER%", player.getName());
/* 158 */     Main pluginInstance = Main.getInstance();
/* 159 */     if (pluginInstance == null)
/*     */       return; 
/* 165 */     Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */           if (paramString == null)
/*     */             return; 
/*     */           paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */         });
/* 175 */     violationCount.remove(player.getUniqueId());
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\combat\ReachA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */