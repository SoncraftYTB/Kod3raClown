/*     */ package be.kod3ra.storm.check.movement;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.MovementViolationEvent;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerVelocityEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class MotionA implements Listener {
/*  29 */   private Map<UUID, Long> lastMoveTime = new HashMap<>();
/*     */   
/*  30 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*  31 */   private Map<UUID, Location> lastKnownLocations = new HashMap<>();
/*     */   
/*  32 */   private Map<UUID, Long> ignoreTimeMap = new HashMap<>();
/*     */   
/*     */   private static final long IGNORE_TIME_DURATION = 3000L;
/*     */   
/*     */   private static final long COMBAT_IGNORE_TIME = 1000L;
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   public MotionA() {
/*  38 */     loadConfigValues();
/*  40 */     if (this.isEnabled)
/*  41 */       registerListeners(); 
/*     */   }
/*     */   
/*     */   private void registerListeners() {
/*  46 */     ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(
/*  47 */           (Plugin)Main.getInstance(), 
/*  48 */           ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.LOOK, 
/*  50 */             PacketType.Play.Client.POSITION, 
/*  51 */             PacketType.Play.Client.POSITION_LOOK, 
/*  52 */             PacketType.Play.Client.SET_CREATIVE_SLOT }) {
/*     */           public void onPacketReceiving(PacketEvent event) {
/*  56 */             if (event.getPacketType() == PacketType.Play.Client.SET_CREATIVE_SLOT)
/*     */               return; 
/*  60 */             Player player = event.getPlayer();
/*  63 */             if (player.isOp() || player.hasPermission("storm.bypass.motion") || MotionA.this.isPlayerInIgnoreTime(player) || MotionA.this.isPlayerRecentlyJoined(player))
/*     */               return; 
/*  67 */             if (MotionA.this.hasPlayerTeleported(player))
/*     */               return; 
/*  71 */             MotionA.this.lastKnownLocations.put(player.getUniqueId(), player.getLocation());
/*  73 */             UUID playerUUID = player.getUniqueId();
/*  75 */             long currentTime = System.currentTimeMillis();
/*  76 */             if (MotionA.this.lastMoveTime.containsKey(playerUUID)) {
/*  77 */               long lastMove = ((Long)MotionA.this.lastMoveTime.get(playerUUID)).longValue();
/*  78 */               long moveTimeDiff = currentTime - lastMove;
/*  81 */               if (moveTimeDiff < 6L)
/*  82 */                 MotionA.this.handleSpeedDetection(player); 
/*     */             } 
/*  86 */             MotionA.this.lastMoveTime.put(playerUUID, Long.valueOf(currentTime));
/*     */           }
/*     */         });
/*  90 */     Bukkit.getPluginManager().registerEvents(new Listener() {
/*     */           @EventHandler
/*     */           public void onPlayerKnockback(PlayerVelocityEvent event) {
/*  93 */             Player player = event.getPlayer();
/*  96 */             if (player.isOp() || player.hasPermission("storm.bypass.motion") || MotionA.this.isPlayerInIgnoreTime(player) || MotionA.this.isBlockAbovePlayer(player) || MotionA.this.isPlayerNearTrap(player))
/*     */               return; 
/* 101 */             if (event.getVelocity().length() > 0.4D)
/* 103 */               MotionA.this.ignoreTimeMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis() + 3000L)); 
/*     */           }
/*     */           
/*     */           @EventHandler
/*     */           public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 109 */             if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
/* 110 */               Player attacker = (Player)event.getDamager();
/* 111 */               Player victim = (Player)event.getEntity();
/* 114 */               if (!attacker.hasPermission("storm.bypass.combat"))
/* 116 */                 MotionA.this.ignoreTimeMap.put(attacker.getUniqueId(), Long.valueOf(System.currentTimeMillis() + 1000L)); 
/*     */             } 
/*     */           }
/*     */           
/*     */           @EventHandler
/*     */           public void onPlayerJoin(PlayerJoinEvent event) {
/* 123 */             Player player = event.getPlayer();
/* 126 */             MotionA.this.ignoreTimeMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis() + 3000L));
/*     */           }
/* 128 */         }(Plugin)Main.getInstance());
/*     */   }
/*     */   
/*     */   private boolean isPlayerNearTrap(Player player) {
/* 132 */     int radius = 1;
/* 135 */     Location playerLocation = player.getLocation();
/* 138 */     for (int x = -radius; x <= radius; x++) {
/* 139 */       for (int y = -radius; y <= radius; y++) {
/* 140 */         for (int z = -radius; z <= radius; z++) {
/* 141 */           Location blockLocation = playerLocation.clone().add(x, y, z);
/* 144 */           if (isTrapBlock(blockLocation.getBlock().getType()))
/* 145 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isTrapBlock(Material blockType) {
/* 156 */     if (blockType == Material.IRON_TRAPDOOR || blockType == Material.TRAP_DOOR)
/* 157 */       return true; 
/* 161 */     if (blockType.name().contains("_TRAPDOOR"))
/* 162 */       return true; 
/* 165 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isBlockAbovePlayer(Player player) {
/* 169 */     UUID playerUUID = player.getUniqueId();
/* 172 */     if (this.ignoreTimeMap.containsKey(playerUUID)) {
/* 173 */       long ignoreTime = ((Long)this.ignoreTimeMap.get(playerUUID)).longValue();
/* 174 */       long currentTime = System.currentTimeMillis();
/* 176 */       if (currentTime - ignoreTime < 3000L)
/* 177 */         return true; 
/* 179 */       this.ignoreTimeMap.remove(playerUUID);
/*     */     } 
/* 183 */     int playerEyeLevel = player.getEyeLocation().getBlockY();
/* 186 */     if (player.getWorld().getBlockAt(player.getLocation().getBlockX(), playerEyeLevel + 1, player.getLocation().getBlockZ()).getType().isSolid()) {
/* 188 */       this.ignoreTimeMap.put(playerUUID, Long.valueOf(System.currentTimeMillis() + 3000L));
/* 189 */       return true;
/*     */     } 
/* 192 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isPlayerInCombatIgnoreTime(Player player) {
/* 196 */     UUID playerUUID = player.getUniqueId();
/* 198 */     if (this.ignoreTimeMap.containsKey(playerUUID)) {
/* 199 */       long ignoreTime = ((Long)this.ignoreTimeMap.get(playerUUID)).longValue();
/* 200 */       long currentTime = System.currentTimeMillis();
/* 203 */       return (currentTime < ignoreTime);
/*     */     } 
/* 206 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isPlayerRecentlyJoined(Player player) {
/* 210 */     UUID playerUUID = player.getUniqueId();
/* 212 */     if (this.ignoreTimeMap.containsKey(playerUUID)) {
/* 213 */       long ignoreTime = ((Long)this.ignoreTimeMap.get(playerUUID)).longValue();
/* 214 */       long currentTime = System.currentTimeMillis();
/* 217 */       return (currentTime < ignoreTime);
/*     */     } 
/* 220 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isPlayerInIgnoreTime(Player player) {
/* 224 */     UUID playerUUID = player.getUniqueId();
/* 226 */     if (this.ignoreTimeMap.containsKey(playerUUID)) {
/* 227 */       long ignoreTime = ((Long)this.ignoreTimeMap.get(playerUUID)).longValue();
/* 228 */       long currentTime = System.currentTimeMillis();
/* 231 */       return (currentTime < ignoreTime);
/*     */     } 
/* 234 */     return false;
/*     */   }
/*     */   
/*     */   private boolean hasPlayerTeleported(Player player) {
/* 238 */     Location lastLocation = this.lastKnownLocations.get(player.getUniqueId());
/* 239 */     Location currentLocation = player.getLocation();
/* 242 */     return !((lastLocation == null || lastLocation.getWorld().equals(currentLocation.getWorld())) && (
/* 243 */       lastLocation == null || lastLocation.distanceSquared(currentLocation) <= 64.0D));
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/* 247 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/* 251 */     UUID playerUUID = player.getUniqueId();
/* 252 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/* 256 */     this.isEnabled = Main.getInstance().getConfig().getBoolean("checks.MotionA.enabled", true);
/*     */   }
/*     */   
/*     */   private void handleSpeedDetection(Player player) {
/* 260 */     if (!this.isEnabled)
/*     */       return; 
/* 264 */     UUID playerUUID = player.getUniqueId();
/* 266 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 267 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 269 */     Bukkit.getServer().getPluginManager().callEvent((Event)new MovementViolationEvent(player));
/* 270 */     LagBack.updateLastKnownLocation(player);
/* 272 */     int maxViolations = Main.getInstance().getConfig().getInt("checks.MotionA.max-violations");
/* 273 */     String kickCommand = Main.getInstance().getConfig().getString("checks.MotionA.kick-command");
/* 274 */     String violationMessage = Main.getInstance().getConfig().getString("checks.MotionA.violation-message");
/* 276 */     Logs.logViolation(player, "MotionA", violationMessage);
/* 278 */     String message = violationMessage
/* 279 */       .replace("%PLAYER%", player.getName())
/* 280 */       .replace("%VL%", String.valueOf(violations))
/* 281 */       .replace("%MAX_VL%", String.valueOf(maxViolations));
/* 283 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 284 */       if (staff.hasPermission("storm.alerts"))
/* 285 */         staff.sendMessage(message); 
/*     */     } 
/* 290 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/* 292 */     if (violations >= maxViolations)
/* 293 */       handleAction(player, kickCommand); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player, String kickCommand) {
/* 298 */     if (!kickCommand.isEmpty()) {
/* 299 */       String commandToExecute = kickCommand.replace("%PLAYER%", player.getName());
/* 300 */       Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getServer().getConsoleSender(), commandToExecute);
/*     */     } 
/* 303 */     violationCount.remove(player.getUniqueId());
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\movement\MotionA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */