/*     */ package be.kod3ra.storm.check.movement;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.MovementViolationEvent;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.player.PlayerVelocityEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class SpeedA implements Listener {
/*     */   private boolean isEnabled;
/*     */   
/*  32 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*  33 */   private Map<UUID, Long> ignoreTimeMap = new HashMap<>();
/*     */   
/*     */   private static final long IGNORE_TIME_DURATION = 3000L;
/*     */   
/*     */   private static final long VIOLATION_DELAY = 1L;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private String violationMessage;
/*     */   
/*     */   public SpeedA() {
/*  41 */     loadConfigValues();
/*  43 */     if (this.isEnabled) {
/*  44 */       ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(
/*  45 */             (Plugin)Main.getInstance(), 
/*  46 */             ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.POSITION, 
/*  48 */               PacketType.Play.Client.POSITION_LOOK, 
/*  49 */               PacketType.Play.Client.LOOK }) {
/*     */             public void onPacketReceiving(PacketEvent event) {
/*  53 */               if (event.getPacketType() == PacketType.Play.Client.POSITION || 
/*  54 */                 event.getPacketType() == PacketType.Play.Client.POSITION_LOOK || 
/*  55 */                 event.getPacketType() == PacketType.Play.Client.LOOK) {
/*  57 */                 Player player = event.getPlayer();
/*  60 */                 if (player.isOp() || player.hasPermission("storm.bypass.speed"))
/*     */                   return; 
/*  64 */                 if (!SpeedA.this.isBlockAbovePlayer(player) && !SpeedA.this.hasRecentlyDamagedByExplosion(player))
/*  65 */                   SpeedA.this.detectSpeedCheat(player); 
/*     */               } 
/*     */             }
/*     */           });
/*  72 */       Bukkit.getPluginManager().registerEvents(new ExplosionDamageListener(null), (Plugin)Main.getInstance());
/*  74 */       Bukkit.getPluginManager().registerEvents(new KnockbackListener(null), (Plugin)Main.getInstance());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/*  79 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/*  83 */     UUID playerUUID = player.getUniqueId();
/*  84 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   private class KnockbackListener implements Listener {
/*     */     private KnockbackListener() {}
/*     */     
/*     */     @EventHandler
/*     */     public void onPlayerKnockback(PlayerVelocityEvent event) {
/*  91 */       Player player = event.getPlayer();
/*  94 */       if (player.getGameMode() == GameMode.CREATIVE || player.hasPermission("storm.bypass.speed"))
/*     */         return; 
/*  99 */       if (event.getVelocity().length() > 0.4D)
/* 101 */         SpeedA.this.ignoreTimeMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis() + 3000L)); 
/*     */     }
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/* 107 */     FileConfiguration config = Main.getInstance().getConfig();
/* 109 */     this.isEnabled = config.getBoolean("checks.SpeedA.enabled", true);
/* 111 */     if (!this.isEnabled)
/*     */       return; 
/* 115 */     this.maxViolations = config.getInt("checks.SpeedA.max-violations");
/* 116 */     this.kickCommand = config.getString("checks.SpeedA.kick-command");
/* 117 */     this.violationMessage = config.getString("checks.SpeedA.violation-message");
/*     */   }
/*     */   
/*     */   private void detectSpeedCheat(Player player) {
/* 121 */     if (player.isFlying())
/*     */       return; 
/* 125 */     double playerSpeed = getPlayerSpeed(player);
/* 126 */     double maxSpeed = 0.25D;
/* 128 */     if (!isPlayerNearby(player) && playerSpeed > maxSpeed)
/* 129 */       handleViolation(player); 
/*     */   }
/*     */   
/*     */   private boolean isPlayerNearby(Player player) {
/* 134 */     Location playerLocation = player.getLocation();
/* 136 */     for (Player otherPlayer : Bukkit.getServer().getOnlinePlayers()) {
/* 137 */       if (otherPlayer != player && otherPlayer.getWorld() == player.getWorld() && 
/* 138 */         otherPlayer.getLocation().distanceSquared(playerLocation) < 4.0D)
/* 140 */         return true; 
/*     */     } 
/* 144 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isBlockAbovePlayer(Player player) {
/* 148 */     UUID playerUUID = player.getUniqueId();
/* 151 */     if (this.ignoreTimeMap.containsKey(playerUUID)) {
/* 152 */       long ignoreTime = ((Long)this.ignoreTimeMap.get(playerUUID)).longValue();
/* 153 */       long currentTime = System.currentTimeMillis();
/* 155 */       if (currentTime - ignoreTime < 3000L)
/* 156 */         return true; 
/* 158 */       this.ignoreTimeMap.remove(playerUUID);
/*     */     } 
/* 162 */     int playerEyeLevel = player.getEyeLocation().getBlockY();
/* 165 */     if (player.getWorld().getBlockAt(player.getLocation().getBlockX(), playerEyeLevel + 1, player.getLocation().getBlockZ()).getType().isSolid()) {
/* 167 */       this.ignoreTimeMap.put(playerUUID, Long.valueOf(System.currentTimeMillis() + 3000L));
/* 168 */       return true;
/*     */     } 
/* 171 */     return false;
/*     */   }
/*     */   
/*     */   private double getPlayerSpeed(Player player) {
/* 175 */     return Math.sqrt(Math.pow(player.getVelocity().getX(), 2.0D) + Math.pow(player.getVelocity().getZ(), 2.0D));
/*     */   }
/*     */   
/*     */   private void handleViolation(Player player) {
/* 179 */     if (!this.isEnabled)
/*     */       return; 
/* 183 */     long currentTime = System.currentTimeMillis();
/* 184 */     UUID playerUUID = player.getUniqueId();
/* 187 */     if (this.ignoreTimeMap.containsKey(playerUUID) && currentTime - ((Long)this.ignoreTimeMap.get(playerUUID)).longValue() < 1L)
/*     */       return; 
/* 191 */     Bukkit.getServer().getPluginManager().callEvent((Event)new MovementViolationEvent(player));
/* 192 */     LagBack.updateLastKnownLocation(player);
/* 195 */     this.ignoreTimeMap.put(playerUUID, Long.valueOf(currentTime));
/* 197 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 198 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 200 */     String message = this.violationMessage
/* 201 */       .replace("%PLAYER%", player.getName())
/* 202 */       .replace("%VL%", String.valueOf(violations))
/* 203 */       .replace("%MAX_VL%", String.valueOf(this.maxViolations));
/* 205 */     Logs.logViolation(player, "SpeedA", this.violationMessage);
/* 207 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 208 */       if (staff.hasPermission("storm.alerts"))
/* 209 */         staff.sendMessage(message); 
/*     */     } 
/* 214 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/* 216 */     if (violations >= this.maxViolations)
/* 217 */       handleAction(player); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player) {
/* 222 */     if (!this.isEnabled)
/*     */       return; 
/* 226 */     String commandToExecute = this.kickCommand.replace("%PLAYER%", player.getName());
/* 227 */     Main pluginInstance = Main.getInstance();
/* 228 */     if (pluginInstance == null)
/*     */       return; 
/* 234 */     Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */           if (paramString == null)
/*     */             return; 
/*     */           paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */         });
/* 244 */     violationCount.remove(player.getUniqueId());
/*     */   }
/*     */   
/*     */   private boolean hasRecentlyDamagedByExplosion(Player player) {
/* 249 */     return this.ignoreTimeMap.containsKey(player.getUniqueId());
/*     */   }
/*     */   
/*     */   private class ExplosionDamageListener implements Listener {
/*     */     private ExplosionDamageListener() {}
/*     */     
/*     */     @EventHandler
/*     */     public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 256 */       if (event.getDamager().getType() == EntityType.CREEPER && event.getEntity() instanceof Player) {
/* 257 */         Player player = (Player)event.getEntity();
/* 258 */         Location playerLocation = player.getLocation();
/* 261 */         SpeedA.this.ignoreTimeMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis() + 3000L));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\movement\SpeedA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */