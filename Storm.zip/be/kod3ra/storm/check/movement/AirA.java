/*     */ package be.kod3ra.storm.check.movement;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.MovementViolationEvent;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class AirA implements Listener {
/*  26 */   private Map<UUID, Long> lastOnGroundTime = new HashMap<>();
/*     */   
/*  27 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   public AirA() {
/*  31 */     loadConfigValues();
/*  33 */     if (this.isEnabled)
/*  34 */       registerListeners(); 
/*     */   }
/*     */   
/*     */   private void registerListeners() {
/*  39 */     Bukkit.getPluginManager().registerEvents(this, (Plugin)Main.getInstance());
/*  41 */     ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(
/*  42 */           (Plugin)Main.getInstance(), 
/*  43 */           ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.POSITION }) {
/*     */           public void onPacketReceiving(PacketEvent event) {
/*  48 */             Player player = event.getPlayer();
/*  49 */             UUID playerUUID = player.getUniqueId();
/*  52 */             if (player.hasPermission("storm.bypass.air") || player.isOp())
/*     */               return; 
/*  56 */             if (AirA.this.isPlayerInAir(player)) {
/*  57 */               long currentTime = System.currentTimeMillis();
/*  59 */               if (!AirA.this.lastOnGroundTime.containsKey(playerUUID)) {
/*  60 */                 AirA.this.lastOnGroundTime.put(playerUUID, Long.valueOf(currentTime));
/*     */               } else {
/*  62 */                 long lastOnGround = ((Long)AirA.this.lastOnGroundTime.get(playerUUID)).longValue();
/*  63 */                 long airTime = currentTime - lastOnGround;
/*  66 */                 double deltaY = ((Double)event.getPacket().getDoubles().read(1)).doubleValue();
/*  67 */                 if (deltaY < -0.5D || AirA.this.hasLaddersNearby(player.getLocation()))
/*     */                   return; 
/*  71 */                 if (airTime > 2000L)
/*  72 */                   AirA.this.handleAirDetection(player); 
/*     */               } 
/*     */             } else {
/*  76 */               AirA.this.lastOnGroundTime.put(playerUUID, Long.valueOf(System.currentTimeMillis()));
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/*  83 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/*  87 */     UUID playerUUID = player.getUniqueId();
/*  88 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/*  92 */     this.isEnabled = Main.getInstance().getConfig().getBoolean("checks.AirA.enabled", true);
/*     */   }
/*     */   
/*     */   private boolean isPlayerInAir(Player player) {
/*  96 */     Location location = player.getLocation().clone();
/*  97 */     location.setY(location.getY() - 1.0D);
/*  98 */     return (location.getBlock().getType() == Material.AIR);
/*     */   }
/*     */   
/*     */   private boolean hasLaddersNearby(Location location) {
/* 103 */     for (int x = -2; x <= 2; x++) {
/* 104 */       for (int y = -2; y <= 2; y++) {
/* 105 */         for (int z = -2; z <= 2; z++) {
/* 106 */           Location checkLocation = location.clone().add(x, y, z);
/* 107 */           if (checkLocation.getBlock().getType() == Material.LADDER)
/* 108 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 113 */     return false;
/*     */   }
/*     */   
/*     */   private void handleAirDetection(Player player) {
/* 117 */     if (!this.isEnabled)
/*     */       return; 
/* 121 */     Vector velocity = player.getVelocity();
/* 122 */     if (velocity.getY() > -1.0D)
/*     */       return; 
/* 126 */     if (player.getFallDistance() > 0.0F)
/*     */       return; 
/* 130 */     UUID playerUUID = player.getUniqueId();
/* 132 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 133 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 135 */     Bukkit.getServer().getPluginManager().callEvent((Event)new MovementViolationEvent(player));
/* 136 */     LagBack.updateLastKnownLocation(player);
/* 138 */     int maxViolations = Main.getInstance().getConfig().getInt("checks.AirA.max-violations");
/* 139 */     String kickCommand = Main.getInstance().getConfig().getString("checks.AirA.kick-command");
/* 140 */     String violationMessage = Main.getInstance().getConfig().getString("checks.AirA.violation-message");
/* 142 */     Logs.logViolation(player, "AirA", violationMessage);
/* 144 */     String message = violationMessage
/* 145 */       .replace("%PLAYER%", player.getName())
/* 146 */       .replace("%VL%", String.valueOf(violations))
/* 147 */       .replace("%MAX_VL%", String.valueOf(maxViolations));
/* 149 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 150 */       if (staff.hasPermission("storm.alerts"))
/* 151 */         staff.sendMessage(message); 
/*     */     } 
/* 156 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/* 158 */     if (violations >= maxViolations)
/* 159 */       handleAction(player, kickCommand); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player, String kickCommand) {
/* 164 */     if (!kickCommand.isEmpty()) {
/* 165 */       String commandToExecute = kickCommand.replace("%PLAYER%", player.getName());
/* 166 */       Main pluginInstance = Main.getInstance();
/* 167 */       if (pluginInstance == null)
/*     */         return; 
/* 173 */       Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */             if (paramString == null)
/*     */               return; 
/*     */             paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */           });
/*     */     } 
/* 184 */     violationCount.remove(player.getUniqueId());
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\movement\AirA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */