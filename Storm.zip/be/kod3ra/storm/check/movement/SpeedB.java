/*     */ package be.kod3ra.storm.check.movement;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.MovementViolationEvent;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerVelocityEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class SpeedB implements Listener {
/*  33 */   private final Map<UUID, Long> lastMoveTimestamp = new HashMap<>();
/*     */   
/*  34 */   private final Map<UUID, Long> joinTimestamp = new HashMap<>();
/*     */   
/*  35 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*  36 */   private final Map<UUID, Long> ignoreTimeMap = new HashMap<>();
/*     */   
/*  37 */   private final double MAX_SPEED_B = 57.0D;
/*     */   
/*  38 */   private final double MAX_PLAYER_SPEED = 0.63D;
/*     */   
/*     */   private UUID playerUUID;
/*     */   
/*     */   private final Plugin plugin;
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private static final long IGNORE_TIME_DURATION = 2000L;
/*     */   
/*     */   public SpeedB(Plugin plugin) {
/*  46 */     this.plugin = plugin;
/*  47 */     this.isEnabled = plugin.getConfig().getBoolean("checks.SpeedB.enabled", true);
/*  49 */     if (this.isEnabled) {
/*  51 */       Bukkit.getPluginManager().registerEvents(new KnockbackListener(null), plugin);
/*  53 */       ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(plugin, ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.POSITION }) {
/*     */             public void onPacketReceiving(PacketEvent event) {
/*  56 */               if (event.getPacketType() == PacketType.Play.Client.POSITION) {
/*  57 */                 Player player = event.getPlayer();
/*  60 */                 if (player.isOp() || player.getGameMode() == GameMode.CREATIVE || SpeedB.this.isBlockAbovePlayer(player))
/*     */                   return; 
/*  64 */                 UUID playerId = player.getUniqueId();
/*  65 */                 long currentTime = System.currentTimeMillis();
/*  68 */                 if (SpeedB.this.joinTimestamp.containsKey(playerId)) {
/*  69 */                   long joinTime = ((Long)SpeedB.this.joinTimestamp.get(playerId)).longValue();
/*  70 */                   if (currentTime - joinTime < 2000L)
/*     */                     return; 
/*     */                 } 
/*  75 */                 double deltaX = ((Double)event.getPacket().getDoubles().read(0)).doubleValue();
/*  76 */                 double deltaY = ((Double)event.getPacket().getDoubles().read(1)).doubleValue();
/*  77 */                 double deltaZ = ((Double)event.getPacket().getDoubles().read(2)).doubleValue();
/*  80 */                 if (deltaX > -0.63D && deltaX < 0.63D && 
/*  81 */                   deltaZ > -0.63D && deltaZ < 0.63D)
/*     */                   return; 
/*  85 */                 if (SpeedB.this.lastMoveTimestamp.containsKey(playerId)) {
/*  86 */                   long lastMoveTime = ((Long)SpeedB.this.lastMoveTimestamp.get(playerId)).longValue();
/*  87 */                   double speed = SpeedB.this.calculateSpeed(player, deltaX, deltaY, deltaZ, currentTime, lastMoveTime);
/*  89 */                   if (speed > 57.0D) {
/*  90 */                     SpeedB.this.playerUUID = player.getUniqueId();
/*  91 */                     SpeedB.this.handleSpeedViolation(player);
/*     */                   } 
/*     */                 } 
/*  95 */                 SpeedB.this.lastMoveTimestamp.put(playerId, Long.valueOf(currentTime));
/*     */               } 
/*     */             }
/*     */           });
/* 101 */       Bukkit.getPluginManager().registerEvents(this, plugin);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/* 106 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/* 110 */     UUID playerUUID = player.getUniqueId();
/* 111 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/* 116 */     this.joinTimestamp.put(event.getPlayer().getUniqueId(), Long.valueOf(System.currentTimeMillis()));
/*     */   }
/*     */   
/*     */   private double calculateSpeed(Player player, double x, double y, double z, long currentTime, long lastMoveTime) {
/* 120 */     long timeDifference = currentTime - lastMoveTime;
/* 121 */     Vector currentPosition = player.getLocation().toVector();
/* 122 */     Vector lastPosition = new Vector(x, y, z);
/* 124 */     double distance = currentPosition.distance(lastPosition);
/* 125 */     return distance / timeDifference / 1000.0D;
/*     */   }
/*     */   
/*     */   private boolean isSlimeBlockBelowPlayer(Player player) {
/* 129 */     Location playerLocation = player.getLocation();
/* 132 */     for (int y = -50; y >= -200; y--) {
/* 133 */       Location belowLocation = playerLocation.clone().subtract(0.0D, -y, 0.0D);
/* 136 */       if (belowLocation.getBlock().getType() == Material.SLIME_BLOCK)
/* 137 */         return true; 
/*     */     } 
/* 141 */     return false;
/*     */   }
/*     */   
/*     */   private void handleSpeedViolation(Player player) {
/* 144 */     UUID playerUUID = player.getUniqueId();
/* 146 */     Bukkit.getServer().getPluginManager().callEvent((Event)new MovementViolationEvent(player));
/* 147 */     LagBack.updateLastKnownLocation(player);
/* 150 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 152 */     if (player.getFallDistance() > 0.0F)
/*     */       return; 
/* 157 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 159 */     if (isSlimeBlockBelowPlayer(player))
/*     */       return; 
/* 164 */     String violationMessage = this.plugin.getConfig().getString("checks.SpeedB.violation-message");
/* 167 */     violationMessage = violationMessage
/* 168 */       .replace("%PLAYER%", player.getName())
/* 169 */       .replace("%VL%", String.valueOf(violations))
/* 170 */       .replace("%MAX_VL%", String.valueOf(this.plugin.getConfig().getInt("checks.SpeedB.max-violations")));
/* 172 */     Logs.logViolation(player, "SpeedB", violationMessage);
/* 175 */     String alertMessage = violationMessage;
/* 176 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 177 */       if (staff.hasPermission("storm.alerts"))
/* 178 */         staff.sendMessage(alertMessage); 
/*     */     } 
/* 183 */     Bukkit.getServer().getConsoleSender().sendMessage(alertMessage);
/* 186 */     if (violations >= this.plugin.getConfig().getInt("checks.SpeedB.max-violations"))
/* 187 */       handleAction(player); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player) {
/* 193 */     if (player.hasPermission("storm.bypass.speed"))
/*     */       return; 
/* 197 */     String kickCommand = this.plugin.getConfig().getString("checks.SpeedB.kick-command");
/* 200 */     if (((Integer)violationCount.getOrDefault(this.playerUUID, (V)Integer.valueOf(0))).intValue() >= this.plugin.getConfig().getInt("checks.SpeedB.max-violations") && !kickCommand.isEmpty()) {
/* 201 */       String formattedCommand = kickCommand.replace("%PLAYER%", player.getName());
/* 204 */       Main pluginInstance = Main.getInstance();
/* 205 */       if (pluginInstance == null)
/*     */         return; 
/* 211 */       Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */             if (paramString == null)
/*     */               return; 
/*     */             paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */             violationCount.remove(paramPlayer.getUniqueId());
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isBlockAbovePlayer(Player player) {
/* 227 */     UUID playerUUID = player.getUniqueId();
/* 230 */     if (this.ignoreTimeMap.containsKey(playerUUID)) {
/* 231 */       long ignoreTime = ((Long)this.ignoreTimeMap.get(playerUUID)).longValue();
/* 232 */       long currentTime = System.currentTimeMillis();
/* 234 */       if (currentTime - ignoreTime < 2000L)
/* 235 */         return true; 
/* 237 */       this.ignoreTimeMap.remove(playerUUID);
/*     */     } 
/* 241 */     int playerEyeLevel = player.getEyeLocation().getBlockY();
/* 244 */     if (isStairBlock(player.getWorld().getBlockAt(player.getLocation().getBlockX(), playerEyeLevel + 1, player.getLocation().getBlockZ()))) {
/* 246 */       this.ignoreTimeMap.put(playerUUID, Long.valueOf(System.currentTimeMillis() + 2000L));
/* 247 */       return true;
/*     */     } 
/* 251 */     for (int x = -3; x <= 3; x++) {
/* 252 */       for (int y = -3; y <= 3; y++) {
/* 253 */         for (int z = -3; z <= 3; z++) {
/* 254 */           if (isStairBlock(player.getWorld().getBlockAt(player.getLocation().getBlockX() + x, player.getLocation().getBlockY() + y, player.getLocation().getBlockZ() + z))) {
/* 256 */             this.ignoreTimeMap.put(playerUUID, Long.valueOf(System.currentTimeMillis() + 2000L));
/* 257 */             return true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 263 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isStairBlock(Block block) {
/* 268 */     Material blockType = block.getType();
/* 269 */     return !(!blockType.name().endsWith("_STAIRS") && !blockType.name().endsWith("_STAIR"));
/*     */   }
/*     */   
/*     */   private class KnockbackListener implements Listener {
/*     */     private KnockbackListener() {}
/*     */     
/*     */     @EventHandler
/*     */     public void onPlayerKnockback(PlayerVelocityEvent event) {
/* 277 */       Player player = event.getPlayer();
/* 280 */       if (player.getGameMode() == GameMode.CREATIVE || player.hasPermission("storm.bypass.speed"))
/*     */         return; 
/* 285 */       if (event.getVelocity().length() > 0.4D)
/* 287 */         SpeedB.this.ignoreTimeMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis() + 2000L)); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\movement\SpeedB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */