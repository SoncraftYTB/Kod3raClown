/*     */ package be.kod3ra.storm.check.movement;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.MovementViolationEvent;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class FlightB implements Listener {
/*  26 */   private final Map<Player, Vector> playerPositions = new HashMap<>();
/*     */   
/*  27 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*     */   private boolean isEnabled;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private String violationMessage;
/*     */   
/*     */   public FlightB() {
/*  34 */     loadConfigValues();
/*  36 */     if (this.isEnabled)
/*  37 */       ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(
/*  38 */             (Plugin)Main.getInstance(), 
/*  39 */             ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.POSITION, 
/*  41 */               PacketType.Play.Client.LOOK, 
/*  42 */               PacketType.Play.Client.POSITION_LOOK }) {
/*     */             public void onPacketReceiving(PacketEvent event) {
/*  46 */               if (event.getPacketType() == PacketType.Play.Client.POSITION || 
/*  47 */                 event.getPacketType() == PacketType.Play.Client.LOOK || 
/*  48 */                 event.getPacketType() == PacketType.Play.Client.POSITION_LOOK) {
/*  50 */                 Player player = event.getPlayer();
/*  53 */                 if (!player.isOp() && !player.hasPermission("storm.bypass.fly"))
/*  54 */                   FlightB.this.detectFlightB(player); 
/*     */               } 
/*     */             }
/*     */           }); 
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/*  63 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/*  67 */     UUID playerUUID = player.getUniqueId();
/*  68 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/*  72 */     FileConfiguration config = Main.getInstance().getConfig();
/*  74 */     this.isEnabled = config.getBoolean("checks.FlightB.enabled", true);
/*  76 */     if (!this.isEnabled)
/*     */       return; 
/*  80 */     this.maxViolations = config.getInt("checks.FlightB.max-violations", 20);
/*  81 */     this.kickCommand = config.getString("checks.FlightB.kick-command", "");
/*  82 */     this.violationMessage = config.getString("checks.FlightB.violation-message");
/*     */   }
/*     */   
/*     */   private void detectFlightB(Player player) {
/*  86 */     if (!this.isEnabled)
/*     */       return; 
/*  90 */     if (player.isOnGround())
/*     */       return; 
/*  94 */     Vector velocity = player.getVelocity();
/*  95 */     if (velocity.getY() > -1.0D)
/*     */       return; 
/*  99 */     if (player.getFallDistance() > 0.0F)
/*     */       return; 
/* 103 */     Vector newPosition = player.getLocation().toVector();
/* 105 */     if (this.playerPositions.containsKey(player)) {
/* 106 */       Vector previousPosition = this.playerPositions.get(player);
/* 108 */       double difference = newPosition.clone().subtract(previousPosition).setY(0).length();
/* 110 */       double threshold = 0.2D;
/* 112 */       if (difference > threshold)
/* 113 */         handleFlightBViolation(player); 
/*     */     } 
/* 117 */     this.playerPositions.put(player, newPosition.clone());
/*     */   }
/*     */   
/*     */   private void handleFlightBViolation(Player player) {
/* 121 */     UUID playerUUID = player.getUniqueId();
/* 123 */     Bukkit.getServer().getPluginManager().callEvent((Event)new MovementViolationEvent(player));
/* 124 */     LagBack.updateLastKnownLocation(player);
/* 127 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 130 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 132 */     String violationMessage = this.violationMessage
/* 133 */       .replace("%PLAYER%", player.getName())
/* 134 */       .replace("%VL%", String.valueOf(violations))
/* 135 */       .replace("%MAX_VL%", String.valueOf(this.maxViolations));
/* 137 */     Logs.logViolation(player, "FlightB", violationMessage);
/* 140 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 141 */       if (staff.hasPermission("storm.alerts"))
/* 142 */         staff.sendMessage(violationMessage); 
/*     */     } 
/* 147 */     Bukkit.getServer().getConsoleSender().sendMessage(violationMessage);
/* 150 */     if (violations >= this.maxViolations && !this.kickCommand.isEmpty()) {
/* 151 */       String formattedCommand = this.kickCommand.replace("%PLAYER%", player.getName());
/* 154 */       Main pluginInstance = Main.getInstance();
/* 155 */       if (pluginInstance == null)
/*     */         return; 
/* 161 */       Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */             if (paramString == null)
/*     */               return; 
/*     */             paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */             violationCount.remove(paramUUID);
/*     */           });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\movement\FlightB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */