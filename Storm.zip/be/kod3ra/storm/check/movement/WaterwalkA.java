/*     */ package be.kod3ra.storm.check.movement;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.MovementViolationEvent;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class WaterwalkA implements Listener {
/*  26 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*     */   private final int maxViolations;
/*     */   
/*     */   private final String kickCommand;
/*     */   
/*     */   private final String violationMessage;
/*     */   
/*     */   private final boolean isEnabled;
/*     */   
/*  31 */   private final int ignoreRadius = 4;
/*     */   
/*  32 */   private final Map<UUID, Long> teleportIgnoreMap = new HashMap<>();
/*     */   
/*  33 */   private final int teleportIgnoreDuration = 1000;
/*     */   
/*     */   public WaterwalkA() {
/*  38 */     Main plugin = Main.getInstance();
/*  39 */     this.isEnabled = plugin.getConfig().getBoolean("checks.WaterwalkA.enabled", true);
/*  41 */     if (!this.isEnabled) {
/*  42 */       this.maxViolations = 0;
/*  43 */       this.kickCommand = "";
/*  44 */       this.violationMessage = "";
/*     */       return;
/*     */     } 
/*  48 */     this.maxViolations = plugin.getConfig().getInt("checks.WaterwalkA.max-violations");
/*  49 */     this.kickCommand = plugin.getConfig().getString("checks.WaterwalkA.kick-command");
/*  50 */     this.violationMessage = plugin.getConfig().getString("checks.WaterwalkA.violation-message");
/*  53 */     ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(
/*  54 */           (Plugin)plugin, 
/*  55 */           ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.POSITION_LOOK, 
/*  57 */             PacketType.Play.Client.POSITION, 
/*  58 */             PacketType.Play.Client.LOOK }) {
/*     */           public void onPacketReceiving(PacketEvent event) {
/*  61 */             Player player = event.getPlayer();
/*  62 */             WaterwalkA.this.checkWaterwalk(player);
/*     */           }
/*     */         });
/*  65 */     Bukkit.getScheduler().runTaskTimer((Plugin)plugin, () -> this.teleportIgnoreMap.entrySet().removeIf(()), 
/*     */         
/*  67 */         0L, 20L);
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/*  71 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/*  75 */     UUID playerUUID = player.getUniqueId();
/*  76 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   private void checkWaterwalk(Player player) {
/*  81 */     if (player.hasPermission("storm.bypass.waterwalk") || player.isOp())
/*     */       return; 
/*  86 */     if (isLilyPadNearby(player.getLocation()))
/*     */       return; 
/*  90 */     if (isPlayerTeleportIgnored(player))
/*     */       return; 
/*  93 */     this.teleportIgnoreMap.put(player.getUniqueId(), Long.valueOf(System.currentTimeMillis() + 1000L));
/*  95 */     Location playerLocation = player.getLocation();
/*  98 */     if (isPlayerNearSolidBlock(playerLocation))
/*     */       return; 
/* 103 */     if (isAboveWaterWithoutFalling(playerLocation)) {
/* 105 */       if (isPlayerTouchingWater(playerLocation))
/*     */         return; 
/* 108 */       handleViolation(player);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPlayerTeleportIgnored(Player player) {
/* 113 */     UUID playerUUID = player.getUniqueId();
/* 114 */     return (this.teleportIgnoreMap.containsKey(playerUUID) && (
/* 115 */       (Long)this.teleportIgnoreMap.get(playerUUID)).longValue() > System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   private boolean isLilyPadNearby(Location location) {
/* 120 */     for (int x = -2; x <= 2; x++) {
/* 121 */       for (int y = -2; y <= 2; y++) {
/* 122 */         for (int z = -2; z <= 2; z++) {
/* 123 */           Location nearbyLocation = location.clone().add(x, y, z);
/* 126 */           if (nearbyLocation.getBlock().getType() == Material.WATER_LILY)
/* 127 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 133 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isAboveWaterWithoutFalling(Location location) {
/* 138 */     Material blockBelow = location.getBlock().getRelative(0, -1, 0).getType();
/* 139 */     return !(blockBelow != Material.WATER && blockBelow != Material.STATIONARY_WATER);
/*     */   }
/*     */   
/*     */   private boolean isPlayerTouchingWater(Location location) {
/* 144 */     Material playerBlock = location.getBlock().getType();
/* 145 */     return !(playerBlock != Material.WATER && playerBlock != Material.STATIONARY_WATER);
/*     */   }
/*     */   
/*     */   private boolean isPlayerNearSolidBlock(Location location) {
/* 150 */     for (int x = -4; x <= 4; x++) {
/* 151 */       for (int y = -4; y <= 4; y++) {
/* 152 */         for (int z = -4; z <= 4; z++) {
/* 153 */           Block block = location.clone().add(x, y, z).getBlock();
/* 154 */           if (block.getType().isSolid())
/* 155 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 160 */     return false;
/*     */   }
/*     */   
/*     */   private void handleViolation(Player player) {
/* 164 */     UUID playerUUID = player.getUniqueId();
/* 166 */     Bukkit.getServer().getPluginManager().callEvent((Event)new MovementViolationEvent(player));
/* 167 */     LagBack.updateLastKnownLocation(player);
/* 169 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 170 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 172 */     String message = this.violationMessage
/* 173 */       .replace("%PLAYER%", player.getName())
/* 174 */       .replace("%VL%", String.valueOf(violations))
/* 175 */       .replace("%MAX_VL%", String.valueOf(this.maxViolations));
/* 177 */     Logs.logViolation(player, "WaterwalkA", this.violationMessage);
/* 179 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 180 */       if (staff.hasPermission("storm.alerts"))
/* 181 */         staff.sendMessage(message); 
/*     */     } 
/* 186 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/* 188 */     if (violations >= this.maxViolations)
/* 189 */       handleAction(player); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player) {
/* 194 */     String commandToExecute = this.kickCommand.replace("%PLAYER%", player.getName());
/* 195 */     Main pluginInstance = Main.getInstance();
/* 196 */     if (pluginInstance == null)
/*     */       return; 
/* 202 */     Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */           if (paramString == null)
/*     */             return; 
/*     */           paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */         });
/* 212 */     violationCount.remove(player.getUniqueId());
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\movement\WaterwalkA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */