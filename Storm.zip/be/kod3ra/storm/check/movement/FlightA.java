/*     */ package be.kod3ra.storm.check.movement;
/*     */ 
/*     */ import be.kod3ra.storm.Main;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.MovementViolationEvent;
/*     */ import com.comphenix.protocol.PacketType;
/*     */ import com.comphenix.protocol.ProtocolLibrary;
/*     */ import com.comphenix.protocol.events.ListenerPriority;
/*     */ import com.comphenix.protocol.events.PacketAdapter;
/*     */ import com.comphenix.protocol.events.PacketEvent;
/*     */ import com.comphenix.protocol.events.PacketListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class FlightA implements Listener {
/*     */   private boolean isEnabled;
/*     */   
/*  30 */   private final Map<UUID, Double> previousY = new HashMap<>();
/*     */   
/*  31 */   private static final Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private String violationMessage;
/*     */   
/*     */   public FlightA() {
/*  37 */     loadConfigValues();
/*  39 */     if (this.isEnabled)
/*  40 */       ProtocolLibrary.getProtocolManager().addPacketListener((PacketListener)new PacketAdapter(
/*  41 */             (Plugin)Main.getInstance(), 
/*  42 */             ListenerPriority.NORMAL, new PacketType[] { PacketType.Play.Client.LOOK, 
/*  44 */               PacketType.Play.Client.POSITION, 
/*  45 */               PacketType.Play.Client.POSITION_LOOK }) {
/*     */             public void onPacketReceiving(PacketEvent event) {
/*  49 */               if (event.getPacketType() == PacketType.Play.Client.POSITION_LOOK || 
/*  50 */                 event.getPacketType() == PacketType.Play.Client.POSITION || 
/*  51 */                 event.getPacketType() == PacketType.Play.Client.LOOK) {
/*  53 */                 Player player = event.getPlayer();
/*  54 */                 FlightA.this.detectFlyCheat(player);
/*     */               } 
/*     */             }
/*     */           }); 
/*     */   }
/*     */   
/*     */   private boolean isNearStair(Player player) {
/*  62 */     Location playerLocation = player.getLocation();
/*  63 */     World world = playerLocation.getWorld();
/*  65 */     int radius = 4;
/*  67 */     for (int x = -radius; x <= radius; x++) {
/*  68 */       for (int y = -radius; y <= radius; y++) {
/*  69 */         for (int z = -radius; z <= radius; z++) {
/*  70 */           Block block = world.getBlockAt(playerLocation.getBlockX() + x, playerLocation.getBlockY() + y, playerLocation.getBlockZ() + z);
/*  71 */           if (isStairBlock(block))
/*  72 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/*  78 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isStairBlock(Block block) {
/*  82 */     Material blockType = block.getType();
/*  83 */     return !(!blockType.name().endsWith("_STAIRS") && !blockType.name().endsWith("_STAIR"));
/*     */   }
/*     */   
/*     */   public static void resetAllViolations() {
/*  87 */     violationCount.clear();
/*     */   }
/*     */   
/*     */   public static void resetViolations(Player player) {
/*  91 */     UUID playerUUID = player.getUniqueId();
/*  92 */     violationCount.remove(playerUUID);
/*     */   }
/*     */   
/*     */   private void loadConfigValues() {
/*  96 */     FileConfiguration config = Main.getInstance().getConfig();
/*  98 */     this.isEnabled = config.getBoolean("checks.FlightA.enabled", true);
/* 100 */     if (!this.isEnabled)
/*     */       return; 
/* 104 */     this.maxViolations = config.getInt("checks.FlightA.max-violations");
/* 105 */     this.kickCommand = config.getString("checks.FlightA.kick-command");
/* 106 */     this.violationMessage = config.getString("checks.FlightA.violation-message");
/*     */   }
/*     */   
/*     */   private void detectFlyCheat(Player player) {
/* 110 */     if (!this.isEnabled)
/*     */       return; 
/* 114 */     if (player.getFallDistance() > 0.0F)
/*     */       return; 
/* 118 */     if (player.isOp())
/*     */       return; 
/* 122 */     if (player.hasPermission("storm.bypass.fly"))
/*     */       return; 
/* 126 */     if (isNearStair(player))
/*     */       return; 
/* 130 */     UUID playerUUID = player.getUniqueId();
/* 131 */     double currentY = player.getLocation().getY();
/* 133 */     if (this.previousY.containsKey(playerUUID)) {
/* 134 */       double previousPosY = ((Double)this.previousY.get(playerUUID)).doubleValue();
/* 136 */       if (currentY < previousPosY)
/*     */         return; 
/*     */     } 
/* 141 */     this.previousY.put(playerUUID, Double.valueOf(currentY));
/* 143 */     double velocityY = Math.abs(player.getVelocity().getY());
/* 144 */     double jumpHeight = 0.42D;
/* 146 */     if (velocityY > jumpHeight)
/* 147 */       handleViolation(player); 
/*     */   }
/*     */   
/*     */   private void handleViolation(Player player) {
/* 152 */     if (!this.isEnabled)
/*     */       return; 
/* 156 */     Bukkit.getServer().getPluginManager().callEvent((Event)new MovementViolationEvent(player));
/* 157 */     LagBack.updateLastKnownLocation(player);
/* 159 */     UUID playerUUID = player.getUniqueId();
/* 161 */     int violations = ((Integer)violationCount.getOrDefault(playerUUID, Integer.valueOf(0))).intValue() + 1;
/* 162 */     violationCount.put(playerUUID, Integer.valueOf(violations));
/* 164 */     String message = this.violationMessage
/* 165 */       .replace("%PLAYER%", player.getName())
/* 166 */       .replace("%VL%", String.valueOf(violations))
/* 167 */       .replace("%MAX_VL%", String.valueOf(this.maxViolations));
/* 169 */     Logs.logViolation(player, "FlightA", this.violationMessage);
/* 171 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 172 */       if (staff.hasPermission("storm.alerts"))
/* 173 */         staff.sendMessage(message); 
/*     */     } 
/* 178 */     Bukkit.getServer().getConsoleSender().sendMessage(message);
/* 180 */     if (violations >= this.maxViolations)
/* 181 */       handleAction(player); 
/*     */   }
/*     */   
/*     */   private void handleAction(Player player) {
/* 186 */     if (!this.isEnabled)
/*     */       return; 
/* 190 */     String commandToExecute = this.kickCommand.replace("%PLAYER%", player.getName());
/* 191 */     Main pluginInstance = Main.getInstance();
/* 192 */     if (pluginInstance == null)
/*     */       return; 
/* 198 */     Bukkit.getScheduler().runTask((Plugin)pluginInstance, () -> {
/*     */           if (paramString == null)
/*     */             return; 
/*     */           paramMain.getServer().dispatchCommand((CommandSender)paramMain.getServer().getConsoleSender(), paramString);
/*     */         });
/* 208 */     violationCount.remove(player.getUniqueId());
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\check\movement\FlightA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */