/*     */ package be.kod3ra.storm;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.logging.Level;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class Metrics {
/*     */   private final Plugin plugin;
/*     */   
/*     */   private final MetricsBase metricsBase;
/*     */   
/*     */   public Metrics(JavaPlugin plugin, int serviceId) {
/*  64 */     this.plugin = (Plugin)plugin;
/*  66 */     File bStatsFolder = new File(plugin.getDataFolder().getParentFile(), "bStats");
/*  67 */     File configFile = new File(bStatsFolder, "config.yml");
/*  68 */     YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
/*  69 */     if (!config.isSet("serverUuid")) {
/*  70 */       config.addDefault("enabled", Boolean.valueOf(true));
/*  71 */       config.addDefault("serverUuid", UUID.randomUUID().toString());
/*  72 */       config.addDefault("logFailedRequests", Boolean.valueOf(false));
/*  73 */       config.addDefault("logSentData", Boolean.valueOf(false));
/*  74 */       config.addDefault("logResponseStatusText", Boolean.valueOf(false));
/*  76 */       config
/*  77 */         .options()
/*  78 */         .header(
/*  79 */           "bStats (https://bStats.org) collects some basic information for plugin authors, like how\nmany people use their plugin and their total player count. It's recommended to keep bStats\nenabled, but if you're not comfortable with this, you can turn this setting off. There is no\nperformance penalty associated with having metrics enabled, and data sent to bStats is fully\nanonymous.")
/*     */         
/*  84 */         .copyDefaults(true);
/*     */       try {
/*  86 */         config.save(configFile);
/*  87 */       } catch (IOException iOException) {}
/*     */     } 
/*  91 */     boolean enabled = config.getBoolean("enabled", true);
/*  92 */     String serverUUID = config.getString("serverUuid");
/*  93 */     boolean logErrors = config.getBoolean("logFailedRequests", false);
/*  94 */     boolean logSentData = config.getBoolean("logSentData", false);
/*  95 */     boolean logResponseStatusText = config.getBoolean("logResponseStatusText", false);
/*  96 */     this.metricsBase = 
/*  97 */       new MetricsBase(
/*  98 */         "bukkit", 
/*  99 */         serverUUID, 
/* 100 */         serviceId, 
/* 101 */         enabled, 
/* 102 */         this::appendPlatformData, 
/* 103 */         this::appendServiceData, submitDataTask -> {
/*     */         
/* 105 */         }plugin::isEnabled, (message, error) -> this.plugin.getLogger().log(Level.WARNING, message, error), message -> this.plugin.getLogger().log(Level.INFO, message), 
/*     */         
/* 108 */         logErrors, 
/* 109 */         logSentData, 
/* 110 */         logResponseStatusText);
/*     */   }
/*     */   
/*     */   public void shutdown() {
/* 115 */     this.metricsBase.shutdown();
/*     */   }
/*     */   
/*     */   public void addCustomChart(CustomChart chart) {
/* 124 */     this.metricsBase.addCustomChart(chart);
/*     */   }
/*     */   
/*     */   private void appendPlatformData(JsonObjectBuilder builder) {
/* 128 */     builder.appendField("playerAmount", getPlayerAmount());
/* 129 */     builder.appendField("onlineMode", Bukkit.getOnlineMode() ? 1 : 0);
/* 130 */     builder.appendField("bukkitVersion", Bukkit.getVersion());
/* 131 */     builder.appendField("bukkitName", Bukkit.getName());
/* 132 */     builder.appendField("javaVersion", System.getProperty("java.version"));
/* 133 */     builder.appendField("osName", System.getProperty("os.name"));
/* 134 */     builder.appendField("osArch", System.getProperty("os.arch"));
/* 135 */     builder.appendField("osVersion", System.getProperty("os.version"));
/* 136 */     builder.appendField("coreCount", Runtime.getRuntime().availableProcessors());
/*     */   }
/*     */   
/*     */   private void appendServiceData(JsonObjectBuilder builder) {
/* 140 */     builder.appendField("pluginVersion", this.plugin.getDescription().getVersion());
/*     */   }
/*     */   
/*     */   private int getPlayerAmount() {
/*     */     try {
/* 148 */       Method onlinePlayersMethod = Class.forName("org.bukkit.Server").getMethod("getOnlinePlayers", new Class[0]);
/* 149 */       return onlinePlayersMethod.getReturnType().equals(Collection.class) ? (
/* 150 */         (Collection)onlinePlayersMethod.invoke(Bukkit.getServer(), new Object[0])).size() : (
/* 151 */         (Player[])onlinePlayersMethod.invoke(Bukkit.getServer(), new Object[0])).length;
/* 152 */     } catch (Exception e) {
/* 154 */       return Bukkit.getOnlinePlayers().size();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class MetricsBase {
/*     */     public static final String METRICS_VERSION = "3.0.2";
/*     */     
/*     */     private static final String REPORT_URL = "https://bStats.org/api/v2/data/%s";
/*     */     
/*     */     private final ScheduledExecutorService scheduler;
/*     */     
/*     */     private final String platform;
/*     */     
/*     */     private final String serverUuid;
/*     */     
/*     */     private final int serviceId;
/*     */     
/*     */     private final Consumer<Metrics.JsonObjectBuilder> appendPlatformDataConsumer;
/*     */     
/*     */     private final Consumer<Metrics.JsonObjectBuilder> appendServiceDataConsumer;
/*     */     
/*     */     private final Consumer<Runnable> submitTaskConsumer;
/*     */     
/*     */     private final Supplier<Boolean> checkServiceEnabledSupplier;
/*     */     
/*     */     private final BiConsumer<String, Throwable> errorLogger;
/*     */     
/*     */     private final Consumer<String> infoLogger;
/*     */     
/*     */     private final boolean logErrors;
/*     */     
/*     */     private final boolean logSentData;
/*     */     
/*     */     private final boolean logResponseStatusText;
/*     */     
/* 191 */     private final Set<Metrics.CustomChart> customCharts = new HashSet<>();
/*     */     
/*     */     private final boolean enabled;
/*     */     
/*     */     public MetricsBase(String platform, String serverUuid, int serviceId, boolean enabled, Consumer<Metrics.JsonObjectBuilder> appendPlatformDataConsumer, Consumer<Metrics.JsonObjectBuilder> appendServiceDataConsumer, Consumer<Runnable> submitTaskConsumer, Supplier<Boolean> checkServiceEnabledSupplier, BiConsumer<String, Throwable> errorLogger, Consumer<String> infoLogger, boolean logErrors, boolean logSentData, boolean logResponseStatusText) {
/* 230 */       ScheduledThreadPoolExecutor scheduler = 
/* 231 */         new ScheduledThreadPoolExecutor(1, task -> new Thread(task, "bStats-Metrics"));
/* 236 */       scheduler.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
/* 237 */       this.scheduler = scheduler;
/* 238 */       this.platform = platform;
/* 239 */       this.serverUuid = serverUuid;
/* 240 */       this.serviceId = serviceId;
/* 241 */       this.enabled = enabled;
/* 242 */       this.appendPlatformDataConsumer = appendPlatformDataConsumer;
/* 243 */       this.appendServiceDataConsumer = appendServiceDataConsumer;
/* 244 */       this.submitTaskConsumer = submitTaskConsumer;
/* 245 */       this.checkServiceEnabledSupplier = checkServiceEnabledSupplier;
/* 246 */       this.errorLogger = errorLogger;
/* 247 */       this.infoLogger = infoLogger;
/* 248 */       this.logErrors = logErrors;
/* 249 */       this.logSentData = logSentData;
/* 250 */       this.logResponseStatusText = logResponseStatusText;
/* 251 */       checkRelocation();
/* 252 */       if (enabled)
/* 255 */         startSubmitting(); 
/*     */     }
/*     */     
/*     */     public void addCustomChart(Metrics.CustomChart chart) {
/* 260 */       this.customCharts.add(chart);
/*     */     }
/*     */     
/*     */     public void shutdown() {
/* 264 */       this.scheduler.shutdown();
/*     */     }
/*     */     
/*     */     private void startSubmitting() {
/* 268 */       Runnable submitTask = () -> {
/*     */           if (!this.enabled || !((Boolean)this.checkServiceEnabledSupplier.get()).booleanValue()) {
/*     */             this.scheduler.shutdown();
/*     */             return;
/*     */           } 
/*     */           if (this.submitTaskConsumer != null) {
/*     */             this.submitTaskConsumer.accept(this::submitData);
/*     */           } else {
/*     */             submitData();
/*     */           } 
/*     */         };
/* 289 */       long initialDelay = (long)(60000.0D * (3.0D + Math.random() * 3.0D));
/* 290 */       long secondDelay = (long)(60000.0D * Math.random() * 30.0D);
/* 291 */       this.scheduler.schedule(submitTask, initialDelay, TimeUnit.MILLISECONDS);
/* 292 */       this.scheduler.scheduleAtFixedRate(
/* 293 */           submitTask, initialDelay + secondDelay, 1800000L, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     
/*     */     private void submitData() {
/* 297 */       Metrics.JsonObjectBuilder baseJsonBuilder = new Metrics.JsonObjectBuilder();
/* 298 */       this.appendPlatformDataConsumer.accept(baseJsonBuilder);
/* 299 */       Metrics.JsonObjectBuilder serviceJsonBuilder = new Metrics.JsonObjectBuilder();
/* 300 */       this.appendServiceDataConsumer.accept(serviceJsonBuilder);
/* 301 */       Metrics.JsonObjectBuilder.JsonObject[] chartData = 
/* 302 */         (Metrics.JsonObjectBuilder.JsonObject[])this.customCharts.stream()
/* 303 */         .map(customChart -> customChart.getRequestJsonObject(this.errorLogger, this.logErrors))
/* 304 */         .filter(Objects::nonNull)
/* 305 */         .toArray(param1Int -> new Metrics.JsonObjectBuilder.JsonObject[param1Int]);
/* 306 */       serviceJsonBuilder.appendField("id", this.serviceId);
/* 307 */       serviceJsonBuilder.appendField("customCharts", chartData);
/* 308 */       baseJsonBuilder.appendField("service", serviceJsonBuilder.build());
/* 309 */       baseJsonBuilder.appendField("serverUUID", this.serverUuid);
/* 310 */       baseJsonBuilder.appendField("metricsVersion", "3.0.2");
/* 311 */       Metrics.JsonObjectBuilder.JsonObject data = baseJsonBuilder.build();
/* 312 */       this.scheduler.execute(() -> {
/*     */             try {
/*     */               sendData(param1JsonObject);
/* 317 */             } catch (Exception e) {
/*     */               if (this.logErrors)
/*     */                 this.errorLogger.accept("Could not submit bStats metrics data", e); 
/*     */             } 
/*     */           });
/*     */     }
/*     */     
/*     */     private void sendData(Metrics.JsonObjectBuilder.JsonObject data) throws Exception {
/*     */       StringBuilder builder;
/* 327 */       if (this.logSentData)
/* 328 */         this.infoLogger.accept("Sent bStats metrics data: " + data.toString()); 
/* 330 */       String url = String.format("https://bStats.org/api/v2/data/%s", new Object[] { this.platform });
/* 331 */       HttpsURLConnection connection = (HttpsURLConnection)(new URL(url)).openConnection();
/* 333 */       byte[] compressedData = compress(data.toString());
/* 334 */       connection.setRequestMethod("POST");
/* 335 */       connection.addRequestProperty("Accept", "application/json");
/* 336 */       connection.addRequestProperty("Connection", "close");
/* 337 */       connection.addRequestProperty("Content-Encoding", "gzip");
/* 338 */       connection.addRequestProperty("Content-Length", String.valueOf(compressedData.length));
/* 339 */       connection.setRequestProperty("Content-Type", "application/json");
/* 340 */       connection.setRequestProperty("User-Agent", "Metrics-Service/1");
/* 341 */       connection.setDoOutput(true);
/* 342 */       Exception exception1 = null, exception2 = null;
/*     */       try {
/* 342 */         DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
/*     */         try {
/* 343 */           outputStream.write(compressedData);
/*     */         } finally {
/* 344 */           if (outputStream != null)
/* 344 */             outputStream.close(); 
/*     */         } 
/*     */       } finally {
/* 344 */         exception2 = null;
/* 344 */         if (exception1 == null) {
/* 344 */           exception1 = exception2;
/* 344 */         } else if (exception1 != exception2) {
/* 344 */           exception1.addSuppressed(exception2);
/*     */         } 
/*     */       } 
/* 346 */       Exception exception3 = null;
/*     */       try {
/* 346 */         BufferedReader bufferedReader = 
/* 347 */           new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*     */         try {
/*     */           String line;
/* 349 */           while ((line = bufferedReader.readLine()) != null)
/* 350 */             builder.append(line); 
/*     */         } finally {
/* 352 */           if (bufferedReader != null)
/* 352 */             bufferedReader.close(); 
/*     */         } 
/*     */       } finally {
/* 352 */         exception3 = null;
/* 352 */         if (exception2 == null) {
/* 352 */           exception2 = exception3;
/* 352 */         } else if (exception2 != exception3) {
/* 352 */           exception2.addSuppressed(exception3);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void checkRelocation() {
/* 361 */       if (System.getProperty("bstats.relocatecheck") == null || 
/* 362 */         !System.getProperty("bstats.relocatecheck").equals("false")) {
/* 365 */         String defaultPackage = 
/* 366 */           new String(new byte[] { 111, 114, 103, 46, 98, 115, 116, 97, 116, 115 });
/* 367 */         String examplePackage = 
/* 368 */           new String(new byte[] { 
/* 368 */               121, 111, 117, 114, 46, 112, 97, 99, 107, 97, 
/* 368 */               103, 101 });
/* 371 */         if (MetricsBase.class.getPackage().getName().startsWith(defaultPackage) || 
/* 372 */           MetricsBase.class.getPackage().getName().startsWith(examplePackage))
/* 373 */           throw new IllegalStateException("bStats Metrics class has not been relocated correctly!"); 
/*     */       } 
/*     */     }
/*     */     
/*     */     private static byte[] compress(String str) throws IOException {
/* 385 */       if (str == null)
/* 386 */         return null; 
/* 388 */       ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
/* 389 */       Exception exception1 = null, exception2 = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SimplePie extends CustomChart {
/*     */     private final Callable<String> callable;
/*     */     
/*     */     public SimplePie(String chartId, Callable<String> callable) {
/* 407 */       super(chartId);
/* 408 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 413 */       String value = this.callable.call();
/* 414 */       if (value == null || value.isEmpty())
/* 416 */         return null; 
/* 418 */       return (new Metrics.JsonObjectBuilder()).appendField("value", value).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MultiLineChart extends CustomChart {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */     
/*     */     public MultiLineChart(String chartId, Callable<Map<String, Integer>> callable) {
/* 433 */       super(chartId);
/* 434 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 439 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 440 */       Map<String, Integer> map = this.callable.call();
/* 441 */       if (map == null || map.isEmpty())
/* 443 */         return null; 
/* 445 */       boolean allSkipped = true;
/* 446 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 447 */         if (((Integer)entry.getValue()).intValue() == 0)
/*     */           continue; 
/* 451 */         allSkipped = false;
/* 452 */         valuesBuilder.appendField(entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */       } 
/* 454 */       if (allSkipped)
/* 456 */         return null; 
/* 458 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AdvancedPie extends CustomChart {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */     
/*     */     public AdvancedPie(String chartId, Callable<Map<String, Integer>> callable) {
/* 473 */       super(chartId);
/* 474 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 479 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 480 */       Map<String, Integer> map = this.callable.call();
/* 481 */       if (map == null || map.isEmpty())
/* 483 */         return null; 
/* 485 */       boolean allSkipped = true;
/* 486 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 487 */         if (((Integer)entry.getValue()).intValue() == 0)
/*     */           continue; 
/* 491 */         allSkipped = false;
/* 492 */         valuesBuilder.appendField(entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */       } 
/* 494 */       if (allSkipped)
/* 496 */         return null; 
/* 498 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SimpleBarChart extends CustomChart {
/*     */     private final Callable<Map<String, Integer>> callable;
/*     */     
/*     */     public SimpleBarChart(String chartId, Callable<Map<String, Integer>> callable) {
/* 513 */       super(chartId);
/* 514 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 519 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 520 */       Map<String, Integer> map = this.callable.call();
/* 521 */       if (map == null || map.isEmpty())
/* 523 */         return null; 
/* 525 */       for (Map.Entry<String, Integer> entry : map.entrySet()) {
/* 526 */         valuesBuilder.appendField(entry.getKey(), new int[] { ((Integer)entry.getValue()).intValue() });
/*     */       } 
/* 528 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AdvancedBarChart extends CustomChart {
/*     */     private final Callable<Map<String, int[]>> callable;
/*     */     
/*     */     public AdvancedBarChart(String chartId, Callable<Map<String, int[]>> callable) {
/* 543 */       super(chartId);
/* 544 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 549 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 550 */       Map<String, int[]> map = this.callable.call();
/* 551 */       if (map == null || map.isEmpty())
/* 553 */         return null; 
/* 555 */       boolean allSkipped = true;
/* 556 */       for (Map.Entry<String, int[]> entry : map.entrySet()) {
/* 557 */         if (((int[])entry.getValue()).length == 0)
/*     */           continue; 
/* 561 */         allSkipped = false;
/* 562 */         valuesBuilder.appendField(entry.getKey(), entry.getValue());
/*     */       } 
/* 564 */       if (allSkipped)
/* 566 */         return null; 
/* 568 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DrilldownPie extends CustomChart {
/*     */     private final Callable<Map<String, Map<String, Integer>>> callable;
/*     */     
/*     */     public DrilldownPie(String chartId, Callable<Map<String, Map<String, Integer>>> callable) {
/* 583 */       super(chartId);
/* 584 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     public Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 589 */       Metrics.JsonObjectBuilder valuesBuilder = new Metrics.JsonObjectBuilder();
/* 590 */       Map<String, Map<String, Integer>> map = this.callable.call();
/* 591 */       if (map == null || map.isEmpty())
/* 593 */         return null; 
/* 595 */       boolean reallyAllSkipped = true;
/* 596 */       for (Map.Entry<String, Map<String, Integer>> entryValues : map.entrySet()) {
/* 597 */         Metrics.JsonObjectBuilder valueBuilder = new Metrics.JsonObjectBuilder();
/* 598 */         boolean allSkipped = true;
/* 599 */         for (Map.Entry<String, Integer> valueEntry : (Iterable<Map.Entry<String, Integer>>)((Map)map.get(entryValues.getKey())).entrySet()) {
/* 600 */           valueBuilder.appendField(valueEntry.getKey(), ((Integer)valueEntry.getValue()).intValue());
/* 601 */           allSkipped = false;
/*     */         } 
/* 603 */         if (!allSkipped) {
/* 604 */           reallyAllSkipped = false;
/* 605 */           valuesBuilder.appendField(entryValues.getKey(), valueBuilder.build());
/*     */         } 
/*     */       } 
/* 608 */       if (reallyAllSkipped)
/* 610 */         return null; 
/* 612 */       return (new Metrics.JsonObjectBuilder()).appendField("values", valuesBuilder.build()).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class CustomChart {
/*     */     private final String chartId;
/*     */     
/*     */     protected CustomChart(String chartId) {
/* 621 */       if (chartId == null)
/* 622 */         throw new IllegalArgumentException("chartId must not be null"); 
/* 624 */       this.chartId = chartId;
/*     */     }
/*     */     
/*     */     public Metrics.JsonObjectBuilder.JsonObject getRequestJsonObject(BiConsumer<String, Throwable> errorLogger, boolean logErrors) {
/* 629 */       Metrics.JsonObjectBuilder builder = new Metrics.JsonObjectBuilder();
/* 630 */       builder.appendField("chartId", this.chartId);
/*     */       try {
/* 632 */         Metrics.JsonObjectBuilder.JsonObject data = getChartData();
/* 633 */         if (data == null)
/* 635 */           return null; 
/* 637 */         builder.appendField("data", data);
/* 638 */       } catch (Throwable t) {
/* 639 */         if (logErrors)
/* 640 */           errorLogger.accept("Failed to get data for custom chart with id " + this.chartId, t); 
/* 642 */         return null;
/*     */       } 
/* 644 */       return builder.build();
/*     */     }
/*     */     
/*     */     protected abstract Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception;
/*     */   }
/*     */   
/*     */   public static class SingleLineChart extends CustomChart {
/*     */     private final Callable<Integer> callable;
/*     */     
/*     */     public SingleLineChart(String chartId, Callable<Integer> callable) {
/* 661 */       super(chartId);
/* 662 */       this.callable = callable;
/*     */     }
/*     */     
/*     */     protected Metrics.JsonObjectBuilder.JsonObject getChartData() throws Exception {
/* 667 */       int value = ((Integer)this.callable.call()).intValue();
/* 668 */       if (value == 0)
/* 670 */         return null; 
/* 672 */       return (new Metrics.JsonObjectBuilder()).appendField("value", value).build();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class JsonObjectBuilder {
/* 684 */     private StringBuilder builder = new StringBuilder();
/*     */     
/*     */     private boolean hasAtLeastOneField = false;
/*     */     
/*     */     public JsonObjectBuilder() {
/* 689 */       this.builder.append("{");
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendNull(String key) {
/* 699 */       appendFieldUnescaped(key, "null");
/* 700 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, String value) {
/* 711 */       if (value == null)
/* 712 */         throw new IllegalArgumentException("JSON value must not be null"); 
/* 714 */       appendFieldUnescaped(key, "\"" + escape(value) + "\"");
/* 715 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, int value) {
/* 726 */       appendFieldUnescaped(key, String.valueOf(value));
/* 727 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, JsonObject object) {
/* 738 */       if (object == null)
/* 739 */         throw new IllegalArgumentException("JSON object must not be null"); 
/* 741 */       appendFieldUnescaped(key, object.toString());
/* 742 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, String[] values) {
/* 753 */       if (values == null)
/* 754 */         throw new IllegalArgumentException("JSON values must not be null"); 
/* 756 */       String escapedValues = 
/* 757 */         Arrays.<String>stream(values)
/* 758 */         .map(value -> "\"" + escape(value) + "\"")
/* 759 */         .collect(Collectors.joining(","));
/* 760 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 761 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, int[] values) {
/* 772 */       if (values == null)
/* 773 */         throw new IllegalArgumentException("JSON values must not be null"); 
/* 775 */       String escapedValues = 
/* 776 */         Arrays.stream(values).<CharSequence>mapToObj(String::valueOf).collect(Collectors.joining(","));
/* 777 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 778 */       return this;
/*     */     }
/*     */     
/*     */     public JsonObjectBuilder appendField(String key, JsonObject[] values) {
/* 789 */       if (values == null)
/* 790 */         throw new IllegalArgumentException("JSON values must not be null"); 
/* 792 */       String escapedValues = 
/* 793 */         Arrays.<JsonObject>stream(values).map(JsonObject::toString).collect(Collectors.joining(","));
/* 794 */       appendFieldUnescaped(key, "[" + escapedValues + "]");
/* 795 */       return this;
/*     */     }
/*     */     
/*     */     private void appendFieldUnescaped(String key, String escapedValue) {
/* 805 */       if (this.builder == null)
/* 806 */         throw new IllegalStateException("JSON has already been built"); 
/* 808 */       if (key == null)
/* 809 */         throw new IllegalArgumentException("JSON key must not be null"); 
/* 811 */       if (this.hasAtLeastOneField)
/* 812 */         this.builder.append(","); 
/* 814 */       this.builder.append("\"").append(escape(key)).append("\":").append(escapedValue);
/* 815 */       this.hasAtLeastOneField = true;
/*     */     }
/*     */     
/*     */     public JsonObject build() {
/* 824 */       if (this.builder == null)
/* 825 */         throw new IllegalStateException("JSON has already been built"); 
/* 827 */       JsonObject object = new JsonObject(this.builder.append("}").toString(), null);
/* 828 */       this.builder = null;
/* 829 */       return object;
/*     */     }
/*     */     
/*     */     private static String escape(String value) {
/* 842 */       StringBuilder builder = new StringBuilder();
/* 843 */       for (int i = 0; i < value.length(); i++) {
/* 844 */         char c = value.charAt(i);
/* 845 */         if (c == '"') {
/* 846 */           builder.append("\\\"");
/* 847 */         } else if (c == '\\') {
/* 848 */           builder.append("\\\\");
/* 849 */         } else if (c <= '\017') {
/* 850 */           builder.append("\\u000").append(Integer.toHexString(c));
/* 851 */         } else if (c <= '\037') {
/* 852 */           builder.append("\\u00").append(Integer.toHexString(c));
/*     */         } else {
/* 854 */           builder.append(c);
/*     */         } 
/*     */       } 
/* 857 */       return builder.toString();
/*     */     }
/*     */     
/*     */     public static class JsonObject {
/*     */       private final String value;
/*     */       
/*     */       private JsonObject(String value) {
/* 872 */         this.value = value;
/*     */       }
/*     */       
/*     */       public String toString() {
/* 877 */         return this.value;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\Metrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */