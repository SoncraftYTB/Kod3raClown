/*     */ package be.kod3ra.storm;
/*     */ 
/*     */ import be.kod3ra.storm.check.combat.KillAuraA;
/*     */ import be.kod3ra.storm.check.combat.ReachA;
/*     */ import be.kod3ra.storm.check.movement.AirA;
/*     */ import be.kod3ra.storm.check.movement.FlightA;
/*     */ import be.kod3ra.storm.check.movement.FlightB;
/*     */ import be.kod3ra.storm.check.movement.MotionA;
/*     */ import be.kod3ra.storm.check.movement.SpeedA;
/*     */ import be.kod3ra.storm.check.movement.SpeedB;
/*     */ import be.kod3ra.storm.check.movement.WaterwalkA;
/*     */ import be.kod3ra.storm.command.Storm;
/*     */ import be.kod3ra.storm.command.StormBan;
/*     */ import be.kod3ra.storm.command.StormHelp;
/*     */ import be.kod3ra.storm.command.StormKick;
/*     */ import be.kod3ra.storm.command.StormPlayer;
/*     */ import be.kod3ra.storm.event.LagBack;
/*     */ import be.kod3ra.storm.event.Logs;
/*     */ import be.kod3ra.storm.event.SpigotUpdater;
/*     */ import be.kod3ra.storm.event.StormMacro;
/*     */ import be.kod3ra.storm.gui.BanGui;
/*     */ import be.kod3ra.storm.gui.ChecksGUI;
/*     */ import be.kod3ra.storm.gui.InfoGui;
/*     */ import be.kod3ra.storm.gui.KickGui;
/*     */ import be.kod3ra.storm.gui.LogsViolationsGUI;
/*     */ import be.kod3ra.storm.gui.MainGUI;
/*     */ import be.kod3ra.storm.gui.PlayerGui;
/*     */ import java.io.File;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class Main extends JavaPlugin {
/*     */   private static Main instance;
/*     */   
/*     */   File configFile;
/*     */   
/*     */   FileConfiguration config;
/*     */   
/*     */   private MainGUI mainGUI;
/*     */   
/*     */   private ChecksGUI checksGUI;
/*     */   
/*     */   private KickGui kickGUI;
/*     */   
/*     */   private BanGui banGUI;
/*     */   
/*     */   private InfoGui infoGUI;
/*     */   
/*     */   private PlayerGui playerGUI;
/*     */   
/*     */   private LogsViolationsGUI logsviolationsGUI;
/*     */   
/*     */   private SpeedB speedB;
/*     */   
/*     */   public static final String ANSI_RESET = "\033[0m";
/*     */   
/*     */   public static final String ANSI_BLACK = "\033[30m";
/*     */   
/*     */   public static final String ANSI_RED = "\033[31m";
/*     */   
/*     */   public static final String ANSI_GREEN = "\033[32m";
/*     */   
/*     */   public static final String ANSI_LIGHT_YELLOW = "\033[93m";
/*     */   
/*     */   public static final String ANSI_YELLOW = "\033[33m";
/*     */   
/*     */   public static final String ANSI_YELLOW_BACKGROUND = "\033[43m";
/*     */   
/*     */   public static final String ANSI_BLUE = "\033[34m";
/*     */   
/*     */   public static final String ANSI_PURPLE = "\033[35m";
/*     */   
/*     */   public static final String ANSI_CYAN = "\033[36m";
/*     */   
/*     */   public static final String ANSI_WHITE = "\033[37m";
/*     */   
/*     */   public static final String ANSI_BOLD = "\033[1m";
/*     */   
/*     */   public static final String ANSI_UNBOLD = "\033[21m";
/*     */   
/*     */   public static final String ANSI_UNDERLINE = "\033[4m";
/*     */   
/*     */   public static final String ANSI_STOP_UNDERLINE = "\033[24m";
/*     */   
/*     */   public static final String ANSI_BLINK = "\033[5m";
/*     */   
/*     */   public static Main getInstance() {
/*  27 */     return instance;
/*     */   }
/*     */   
/*     */   public void onEnable() {
/*  63 */     instance = this;
/*  65 */     SpigotUpdater updater = new SpigotUpdater(this, 999999999);
/*     */     try {
/*  67 */       if (updater.checkForUpdates())
/*  68 */         getLogger().info("An update was found! New version: " + updater.getLatestVersion() + " download: " + updater.getResourceURL()); 
/*  69 */     } catch (Exception e) {
/*  70 */       getLogger().info("Could not check for updates! Stacktrace:");
/*  71 */       e.printStackTrace();
/*     */     } 
/*  74 */     getLogger().info("\033[34m+---------------------------------------------+\033[0m");
/*  75 */     getLogger().info("\033[34m|                \033[1mStorm Anticheat\033[0m\033[34m              |\033[0m");
/*  76 */     getLogger().info("\033[34m+---------------------------------------------+\033[0m");
/*  77 */     getLogger().info("\033[34m| \033[1mVersion:       0.1                          \033[0m\033[34m|\033[0m");
/*  78 */     getLogger().info("\033[34m| \033[1mAuteur:        Kod3ra                       \033[0m\033[34m|\033[0m");
/*  79 */     getLogger().info("\033[34m| \033[1mStatus:        Has been enabled successfully\033[0m\033[34m|\033[0m");
/*  80 */     getLogger().info("\033[34m+---------------------------------------------+\033[0m");
/*  82 */     getCommand("storm").setExecutor((CommandExecutor)new Storm());
/*  83 */     getCommand("stormhelp").setExecutor((CommandExecutor)new StormHelp());
/*  84 */     getCommand("stormban").setExecutor((CommandExecutor)new StormBan(this));
/*  85 */     getCommand("stormkick").setExecutor((CommandExecutor)new StormKick(this));
/*  86 */     getCommand("stormplayer").setExecutor((CommandExecutor)new StormPlayer(getConfig()));
/*  88 */     getServer().getPluginManager().registerEvents((Listener)new FlightA(), (Plugin)this);
/*  89 */     getServer().getPluginManager().registerEvents((Listener)new FlightB(), (Plugin)this);
/*  90 */     getServer().getPluginManager().registerEvents((Listener)new AirA(), (Plugin)this);
/*  91 */     getServer().getPluginManager().registerEvents((Listener)new SpeedA(), (Plugin)this);
/*  92 */     this.speedB = new SpeedB((Plugin)this);
/*  93 */     getServer().getPluginManager().registerEvents((Listener)new MotionA(), (Plugin)this);
/*  94 */     getServer().getPluginManager().registerEvents((Listener)new WaterwalkA(), (Plugin)this);
/*  95 */     getServer().getPluginManager().registerEvents((Listener)new ReachA(), (Plugin)this);
/*  96 */     getServer().getPluginManager().registerEvents((Listener)new KillAuraA(), (Plugin)this);
/*  99 */     getServer().getPluginManager().registerEvents((Listener)new StormMacro(), (Plugin)this);
/* 100 */     getServer().getPluginManager().registerEvents((Listener)new Logs(), (Plugin)this);
/* 101 */     LagBack.registerLagBackListener();
/* 105 */     this.mainGUI = new MainGUI((Plugin)this);
/* 106 */     this.checksGUI = new ChecksGUI((Plugin)this);
/* 107 */     this.kickGUI = new KickGui((Plugin)this);
/* 108 */     this.banGUI = new BanGui((Plugin)this);
/* 109 */     this.infoGUI = new InfoGui((Plugin)this);
/* 110 */     this.playerGUI = new PlayerGui((Plugin)this);
/* 111 */     this.logsviolationsGUI = new LogsViolationsGUI(this, getConfig());
/* 114 */     getServer().getPluginManager().registerEvents((Listener)this.mainGUI, (Plugin)this);
/* 115 */     getServer().getPluginManager().registerEvents((Listener)this.checksGUI, (Plugin)this);
/* 116 */     getServer().getPluginManager().registerEvents((Listener)this.kickGUI, (Plugin)this);
/* 117 */     getServer().getPluginManager().registerEvents((Listener)this.banGUI, (Plugin)this);
/* 118 */     getServer().getPluginManager().registerEvents((Listener)this.infoGUI, (Plugin)this);
/* 119 */     getServer().getPluginManager().registerEvents((Listener)this.playerGUI, (Plugin)this);
/* 120 */     getCommand("stormmenu").setExecutor((CommandExecutor)this.mainGUI);
/* 121 */     getCommand("stormgui2").setExecutor((CommandExecutor)this.checksGUI);
/* 122 */     getCommand("stormgui3").setExecutor((CommandExecutor)this.kickGUI);
/* 123 */     getCommand("stormgui4").setExecutor((CommandExecutor)this.banGUI);
/* 124 */     getCommand("stormgui5").setExecutor((CommandExecutor)this.infoGUI);
/* 125 */     getCommand("stormgui6").setExecutor((CommandExecutor)this.playerGUI);
/* 126 */     getCommand("stormgui7").setExecutor((CommandExecutor)this.logsviolationsGUI);
/* 129 */     int pluginId = 20469;
/* 130 */     Metrics metrics = new Metrics(this, pluginId);
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 136 */     getLogger().info("\033[34mStorm Anticheat has been disabled.\033[0m");
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */