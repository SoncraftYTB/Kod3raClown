/*    */ package be.kod3ra.storm.command;
/*    */ 
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class Storm implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 11 */     sender.sendMessage("");
/* 12 */     sender.sendMessage("§8§m------------------------------------------");
/* 13 */     sender.sendMessage("");
/* 14 */     sender.sendMessage("  §9/storm help §8- §7Help command.");
/* 15 */     sender.sendMessage("");
/* 16 */     sender.sendMessage("  §7Version: §8- §7V0.1");
/* 17 */     sender.sendMessage("  §7Author: §8- §7Kod3ra");
/* 18 */     sender.sendMessage("");
/* 19 */     sender.sendMessage("§8§m------------------------------------------");
/* 20 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\command\Storm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */