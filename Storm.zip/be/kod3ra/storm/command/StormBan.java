/*    */ package be.kod3ra.storm.command;
/*    */ 
/*    */ import be.kod3ra.storm.Main;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.GregorianCalendar;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class StormBan implements CommandExecutor {
/*    */   private final FileConfiguration config;
/*    */   
/*    */   private final Main plugin;
/*    */   
/*    */   public StormBan(Main plugin) {
/* 20 */     this.plugin = plugin;
/* 21 */     this.config = plugin.getConfig();
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 28 */     if (args.length < 2) {
/* 29 */       sender.sendMessage(this.config.getString("stormban.usage"));
/* 30 */       return true;
/*    */     } 
/* 33 */     String playerName = args[0];
/* 34 */     Player targetPlayer = sender.getServer().getPlayer(playerName);
/* 36 */     if (targetPlayer == null || !targetPlayer.isOnline()) {
/* 37 */       sender.sendMessage(this.config.getString("stormban.player_not_found"));
/* 38 */       return true;
/*    */     } 
/*    */     try {
/* 42 */       int durationInHours = Integer.parseInt(args[1]);
/* 43 */       banPlayer(targetPlayer, durationInHours);
/* 44 */       sender.sendMessage(this.config.getString("stormban.success")
/* 45 */           .replace("{player}", playerName)
/* 46 */           .replace("{hours}", String.valueOf(durationInHours)));
/* 47 */     } catch (NumberFormatException e) {
/* 48 */       sender.sendMessage(this.config.getString("stormban.invalid_duration"));
/*    */     } 
/* 51 */     return true;
/*    */   }
/*    */   
/*    */   private void banPlayer(Player player, int durationInHours) {
/* 56 */     Calendar calendar = new GregorianCalendar();
/* 57 */     calendar.add(11, durationInHours);
/* 58 */     Date expirationDate = calendar.getTime();
/* 62 */     player.setBanned(true);
/* 63 */     player.kickPlayer(this.config.getString("stormban.banned_message")
/* 64 */         .replace("{expirationDate}", expirationDate.toString()));
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\command\StormBan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */