/*    */ package be.kod3ra.storm.command;
/*    */ 
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class StormHelp implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 11 */     sender.sendMessage("§8§m------------------------------------------");
/* 12 */     sender.sendMessage("");
/* 13 */     sender.sendMessage("§1§lStorm Anti-cheat §8» §7§lHelp Page");
/* 14 */     sender.sendMessage("");
/* 15 */     sender.sendMessage(" §9/storm §8» §7Storm version and author.");
/* 16 */     sender.sendMessage(" §9/storm help §8» §7List you every command of the anti-cheats.");
/* 17 */     sender.sendMessage(" §9/storm kick <player> §8» §7Kick a player.");
/* 18 */     sender.sendMessage(" §9/storm ban <player> <duration in hours> §8» §7Ban/Tempban a player.");
/* 19 */     sender.sendMessage(" §9/storm player <player> §8» §7Get informations about a player.");
/* 20 */     sender.sendMessage(" §9/storm menu §8» §7Open the main menu of storm anti-cheat..");
/* 21 */     sender.sendMessage("");
/* 22 */     sender.sendMessage("§8§m------------------------------------------");
/* 24 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\command\StormHelp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */