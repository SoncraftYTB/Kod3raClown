/*     */ package be.kod3ra.storm.command;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.BanEntry;
/*     */ import org.bukkit.BanList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class StormPlayer implements CommandExecutor {
/*     */   private final FileConfiguration config;
/*     */   
/*     */   public StormPlayer(FileConfiguration config) {
/*  20 */     this.config = config;
/*     */   }
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/*  25 */     if (args.length < 1) {
/*  26 */       sender.sendMessage(this.config.getString("stormplayer.playerInformationTitle"));
/*  27 */       return true;
/*     */     } 
/*  30 */     String targetName = args[0];
/*  31 */     Player target = Bukkit.getPlayer(targetName);
/*  33 */     if (target == null || !target.isOnline()) {
/*  34 */       sender.sendMessage(this.config.getString("stormplayer.playerNotFound"));
/*  35 */       return true;
/*     */     } 
/*  38 */     UUID uuid = target.getUniqueId();
/*  39 */     String ipAddress = getIPAddress(target);
/*  40 */     String lastLocation = getLastLocation(target);
/*  41 */     boolean banned = isBanned(target);
/*  42 */     boolean whitelisted = target.isWhitelisted();
/*  43 */     boolean op = target.isOp();
/*  44 */     String client = getClient(target);
/*  46 */     sender.sendMessage(this.config.getString("stormplayer.playerInformationTitle")
/*  47 */         .replace("%player%", target.getName()));
/*  48 */     sender.sendMessage("");
/*  49 */     sender.sendMessage(this.config.getString("stormplayer.uuidMessage").replace("%UUID%", uuid.toString()));
/*  50 */     sender.sendMessage(this.config.getString("stormplayer.ipAddressMessage").replace("%IP_ADDRESS%", ipAddress));
/*  51 */     sender.sendMessage(this.config.getString("stormplayer.lastLocationMessage").replace("%LAST_LOCATION%", lastLocation));
/*  52 */     sender.sendMessage(this.config.getString("stormplayer.bannedMessage").replace("%BANNED%", banned ? "Yes" : "No"));
/*  53 */     sender.sendMessage(this.config.getString("stormplayer.whitelistedMessage").replace("%WHITELISTED%", whitelisted ? "Yes" : "No"));
/*  54 */     sender.sendMessage(this.config.getString("stormplayer.opMessage").replace("%OPERATOR%", op ? "Yes" : "No"));
/*  55 */     sender.sendMessage(this.config.getString("stormplayer.forgeMessage").replace("%FORGE%", hasForge(target) ? "Yes" : "No"));
/*  56 */     sender.sendMessage(this.config.getString("stormplayer.clientMessage").replace("%CLIENT%", client));
/*  58 */     return true;
/*     */   }
/*     */   
/*     */   private String getIPAddress(Player player) {
/*  62 */     InetSocketAddress address = player.getAddress();
/*  63 */     if (address != null) {
/*  64 */       InetAddress inetAddress = address.getAddress();
/*  65 */       if (inetAddress != null)
/*  66 */         return inetAddress.getHostAddress(); 
/*     */     } 
/*  69 */     return this.config.getString("stormplayer.notApplicableMessage");
/*     */   }
/*     */   
/*     */   private String getLastLocation(Player player) {
/*  73 */     return String.valueOf(player.getLocation().getBlockX()) + ", " + player.getLocation().getBlockY() + ", " + 
/*  74 */       player.getLocation().getBlockZ();
/*     */   }
/*     */   
/*     */   private boolean isBanned(Player player) {
/*  78 */     BanList banList = Bukkit.getBanList(BanList.Type.NAME);
/*  79 */     BanEntry banEntry = banList.getBanEntry(player.getName());
/*  80 */     return (banEntry != null && banEntry.getExpiration() == null);
/*     */   }
/*     */   
/*     */   public boolean hasForge(Player player) {
/*  84 */     return player.getListeningPluginChannels().contains("FML|HS");
/*     */   }
/*     */   
/*     */   private String getClient(Player player) {
/*  88 */     if (isUsingLunarClient(player))
/*  89 */       return "lunarclient:3d83df6"; 
/*  90 */     if (isUsingBadlionClient(player))
/*  91 */       return "BadlionClient"; 
/*  92 */     if (isUsingFeatherClient(player))
/*  93 */       return "FeatherClient"; 
/*  95 */     return this.config.getString("stormplayer.notApplicableMessage");
/*     */   }
/*     */   
/*     */   private boolean isUsingLunarClient(Player player) {
/* 100 */     return player.getListeningPluginChannels().contains("lunarclient:3d83df6");
/*     */   }
/*     */   
/*     */   private boolean isUsingBadlionClient(Player player) {
/* 104 */     return !(!player.getListeningPluginChannels().contains("Badlion-Client") && 
/* 105 */       !player.getListeningPluginChannels().contains("BadlionClient") && 
/* 106 */       !player.getListeningPluginChannels().contains("Badlion"));
/*     */   }
/*     */   
/*     */   private boolean isUsingFeatherClient(Player player) {
/* 110 */     return !(!player.getListeningPluginChannels().contains("Feather-Client") && 
/* 111 */       !player.getListeningPluginChannels().contains("FeatherClient") && 
/* 112 */       !player.getListeningPluginChannels().contains("Feather"));
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\command\StormPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */