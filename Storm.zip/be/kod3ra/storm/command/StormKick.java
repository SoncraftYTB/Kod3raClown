/*    */ package be.kod3ra.storm.command;
/*    */ 
/*    */ import be.kod3ra.storm.Main;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class StormKick implements CommandExecutor {
/*    */   private final FileConfiguration config;
/*    */   
/*    */   private final Main plugin;
/*    */   
/*    */   public StormKick(Main plugin) {
/* 19 */     this.plugin = plugin;
/* 20 */     this.config = plugin.getConfig();
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 26 */     if (args.length < 1) {
/* 27 */       sender.sendMessage(this.config.getString("stormkick.usage"));
/* 28 */       return true;
/*    */     } 
/* 31 */     String playerName = args[0];
/* 32 */     Player targetPlayer = sender.getServer().getPlayer(playerName);
/* 34 */     if (targetPlayer == null || !targetPlayer.isOnline()) {
/* 35 */       sender.sendMessage(this.config.getString("stormkick.player_not_found"));
/* 36 */       return true;
/*    */     } 
/* 39 */     kickPlayer(targetPlayer);
/* 40 */     sender.sendMessage(this.config.getString("stormkick.success").replace("{player}", playerName));
/* 42 */     return true;
/*    */   }
/*    */   
/*    */   private void kickPlayer(Player player) {
/* 46 */     player.kickPlayer(this.config.getString("stormkick.kicked_message"));
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\command\StormKick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */