package be.kod3ra.storm.event;

public interface MovementViolationListener {
  void onMovementViolation(MovementViolationEvent paramMovementViolationEvent);
}


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\event\MovementViolationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */