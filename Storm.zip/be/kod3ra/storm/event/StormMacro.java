/*    */ package be.kod3ra.storm.event;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ 
/*    */ public class StormMacro implements Listener {
/*    */   @EventHandler
/*    */   public void onCommandPreProcess(PlayerCommandPreprocessEvent event) {
/* 12 */     String command = event.getMessage().toLowerCase();
/* 14 */     if (command.startsWith("/storm help")) {
/* 15 */       event.setCancelled(true);
/* 16 */       event.setMessage("/stormhelp");
/* 17 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "stormhelp");
/* 18 */     } else if (command.startsWith("/storm ban")) {
/* 19 */       event.setCancelled(true);
/* 20 */       event.setMessage("/stormban" + command.substring("/storm ban".length()));
/* 21 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "stormban" + command.substring("/storm ban".length()));
/* 22 */     } else if (command.startsWith("/storm kick")) {
/* 23 */       event.setCancelled(true);
/* 24 */       event.setMessage("/stormkick" + command.substring("/storm kick".length()));
/* 25 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "stormkick" + command.substring("/storm kick".length()));
/* 26 */     } else if (command.startsWith("/storm player")) {
/* 27 */       event.setCancelled(true);
/* 28 */       event.setMessage("/stormplayer" + command.substring("/storm player".length()));
/* 29 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "stormplayer" + command.substring("/storm player".length()));
/* 30 */     } else if (command.startsWith("/storm menu")) {
/* 31 */       event.setCancelled(true);
/* 32 */       event.setMessage("/stormmenu");
/* 33 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "stormmenu");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\event\StormMacro.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */