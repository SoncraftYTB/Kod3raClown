/*    */ package be.kod3ra.storm.event;
/*    */ 
/*    */ import be.kod3ra.storm.Main;
/*    */ import be.kod3ra.storm.check.combat.AutoclickerA;
/*    */ import be.kod3ra.storm.check.combat.KillAuraA;
/*    */ import be.kod3ra.storm.check.combat.ReachA;
/*    */ import be.kod3ra.storm.check.movement.AirA;
/*    */ import be.kod3ra.storm.check.movement.FlightA;
/*    */ import be.kod3ra.storm.check.movement.FlightB;
/*    */ import be.kod3ra.storm.check.movement.MotionA;
/*    */ import be.kod3ra.storm.check.movement.SpeedA;
/*    */ import be.kod3ra.storm.check.movement.SpeedB;
/*    */ import be.kod3ra.storm.check.movement.WaterwalkA;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.scheduler.BukkitRunnable;
/*    */ 
/*    */ public class ResetVL {
/*    */   public ResetVL() {
/* 13 */     int resetInterval = Main.getInstance().getConfig().getInt("reset-vl-interval", 1200);
/* 16 */     (new BukkitRunnable() {
/*    */         public void run() {
/* 19 */           AirA.resetAllViolations();
/* 20 */           FlightA.resetAllViolations();
/* 21 */           FlightB.resetAllViolations();
/* 22 */           SpeedA.resetAllViolations();
/* 23 */           SpeedB.resetAllViolations();
/* 24 */           MotionA.resetAllViolations();
/* 25 */           WaterwalkA.resetAllViolations();
/* 26 */           AutoclickerA.resetAllViolations();
/* 27 */           KillAuraA.resetAllViolations();
/* 28 */           ReachA.resetAllViolations();
/*    */         }
/* 30 */       }).runTaskTimer((Plugin)Main.getInstance(), 0L, resetInterval);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\event\ResetVL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */