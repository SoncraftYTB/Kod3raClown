/*    */ package be.kod3ra.storm.event;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ public class Logs implements Listener {
/*    */   private static int getPing(Player player) {
/*    */     try {
/* 19 */       Object entityPlayer = player.getClass().getMethod("getHandle", new Class[0]).invoke(player, new Object[0]);
/* 20 */       return ((Integer)entityPlayer.getClass().getField("ping").get(entityPlayer)).intValue();
/* 21 */     } catch (Exception e) {
/* 22 */       e.printStackTrace();
/* 23 */       return -1;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void logViolation(Player player, String check, String details) {
/* 28 */     FileConfiguration config = Bukkit.getServer().getPluginManager().getPlugin("Storm").getConfig();
/* 31 */     if (!config.getBoolean("logs.enabled"))
/*    */       return; 
/* 36 */     File pluginFolder = new File(Bukkit.getServer().getPluginManager().getPlugin("Storm").getDataFolder(), "logs");
/* 38 */     if (!pluginFolder.exists())
/* 39 */       pluginFolder.mkdirs(); 
/* 43 */     String timestamp = (new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss")).format(new Date());
/* 46 */     File logFile = new File(pluginFolder, String.valueOf(player.getName()) + "_" + check + "_" + timestamp + ".txt");
/*    */     try {
/* 50 */       FileWriter writer = new FileWriter(logFile);
/* 51 */       writer.write("Player: " + player.getName() + "\n");
/* 52 */       writer.write("Ping: " + getPing(player) + "\n");
/* 53 */       writer.write("Coordinates: " + getLocationString(player.getLocation()) + "\n");
/* 54 */       writer.write("Check: " + check + "\n");
/* 58 */       writer.close();
/* 59 */     } catch (IOException e) {
/* 60 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   private static String getLocationString(Location location) {
/* 65 */     return "X: " + location.getX() + ", Y: " + location.getY() + ", Z: " + location.getZ();
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\event\Logs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */