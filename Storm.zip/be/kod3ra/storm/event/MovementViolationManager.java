/*    */ package be.kod3ra.storm.event;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MovementViolationManager {
/*  7 */   private static final List<MovementViolationListener> listeners = new ArrayList<>();
/*    */   
/*    */   public static void registerListener(MovementViolationListener listener) {
/* 10 */     listeners.add(listener);
/*    */   }
/*    */   
/*    */   public static List<MovementViolationListener> getListeners() {
/* 14 */     return new ArrayList<>(listeners);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\event\MovementViolationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */