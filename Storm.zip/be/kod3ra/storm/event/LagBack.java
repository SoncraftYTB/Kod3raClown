/*    */ package be.kod3ra.storm.event;
/*    */ 
/*    */ import be.kod3ra.storm.Main;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class LagBack implements MovementViolationListener, Listener {
/* 16 */   private static final Map<UUID, Location> lastKnownLocations = new HashMap<>();
/*    */   
/*    */   private static boolean lagBackEnabled;
/*    */   
/*    */   public LagBack() {
/* 21 */     lagBackEnabled = Main.getInstance().getConfig().getBoolean("lagback.enabled", true);
/* 23 */     if (lagBackEnabled) {
/* 25 */       MovementViolationManager.registerListener(this);
/* 26 */       Bukkit.getPluginManager().registerEvents(this, (Plugin)Main.getInstance());
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onMovementViolation(MovementViolationEvent event) {
/* 33 */     if (!lagBackEnabled)
/*    */       return; 
/* 37 */     Player player = event.getPlayer();
/* 40 */     Location groundLocation = getGroundLocation(player);
/* 41 */     if (groundLocation != null) {
/* 42 */       player.teleport(groundLocation);
/* 45 */       player.teleport(player.getLocation().add(0.0D, 0.1D, 0.0D));
/*    */     } 
/*    */   }
/*    */   
/*    */   private Location getGroundLocation(Player player) {
/* 50 */     Location playerLocation = player.getLocation();
/* 51 */     Location groundLocation = playerLocation.clone();
/* 54 */     while (groundLocation.getBlockY() > 0 && !groundLocation.getBlock().getType().isSolid())
/* 55 */       groundLocation.subtract(0.0D, 1.0D, 0.0D); 
/* 58 */     return (groundLocation.getBlockY() > 0) ? groundLocation.add(0.0D, 1.0D, 0.0D) : null;
/*    */   }
/*    */   
/*    */   public static void updateLastKnownLocation(Player player) {
/* 63 */     MovementViolationManager.getListeners().forEach(listener -> listener.onMovementViolation(new MovementViolationEvent(paramPlayer)));
/* 64 */     lastKnownLocations.put(player.getUniqueId(), player.getLocation());
/*    */   }
/*    */   
/*    */   public static void registerLagBackListener() {}
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\event\LagBack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */