/*    */ package be.kod3ra.storm.event;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class MovementViolationEvent extends Event {
/*  8 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private final Player player;
/*    */   
/*    */   public MovementViolationEvent(Player player) {
/* 12 */     this.player = player;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 16 */     return this.player;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 20 */     return handlers;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 25 */     return handlers;
/*    */   }
/*    */   
/*    */   public void callEvent() {
/* 29 */     for (MovementViolationListener listener : MovementViolationManager.getListeners())
/* 30 */       listener.onMovementViolation(this); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Storm V0.1.jar!\be\kod3ra\storm\event\MovementViolationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */