/*     */ package be.kod3ra.ghostac.detection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Vehicle;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.vehicle.VehicleMoveEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class VehicleDetection implements Listener {
/*     */   private Plugin plugin;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private static final double MAX_SPEED = 0.8D;
/*     */   
/*  27 */   private Map<Player, Integer> violationCount = new HashMap<>();
/*     */   
/*     */   public VehicleDetection(Plugin plugin) {
/*  30 */     this.plugin = plugin;
/*  31 */     registerEvents();
/*     */   }
/*     */   
/*     */   private void registerEvents() {
/*  35 */     Bukkit.getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */   public void loadConfig(FileConfiguration config) {
/*  40 */     this.kickCommand = config.getString("commands.vehicle_kick");
/*  41 */     this.maxViolations = config.getInt("max_vl.vehicle");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onVehicleMove(VehicleMoveEvent event) {
/*  46 */     Vehicle vehicle = event.getVehicle();
/*  48 */     if (vehicle instanceof org.bukkit.entity.Boat || vehicle instanceof org.bukkit.entity.Horse) {
/*  49 */       Player player = null;
/*  51 */       if (vehicle.getPassenger() instanceof Player)
/*  52 */         player = (Player)vehicle.getPassenger(); 
/*  55 */       if (player != null) {
/*  56 */         double speed = vehicle.getVelocity().length();
/*  57 */         if (speed > 0.8D) {
/*  58 */           int violations = ((Integer)this.violationCount.getOrDefault(player, Integer.valueOf(0))).intValue();
/*  59 */           violations++;
/*  61 */           this.violationCount.put(player, Integer.valueOf(violations));
/*  64 */           if (hasSolidBlockAbove(player)) {
/*  65 */             this.violationCount.remove(player);
/*     */             return;
/*     */           } 
/*  70 */           String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.vehicle_alert")
/*  71 */             .replace("{player}", player.getName())
/*  72 */             .replace("{violations}", String.valueOf(violations))
/*  73 */             .replace("{max_vl}", String.valueOf(this.maxViolations));
/*  75 */           for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/*  76 */             if (staff.hasPermission("ghostac.alerts"))
/*  77 */               staff.sendMessage(message); 
/*     */           } 
/*  81 */           if (violations >= this.maxViolations) {
/*  82 */             Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", player.getName()));
/*  83 */             this.violationCount.remove(player);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasSolidBlockAbove(Player player) {
/*  91 */     for (int y = 1; y <= 3; y++) {
/*  92 */       Material blockType = player.getLocation().getBlock().getRelative(0, y, 0).getType();
/*  93 */       if (blockType.isSolid())
/*  94 */         return true; 
/*     */     } 
/*  99 */     Material blockTypeLeft = player.getLocation().getBlock().getRelative(-1, 1, 0).getType();
/* 100 */     Material blockTypeRight = player.getLocation().getBlock().getRelative(1, 1, 0).getType();
/* 102 */     if (blockTypeLeft.isSolid() || blockTypeRight.isSolid())
/* 103 */       return true; 
/* 107 */     return (blockTypeLeft == Material.AIR && blockTypeRight == Material.AIR);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\VehicleDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */