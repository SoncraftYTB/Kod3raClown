/*     */ package be.kod3ra.ghostac.detection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class AimbotDetection implements Listener {
/*     */   private Plugin plugin;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*  24 */   private Map<Player, Integer> violationCount = new HashMap<>();
/*     */   
/*  25 */   private Map<Player, Vector> lastDirection = new HashMap<>();
/*     */   
/*     */   private static final double MAX_ROTATION_SPEED = 2.0D;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*  28 */   private Map<Player, Long> lastAttackTime = new HashMap<>();
/*     */   
/*     */   private static final int ATTACK_DETECTION_DURATION = 2000;
/*     */   
/*     */   public AimbotDetection(FileConfiguration config) {
/*  32 */     this.maxViolations = config.getInt("max_vl.aimbot");
/*  33 */     this.kickCommand = config.getString("commands.aimbot");
/*     */   }
/*     */   
/*     */   public AimbotDetection(Plugin plugin) {
/*  37 */     this.plugin = plugin;
/*  38 */     registerEvents();
/*     */   }
/*     */   
/*     */   private void registerEvents() {
/*  42 */     Bukkit.getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/*  47 */     Player player = event.getPlayer();
/*  49 */     boolean hasNearbyPlayer = hasNearbyPlayer(player, 4.0D);
/*  51 */     if (!hasNearbyPlayer)
/*     */       return; 
/*  55 */     if (player.isOp() || player.hasPermission("ghostac.bypass"))
/*     */       return; 
/*  59 */     Vector currentDirection = player.getLocation().getDirection().normalize();
/*  61 */     if (this.lastDirection.containsKey(player)) {
/*  62 */       Vector previousDirection = this.lastDirection.get(player);
/*  65 */       double rotationSpeed = currentDirection.angle(previousDirection);
/*  68 */       if (rotationSpeed > 2.0D && isWithinAttackDetectionTime(player)) {
/*  69 */         int violations = ((Integer)this.violationCount.getOrDefault(player, Integer.valueOf(0))).intValue();
/*  70 */         violations++;
/*  72 */         this.violationCount.put(player, Integer.valueOf(violations));
/*  75 */         String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.aimbot_alert")
/*  76 */           .replace("{player}", player.getName())
/*  77 */           .replace("{violations}", String.valueOf(violations))
/*  78 */           .replace("{max_vl}", String.valueOf(this.maxViolations));
/*  80 */         for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/*  81 */           if (staff.hasPermission("ghostac.alerts"))
/*  82 */             staff.sendMessage(message); 
/*     */         } 
/*  86 */         if (violations >= this.maxViolations) {
/*  87 */           Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", player.getName()));
/*  88 */           this.violationCount.remove(player);
/*     */         } 
/*     */       } 
/*     */     } 
/*  93 */     this.lastDirection.put(player, currentDirection);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/*  98 */     if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
/*  99 */       Player attacker = (Player)event.getDamager();
/* 100 */       this.lastAttackTime.put(attacker, Long.valueOf(System.currentTimeMillis()));
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasNearbyPlayer(Player player, double radius) {
/* 105 */     for (Entity nearbyEntity : player.getNearbyEntities(radius, radius, radius)) {
/* 106 */       if (nearbyEntity instanceof Player && nearbyEntity != player)
/* 107 */         return true; 
/*     */     } 
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isWithinAttackDetectionTime(Player player) {
/* 114 */     if (this.lastAttackTime.containsKey(player)) {
/* 115 */       long lastAttack = ((Long)this.lastAttackTime.get(player)).longValue();
/* 116 */       long currentTime = System.currentTimeMillis();
/* 117 */       long timeDifference = currentTime - lastAttack;
/* 118 */       return (timeDifference <= 2000L);
/*     */     } 
/* 120 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\AimbotDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */