/*     */ package be.kod3ra.ghostac.detection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerVelocityEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ public class SpeedDetection implements Listener {
/*     */   private Plugin plugin;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private static final double MAX_SPEED = 0.62D;
/*     */   
/*     */   private static final double MAX_SPEED_SPEED = 0.678D;
/*     */   
/*     */   private static final double MAX_SPEED_SOLID = 0.68D;
/*     */   
/*     */   private static final double MAX_SPEED_SPEED_SOLID = 0.78D;
/*     */   
/*     */   private static final int ICE_RADIUS = 2;
/*     */   
/*  32 */   private Map<Player, Integer> violationCount = new HashMap<>();
/*     */   
/*  33 */   private Map<Player, Long> ignoreKnockback = new HashMap<>();
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   public SpeedDetection(FileConfiguration config) {
/*  37 */     this.maxViolations = config.getInt("max_vl.speed");
/*  38 */     this.kickCommand = config.getString("commands.speed");
/*     */   }
/*     */   
/*     */   public SpeedDetection(Plugin plugin) {
/*  42 */     this.plugin = plugin;
/*  43 */     registerEvents();
/*     */   }
/*     */   
/*     */   private void registerEvents() {
/*  47 */     Bukkit.getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/*  52 */     Player player = event.getPlayer();
/*  54 */     if (player.isInsideVehicle())
/*  56 */       if (player.getVehicle() instanceof org.bukkit.entity.Horse || player.getVehicle() instanceof org.bukkit.entity.Boat)
/*     */         return;  
/*  61 */     if (player.isInsideVehicle())
/*     */       return; 
/*  65 */     if (player.isOp())
/*     */       return; 
/*  69 */     if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR)
/*     */       return; 
/*  73 */     if (this.ignoreKnockback.containsKey(player)) {
/*  74 */       long ignoreDuration = 2000L;
/*  75 */       long ignoreStartTime = ((Long)this.ignoreKnockback.get(player)).longValue();
/*  76 */       long currentTime = System.currentTimeMillis();
/*  77 */       if (currentTime - ignoreStartTime <= ignoreDuration)
/*     */         return; 
/*  80 */       this.ignoreKnockback.remove(player);
/*     */     } 
/*  84 */     double horizontalSpeed = getHorizontalSpeed(event.getFrom().getX(), event.getFrom().getZ(), event.getTo().getX(), event.getTo().getZ());
/*  85 */     double maxSpeed = getMaxSpeed(player);
/*  87 */     if (horizontalSpeed > maxSpeed) {
/*  88 */       int violations = ((Integer)this.violationCount.getOrDefault(player, Integer.valueOf(0))).intValue();
/*  89 */       violations++;
/*  91 */       this.violationCount.put(player, Integer.valueOf(violations));
/*  94 */       if (isNearIce(player, 2)) {
/*  95 */         this.violationCount.remove(player);
/*     */         return;
/*     */       } 
/* 100 */       String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.speed_alert")
/* 101 */         .replace("{player}", player.getName())
/* 102 */         .replace("{violations}", String.valueOf(violations))
/* 103 */         .replace("{max_vl}", String.valueOf(this.maxViolations));
/* 105 */       for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 106 */         if (staff.hasPermission("ghostac.alerts"))
/* 107 */           staff.sendMessage(message); 
/*     */       } 
/* 111 */       if (violations >= this.maxViolations) {
/* 112 */         Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", player.getName()));
/* 113 */         this.violationCount.remove(player);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerVelocity(PlayerVelocityEvent event) {
/* 120 */     Player player = event.getPlayer();
/* 121 */     this.ignoreKnockback.put(player, Long.valueOf(System.currentTimeMillis()));
/*     */   }
/*     */   
/*     */   private double getMaxSpeed(Player player) {
/* 125 */     if (hasSpeedEffect(player)) {
/* 126 */       if (hasSolidBlockAbove(player))
/* 127 */         return 0.78D; 
/* 129 */       return 0.678D;
/*     */     } 
/* 131 */     if (hasSolidBlockAbove(player))
/* 132 */       return 0.68D; 
/* 134 */     return 0.62D;
/*     */   }
/*     */   
/*     */   private boolean hasSpeedEffect(Player player) {
/* 139 */     return player.hasPotionEffect(PotionEffectType.SPEED);
/*     */   }
/*     */   
/*     */   private double getHorizontalSpeed(double startX, double startZ, double endX, double endZ) {
/* 143 */     double deltaX = endX - startX;
/* 144 */     double deltaZ = endZ - startZ;
/* 145 */     double distanceSquared = deltaX * deltaX + deltaZ * deltaZ;
/* 146 */     return Math.sqrt(distanceSquared);
/*     */   }
/*     */   
/*     */   private boolean isNearIce(Player player, int radius) {
/* 150 */     for (int x = -radius; x <= radius; x++) {
/* 151 */       for (int y = -radius; y <= radius; y++) {
/* 152 */         for (int z = -radius; z <= radius; z++) {
/* 153 */           Material blockType = player.getLocation().getBlock().getRelative(x, y, z).getType();
/* 154 */           if (blockType == Material.ICE || blockType == Material.PACKED_ICE || blockType == Material.TRAP_DOOR || blockType == Material.IRON_TRAPDOOR)
/* 155 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 160 */     return false;
/*     */   }
/*     */   
/*     */   private boolean hasSolidBlockAbove(Player player) {
/* 164 */     for (int y = 1; y <= 3; y++) {
/* 165 */       Material blockType = player.getLocation().getBlock().getRelative(0, y, 0).getType();
/* 166 */       if (blockType.isSolid())
/* 167 */         return true; 
/*     */     } 
/* 172 */     Material blockTypeLeft = player.getLocation().getBlock().getRelative(-1, 1, 0).getType();
/* 173 */     Material blockTypeRight = player.getLocation().getBlock().getRelative(1, 1, 0).getType();
/* 175 */     if (blockTypeLeft.isSolid() || blockTypeRight.isSolid())
/* 176 */       return true; 
/* 180 */     return (blockTypeLeft == Material.AIR && blockTypeRight == Material.AIR);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\SpeedDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */