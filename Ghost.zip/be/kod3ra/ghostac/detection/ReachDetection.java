/*    */ package be.kod3ra.ghostac.detection;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class ReachDetection implements Listener {
/*    */   private Plugin plugin;
/*    */   
/*    */   private String kickCommand;
/*    */   
/*    */   private static final double MAX_REACH = 3.75D;
/*    */   
/* 22 */   private Map<Player, Long> lastAttackTime = new HashMap<>();
/*    */   
/* 23 */   private Map<Player, Integer> violationCount = new HashMap<>();
/*    */   
/*    */   private int maxViolations;
/*    */   
/*    */   public ReachDetection(FileConfiguration config) {
/* 27 */     this.maxViolations = config.getInt("max_vl.reach");
/* 28 */     this.kickCommand = config.getString("commands.reach");
/*    */   }
/*    */   
/*    */   public ReachDetection(Plugin plugin) {
/* 32 */     this.plugin = plugin;
/* 33 */     registerEvents();
/*    */   }
/*    */   
/*    */   private void registerEvents() {
/* 37 */     Bukkit.getPluginManager().registerEvents(this, this.plugin);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 42 */     if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
/* 43 */       Player attacker = (Player)event.getDamager();
/* 44 */       Player victim = (Player)event.getEntity();
/* 46 */       long currentTime = System.currentTimeMillis();
/* 47 */       long lastAttack = ((Long)this.lastAttackTime.getOrDefault(attacker, Long.valueOf(0L))).longValue();
/* 48 */       if (currentTime - lastAttack < 1000L)
/*    */         return; 
/* 52 */       if (attacker.hasPermission("ghostac.bypass"))
/*    */         return; 
/* 56 */       if (attacker.getGameMode() == GameMode.CREATIVE || attacker.isOp())
/*    */         return; 
/* 61 */       if (attacker.getItemInHand().getType().name().contains("BOW"))
/*    */         return; 
/* 65 */       double reach = attacker.getLocation().distance(victim.getLocation());
/* 66 */       if (reach > 3.75D) {
/* 67 */         if (!victim.isOnGround())
/*    */           return; 
/* 71 */         int violations = ((Integer)this.violationCount.getOrDefault(attacker, Integer.valueOf(0))).intValue();
/* 72 */         violations++;
/* 74 */         this.violationCount.put(attacker, Integer.valueOf(violations));
/* 75 */         this.lastAttackTime.put(attacker, Long.valueOf(currentTime));
/* 77 */         String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.reach_alert")
/* 78 */           .replace("{player}", attacker.getName())
/* 79 */           .replace("{violations}", String.valueOf(violations))
/* 80 */           .replace("{max_vl}", String.valueOf(this.maxViolations));
/* 82 */         for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 83 */           if (staff.hasPermission("ghostac.alerts"))
/* 84 */             staff.sendMessage(message); 
/*    */         } 
/* 88 */         if (violations >= this.maxViolations) {
/* 89 */           Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", attacker.getName()));
/* 90 */           this.violationCount.remove(attacker);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\ReachDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */