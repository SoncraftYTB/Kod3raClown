/*     */ package be.kod3ra.ghostac.detection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class AntiKBDetection implements Listener {
/*     */   private Plugin plugin;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private Map<Player, Integer> violationCount;
/*     */   
/*     */   private Map<Player, Cooldown> cooldowns;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private static final double MAX_VERTICAL_KB = 0.01D;
/*     */   
/*     */   private static final double MAX_HORIZONTAL_KB = 0.1D;
/*     */   
/*     */   private static final int COOLDOWN_SECONDS = 10;
/*     */   
/*     */   private static final int DETECTION_CHANCE = 20;
/*     */   
/*     */   public AntiKBDetection(JavaPlugin plugin, int maxViolations, String kickCommand, String alertMessage) {
/*  37 */     this.plugin = (Plugin)plugin;
/*  38 */     this.maxViolations = maxViolations;
/*  39 */     this.kickCommand = kickCommand;
/*  40 */     this.violationCount = new HashMap<>();
/*  41 */     this.cooldowns = new HashMap<>();
/*  42 */     registerEvents();
/*     */   }
/*     */   
/*     */   public AntiKBDetection(JavaPlugin plugin, FileConfiguration config) {
/*  46 */     this.plugin = (Plugin)plugin;
/*  47 */     this.maxViolations = config.getInt("max_vl.antikb");
/*  48 */     this.kickCommand = config.getString("commands.antikb");
/*  49 */     this.violationCount = new HashMap<>();
/*  50 */     this.cooldowns = new HashMap<>();
/*  51 */     registerEvents();
/*     */   }
/*     */   
/*     */   private void registerEvents() {
/*  55 */     Bukkit.getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/*  60 */     if (event.getEntity() instanceof Player && event.getDamager() instanceof Player) {
/*  61 */       final Player player = (Player)event.getEntity();
/*  62 */       Player damager = (Player)event.getDamager();
/*  64 */       if (player.getGameMode() == GameMode.CREATIVE || damager.getGameMode() == GameMode.CREATIVE)
/*     */         return; 
/*  68 */       if (hasCooldown(player))
/*     */         return; 
/*  72 */       if (isLagging(player))
/*     */         return; 
/*  77 */       Random random = new Random();
/*  78 */       int randomNumber = random.nextInt(20) + 1;
/*  80 */       if (randomNumber == 1) {
/*  81 */         Vector velocity = player.getVelocity();
/*  82 */         double horizontalKB = Math.sqrt(velocity.getX() * velocity.getX() + velocity.getZ() * velocity.getZ());
/*  83 */         double verticalKB = Math.abs(velocity.getY());
/*  85 */         if (horizontalKB >= 0.1D || verticalKB >= 0.01D) {
/*  86 */           addViolation(player);
/*  87 */           event.setCancelled(true);
/*  89 */           (new BukkitRunnable() {
/*     */               public void run() {
/*  92 */                 player.setVelocity(new Vector(0, 0, 0));
/*     */               }
/*  94 */             }).runTaskLater(this.plugin, 1L);
/*  97 */           activateCooldown(player);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addViolation(Player player) {
/* 104 */     int violations = ((Integer)this.violationCount.getOrDefault(player, Integer.valueOf(0))).intValue();
/* 105 */     violations++;
/* 106 */     this.violationCount.put(player, Integer.valueOf(violations));
/* 108 */     String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.antikb_alert")
/* 109 */       .replace("{player}", player.getName())
/* 110 */       .replace("{violations}", String.valueOf(violations))
/* 111 */       .replace("{max_vl}", String.valueOf(this.maxViolations));
/* 113 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/* 114 */       if (staff.hasPermission("ghostac.alerts"))
/* 115 */         staff.sendMessage(message); 
/*     */     } 
/* 119 */     if (violations >= this.maxViolations) {
/* 120 */       Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", player.getName()));
/* 121 */       this.violationCount.remove(player);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasCooldown(Player player) {
/* 126 */     if (this.cooldowns.containsKey(player)) {
/* 127 */       Cooldown cooldown = this.cooldowns.get(player);
/* 128 */       return !cooldown.hasExpired();
/*     */     } 
/* 130 */     return false;
/*     */   }
/*     */   
/*     */   private void activateCooldown(Player player) {
/* 134 */     Cooldown cooldown = new Cooldown(10000L);
/* 135 */     this.cooldowns.put(player, cooldown);
/*     */   }
/*     */   
/*     */   private static class Cooldown {
/*     */     private final long duration;
/*     */     
/*     */     private long startTime;
/*     */     
/*     */     public Cooldown(long duration) {
/* 143 */       this.duration = duration;
/* 144 */       this.startTime = System.currentTimeMillis();
/*     */     }
/*     */     
/*     */     public boolean hasExpired() {
/* 148 */       return (System.currentTimeMillis() >= this.startTime + this.duration);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isLagging(Player player) {
/* 153 */     int onlinePlayers = Bukkit.getServer().getOnlinePlayers().size();
/* 154 */     int maxPlayers = Bukkit.getServer().getMaxPlayers();
/* 155 */     double playerRatio = onlinePlayers / maxPlayers;
/* 158 */     double lagThreshold = 0.8D;
/* 161 */     if (playerRatio > lagThreshold)
/* 162 */       return true; 
/* 165 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\AntiKBDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */