/*     */ package be.kod3ra.ghostac.detection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class SneakDetection implements Listener {
/*     */   private Plugin plugin;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private static final double maxSpeed = 5.7D;
/*     */   
/*     */   private static final double jumpThreshold = 0.5D;
/*     */   
/*     */   private String alertMessage;
/*     */   
/*     */   private Map<Player, Integer> violationCounts;
/*     */   
/*     */   private Map<Player, Vector> previousPositions;
/*     */   
/*     */   public SneakDetection(FileConfiguration config) {
/*  28 */     this.maxViolations = config.getInt("max_vl.sneak");
/*  29 */     this.kickCommand = config.getString("commands.sneak");
/*  30 */     this.alertMessage = config.getString("messages.sneak_alert");
/*  31 */     this.violationCounts = new HashMap<>();
/*  32 */     this.previousPositions = new HashMap<>();
/*     */   }
/*     */   
/*     */   public SneakDetection(Plugin plugin) {
/*  36 */     this.plugin = plugin;
/*  37 */     registerEvents();
/*     */   }
/*     */   
/*     */   private void registerEvents() {
/*  41 */     Bukkit.getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/*  46 */     Player player = event.getPlayer();
/*  48 */     if (player.isOp() || player.hasPermission("ghostac.bypass"))
/*     */       return; 
/*  52 */     if (player.getFallDistance() > 0.0F && player.isSneaking())
/*     */       return; 
/*  57 */     if (event.getFrom().getY() != event.getTo().getY()) {
/*  59 */       double deltaY = event.getTo().getY() - event.getFrom().getY();
/*  60 */       if (deltaY > 0.5D)
/*     */         return; 
/*     */     } 
/*  65 */     if (isSneaking(player) && isExceedingMaxSpeed(player)) {
/*  66 */       int violations = ((Integer)this.violationCounts.getOrDefault(player, Integer.valueOf(0))).intValue();
/*  67 */       violations++;
/*  70 */       String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.sneak_alert")
/*  71 */         .replace("{player}", player.getName())
/*  72 */         .replace("{violations}", String.valueOf(violations))
/*  73 */         .replace("{max_vl}", String.valueOf(this.maxViolations));
/*  75 */       for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/*  76 */         if (staff.hasPermission("ghostac.alerts"))
/*  77 */           staff.sendMessage(message); 
/*     */       } 
/*  81 */       if (violations >= this.maxViolations) {
/*  82 */         Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", player.getName()));
/*  83 */         this.violationCounts.remove(player);
/*     */       } else {
/*  85 */         this.violationCounts.put(player, Integer.valueOf(violations));
/*     */       } 
/*     */     } else {
/*  88 */       resetVL(player);
/*     */     } 
/*  92 */     this.previousPositions.put(player, player.getLocation().toVector());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/*  97 */     if (event.getEntity() instanceof Player && event.getDamager() instanceof Player) {
/*  98 */       Player player = (Player)event.getEntity();
/*  99 */       Player damager = (Player)event.getDamager();
/* 101 */       if (isSneaking(player))
/* 102 */         event.setCancelled(true); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isSneaking(Player player) {
/* 108 */     return player.isSneaking();
/*     */   }
/*     */   
/*     */   private boolean isExceedingMaxSpeed(Player player) {
/* 112 */     Vector previousPosition = this.previousPositions.getOrDefault(player, player.getLocation().toVector());
/* 113 */     Vector currentPosition = player.getLocation().toVector();
/* 115 */     currentPosition.setY(previousPosition.getY());
/* 117 */     double distance = currentPosition.distance(previousPosition);
/* 120 */     double speed = distance / 0.05D;
/* 122 */     return (speed > 5.7D);
/*     */   }
/*     */   
/*     */   public void resetVL(Player player) {
/* 126 */     this.violationCounts.remove(player);
/* 127 */     this.previousPositions.remove(player);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\SneakDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */