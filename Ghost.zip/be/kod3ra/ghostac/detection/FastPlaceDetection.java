/*     */ package be.kod3ra.ghostac.detection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class FastPlaceDetection implements Listener {
/*     */   private Plugin plugin;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*     */   private Map<Player, Integer> violationCount;
/*     */   
/*     */   private Map<Player, Long> lastInteractionTimes;
/*     */   
/*     */   private Map<Player, Long> lastClickTimes;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private static final double FAST_PLACE_DELAY = 0.001D;
/*     */   
/*     */   private static final long FAST_PLACE_DELAY_MS = 0L;
/*     */   
/*     */   private static final double FAST_PLACE_TOLERANCE = 0.001D;
/*     */   
/*     */   public FastPlaceDetection(Plugin plugin, int maxViolations, String kickCommand) {
/*  31 */     this.plugin = plugin;
/*  32 */     this.maxViolations = maxViolations;
/*  33 */     this.kickCommand = kickCommand;
/*  34 */     this.violationCount = new HashMap<>();
/*  35 */     this.lastInteractionTimes = new HashMap<>();
/*  36 */     this.lastClickTimes = new HashMap<>();
/*  37 */     registerEvents();
/*     */   }
/*     */   
/*     */   public FastPlaceDetection(FileConfiguration config) {
/*  41 */     this.maxViolations = config.getInt("max_vl.fastplace");
/*  42 */     this.kickCommand = config.getString("commands.fastplace");
/*  43 */     this.violationCount = new HashMap<>();
/*  44 */     this.lastInteractionTimes = new HashMap<>();
/*  45 */     this.lastClickTimes = new HashMap<>();
/*  46 */     registerEvents();
/*     */   }
/*     */   
/*     */   private void registerEvents() {
/*  50 */     if (this.plugin != null)
/*  51 */       Bukkit.getPluginManager().registerEvents(this, this.plugin); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/*  58 */     Player player = event.getPlayer();
/*  60 */     if (player.getGameMode() == GameMode.CREATIVE)
/*     */       return; 
/*  64 */     if (event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.RIGHT_CLICK_AIR) {
/*  65 */       if (event.getAction() == Action.RIGHT_CLICK_AIR && event.getClickedBlock() == null)
/*     */         return; 
/*  69 */       if (!hasSolidBlockInHand(player))
/*     */         return; 
/*  73 */       long currentTime = System.currentTimeMillis();
/*  75 */       long lastClickTime = ((Long)this.lastClickTimes.getOrDefault(player, Long.valueOf(0L))).longValue();
/*  76 */       long timeSinceLastClick = currentTime - lastClickTime;
/*  78 */       double timeDifference = timeSinceLastClick / 1000.0D;
/*  79 */       double delayDifference = Math.abs(timeDifference - 0.001D);
/*  81 */       if (delayDifference <= 0.001D) {
/*  83 */         this.lastClickTimes.put(player, Long.valueOf(currentTime));
/*     */         return;
/*     */       } 
/*  87 */       if (isFastPlaceViolation(player, currentTime)) {
/*  88 */         addViolation(player);
/*  90 */         int violations = ((Integer)this.violationCount.getOrDefault(player, Integer.valueOf(0))).intValue();
/*  91 */         String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.fastplace_alert")
/*  92 */           .replace("{player}", player.getName())
/*  93 */           .replace("{violations}", String.valueOf(violations))
/*  94 */           .replace("{max_vl}", String.valueOf(this.maxViolations));
/*  96 */         for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/*  97 */           if (staff.hasPermission("ghostac.alerts"))
/*  98 */             staff.sendMessage(message); 
/*     */         } 
/* 102 */         if (violations >= this.maxViolations) {
/* 103 */           Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", player.getName()));
/* 104 */           this.violationCount.remove(player);
/*     */         } 
/*     */       } 
/* 109 */       this.lastInteractionTimes.put(player, Long.valueOf(currentTime));
/* 110 */       this.lastClickTimes.put(player, Long.valueOf(currentTime));
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasSolidBlockInHand(Player player) {
/* 115 */     Material handMaterial = player.getInventory().getItemInHand().getType();
/* 116 */     return handMaterial.isSolid();
/*     */   }
/*     */   
/*     */   private void addViolation(Player player) {
/* 120 */     int violations = ((Integer)this.violationCount.getOrDefault(player, Integer.valueOf(0))).intValue();
/* 121 */     this.violationCount.put(player, Integer.valueOf(violations + 1));
/*     */   }
/*     */   
/*     */   private boolean isFastPlaceViolation(Player player, long currentTime) {
/* 125 */     long lastInteractionTime = ((Long)this.lastInteractionTimes.getOrDefault(player, Long.valueOf(0L))).longValue();
/* 126 */     long timeSinceLastInteraction = currentTime - lastInteractionTime;
/* 128 */     return (timeSinceLastInteraction < 0L);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\FastPlaceDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */