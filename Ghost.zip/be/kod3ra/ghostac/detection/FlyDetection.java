/*     */ package be.kod3ra.ghostac.detection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerVelocityEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class FlyDetection implements Listener {
/*     */   private Plugin plugin;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*  24 */   private Map<Player, Integer> violationCount = new HashMap<>();
/*     */   
/*     */   private static final int WATER_RADIUS = 2;
/*     */   
/*     */   private static final int LADDER_RADIUS = 2;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*  28 */   private double jumpThreshold = 0.5D;
/*     */   
/*     */   public FlyDetection(FileConfiguration config) {
/*  31 */     this.maxViolations = config.getInt("max_vl.fly");
/*  32 */     this.kickCommand = config.getString("commands.fly");
/*     */   }
/*     */   
/*     */   public FlyDetection(Plugin plugin) {
/*  36 */     this.plugin = plugin;
/*  37 */     registerEvents();
/*     */   }
/*     */   
/*     */   private void registerEvents() {
/*  41 */     Bukkit.getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/*  46 */     Player player = event.getPlayer();
/*  48 */     if (player.isOp())
/*     */       return; 
/*  52 */     if (player.hasPermission("ghostac.bypass"))
/*     */       return; 
/*  56 */     if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR)
/*     */       return; 
/*  60 */     if (player.getFallDistance() > 0.0F)
/*     */       return; 
/*  65 */     if (player.getVelocity().getY() > 1.0D)
/*     */       return; 
/*  69 */     Vector velocity = player.getVelocity();
/*  70 */     if (velocity.getY() > -1.0D)
/*     */       return; 
/*  74 */     Block block = player.getLocation().getBlock();
/*  75 */     if (block.getType() == Material.WATER || block.getType() == Material.STATIONARY_WATER || isNearWater(player))
/*     */       return; 
/*  79 */     if (isNearLadder(player))
/*     */       return; 
/*  83 */     int violations = ((Integer)this.violationCount.getOrDefault(player, Integer.valueOf(0))).intValue();
/*  84 */     violations++;
/*  86 */     this.violationCount.put(player, Integer.valueOf(violations));
/*  89 */     String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.fly_alert")
/*  90 */       .replace("{player}", player.getName())
/*  91 */       .replace("{violations}", String.valueOf(violations))
/*  92 */       .replace("{max_vl}", String.valueOf(this.maxViolations));
/*  94 */     for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/*  95 */       if (staff.hasPermission("ghostac.alerts"))
/*  96 */         staff.sendMessage(message); 
/*     */     } 
/* 100 */     if (violations >= this.maxViolations) {
/* 101 */       Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", player.getName()));
/* 102 */       this.violationCount.remove(player);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isNearWater(Player player) {
/* 107 */     for (int x = -2; x <= 2; x++) {
/* 108 */       for (int y = -2; y <= 2; y++) {
/* 109 */         for (int z = -2; z <= 2; z++) {
/* 110 */           Block block = player.getLocation().getBlock().getRelative(x, y, z);
/* 111 */           if (block.getType() == Material.WATER || block.getType() == Material.STATIONARY_WATER)
/* 112 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 117 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isNearLadder(Player player) {
/* 121 */     for (int x = -2; x <= 2; x++) {
/* 122 */       for (int y = -2; y <= 2; y++) {
/* 123 */         for (int z = -2; z <= 2; z++) {
/* 124 */           Block block = player.getLocation().getBlock().getRelative(x, y, z);
/* 125 */           if (block.getType() == Material.LADDER)
/* 126 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 131 */     return false;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerVelocity(PlayerVelocityEvent event) {
/* 136 */     Player player = event.getPlayer();
/* 137 */     this.violationCount.remove(player);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\FlyDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */