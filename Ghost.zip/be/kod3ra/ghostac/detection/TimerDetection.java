/*     */ package be.kod3ra.ghostac.detection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerChangedWorldEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class TimerDetection implements Listener {
/*     */   private Plugin plugin;
/*     */   
/*     */   private String kickCommand;
/*     */   
/*     */   private int maxViolations;
/*     */   
/*  21 */   private Map<UUID, Integer> violationCount = new HashMap<>();
/*     */   
/*  22 */   private Map<UUID, Long> lastMoveTime = new HashMap<>();
/*     */   
/*  23 */   private Map<UUID, Double> lastX = new HashMap<>();
/*     */   
/*  24 */   private Map<UUID, Double> lastY = new HashMap<>();
/*     */   
/*  25 */   private Map<UUID, Double> lastZ = new HashMap<>();
/*     */   
/*  26 */   private Map<UUID, Boolean> ignorePlayer = new HashMap<>();
/*     */   
/*     */   public TimerDetection(FileConfiguration config) {
/*  29 */     this.maxViolations = config.getInt("max_vl.timer");
/*  30 */     this.kickCommand = config.getString("commands.timer");
/*     */   }
/*     */   
/*     */   public TimerDetection(Plugin plugin) {
/*  34 */     this.plugin = plugin;
/*  35 */     registerEvents();
/*     */   }
/*     */   
/*     */   private void registerEvents() {
/*  39 */     Bukkit.getPluginManager().registerEvents(this, this.plugin);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/*  44 */     Player player = event.getPlayer();
/*  45 */     UUID uuid = player.getUniqueId();
/*  47 */     if (player.isOp() || player.hasPermission("ghostac.bypass") || ((Boolean)this.ignorePlayer.getOrDefault(uuid, Boolean.valueOf(false))).booleanValue())
/*     */       return; 
/*  51 */     long currentTime = System.currentTimeMillis();
/*  53 */     if (this.lastMoveTime.containsKey(uuid)) {
/*  54 */       long lastMove = ((Long)this.lastMoveTime.get(uuid)).longValue();
/*  55 */       long timeDifference = currentTime - lastMove;
/*  57 */       if (timeDifference >= 350L) {
/*  58 */         double lastXCoord = ((Double)this.lastX.getOrDefault(uuid, Double.valueOf(event.getFrom().getX()))).doubleValue();
/*  59 */         double lastYCoord = ((Double)this.lastY.getOrDefault(uuid, Double.valueOf(event.getFrom().getY()))).doubleValue();
/*  60 */         double lastZCoord = ((Double)this.lastZ.getOrDefault(uuid, Double.valueOf(event.getFrom().getZ()))).doubleValue();
/*  62 */         if (event.getTo().getX() != lastXCoord || event.getTo().getY() != lastYCoord || event.getTo().getZ() != lastZCoord) {
/*  63 */           int violations = ((Integer)this.violationCount.getOrDefault(uuid, Integer.valueOf(0))).intValue();
/*  64 */           violations++;
/*  66 */           this.violationCount.put(uuid, Integer.valueOf(violations));
/*  68 */           String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("messages.timer_alert")
/*  69 */             .replace("{player}", player.getName())
/*  70 */             .replace("{violations}", String.valueOf(violations))
/*  71 */             .replace("{max_vl}", String.valueOf(this.maxViolations));
/*  73 */           for (Player staff : Bukkit.getServer().getOnlinePlayers()) {
/*  74 */             if (staff.hasPermission("ghostac.alerts"))
/*  75 */               staff.sendMessage(message); 
/*     */           } 
/*  79 */           if (violations >= this.maxViolations) {
/*  80 */             Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), this.kickCommand.replace("{player}", player.getName()));
/*  81 */             this.violationCount.remove(uuid);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  87 */     this.lastMoveTime.put(uuid, Long.valueOf(currentTime));
/*  88 */     this.lastX.put(uuid, Double.valueOf(event.getTo().getX()));
/*  89 */     this.lastY.put(uuid, Double.valueOf(event.getTo().getY()));
/*  90 */     this.lastZ.put(uuid, Double.valueOf(event.getTo().getZ()));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerChangedWorld(PlayerChangedWorldEvent event) {
/*  95 */     Player player = event.getPlayer();
/*  96 */     UUID uuid = player.getUniqueId();
/*  97 */     this.ignorePlayer.put(uuid, Boolean.valueOf(true));
/*  99 */     Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.ignorePlayer.put(paramUUID, Boolean.valueOf(false)), 
/*     */         
/* 101 */         20L);
/*     */   }
/*     */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\detection\TimerDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */