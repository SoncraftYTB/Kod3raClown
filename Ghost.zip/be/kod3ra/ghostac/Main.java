/*    */ package be.kod3ra.ghostac;
/*    */ 
/*    */ import be.kod3ra.ghostac.cmd.GhostBanCommand;
/*    */ import be.kod3ra.ghostac.cmd.GhostCmd;
/*    */ import be.kod3ra.ghostac.cmd.GhostHelpCommand;
/*    */ import be.kod3ra.ghostac.cmd.GhostKickCommand;
/*    */ import be.kod3ra.ghostac.cmd.GhostMacro;
/*    */ import be.kod3ra.ghostac.cmd.GhostNotifyCommand;
/*    */ import be.kod3ra.ghostac.cmd.GhostPlayerCommand;
/*    */ import be.kod3ra.ghostac.detection.AimbotDetection;
/*    */ import be.kod3ra.ghostac.detection.AntiKBDetection;
/*    */ import be.kod3ra.ghostac.detection.FastPlaceDetection;
/*    */ import be.kod3ra.ghostac.detection.FlyDetection;
/*    */ import be.kod3ra.ghostac.detection.ReachDetection;
/*    */ import be.kod3ra.ghostac.detection.SneakDetection;
/*    */ import be.kod3ra.ghostac.detection.SpeedDetection;
/*    */ import be.kod3ra.ghostac.detection.VehicleDetection;
/*    */ import be.kod3ra.ghostac.fakeac.AAC;
/*    */ import be.kod3ra.ghostac.fakeac.GodsEye;
/*    */ import be.kod3ra.ghostac.fakeac.Matrix;
/*    */ import be.kod3ra.ghostac.fakeac.Negativity;
/*    */ import be.kod3ra.ghostac.fakeac.NoCheatPlus;
/*    */ import be.kod3ra.ghostac.fakeac.Spartan;
/*    */ import be.kod3ra.ghostac.fakeac.Vulcan;
/*    */ import be.kod3ra.ghostac.lag.TPSDetection;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class Main extends JavaPlugin implements Listener {
/*    */   private FileConfiguration config;
/*    */   
/*    */   private TPSDetection tpsDetection;
/*    */   
/*    */   public void onEnable() {
/* 28 */     getLogger().info("Ghost Anticheat is enabled!");
/* 29 */     getLogger().info("Author: Kod3ra");
/* 30 */     getLogger().info("Version: V0.9");
/* 33 */     this.config = getConfig();
/* 34 */     this.config.options().copyDefaults(true);
/* 35 */     saveConfig();
/* 38 */     FileConfiguration config = getConfig();
/* 41 */     getCommand("ghosthelp").setExecutor((CommandExecutor)new GhostHelpCommand());
/* 42 */     getCommand("ghostnotify").setExecutor((CommandExecutor)new GhostNotifyCommand());
/* 43 */     getCommand("ghostban").setExecutor((CommandExecutor)new GhostBanCommand(this));
/* 44 */     getCommand("ghostkick").setExecutor((CommandExecutor)new GhostKickCommand(this));
/* 45 */     getCommand("ghostplayer").setExecutor((CommandExecutor)new GhostPlayerCommand());
/* 46 */     getCommand("ghost").setExecutor((CommandExecutor)new GhostCmd());
/* 49 */     getCommand("aac").setExecutor((CommandExecutor)new AAC());
/* 50 */     getCommand("godseye").setExecutor((CommandExecutor)new GodsEye());
/* 51 */     getCommand("matrix").setExecutor((CommandExecutor)new Matrix());
/* 52 */     getCommand("negativity").setExecutor((CommandExecutor)new Negativity());
/* 53 */     getCommand("nocheatplus").setExecutor((CommandExecutor)new NoCheatPlus());
/* 54 */     getCommand("spartan").setExecutor((CommandExecutor)new Spartan());
/* 55 */     getCommand("vulcan").setExecutor((CommandExecutor)new Vulcan());
/* 57 */     getServer().getPluginManager().registerEvents((Listener)new TPSDetection((Plugin)this, getConfig()), (Plugin)this);
/* 60 */     getServer().getPluginManager().registerEvents(this, (Plugin)this);
/* 61 */     getServer().getPluginManager().registerEvents((Listener)new GhostMacro(), (Plugin)this);
/* 62 */     getServer().getPluginManager().registerEvents((Listener)new SpeedDetection(config), (Plugin)this);
/* 63 */     getServer().getPluginManager().registerEvents((Listener)new FlyDetection(config), (Plugin)this);
/* 64 */     getServer().getPluginManager().registerEvents((Listener)new ReachDetection(config), (Plugin)this);
/* 65 */     getServer().getPluginManager().registerEvents((Listener)new AimbotDetection(config), (Plugin)this);
/* 66 */     getServer().getPluginManager().registerEvents((Listener)new SneakDetection(config), (Plugin)this);
/* 67 */     getServer().getPluginManager().registerEvents((Listener)new FastPlaceDetection(config), (Plugin)this);
/* 68 */     AntiKBDetection antiKBDetection = new AntiKBDetection(this, config);
/* 69 */     getServer().getPluginManager().registerEvents((Listener)antiKBDetection, (Plugin)this);
/* 70 */     VehicleDetection vehicleDetection = new VehicleDetection((Plugin)this);
/* 71 */     getServer().getPluginManager().registerEvents((Listener)vehicleDetection, (Plugin)this);
/*    */   }
/*    */   
/*    */   public String getBroadcastMessage() {
/* 76 */     return this.config.getString("messages.broadcast_message", "{player} has been removed from the network!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */