/*    */ package be.kod3ra.ghostac.fakeac;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Vulcan implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 13 */     if (sender instanceof Player) {
/* 14 */       Player player = (Player)sender;
/* 15 */       String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("fakeac.vulcan");
/* 16 */       sender.sendMessage(message);
/*    */     } 
/* 18 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\fakeac\Vulcan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */