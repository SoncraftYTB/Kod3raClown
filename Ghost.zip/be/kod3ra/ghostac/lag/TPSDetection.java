/*    */ package be.kod3ra.ghostac.lag;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class TPSDetection implements Listener {
/*    */   private Plugin plugin;
/*    */   
/*    */   private int tpsThreshold;
/*    */   
/*    */   private boolean enabled;
/*    */   
/*    */   public TPSDetection(Plugin plugin, FileConfiguration config) {
/* 17 */     this.plugin = plugin;
/* 18 */     this.tpsThreshold = config.getInt("anti-lagTPS_DISABLE", 12);
/*    */   }
/*    */   
/*    */   public void startDetection() {
/* 21 */     this.enabled = true;
/* 24 */     Bukkit.getScheduler().runTaskTimer(this.plugin, this::checkTPS, 0L, 20L);
/*    */   }
/*    */   
/*    */   public void stopDetection() {
/* 28 */     this.enabled = false;
/*    */   }
/*    */   
/*    */   private void checkTPS() {
/* 32 */     double tps = getServerTPS();
/* 33 */     if (tps < this.tpsThreshold)
/* 35 */       this.plugin.getServer().getPluginManager().disablePlugin(this.plugin); 
/*    */   }
/*    */   
/*    */   private double getServerTPS() {
/*    */     try {
/* 41 */       Object minecraftServer = Bukkit.getServer().getClass().getMethod("getServer", new Class[0]).invoke(Bukkit.getServer(), new Object[0]);
/* 42 */       double tps = ((Double)minecraftServer.getClass().getMethod("getTPS", new Class[0]).invoke(minecraftServer, new Object[0])).doubleValue();
/* 43 */       return Math.min(20.0D, tps);
/* 44 */     } catch (Exception e) {
/* 45 */       e.printStackTrace();
/* 47 */       return 20.0D;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\lag\TPSDetection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */