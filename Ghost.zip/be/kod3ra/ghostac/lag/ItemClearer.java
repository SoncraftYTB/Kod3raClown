/*    */ package be.kod3ra.ghostac.lag;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.scheduler.BukkitRunnable;
/*    */ 
/*    */ public class ItemClearer {
/*    */   private final JavaPlugin plugin;
/*    */   
/*    */   private final int clearInterval;
/*    */   
/*    */   public ItemClearer(JavaPlugin plugin, int clearInterval) {
/* 19 */     this.plugin = plugin;
/* 20 */     this.clearInterval = clearInterval;
/*    */   }
/*    */   
/*    */   public void start() {
/* 24 */     final int interval = this.plugin.getConfig().getInt("anti-lag.CLEANUP_INTERVAL", this.clearInterval);
/* 27 */     int warningTime = 5;
/* 28 */     final int warningTicks = warningTime * 20;
/* 30 */     (new BukkitRunnable() {
/* 31 */         int ticks = 0;
/*    */         
/*    */         public void run() {
/* 35 */           if (this.ticks % 20 == 0 && this.ticks >= interval - warningTicks) {
/* 36 */             int remainingSeconds = (interval - this.ticks) / 20;
/* 37 */             String message = Bukkit.getServer().getPluginManager().getPlugin("GhostAnticheat").getConfig().getString("anti-lag.CLEANUP_WARNING_MESSAGE")
/* 38 */               .replace("{time}", String.valueOf(ItemClearer.this.clearInterval / 20));
/* 40 */             for (Player player : Bukkit.getServer().getOnlinePlayers()) {
/* 41 */               if (player.hasPermission("ghostac.alerts"))
/* 42 */                 player.sendMessage(message); 
/*    */             } 
/*    */           } 
/* 47 */           if (this.ticks >= interval) {
/* 48 */             ItemClearer.this.clearItems();
/* 49 */             ItemClearer.this.clearEntities();
/* 50 */             this.ticks = 0;
/*    */           } 
/* 53 */           this.ticks++;
/*    */         }
/* 55 */       }).runTaskTimer((Plugin)this.plugin, 0L, 1L);
/*    */   }
/*    */   
/*    */   private void clearItems() {
/* 59 */     for (World world : Bukkit.getWorlds()) {
/* 60 */       for (Entity entity : world.getEntities()) {
/* 61 */         if (entity instanceof org.bukkit.entity.Item)
/* 62 */           entity.remove(); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void clearEntities() {
/* 69 */     for (World world : Bukkit.getWorlds()) {
/* 70 */       for (Entity entity : world.getEntities()) {
/* 71 */         if (!(entity instanceof Player))
/* 72 */           entity.remove(); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\lag\ItemClearer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */