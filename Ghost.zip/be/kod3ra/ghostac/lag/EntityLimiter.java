/*    */ package be.kod3ra.ghostac.lag;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntitySpawnEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class EntityLimiter implements Listener {
/*    */   private final JavaPlugin plugin;
/*    */   
/*    */   private final List<World> worlds;
/*    */   
/*    */   private final int entityLimit;
/*    */   
/*    */   public EntityLimiter(JavaPlugin plugin, int entityLimit, List<World> worlds) {
/* 24 */     this.plugin = plugin;
/* 25 */     this.entityLimit = entityLimit;
/* 26 */     this.worlds = worlds;
/*    */   }
/*    */   
/*    */   public void start() {
/* 30 */     Bukkit.getPluginManager().registerEvents(this, (Plugin)this.plugin);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntitySpawn(EntitySpawnEvent event) {
/* 35 */     World world = event.getLocation().getWorld();
/* 36 */     if (this.worlds.contains(world) && 
/* 37 */       getEntityCount(world) >= this.entityLimit)
/* 38 */       event.setCancelled(true); 
/*    */   }
/*    */   
/*    */   private int getEntityCount(World world) {
/* 44 */     int count = 0;
/* 45 */     for (Entity entity : world.getEntities()) {
/* 46 */       if (!(entity instanceof org.bukkit.entity.Player))
/* 47 */         count++; 
/*    */     } 
/* 50 */     return count;
/*    */   }
/*    */   
/*    */   public static EntityLimiter loadFromConfig(JavaPlugin plugin) {
/* 54 */     FileConfiguration config = plugin.getConfig();
/* 55 */     int entityLimit = config.getInt("anti-lag.entity_limit");
/* 56 */     List<World> worlds = new ArrayList<>();
/* 57 */     ConfigurationSection worldSection = config.getConfigurationSection("anti-lag.worlds");
/* 58 */     if (worldSection != null)
/* 59 */       for (String worldName : worldSection.getKeys(false)) {
/* 60 */         World world = Bukkit.getWorld(worldName);
/* 61 */         if (world != null) {
/* 62 */           worlds.add(world);
/*    */           continue;
/*    */         } 
/* 64 */         plugin.getLogger().warning("World '" + worldName + "' specified in the configuration does not exist.");
/*    */       }  
/* 68 */     return new EntityLimiter(plugin, entityLimit, worlds);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\lag\EntityLimiter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */