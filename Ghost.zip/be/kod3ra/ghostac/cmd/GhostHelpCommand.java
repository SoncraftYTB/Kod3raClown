/*    */ package be.kod3ra.ghostac.cmd;
/*    */ 
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class GhostHelpCommand implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 11 */     sender.sendMessage("");
/* 12 */     sender.sendMessage("§8§m------------------------------------------");
/* 13 */     sender.sendMessage("");
/* 14 */     sender.sendMessage("§d§lGhost §8- §7Help Command");
/* 15 */     sender.sendMessage("");
/* 16 */     sender.sendMessage("§7/ghost help §8- §7Help command.");
/* 17 */     sender.sendMessage("§7/ghost notify <message> §8- §7Broadcast the server.");
/* 18 */     sender.sendMessage("§7/ghost ban <player> §8- §7Ban a player with an animation.");
/* 19 */     sender.sendMessage("§7/ghost kick <player> §8- §7Kick a player with an animation.");
/* 20 */     sender.sendMessage("§7/ghost player <player> §8- §7Get informations about a player.");
/* 21 */     sender.sendMessage("");
/* 22 */     sender.sendMessage("§8§m------------------------------------------");
/* 24 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\cmd\GhostHelpCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */