/*    */ package be.kod3ra.ghostac.cmd;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class GhostNotifyCommand implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 12 */     if (args.length < 1) {
/* 13 */       sender.sendMessage("§d§lGhost§b§lAC §7-> §cUsage: /ghost notify <message>");
/* 14 */       return true;
/*    */     } 
/* 17 */     StringBuilder message = new StringBuilder();
/*    */     byte b;
/*    */     int i;
/*    */     String[] arrayOfString;
/* 18 */     for (i = (arrayOfString = args).length, b = 0; b < i; ) {
/* 18 */       String arg = arrayOfString[b];
/* 19 */       message.append(arg).append(" ");
/*    */       b++;
/*    */     } 
/* 22 */     Bukkit.getServer().broadcastMessage("§d§lGhost §8-> §7" + message.toString());
/* 24 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\cmd\GhostNotifyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */