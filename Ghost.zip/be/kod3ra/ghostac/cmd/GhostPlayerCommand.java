/*    */ package be.kod3ra.ghostac.cmd;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.BanEntry;
/*    */ import org.bukkit.BanList;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class GhostPlayerCommand implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 19 */     if (args.length < 1) {
/* 20 */       sender.sendMessage("§cUsage: /ghost player <player>");
/* 21 */       return true;
/*    */     } 
/* 24 */     String targetName = args[0];
/* 25 */     Player target = Bukkit.getPlayer(targetName);
/* 27 */     if (target == null || !target.isOnline()) {
/* 28 */       sender.sendMessage("§cPlayer not found or offline.");
/* 29 */       return true;
/*    */     } 
/* 32 */     UUID uuid = target.getUniqueId();
/* 33 */     String ipAddress = getIPAddress(target);
/* 34 */     String lastLocation = getLastLocation(target);
/* 35 */     boolean banned = isBanned(target);
/* 36 */     boolean whitelisted = target.isWhitelisted();
/* 37 */     boolean op = target.isOp();
/* 39 */     sender.sendMessage("§d§lGhost §7| §b§lPlayer §7" + target.getName() + " §b§lInformation");
/* 40 */     sender.sendMessage("");
/* 41 */     sender.sendMessage("§dUUID: §7" + uuid.toString());
/* 42 */     sender.sendMessage("§dIP Address: §7" + ipAddress);
/* 43 */     sender.sendMessage("§dLast Location: §7" + lastLocation);
/* 44 */     sender.sendMessage("§dBanned: §7" + (banned ? "Yes" : "No"));
/* 45 */     sender.sendMessage("§dWhitelisted: §7" + (whitelisted ? "Yes" : "No"));
/* 46 */     sender.sendMessage("§dOperator: §7" + (op ? "Yes" : "No"));
/* 48 */     return true;
/*    */   }
/*    */   
/*    */   private String getIPAddress(Player player) {
/* 52 */     InetSocketAddress address = player.getAddress();
/* 53 */     if (address != null) {
/* 54 */       InetAddress inetAddress = address.getAddress();
/* 55 */       if (inetAddress != null)
/* 56 */         return inetAddress.getHostAddress(); 
/*    */     } 
/* 59 */     return "N/A";
/*    */   }
/*    */   
/*    */   private String getLastLocation(Player player) {
/* 63 */     return String.valueOf(player.getLocation().getBlockX()) + ", " + player.getLocation().getBlockY() + ", " + 
/* 64 */       player.getLocation().getBlockZ();
/*    */   }
/*    */   
/*    */   private boolean isBanned(Player player) {
/* 68 */     BanList banList = Bukkit.getBanList(BanList.Type.NAME);
/* 69 */     BanEntry banEntry = banList.getBanEntry(player.getName());
/* 70 */     return (banEntry != null && banEntry.getExpiration() == null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\cmd\GhostPlayerCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */