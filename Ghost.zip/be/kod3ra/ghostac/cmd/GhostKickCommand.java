/*    */ package be.kod3ra.ghostac.cmd;
/*    */ 
/*    */ import be.kod3ra.ghostac.Main;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ public class GhostKickCommand implements CommandExecutor {
/*    */   private final Main plugin;
/*    */   
/*    */   public GhostKickCommand(Main plugin) {
/* 21 */     this.plugin = plugin;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 26 */     if (args.length < 1) {
/* 27 */       sender.sendMessage("§cUsage: /ghost kick aggresive <player>");
/* 28 */       return true;
/*    */     } 
/* 31 */     String targetName = args[0];
/* 32 */     Player target = Bukkit.getPlayer(targetName);
/* 34 */     if (target == null || !target.isOnline()) {
/* 35 */       sender.sendMessage("§cPlayer not found or offline.");
/* 36 */       return true;
/*    */     } 
/* 39 */     sendPreBanMessage(target);
/* 41 */     target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0));
/* 42 */     target.addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, 100, 0));
/* 44 */     sendPreBanMessage(target);
/* 46 */     Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
/*    */           paramPlayer.kickPlayer("§d§lGhost §8-> §7You have been kicked!");
/*    */           String message = this.plugin.getBroadcastMessage().replace("{player}", paramPlayer.getName());
/*    */           Bukkit.broadcastMessage("§d§lGhost §8-> §7" + message);
/* 52 */         }60L);
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   private void sendPreBanMessage(Player player) {
/* 58 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMA");
/* 59 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB");
/* 60 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMC");
/* 61 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMD");
/* 62 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMF");
/* 63 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMG");
/* 64 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMH");
/* 65 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMI");
/* 66 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMJ");
/* 67 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK");
/* 68 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMML");
/* 69 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
/* 70 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMN");
/* 71 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMO");
/* 72 */     player.sendMessage("§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMKMMM");
/* 73 */     player.sendTitle("", "§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMA");
/* 74 */     player.sendTitle("", "§4§l§kMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMA");
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\cmd\GhostKickCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */