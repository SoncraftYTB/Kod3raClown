/*    */ package be.kod3ra.ghostac.cmd;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ 
/*    */ public class GhostMacro implements Listener {
/*    */   @EventHandler
/*    */   public void onCommandPreProcess(PlayerCommandPreprocessEvent event) {
/* 12 */     String command = event.getMessage().toLowerCase();
/* 14 */     if (command.startsWith("/ghost help")) {
/* 15 */       event.setCancelled(true);
/* 16 */       event.setMessage("/ghosthelp");
/* 17 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "ghosthelp");
/* 18 */     } else if (command.startsWith("/ghost notify")) {
/* 19 */       event.setCancelled(true);
/* 20 */       String message = command.substring("/ghost notify".length()).trim();
/* 21 */       String capitalizedMessage = String.valueOf(message.substring(0, 1).toUpperCase()) + message.substring(1);
/* 22 */       event.setMessage("/ghostnotify " + capitalizedMessage);
/* 23 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "ghostnotify " + capitalizedMessage);
/* 24 */     } else if (command.startsWith("/ghost ban")) {
/* 25 */       event.setCancelled(true);
/* 26 */       event.setMessage("/ghostban" + command.substring("/ghost ban".length()));
/* 27 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "ghostban" + command.substring("/ghost kick".length()));
/* 28 */     } else if (command.startsWith("/ghost kick")) {
/* 29 */       event.setCancelled(true);
/* 30 */       event.setMessage("/ghostkick" + command.substring("/ghost ban".length()));
/* 31 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "ghostkick" + command.substring("/ghost ban".length()));
/* 32 */     } else if (command.startsWith("/ghost player")) {
/* 33 */       event.setCancelled(true);
/* 34 */       event.setMessage("/ghostplayer" + command.substring("/ghost player".length()));
/* 35 */       Bukkit.dispatchCommand((CommandSender)event.getPlayer(), "ghostplayer" + command.substring("/ghost player".length()));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Soncraft\Downloads\Ghost V0.9.jar!\be\kod3ra\ghostac\cmd\GhostMacro.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */